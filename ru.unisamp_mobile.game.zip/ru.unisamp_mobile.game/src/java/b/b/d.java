package b.b;

public interface d
{
    void a();
}
