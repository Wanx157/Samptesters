package b.b;

public class k
{
    private a a;
    private boolean b;
    private boolean c;
    private boolean d;
    
    public a a() {
        return this.a;
    }
    
    public boolean b() {
        return this.d;
    }
    
    public boolean c() {
        return this.c;
    }
    
    public boolean d() {
        return this.b;
    }
    
    public void e(final boolean d) {
        this.d = d;
    }
    
    public void f(final a a) {
        this.a = a;
    }
    
    public void g(final boolean c) {
        this.c = c;
    }
    
    public void h(final boolean b) {
        this.b = b;
    }
}
