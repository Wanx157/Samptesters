package b.b.q;

import b.b.k;
import b.b.j;
import b.b.l;
import java.io.File;
import java.io.IOException;
import b.b.p.b;
import java.io.InputStream;
import b.b.r.a;

public class d
{
    private final a a;
    private b.b.o.a b;
    private long c;
    private long d;
    private InputStream e;
    private b.b.q.e.a f;
    private b g;
    private long h;
    private int i;
    private String j;
    private boolean k;
    private String l;
    
    private d(final a a) {
        this.a = a;
    }
    
    private boolean a(final b.b.n.d d) {
        if (this.i != 416 && !this.h(d)) {
            return false;
        }
        if (d != null) {
            this.j();
        }
        this.f();
        this.a.A(0L);
        this.a.I(0L);
        (this.g = b.b.q.a.d().c()).q(this.a);
        final b c = b.b.s.a.c(this.g, this.a);
        this.g = c;
        this.i = c.u();
        return true;
    }
    
    private void b(final b.b.q.e.a a) {
        final b g = this.g;
        if (g != null) {
            try {
                g.close();
            }
            catch (final Exception ex) {
                ex.printStackTrace();
            }
        }
        final InputStream e = this.e;
        if (e != null) {
            try {
                e.close();
            }
            catch (final IOException ex2) {
                ex2.printStackTrace();
            }
        }
        if (a != null) {
            while (true) {
                try {
                    try {
                        this.n(a);
                    }
                    finally {
                        if (a != null) {
                            final b.b.q.e.a a2 = a;
                            a2.close();
                        }
                    }
                }
                catch (final Exception ex3) {}
                try {
                    final b.b.q.e.a a2 = a;
                    a2.close();
                    continue;
                }
                catch (final IOException ex4) {}
                break;
            }
        }
        if (a != null) {
            try {
                a.close();
            }
            catch (final IOException ex5) {
                ex5.printStackTrace();
            }
        }
    }
    
    private String c(final InputStream p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: invokespecial   java/lang/StringBuilder.<init>:()V
        //     7: astore          5
        //     9: aload_1        
        //    10: ifnull          94
        //    13: aconst_null    
        //    14: astore          4
        //    16: aconst_null    
        //    17: astore_3       
        //    18: new             Ljava/io/BufferedReader;
        //    21: astore_2       
        //    22: new             Ljava/io/InputStreamReader;
        //    25: astore          6
        //    27: aload           6
        //    29: aload_1        
        //    30: invokespecial   java/io/InputStreamReader.<init>:(Ljava/io/InputStream;)V
        //    33: aload_2        
        //    34: aload           6
        //    36: invokespecial   java/io/BufferedReader.<init>:(Ljava/io/Reader;)V
        //    39: aload_2        
        //    40: invokevirtual   java/io/BufferedReader.readLine:()Ljava/lang/String;
        //    43: astore_1       
        //    44: aload_1        
        //    45: ifnull          58
        //    48: aload           5
        //    50: aload_1        
        //    51: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    54: pop            
        //    55: goto            39
        //    58: aload_2        
        //    59: invokevirtual   java/io/BufferedReader.close:()V
        //    62: goto            94
        //    65: astore_1       
        //    66: goto            76
        //    69: astore_1       
        //    70: goto            86
        //    73: astore_1       
        //    74: aload_3        
        //    75: astore_2       
        //    76: aload_2        
        //    77: ifnull          84
        //    80: aload_2        
        //    81: invokevirtual   java/io/BufferedReader.close:()V
        //    84: aload_1        
        //    85: athrow         
        //    86: aload_2        
        //    87: ifnull          94
        //    90: aload_2        
        //    91: invokevirtual   java/io/BufferedReader.close:()V
        //    94: aload           5
        //    96: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    99: areturn        
        //   100: astore_1       
        //   101: aload           4
        //   103: astore_2       
        //   104: goto            86
        //   107: astore_1       
        //   108: goto            94
        //   111: astore_2       
        //   112: goto            84
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  18     39     100    107    Ljava/io/IOException;
        //  18     39     73     76     Any
        //  39     44     69     73     Ljava/io/IOException;
        //  39     44     65     69     Any
        //  48     55     69     73     Ljava/io/IOException;
        //  48     55     65     69     Any
        //  58     62     107    111    Ljava/lang/NullPointerException;
        //  58     62     107    111    Ljava/io/IOException;
        //  80     84     111    115    Ljava/lang/NullPointerException;
        //  80     84     111    115    Ljava/io/IOException;
        //  90     94     107    111    Ljava/lang/NullPointerException;
        //  90     94     107    111    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 61 out of bounds for length 61
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        //     at java.util.Objects.checkIndex(Objects.java:359)
        //     at java.util.ArrayList.get(ArrayList.java:434)
        //     at w5.a.o(SourceFile:31)
        //     at w5.a.j(SourceFile:218)
        //     at a6.j.j(SourceFile:23)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static d d(final a a) {
        return new d(a);
    }
    
    private void e() {
        final b.b.n.d d = new b.b.n.d();
        d.m(this.a.n());
        d.p(this.a.y());
        d.k(this.j);
        d.i(this.a.m());
        d.l(this.a.p());
        d.j(this.a.o());
        d.o(this.h);
        d.n(System.currentTimeMillis());
        b.b.q.a.d().b().d(d);
    }
    
    private void f() {
        final File file = new File(this.l);
        if (file.exists()) {
            file.delete();
        }
    }
    
    private b.b.n.d g() {
        return b.b.q.a.d().b().b(this.a.n());
    }
    
    private boolean h(final b.b.n.d d) {
        return this.j != null && d != null && d.c() != null && !d.c().equals((Object)this.j);
    }
    
    private boolean i() {
        final int i = this.i;
        return i >= 200 && i < 300;
    }
    
    private void j() {
        b.b.q.a.d().b().remove(this.a.n());
    }
    
    private void l() {
        if (this.a.w() != b.b.l.f) {
            final b.b.o.a b = this.b;
            if (b != null) {
                b.obtainMessage(1, (Object)new j(this.a.o(), this.h)).sendToTarget();
            }
        }
    }
    
    private void m() {
        this.k = (this.i == 206);
    }
    
    private void n(final b.b.q.e.a a) {
        boolean b;
        try {
            a.b();
            b = true;
        }
        catch (final IOException ex) {
            ex.printStackTrace();
            b = false;
        }
        if (b && this.k) {
            a.d().b().a(this.a.n(), this.a.o(), System.currentTimeMillis());
        }
    }
    
    private void o(final b.b.q.e.a a) {
        final long o = this.a.o();
        final long currentTimeMillis = System.currentTimeMillis();
        final long d = this.d;
        final long c = this.c;
        if (o - d > 65536L && currentTimeMillis - c > 2000L) {
            this.n(a);
            this.d = o;
            this.c = currentTimeMillis;
        }
    }
    
    k k() {
        final k k = new k();
        if (this.a.w() == b.b.l.f) {
            k.e(true);
            return k;
        }
        if (this.a.w() == b.b.l.d) {
            k.g(true);
            return k;
        }
        try {
            Label_0858: {
                try {
                    if (this.a.r() != null) {
                        this.b = new b.b.o.a(this.a.r());
                    }
                    this.l = b.b.s.a.d(this.a.m(), this.a.p());
                    final File file = new File(this.l);
                    final b.b.n.d g = this.g();
                    final b.b.n.d d = null;
                    b.b.n.d d2;
                    if ((d2 = g) != null) {
                        if (file.exists()) {
                            this.a.I(g.g());
                            this.a.A(g.b());
                            d2 = g;
                        }
                        else {
                            this.j();
                            this.a.A(0L);
                            this.a.I(0L);
                            d2 = null;
                        }
                    }
                    (this.g = b.b.q.a.d().c()).q(this.a);
                    Label_0245: {
                        Label_0239: {
                            if (this.a.w() != b.b.l.f) {
                                if (this.a.w() != b.b.l.d) {
                                    final b c = b.b.s.a.c(this.g, this.a);
                                    this.g = c;
                                    this.i = c.u();
                                    this.j = this.g.D("ETag");
                                    if (this.a(d2)) {
                                        d2 = d;
                                    }
                                    if (!this.i()) {
                                        final b.b.a a = new b.b.a();
                                        a.g(true);
                                        a.h(this.c(this.g.j()));
                                        a.e(this.g.R());
                                        a.f(this.i);
                                        k.f(a);
                                        break Label_0245;
                                    }
                                    this.m();
                                    this.h = this.a.x();
                                    if (!this.k) {
                                        this.f();
                                    }
                                    if (this.h == 0L) {
                                        final long contentLength = this.g.getContentLength();
                                        this.h = contentLength;
                                        this.a.I(contentLength);
                                    }
                                    if (this.k && d2 == null) {
                                        this.e();
                                    }
                                    if (this.a.w() == b.b.l.f) {
                                        break Label_0239;
                                    }
                                    if (this.a.w() != b.b.l.d) {
                                        this.a.g();
                                        this.e = this.g.n();
                                        final byte[] array = new byte[4096];
                                        if (!file.exists() && (file.getParentFile() == null || file.getParentFile().exists() || file.getParentFile().mkdirs())) {
                                            file.createNewFile();
                                        }
                                        this.f = b.b.q.e.b.d(file);
                                        if (this.k && this.a.o() != 0L) {
                                            this.f.c(this.a.o());
                                        }
                                        if (this.a.w() == b.b.l.f) {
                                            break Label_0239;
                                        }
                                        if (this.a.w() != b.b.l.d) {
                                            do {
                                                final int read = this.e.read(array, 0, 4096);
                                                if (read == -1) {
                                                    b.b.s.a.g(this.l, b.b.s.a.b(this.a.m(), this.a.p()));
                                                    k.h(true);
                                                    if (this.k) {
                                                        this.j();
                                                    }
                                                    break Label_0858;
                                                }
                                                else {
                                                    this.f.a(array, 0, read);
                                                    this.a.A(this.a.o() + read);
                                                    this.l();
                                                    this.o(this.f);
                                                    if (this.a.w() == b.b.l.f) {
                                                        break Label_0239;
                                                    }
                                                    continue;
                                                }
                                            } while (this.a.w() != b.b.l.d);
                                            this.n(this.f);
                                        }
                                    }
                                }
                                k.g(true);
                                break Label_0245;
                            }
                        }
                        k.e(true);
                    }
                    this.b(this.f);
                    return k;
                }
                finally {
                    this.b(this.f);
                    while (true) {}
                    this.b(this.f);
                    return k;
                    final b.b.a a2 = new b.b.a();
                    a2.c(true);
                    final Throwable t;
                    a2.d(t);
                    k.f(a2);
                }
            }
        }
        catch (final IllegalAccessException ex) {}
        catch (final IOException ex2) {}
    }
}
