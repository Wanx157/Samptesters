package b.b.q.e;

import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.RandomAccessFile;
import java.io.FileDescriptor;
import java.io.BufferedOutputStream;

public class b implements a
{
    private final BufferedOutputStream a;
    private final FileDescriptor b;
    private final RandomAccessFile c;
    
    private b(final File file) {
        final RandomAccessFile c = new RandomAccessFile(file, "rw");
        this.c = c;
        this.b = c.getFD();
        this.a = new BufferedOutputStream((OutputStream)new FileOutputStream(this.c.getFD()));
    }
    
    public static a d(final File file) {
        return (a)new b(file);
    }
    
    public void a(final byte[] array, final int n, final int n2) {
        this.a.write(array, n, n2);
    }
    
    public void b() {
        this.a.flush();
        this.b.sync();
    }
    
    public void c(final long n) {
        this.c.seek(n);
    }
    
    public void close() {
        this.a.close();
        this.c.close();
    }
}
