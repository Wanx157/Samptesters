package b.b.q.e;

public interface a
{
    void a(final byte[] p0, final int p1, final int p2);
    
    void b();
    
    void c(final long p0);
    
    void close();
}
