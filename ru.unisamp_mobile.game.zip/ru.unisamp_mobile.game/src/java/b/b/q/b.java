package b.b.q;

import java.util.concurrent.Future;
import b.b.l;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import b.b.r.a;
import java.util.Map;

public class b
{
    private static b c;
    private final Map<Integer, a> a;
    private final AtomicInteger b;
    
    private b() {
        this.a = (Map<Integer, a>)new ConcurrentHashMap();
        this.b = new AtomicInteger();
    }
    
    public static b c() {
        if (b.c == null) {
            synchronized (b.class) {
                if (b.c == null) {
                    b.c = new b();
                }
            }
        }
        return b.c;
    }
    
    private int d() {
        return this.b.incrementAndGet();
    }
    
    public static void e() {
        c();
    }
    
    public void a(final a a) {
        this.a.put((Object)a.n(), (Object)a);
        a.H(l.b);
        a.G(this.d());
        a.B(b.b.m.a.b().a().b().submit((Runnable)new c(a)));
    }
    
    public void b(final a a) {
        this.a.remove((Object)a.n());
    }
}
