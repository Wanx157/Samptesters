package b.b.q;

import b.b.g;
import b.b.h;
import android.content.Context;
import b.b.n.e;
import b.b.n.c;
import b.b.p.b;

public class a
{
    private static final a f;
    private int a;
    private int b;
    private String c;
    private b d;
    private c e;
    
    static {
        f = new a();
    }
    
    public static a d() {
        return a.f;
    }
    
    public int a() {
        if (this.b == 0) {
            synchronized (a.class) {
                if (this.b == 0) {
                    this.b = 20000;
                }
            }
        }
        return this.b;
    }
    
    public c b() {
        if (this.e == null) {
            synchronized (a.class) {
                if (this.e == null) {
                    this.e = (c)new e();
                }
            }
        }
        return this.e;
    }
    
    public b c() {
        if (this.d == null) {
            synchronized (a.class) {
                if (this.d == null) {
                    this.d = (b)new b.b.p.a();
                }
            }
        }
        return this.d.m();
    }
    
    public int e() {
        if (this.a == 0) {
            synchronized (a.class) {
                if (this.a == 0) {
                    this.a = 20000;
                }
            }
        }
        return this.a;
    }
    
    public String f() {
        if (this.c == null) {
            synchronized (a.class) {
                if (this.c == null) {
                    this.c = "PRDownloader";
                }
            }
        }
        return this.c;
    }
    
    public void g(final Context context, final h h) {
        this.a = h.c();
        this.b = h.a();
        this.c = h.d();
        this.d = h.b();
        Object e;
        if (h.e()) {
            e = new b.b.n.a(context);
        }
        else {
            e = new e();
        }
        this.e = (c)e;
        if (h.e()) {
            g.a(30);
        }
    }
}
