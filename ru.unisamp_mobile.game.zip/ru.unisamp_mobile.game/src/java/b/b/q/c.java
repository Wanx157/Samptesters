package b.b.q;

import b.b.k;
import b.b.l;
import b.b.r.a;
import b.b.i;

public class c implements Runnable
{
    public final i b;
    public final int c;
    public final a d;
    
    c(final a d) {
        this.d = d;
        this.b = d.s();
        this.c = d.v();
    }
    
    public void run() {
        this.d.H(l.c);
        final k k = b.b.q.d.d(this.d).k();
        if (k.d()) {
            this.d.h();
        }
        else if (k.c()) {
            this.d.f();
        }
        else if (k.a() != null) {
            this.d.e(k.a());
        }
        else if (!k.b()) {
            this.d.e(new b.b.a());
        }
    }
}
