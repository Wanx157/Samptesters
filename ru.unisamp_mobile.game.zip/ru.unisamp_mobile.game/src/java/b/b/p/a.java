package b.b.p;

import java.util.Locale;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;
import java.util.List;
import java.util.Map$Entry;
import java.net.URLConnection;

public class a implements b
{
    private URLConnection b;
    
    private void a(final b.b.r.a a) {
        final HashMap q = a.q();
        if (q != null) {
            for (final Map$Entry map$Entry : q.entrySet()) {
                final String s = (String)map$Entry.getKey();
                final List list = (List)map$Entry.getValue();
                if (list != null) {
                    final Iterator iterator2 = list.iterator();
                    while (iterator2.hasNext()) {
                        this.b.addRequestProperty(s, (String)iterator2.next());
                    }
                }
            }
        }
    }
    
    public String D(final String s) {
        return this.b.getHeaderField(s);
    }
    
    public Map<String, List<String>> R() {
        return (Map<String, List<String>>)this.b.getHeaderFields();
    }
    
    public void close() {
    }
    
    public long getContentLength() {
        final String headerField = this.b.getHeaderField("Content-Length");
        try {
            return Long.parseLong(headerField);
        }
        catch (final NumberFormatException ex) {
            return -1L;
        }
    }
    
    public InputStream j() {
        final URLConnection b = this.b;
        if (b instanceof HttpURLConnection) {
            return ((HttpURLConnection)b).getErrorStream();
        }
        return null;
    }
    
    public b m() {
        return (b)new a();
    }
    
    public InputStream n() {
        return this.b.getInputStream();
    }
    
    public void q(final b.b.r.a a) {
        (this.b = new URL(a.y()).openConnection()).setReadTimeout(a.t());
        this.b.setConnectTimeout(a.k());
        this.b.addRequestProperty("Range", String.format(Locale.ENGLISH, "bytes=%d-", new Object[] { a.o() }));
        this.b.addRequestProperty("User-Agent", a.z());
        this.a(a);
        this.b.connect();
    }
    
    public int u() {
        final URLConnection b = this.b;
        int responseCode;
        if (b instanceof HttpURLConnection) {
            responseCode = ((HttpURLConnection)b).getResponseCode();
        }
        else {
            responseCode = 0;
        }
        return responseCode;
    }
}
