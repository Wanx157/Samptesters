package b.b.p;

import b.b.r.a;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public interface b extends Cloneable
{
    String D(final String p0);
    
    Map<String, List<String>> R();
    
    void close();
    
    long getContentLength();
    
    InputStream j();
    
    b m();
    
    InputStream n();
    
    void q(final a p0);
    
    int u();
}
