package b.b;

import android.content.Context;
import b.b.r.b;
import b.b.s.a;

public class g
{
    public static void a(final int n) {
        a.a(n);
    }
    
    public static b b(final String s, final String s2, final String s3) {
        return new b(s, s2, s3);
    }
    
    public static void c(final Context context, final h h) {
        b.b.q.a.d().g(context, h);
        b.b.q.b.e();
    }
}
