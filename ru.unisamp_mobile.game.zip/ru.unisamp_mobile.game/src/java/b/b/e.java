package b.b;

public interface e
{
    void a(final j p0);
}
