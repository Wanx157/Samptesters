package b.b;

public interface f
{
    void a();
}
