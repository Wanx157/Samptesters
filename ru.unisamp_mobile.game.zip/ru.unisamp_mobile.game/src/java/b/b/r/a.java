package b.b.r;

import java.util.concurrent.Future;
import b.b.l;
import java.util.List;
import java.util.HashMap;
import b.b.d;
import b.b.f;
import b.b.c;
import b.b.e;
import b.b.i;

public class a
{
    private i a;
    private Object b;
    private String c;
    private String d;
    private String e;
    private int f;
    private long g;
    private long h;
    private int i;
    private int j;
    private String k;
    private e l;
    private c m;
    private f n;
    private d o;
    private int p;
    private HashMap<String, List<String>> q;
    private l r;
    
    a(final b b) {
        this.c = b.a;
        this.d = b.b;
        this.e = b.c;
        this.q = b.i;
        this.a = b.d;
        this.b = b.e;
        int i = b.f;
        if (i == 0) {
            i = this.u();
        }
        this.i = i;
        int j = b.g;
        if (j == 0) {
            j = this.l();
        }
        this.j = j;
        this.k = b.h;
    }
    
    private void i() {
        this.l = null;
        this.m = null;
        this.n = null;
        this.o = null;
    }
    
    private void j() {
        this.i();
        b.b.q.b.c().b(this);
    }
    
    private int l() {
        return b.b.q.a.d().a();
    }
    
    private int u() {
        return b.b.q.a.d().e();
    }
    
    public void A(final long g) {
        this.g = g;
    }
    
    public void B(final Future future) {
    }
    
    public a C(final b.b.b b) {
        return this;
    }
    
    public a D(final d o) {
        this.o = o;
        return this;
    }
    
    public a E(final e l) {
        this.l = l;
        return this;
    }
    
    public a F(final f n) {
        this.n = n;
        return this;
    }
    
    public void G(final int f) {
        this.f = f;
    }
    
    public void H(final l r) {
        this.r = r;
    }
    
    public void I(final long h) {
        this.h = h;
    }
    
    public void J(final String c) {
        this.c = c;
    }
    
    public int K(final c m) {
        this.m = m;
        this.p = b.b.s.a.e(this.c, this.d, this.e);
        b.b.q.b.c().a(this);
        return this.p;
    }
    
    public void e(final b.b.a a) {
        if (this.r != b.b.l.f) {
            this.H(b.b.l.g);
            b.b.m.a.b().a().a().execute((Runnable)new Runnable(this, a) {
                final b.b.a b;
                final a c;
                
                public void run() {
                    if (this.c.m != null) {
                        this.c.m.a(this.b);
                    }
                    this.c.j();
                }
            });
        }
    }
    
    public void f() {
        if (this.r != b.b.l.f) {
            b.b.m.a.b().a().a().execute((Runnable)new Runnable(this) {
                final a b;
                
                public void run() {
                    if (this.b.o != null) {
                        this.b.o.a();
                    }
                }
            });
        }
    }
    
    public void g() {
        if (this.r != b.b.l.f) {
            b.b.m.a.b().a().a().execute((Runnable)new Runnable(this) {
                final a b;
                
                public void run() {
                    if (this.b.n != null) {
                        this.b.n.a();
                    }
                }
            });
        }
    }
    
    public void h() {
        if (this.r != b.b.l.f) {
            this.H(b.b.l.e);
            b.b.m.a.b().a().a().execute((Runnable)new Runnable(this) {
                final a b;
                
                public void run() {
                    if (this.b.m != null) {
                        this.b.m.b();
                    }
                    this.b.j();
                }
            });
        }
    }
    
    public int k() {
        return this.j;
    }
    
    public String m() {
        return this.d;
    }
    
    public int n() {
        return this.p;
    }
    
    public long o() {
        return this.g;
    }
    
    public String p() {
        return this.e;
    }
    
    public HashMap<String, List<String>> q() {
        return this.q;
    }
    
    public e r() {
        return this.l;
    }
    
    public i s() {
        return this.a;
    }
    
    public int t() {
        return this.i;
    }
    
    public int v() {
        return this.f;
    }
    
    public l w() {
        return this.r;
    }
    
    public long x() {
        return this.h;
    }
    
    public String y() {
        return this.c;
    }
    
    public String z() {
        if (this.k == null) {
            this.k = b.b.q.a.d().f();
        }
        return this.k;
    }
}
