package b.b.r;

import java.util.List;
import java.util.HashMap;
import b.b.i;

public class b
{
    String a;
    String b;
    String c;
    i d;
    Object e;
    int f;
    int g;
    String h;
    HashMap<String, List<String>> i;
    
    public b(final String a, final String b, final String c) {
        this.d = b.b.i.c;
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public a a() {
        return new a(this);
    }
}
