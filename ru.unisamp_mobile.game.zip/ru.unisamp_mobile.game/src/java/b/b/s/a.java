package b.b.s;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import b.b.p.b;
import java.util.Iterator;
import java.util.List;
import java.io.File;
import b.b.n.d;

public final class a
{
    public static void a(final int n) {
        b.b.m.a.b().a().c().execute((Runnable)new Runnable(n) {
            final int b;
            
            public void run() {
                final List<d> c = b.b.q.a.d().b().c(this.b);
                if (c != null) {
                    for (final d d : c) {
                        final String d2 = a.d(d.a(), d.d());
                        b.b.q.a.d().b().remove(d.e());
                        final File file = new File(d2);
                        if (file.exists()) {
                            file.delete();
                        }
                    }
                }
            }
        });
    }
    
    public static String b(final String s, final String s2) {
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        sb.append(File.separator);
        sb.append(s2);
        return sb.toString();
    }
    
    public static b c(b c, final b.b.r.a a) {
        int n = c.u();
        String s = c.D("Location");
        int n2 = 0;
        while (f(n)) {
            if (s == null) {
                throw new IllegalAccessException("Location is null");
            }
            c.close();
            a.J(s);
            c = b.b.q.a.d().c();
            c.q(a);
            n = c.u();
            s = c.D("Location");
            if (++n2 < 10) {
                continue;
            }
            throw new IllegalAccessException("Max redirection done");
        }
        return c;
    }
    
    public static String d(final String s, final String s2) {
        final StringBuilder sb = new StringBuilder();
        sb.append(b(s, s2));
        sb.append(".temp");
        return sb.toString();
    }
    
    public static int e(String string, final String s, final String s2) {
        final StringBuilder sb = new StringBuilder();
        sb.append("Nope");
        sb.append(File.separator);
        sb.append(s);
        sb.append(File.separator);
        sb.append(s2);
        string = sb.toString();
        try {
            final byte[] digest = MessageDigest.getInstance("MD5").digest(string.getBytes("UTF-8"));
            final StringBuilder sb2 = new StringBuilder(digest.length * 2);
            for (int length = digest.length, i = 0; i < length; ++i) {
                final int n = digest[i] & 0xFF;
                if (n < 16) {
                    sb2.append("0");
                }
                sb2.append(Integer.toHexString(n));
            }
            return sb2.toString().hashCode();
        }
        catch (final UnsupportedEncodingException ex) {
            throw new RuntimeException("UnsupportedEncodingException", (Throwable)ex);
        }
        catch (final NoSuchAlgorithmException ex2) {
            throw new RuntimeException("NoSuchAlgorithmException", (Throwable)ex2);
        }
    }
    
    private static boolean f(final int n) {
        return n == 301 || n == 302 || n == 303 || n == 300 || n == 307 || n == 308;
    }
    
    public static void g(String s, final String s2) {
        s = (String)new File(s);
        try {
            final File file = new File(s2);
            if (file.exists() && !file.delete()) {
                throw new IOException("Deletion Failed");
            }
            if (((File)s).renameTo(file)) {
                return;
            }
            throw new IOException("Rename Failed");
        }
        finally {
            if (((File)s).exists()) {
                ((File)s).delete();
            }
        }
    }
}
