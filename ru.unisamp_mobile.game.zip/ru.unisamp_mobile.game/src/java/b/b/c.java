package b.b;

public interface c
{
    void a(final a p0);
    
    void b();
}
