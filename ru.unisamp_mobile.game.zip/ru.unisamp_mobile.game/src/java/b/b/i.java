package b.b;

public enum i
{
    b, 
    c, 
    d, 
    e;
    
    private static final i[] f;
}
