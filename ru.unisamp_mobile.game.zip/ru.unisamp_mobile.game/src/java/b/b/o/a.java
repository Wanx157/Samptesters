package b.b.o;

import b.b.j;
import android.os.Message;
import android.os.Looper;
import b.b.e;
import android.os.Handler;

public class a extends Handler
{
    private final e a;
    
    public a(final e a) {
        super(Looper.getMainLooper());
        this.a = a;
    }
    
    public void handleMessage(final Message message) {
        if (message.what != 1) {
            super.handleMessage(message);
        }
        else {
            final e a = this.a;
            if (a != null) {
                a.a((j)message.obj);
            }
        }
    }
}
