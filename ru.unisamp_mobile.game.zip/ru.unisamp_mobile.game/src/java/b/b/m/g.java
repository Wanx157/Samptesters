package b.b.m;

import android.os.Process;
import java.util.concurrent.ThreadFactory;

public class g implements ThreadFactory
{
    private final int a;
    
    g(final int a) {
        this.a = a;
    }
    
    public Thread newThread(final Runnable runnable) {
        return new Thread((Runnable)new Runnable(this, runnable) {
            final Runnable b;
            final g c;
            
            public void run() {
                while (true) {
                    try {
                        Process.setThreadPriority(this.c.a);
                        this.b.run();
                    }
                    finally {
                        continue;
                    }
                    break;
                }
            }
        });
    }
}
