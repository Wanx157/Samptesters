package b.b.m;

import android.os.Looper;
import android.os.Handler;
import java.util.concurrent.Executor;

public class f implements Executor
{
    private final Handler a;
    
    public f() {
        this.a = new Handler(Looper.getMainLooper());
    }
    
    public void execute(final Runnable runnable) {
        this.a.post(runnable);
    }
}
