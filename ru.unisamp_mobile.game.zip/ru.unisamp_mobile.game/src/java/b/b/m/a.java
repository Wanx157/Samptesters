package b.b.m;

public class a
{
    private static a b;
    private final e a;
    
    private a() {
        this.a = (e)new b();
    }
    
    public static a b() {
        if (a.b == null) {
            synchronized (a.class) {
                if (a.b == null) {
                    a.b = new a();
                }
            }
        }
        return a.b;
    }
    
    public e a() {
        return this.a;
    }
}
