package b.b.m;

import b.b.i;
import b.b.q.c;
import java.util.concurrent.FutureTask;

public class d extends FutureTask<c> implements Comparable<d>
{
    private final c b;
    
    d(final c b) {
        super((Runnable)b, (Object)null);
        this.b = b;
    }
    
    public int d(final d d) {
        final c b = this.b;
        final i b2 = b.b;
        final c b3 = d.b;
        final i b4 = b3.b;
        int n;
        if (b2 == b4) {
            n = b.c - b3.c;
        }
        else {
            n = b4.ordinal() - b2.ordinal();
        }
        return n;
    }
}
