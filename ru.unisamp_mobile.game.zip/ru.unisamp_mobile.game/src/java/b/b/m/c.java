package b.b.m;

import java.util.concurrent.Future;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;

public class c extends ThreadPoolExecutor
{
    c(final int n, final ThreadFactory threadFactory) {
        super(n, n, 0L, TimeUnit.MILLISECONDS, (BlockingQueue)new PriorityBlockingQueue(), threadFactory);
    }
    
    public Future<?> submit(final Runnable runnable) {
        final d d = new d((b.b.q.c)runnable);
        this.execute((Runnable)d);
        return (Future<?>)d;
    }
}
