package b.b.m;

import java.util.concurrent.Executor;

public interface e
{
    Executor a();
    
    c b();
    
    Executor c();
}
