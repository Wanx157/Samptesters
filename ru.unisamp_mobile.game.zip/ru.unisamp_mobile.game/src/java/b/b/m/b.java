package b.b.m;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.Executor;

public class b implements e
{
    private static final int d;
    private final c a;
    private final Executor b;
    private final Executor c;
    
    static {
        d = Runtime.getRuntime().availableProcessors() * 2 + 1;
    }
    
    b() {
        this.a = new c(b.b.m.b.d, (ThreadFactory)new g(10));
        this.b = (Executor)Executors.newSingleThreadExecutor();
        this.c = (Executor)new f();
    }
    
    public Executor a() {
        return this.c;
    }
    
    public c b() {
        return this.a;
    }
    
    public Executor c() {
        return this.b;
    }
}
