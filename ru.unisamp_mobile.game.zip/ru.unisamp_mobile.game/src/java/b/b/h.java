package b.b;

import b.b.p.a;
import b.b.p.b;

public class h
{
    private int a;
    private int b;
    private String c;
    private b.b.p.b d;
    private boolean e;
    
    private h(final b b) {
        this.a = b.a;
        this.b = b.b;
        this.c = b.c;
        this.d = b.d;
        this.e = b.e;
    }
    
    public static b f() {
        return new b();
    }
    
    public int a() {
        return this.b;
    }
    
    public b.b.p.b b() {
        return this.d;
    }
    
    public int c() {
        return this.a;
    }
    
    public String d() {
        return this.c;
    }
    
    public boolean e() {
        return this.e;
    }
    
    public static class b
    {
        int a;
        int b;
        String c;
        b.b.p.b d;
        boolean e;
        
        public b() {
            this.a = 20000;
            this.b = 20000;
            this.c = "PRDownloader";
            this.d = (b.b.p.b)new a();
            this.e = false;
        }
        
        public h a() {
            return new h(this, null);
        }
        
        public b b(final int b) {
            this.b = b;
            return this;
        }
        
        public b c(final boolean e) {
            this.e = e;
            return this;
        }
        
        public b d(final int a) {
            this.a = a;
            return this;
        }
    }
}
