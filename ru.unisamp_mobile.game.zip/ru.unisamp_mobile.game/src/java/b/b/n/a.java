package b.b.n;

import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class a implements c
{
    private final SQLiteDatabase a;
    
    public a(final Context context) {
        this.a = ((SQLiteOpenHelper)new b(context)).getWritableDatabase();
    }
    
    public void a(final int n, final long n2, final long n3) {
        try {
            final ContentValues contentValues = new ContentValues();
            contentValues.put("downloaded_bytes", Long.valueOf(n2));
            contentValues.put("last_modified_at", Long.valueOf(n3));
            this.a.update("prdownloader", contentValues, "id = ? ", new String[] { String.valueOf(n) });
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public d b(final int n) {
        Object rawQuery = null;
        final Exception ex = null;
        final StringBuilder sb = null;
        Object o = rawQuery;
        Object o2 = null;
        d d2 = null;
        try {
            try {
                final SQLiteDatabase a = this.a;
                o = rawQuery;
                o2 = new(java.lang.StringBuilder.class)();
                o = rawQuery;
                new StringBuilder();
                o = rawQuery;
                ((StringBuilder)o2).append("SELECT * FROM prdownloader WHERE id = ");
                o = rawQuery;
                ((StringBuilder)o2).append(n);
                o = rawQuery;
                rawQuery = a.rawQuery(((StringBuilder)o2).toString(), (String[])null);
                o = sb;
                Label_0267: {
                    if (rawQuery != null) {
                        o = sb;
                        try {
                            try {
                                if (!((Cursor)rawQuery).moveToFirst()) {
                                    break Label_0267;
                                }
                                final d d = new d();
                                try {
                                    d.m(n);
                                    d.p(((Cursor)rawQuery).getString(((Cursor)rawQuery).getColumnIndex("url")));
                                    d.k(((Cursor)rawQuery).getString(((Cursor)rawQuery).getColumnIndex("etag")));
                                    d.i(((Cursor)rawQuery).getString(((Cursor)rawQuery).getColumnIndex("dir_path")));
                                    d.l(((Cursor)rawQuery).getString(((Cursor)rawQuery).getColumnIndex("file_name")));
                                    d.o(((Cursor)rawQuery).getLong(((Cursor)rawQuery).getColumnIndex("total_bytes")));
                                    d.j(((Cursor)rawQuery).getLong(((Cursor)rawQuery).getColumnIndex("downloaded_bytes")));
                                    d.n(((Cursor)rawQuery).getLong(((Cursor)rawQuery).getColumnIndex("last_modified_at")));
                                }
                                catch (final Exception ex2) {}
                            }
                            finally {
                                o = rawQuery;
                            }
                        }
                        catch (final Exception o) {}
                        o2 = o;
                    }
                }
                if (rawQuery != null) {
                    ((Cursor)rawQuery).close();
                    return d2;
                }
                return d2;
            }
            finally {}
        }
        catch (final Exception o2) {
            d2 = null;
            rawQuery = ex;
        }
        ((Exception)o2).printStackTrace();
        if (rawQuery != null) {
            ((Cursor)rawQuery).close();
        }
        return d2;
        if (o != null) {
            ((Cursor)o).close();
        }
    }
    
    public List<d> c(final int n) {
        final ArrayList list = new ArrayList();
        final long n2 = n * 24 * 60 * 60;
        Cursor cursor2;
        final Cursor cursor = cursor2 = null;
        try {
            Label_0493: {
                try {
                    final long currentTimeMillis = System.currentTimeMillis();
                    cursor2 = cursor;
                    final SQLiteDatabase a = this.a;
                    cursor2 = cursor;
                    cursor2 = cursor;
                    final StringBuilder sb = new StringBuilder();
                    cursor2 = cursor;
                    sb.append("SELECT * FROM prdownloader WHERE last_modified_at <= ");
                    cursor2 = cursor;
                    sb.append(currentTimeMillis - n2 * 1000L);
                    cursor2 = cursor;
                    final Cursor rawQuery = a.rawQuery(sb.toString(), (String[])null);
                    if (rawQuery != null) {
                        cursor2 = rawQuery;
                        if (rawQuery.moveToFirst()) {
                            do {
                                cursor2 = rawQuery;
                                cursor2 = rawQuery;
                                final d d = new d();
                                cursor2 = rawQuery;
                                d.m(rawQuery.getInt(rawQuery.getColumnIndex("id")));
                                cursor2 = rawQuery;
                                d.p(rawQuery.getString(rawQuery.getColumnIndex("url")));
                                cursor2 = rawQuery;
                                d.k(rawQuery.getString(rawQuery.getColumnIndex("etag")));
                                cursor2 = rawQuery;
                                d.i(rawQuery.getString(rawQuery.getColumnIndex("dir_path")));
                                cursor2 = rawQuery;
                                d.l(rawQuery.getString(rawQuery.getColumnIndex("file_name")));
                                cursor2 = rawQuery;
                                d.o(rawQuery.getLong(rawQuery.getColumnIndex("total_bytes")));
                                cursor2 = rawQuery;
                                d.j(rawQuery.getLong(rawQuery.getColumnIndex("downloaded_bytes")));
                                cursor2 = rawQuery;
                                d.n(rawQuery.getLong(rawQuery.getColumnIndex("last_modified_at")));
                                cursor2 = rawQuery;
                                ((List)list).add((Object)d);
                                cursor2 = rawQuery;
                            } while (rawQuery.moveToNext());
                        }
                    }
                    if (rawQuery != null) {
                        final Cursor cursor3 = rawQuery;
                        break Label_0493;
                    }
                    return (List<d>)list;
                }
                finally {
                    Label_0515: {
                        if (cursor2 != null) {
                            cursor2.close();
                            break Label_0515;
                        }
                        break Label_0515;
                    }
                    while (true) {}
                    final Cursor cursor3;
                    cursor3.close();
                    return (List<d>)list;
                }
            }
        }
        catch (final Exception ex) {}
    }
    
    public void d(final d d) {
        try {
            final ContentValues contentValues = new ContentValues();
            contentValues.put("id", Integer.valueOf(d.e()));
            contentValues.put("url", d.h());
            contentValues.put("etag", d.c());
            contentValues.put("dir_path", d.a());
            contentValues.put("file_name", d.d());
            contentValues.put("total_bytes", Long.valueOf(d.g()));
            contentValues.put("downloaded_bytes", Long.valueOf(d.b()));
            contentValues.put("last_modified_at", Long.valueOf(d.f()));
            this.a.insert("prdownloader", (String)null, contentValues);
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void remove(final int n) {
        try {
            final SQLiteDatabase a = this.a;
            final StringBuilder sb = new StringBuilder();
            sb.append("DELETE FROM prdownloader WHERE id = ");
            sb.append(n);
            a.execSQL(sb.toString());
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
}
