package b.b.n;

import java.util.List;

public interface c
{
    void a(final int p0, final long p1, final long p2);
    
    d b(final int p0);
    
    List<d> c(final int p0);
    
    void d(final d p0);
    
    void remove(final int p0);
}
