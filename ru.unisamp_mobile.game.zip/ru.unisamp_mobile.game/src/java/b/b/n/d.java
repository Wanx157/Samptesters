package b.b.n;

public class d
{
    private int a;
    private String b;
    private String c;
    private String d;
    private String e;
    private long f;
    private long g;
    private long h;
    
    public String a() {
        return this.d;
    }
    
    public long b() {
        return this.g;
    }
    
    public String c() {
        return this.c;
    }
    
    public String d() {
        return this.e;
    }
    
    public int e() {
        return this.a;
    }
    
    public long f() {
        return this.h;
    }
    
    public long g() {
        return this.f;
    }
    
    public String h() {
        return this.b;
    }
    
    public void i(final String d) {
        this.d = d;
    }
    
    public void j(final long g) {
        this.g = g;
    }
    
    public void k(final String c) {
        this.c = c;
    }
    
    public void l(final String e) {
        this.e = e;
    }
    
    public void m(final int a) {
        this.a = a;
    }
    
    public void n(final long h) {
        this.h = h;
    }
    
    public void o(final long f) {
        this.f = f;
    }
    
    public void p(final String b) {
        this.b = b;
    }
}
