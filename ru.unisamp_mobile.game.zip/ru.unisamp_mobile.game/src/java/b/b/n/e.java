package b.b.n;

import java.util.List;

public class e implements c
{
    public void a(final int n, final long n2, final long n3) {
    }
    
    public d b(final int n) {
        return null;
    }
    
    public List<d> c(final int n) {
        return null;
    }
    
    public void d(final d d) {
    }
    
    public void remove(final int n) {
    }
}
