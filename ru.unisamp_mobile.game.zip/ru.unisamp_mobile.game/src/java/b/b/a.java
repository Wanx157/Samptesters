package b.b;

import java.util.List;
import java.util.Map;

public class a
{
    private boolean a;
    private boolean b;
    
    public boolean a() {
        return this.b;
    }
    
    public boolean b() {
        return this.a;
    }
    
    public void c(final boolean b) {
        this.b = b;
    }
    
    public void d(final Throwable t) {
    }
    
    public void e(final Map<String, List<String>> map) {
    }
    
    public void f(final int n) {
    }
    
    public void g(final boolean a) {
        this.a = a;
    }
    
    public void h(final String s) {
    }
}
