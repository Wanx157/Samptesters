package b.b;

public enum l
{
    b, 
    c, 
    d, 
    e, 
    f, 
    g, 
    h;
    
    private static final l[] i;
}
