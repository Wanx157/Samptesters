package b.b;

import java.io.Serializable;

public class j implements Serializable
{
    public long b;
    public long c;
    
    public j(final long b, final long c) {
        this.b = b;
        this.c = c;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("Progress{currentBytes=");
        sb.append(this.b);
        sb.append(", totalBytes=");
        sb.append(this.c);
        sb.append('}');
        return sb.toString();
    }
}
