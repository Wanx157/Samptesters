package b.b;

public interface b
{
}
