package b.c.a.a.i.z;

import b.c.a.a.i.u.a.d;
import b.c.a.a.i.u.a.b;

public final class c implements b<a>
{
    public static c a() {
        return c.c$a.a();
    }
    
    public static a b() {
        final a a = b.c.a.a.i.z.b.a();
        d.c((Object)a, "Cannot return null from a non-@Nullable @Provides method");
        return a;
    }
    
    public a c() {
        return b();
    }
}
