package b.c.a.a;

import com.google.auto.value.AutoValue;

@AutoValue
public abstract class c<T>
{
    public static <T> c<T> d(final T t) {
        return (c<T>)new a((Integer)null, (Object)t, d.b);
    }
    
    public static <T> c<T> e(final T t) {
        return (c<T>)new a((Integer)null, (Object)t, d.c);
    }
    
    public static <T> c<T> f(final T t) {
        return (c<T>)new a((Integer)null, (Object)t, d.d);
    }
    
    public abstract Integer a();
    
    public abstract T b();
    
    public abstract d c();
}
