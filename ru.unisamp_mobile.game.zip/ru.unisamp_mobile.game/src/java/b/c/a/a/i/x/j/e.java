package b.c.a.a.i.x.j;

public abstract class e
{
    static String a() {
        return "com.google.android.datatransport.events";
    }
    
    static int b() {
        return h0.d;
    }
    
    static d c() {
        return d.a;
    }
}
