package b.c.a.a.i.y;

public interface b
{
     <T> T a(final a<T> p0);
    
    public interface a<T>
    {
        T i();
    }
}
