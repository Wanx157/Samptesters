package b.c.a.a.i;

import com.google.auto.value.AutoValue$Builder;
import android.util.Base64;
import b.c.a.a.d;
import com.google.auto.value.AutoValue;

@AutoValue
public abstract class m
{
    public static a a() {
        final c$b c$b = new c$b();
        c$b.d(d.b);
        return (a)c$b;
    }
    
    public abstract String b();
    
    public abstract byte[] c();
    
    public abstract d d();
    
    public m e(final d d) {
        final a a = a();
        a.b(this.b());
        a.d(d);
        a.c(this.c());
        return a.a();
    }
    
    @Override
    public final String toString() {
        final String b = this.b();
        final d d = this.d();
        String encodeToString;
        if (this.c() == null) {
            encodeToString = "";
        }
        else {
            encodeToString = Base64.encodeToString(this.c(), 2);
        }
        return String.format("TransportContext(%s, %s, %s)", new Object[] { b, d, encodeToString });
    }
    
    @AutoValue$Builder
    public abstract static class a
    {
        public abstract m a();
        
        public abstract a b(final String p0);
        
        public abstract a c(final byte[] p0);
        
        public abstract a d(final d p0);
    }
}
