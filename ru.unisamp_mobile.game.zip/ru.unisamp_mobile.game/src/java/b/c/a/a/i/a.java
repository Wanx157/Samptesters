package b.c.a.a.i;

import java.util.Map;

final class a extends h
{
    private final String a;
    private final Integer b;
    private final g c;
    private final long d;
    private final long e;
    private final Map<String, String> f;
    
    private a(final String a, final Integer b, final g c, final long d, final long e, final Map<String, String> f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    protected Map<String, String> c() {
        return this.f;
    }
    
    public Integer d() {
        return this.b;
    }
    
    public g e() {
        return this.c;
    }
    
    public boolean equals(final Object o) {
        boolean b = true;
        if (o == this) {
            return true;
        }
        if (o instanceof h) {
            final h h = (h)o;
            if (this.a.equals((Object)h.j())) {
                final Integer b2 = this.b;
                if (b2 == null) {
                    if (h.d() != null) {
                        return false;
                    }
                }
                else if (!b2.equals((Object)h.d())) {
                    return false;
                }
                if (this.c.equals((Object)h.e()) && this.d == h.f() && this.e == h.k() && this.f.equals((Object)h.c())) {
                    return b;
                }
            }
            b = false;
            return b;
        }
        return false;
    }
    
    public long f() {
        return this.d;
    }
    
    public int hashCode() {
        final int hashCode = this.a.hashCode();
        final Integer b = this.b;
        int hashCode2;
        if (b == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = b.hashCode();
        }
        final int hashCode3 = this.c.hashCode();
        final long d = this.d;
        final int n = (int)(d ^ d >>> 32);
        final long e = this.e;
        return (((((hashCode ^ 0xF4243) * 1000003 ^ hashCode2) * 1000003 ^ hashCode3) * 1000003 ^ n) * 1000003 ^ (int)(e ^ e >>> 32)) * 1000003 ^ this.f.hashCode();
    }
    
    public String j() {
        return this.a;
    }
    
    public long k() {
        return this.e;
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("EventInternal{transportName=");
        sb.append(this.a);
        sb.append(", code=");
        sb.append((Object)this.b);
        sb.append(", encodedPayload=");
        sb.append((Object)this.c);
        sb.append(", eventMillis=");
        sb.append(this.d);
        sb.append(", uptimeMillis=");
        sb.append(this.e);
        sb.append(", autoMetadata=");
        sb.append((Object)this.f);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends h$a
    {
        private String a;
        private Integer b;
        private g c;
        private Long d;
        private Long e;
        private Map<String, String> f;
        
        public h d() {
            final String a = this.a;
            String string = "";
            if (a == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(" transportName");
                string = sb.toString();
            }
            String string2 = string;
            if (this.c == null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append(" encodedPayload");
                string2 = sb2.toString();
            }
            String string3 = string2;
            if (this.d == null) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append(string2);
                sb3.append(" eventMillis");
                string3 = sb3.toString();
            }
            String string4 = string3;
            if (this.e == null) {
                final StringBuilder sb4 = new StringBuilder();
                sb4.append(string3);
                sb4.append(" uptimeMillis");
                string4 = sb4.toString();
            }
            String string5 = string4;
            if (this.f == null) {
                final StringBuilder sb5 = new StringBuilder();
                sb5.append(string4);
                sb5.append(" autoMetadata");
                string5 = sb5.toString();
            }
            if (string5.isEmpty()) {
                return new a(this.a, this.b, this.c, this.d, this.e, this.f, null);
            }
            final StringBuilder sb6 = new StringBuilder();
            sb6.append("Missing required properties:");
            sb6.append(string5);
            throw new IllegalStateException(sb6.toString());
        }
        
        protected Map<String, String> e() {
            final Map<String, String> f = this.f;
            if (f != null) {
                return f;
            }
            throw new IllegalStateException("Property \"autoMetadata\" has not been set");
        }
        
        protected h$a f(final Map<String, String> f) {
            if (f != null) {
                this.f = f;
                return this;
            }
            throw new NullPointerException("Null autoMetadata");
        }
        
        public h$a g(final Integer b) {
            this.b = b;
            return this;
        }
        
        public h$a h(final g c) {
            if (c != null) {
                this.c = c;
                return this;
            }
            throw new NullPointerException("Null encodedPayload");
        }
        
        public h$a i(final long n) {
            this.d = n;
            return this;
        }
        
        public h$a j(final String a) {
            if (a != null) {
                this.a = a;
                return this;
            }
            throw new NullPointerException("Null transportName");
        }
        
        public h$a k(final long n) {
            this.e = n;
            return this;
        }
    }
}
