package b.c.a.a.i.x;

import b.c.a.a.i.h;
import b.c.a.a.i.m;

public interface e
{
    void a(final m p0, final h p1, final b.c.a.a.h p2);
}
