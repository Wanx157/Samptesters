package b.c.a.a.i;

import com.google.auto.value.AutoValue$Builder;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import com.google.auto.value.AutoValue;

@AutoValue
public abstract class h
{
    public static a a() {
        final a$b a$b = new a$b();
        a$b.f((Map)new HashMap());
        return (a)a$b;
    }
    
    public final String b(String s) {
        if ((s = (String)this.c().get((Object)s)) == null) {
            s = "";
        }
        return s;
    }
    
    protected abstract Map<String, String> c();
    
    public abstract Integer d();
    
    public abstract g e();
    
    public abstract long f();
    
    public final int g(String s) {
        s = (String)this.c().get((Object)s);
        int intValue;
        if (s == null) {
            intValue = 0;
        }
        else {
            intValue = Integer.valueOf(s);
        }
        return intValue;
    }
    
    public final long h(String s) {
        s = (String)this.c().get((Object)s);
        long longValue;
        if (s == null) {
            longValue = 0L;
        }
        else {
            longValue = Long.valueOf(s);
        }
        return longValue;
    }
    
    public final Map<String, String> i() {
        return (Map<String, String>)Collections.unmodifiableMap((Map)this.c());
    }
    
    public abstract String j();
    
    public abstract long k();
    
    public a l() {
        final a$b a$b = new a$b();
        a$b.j(this.j());
        ((a)a$b).g(this.d());
        ((a)a$b).h(this.e());
        ((a)a$b).i(this.f());
        ((a)a$b).k(this.k());
        ((a)a$b).f((Map<String, String>)new HashMap((Map)this.c()));
        return (a)a$b;
    }
    
    @AutoValue$Builder
    public abstract static class a
    {
        public final a a(final String s, final int n) {
            this.e().put((Object)s, (Object)String.valueOf(n));
            return this;
        }
        
        public final a b(final String s, final long n) {
            this.e().put((Object)s, (Object)String.valueOf(n));
            return this;
        }
        
        public final a c(final String s, final String s2) {
            this.e().put((Object)s, (Object)s2);
            return this;
        }
        
        public abstract h d();
        
        protected abstract Map<String, String> e();
        
        protected abstract a f(final Map<String, String> p0);
        
        public abstract a g(final Integer p0);
        
        public abstract a h(final g p0);
        
        public abstract a i(final long p0);
        
        public abstract a j(final String p0);
        
        public abstract a k(final long p0);
    }
}
