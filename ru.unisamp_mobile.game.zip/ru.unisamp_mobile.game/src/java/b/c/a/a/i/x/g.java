package b.c.a.a.i.x;

import b.c.a.a.i.u.a.d;
import c.a.a;
import b.c.a.a.i.u.a.b;

public final class g implements b<com.google.android.datatransport.runtime.scheduling.jobscheduling.g>
{
    private final a<b.c.a.a.i.z.a> a;
    
    public g(final a<b.c.a.a.i.z.a> a) {
        this.a = a;
    }
    
    public static com.google.android.datatransport.runtime.scheduling.jobscheduling.g a(final b.c.a.a.i.z.a a) {
        final com.google.android.datatransport.runtime.scheduling.jobscheduling.g a2 = f.a(a);
        d.c((Object)a2, "Cannot return null from a non-@Nullable @Provides method");
        return a2;
    }
    
    public static g b(final a<b.c.a.a.i.z.a> a) {
        return new g(a);
    }
    
    public com.google.android.datatransport.runtime.scheduling.jobscheduling.g c() {
        return a((b.c.a.a.i.z.a)this.a.get());
    }
}
