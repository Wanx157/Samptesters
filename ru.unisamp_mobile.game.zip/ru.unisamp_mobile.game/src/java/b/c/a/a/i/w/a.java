package b.c.a.a.i.w;

public interface a<TInput, TResult, TException extends Throwable>
{
    TResult a(final TInput p0) throws TException;
}
