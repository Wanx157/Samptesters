package b.c.a.a.i;

import b.c.a.a.i.u.a.d;
import java.util.concurrent.Executor;
import b.c.a.a.i.u.a.b;

public final class j implements b<Executor>
{
    public static j a() {
        return j.j$a.a();
    }
    
    public static Executor b() {
        final Executor a = i.a();
        d.c((Object)a, "Cannot return null from a non-@Nullable @Provides method");
        return a;
    }
    
    public Executor c() {
        return b();
    }
}
