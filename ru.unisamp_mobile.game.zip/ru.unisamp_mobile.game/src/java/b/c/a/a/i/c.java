package b.c.a.a.i;

import java.util.Arrays;
import b.c.a.a.d;

final class c extends m
{
    private final String a;
    private final byte[] b;
    private final d c;
    
    private c(final String a, final byte[] b, final d c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public String b() {
        return this.a;
    }
    
    public byte[] c() {
        return this.b;
    }
    
    public d d() {
        return this.c;
    }
    
    public boolean equals(final Object o) {
        boolean b = true;
        if (o == this) {
            return true;
        }
        if (o instanceof m) {
            final m m = (m)o;
            if (this.a.equals((Object)m.b())) {
                final byte[] b2 = this.b;
                byte[] array;
                if (m instanceof c) {
                    array = ((c)m).b;
                }
                else {
                    array = m.c();
                }
                if (Arrays.equals(b2, array) && ((Enum)this.c).equals((Object)m.d())) {
                    return b;
                }
            }
            b = false;
            return b;
        }
        return false;
    }
    
    public int hashCode() {
        return ((this.a.hashCode() ^ 0xF4243) * 1000003 ^ Arrays.hashCode(this.b)) * 1000003 ^ ((Enum)this.c).hashCode();
    }
    
    static final class b extends m$a
    {
        private String a;
        private byte[] b;
        private d c;
        
        public m a() {
            final String a = this.a;
            String string = "";
            if (a == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(" backendName");
                string = sb.toString();
            }
            String string2 = string;
            if (this.c == null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append(" priority");
                string2 = sb2.toString();
            }
            if (string2.isEmpty()) {
                return new c(this.a, this.b, this.c, null);
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("Missing required properties:");
            sb3.append(string2);
            throw new IllegalStateException(sb3.toString());
        }
        
        public m$a b(final String a) {
            if (a != null) {
                this.a = a;
                return this;
            }
            throw new NullPointerException("Null backendName");
        }
        
        public m$a c(final byte[] b) {
            this.b = b;
            return this;
        }
        
        public m$a d(final d c) {
            if (c != null) {
                this.c = c;
                return this;
            }
            throw new NullPointerException("Null priority");
        }
    }
}
