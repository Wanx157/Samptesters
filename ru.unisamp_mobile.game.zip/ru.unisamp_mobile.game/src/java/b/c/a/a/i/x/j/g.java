package b.c.a.a.i.x.j;

import b.c.a.a.i.u.a.b;

public final class g implements b<Integer>
{
    public static g a() {
        return g.g$a.a();
    }
    
    public static int c() {
        return e.b();
    }
    
    public Integer b() {
        return c();
    }
}
