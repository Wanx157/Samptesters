package b.c.a.a;

public enum d
{
    b, 
    c, 
    d;
    
    private static final d[] e;
}
