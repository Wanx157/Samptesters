package b.c.a.a.i.x;

import com.google.android.datatransport.runtime.scheduling.jobscheduling.g;
import b.c.a.a.i.z.a;

public abstract class f
{
    static g a(final a a) {
        return g.f(a);
    }
}
