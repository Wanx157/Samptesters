package b.c.a.a;

final class a<T> extends c<T>
{
    private final Integer a;
    private final T b;
    private final d c;
    
    a(final Integer a, final T b, final d c) {
        this.a = a;
        if (b == null) {
            throw new NullPointerException("Null payload");
        }
        this.b = b;
        if (c != null) {
            this.c = c;
            return;
        }
        throw new NullPointerException("Null priority");
    }
    
    public Integer a() {
        return this.a;
    }
    
    public T b() {
        return this.b;
    }
    
    public d c() {
        return this.c;
    }
    
    public boolean equals(final Object o) {
        boolean b = true;
        if (o == this) {
            return true;
        }
        if (o instanceof c) {
            final c c = (c)o;
            final Integer a = this.a;
            if (a == null) {
                if (c.a() != null) {
                    return false;
                }
            }
            else if (!a.equals((Object)c.a())) {
                return false;
            }
            if (this.b.equals(c.b()) && ((Enum)this.c).equals((Object)c.c())) {
                return b;
            }
            b = false;
            return b;
        }
        return false;
    }
    
    public int hashCode() {
        final Integer a = this.a;
        int hashCode;
        if (a == null) {
            hashCode = 0;
        }
        else {
            hashCode = a.hashCode();
        }
        return ((hashCode ^ 0xF4243) * 1000003 ^ this.b.hashCode()) * 1000003 ^ ((Enum)this.c).hashCode();
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("Event{code=");
        sb.append((Object)this.a);
        sb.append(", payload=");
        sb.append((Object)this.b);
        sb.append(", priority=");
        sb.append((Object)this.c);
        sb.append("}");
        return sb.toString();
    }
}
