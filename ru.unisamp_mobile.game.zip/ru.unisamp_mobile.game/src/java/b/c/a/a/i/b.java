package b.c.a.a.i;

import b.c.a.a.e;
import b.c.a.a.c;

final class b extends l
{
    private final m a;
    private final String b;
    private final c<?> c;
    private final e<?, byte[]> d;
    private final b e;
    
    private b(final m a, final String b, final c<?> c, final e<?, byte[]> d, final b e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public b b() {
        return this.e;
    }
    
    c<?> c() {
        return this.c;
    }
    
    e<?, byte[]> e() {
        return this.d;
    }
    
    public boolean equals(final Object o) {
        boolean b = true;
        if (o == this) {
            return true;
        }
        if (o instanceof l) {
            final l l = (l)o;
            if (!this.a.equals(l.f()) || !this.b.equals((Object)l.g()) || !this.c.equals(l.c()) || !this.d.equals(l.e()) || !this.e.equals((Object)l.b())) {
                b = false;
            }
            return b;
        }
        return false;
    }
    
    public m f() {
        return this.a;
    }
    
    public String g() {
        return this.b;
    }
    
    public int hashCode() {
        return ((((this.a.hashCode() ^ 0xF4243) * 1000003 ^ this.b.hashCode()) * 1000003 ^ this.c.hashCode()) * 1000003 ^ this.d.hashCode()) * 1000003 ^ this.e.hashCode();
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("SendRequest{transportContext=");
        sb.append((Object)this.a);
        sb.append(", transportName=");
        sb.append(this.b);
        sb.append(", event=");
        sb.append((Object)this.c);
        sb.append(", transformer=");
        sb.append((Object)this.d);
        sb.append(", encoding=");
        sb.append((Object)this.e);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends l$a
    {
        private m a;
        private String b;
        private c<?> c;
        private e<?, byte[]> d;
        private b.c.a.a.b e;
        
        public l a() {
            final m a = this.a;
            String string = "";
            if (a == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(" transportContext");
                string = sb.toString();
            }
            String string2 = string;
            if (this.b == null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append(" transportName");
                string2 = sb2.toString();
            }
            String string3 = string2;
            if (this.c == null) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append(string2);
                sb3.append(" event");
                string3 = sb3.toString();
            }
            String string4 = string3;
            if (this.d == null) {
                final StringBuilder sb4 = new StringBuilder();
                sb4.append(string3);
                sb4.append(" transformer");
                string4 = sb4.toString();
            }
            String string5 = string4;
            if (this.e == null) {
                final StringBuilder sb5 = new StringBuilder();
                sb5.append(string4);
                sb5.append(" encoding");
                string5 = sb5.toString();
            }
            if (string5.isEmpty()) {
                return new b.c.a.a.i.b(this.a, this.b, this.c, this.d, this.e, null);
            }
            final StringBuilder sb6 = new StringBuilder();
            sb6.append("Missing required properties:");
            sb6.append(string5);
            throw new IllegalStateException(sb6.toString());
        }
        
        l$a b(final b.c.a.a.b e) {
            if (e != null) {
                this.e = e;
                return this;
            }
            throw new NullPointerException("Null encoding");
        }
        
        l$a c(final c<?> c) {
            if (c != null) {
                this.c = c;
                return this;
            }
            throw new NullPointerException("Null event");
        }
        
        l$a d(final e<?, byte[]> d) {
            if (d != null) {
                this.d = d;
                return this;
            }
            throw new NullPointerException("Null transformer");
        }
        
        public l$a e(final m a) {
            if (a != null) {
                this.a = a;
                return this;
            }
            throw new NullPointerException("Null transportContext");
        }
        
        public l$a f(final String b) {
            if (b != null) {
                this.b = b;
                return this;
            }
            throw new NullPointerException("Null transportName");
        }
    }
}
