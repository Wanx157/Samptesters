package b.c.a.a.i.v;

import android.util.Log;

public final class a
{
    public static void a(final String s, final String s2, final Object o) {
        Log.d(d(s), String.format(s2, new Object[] { o }));
    }
    
    public static void b(final String s, final String s2, final Object... array) {
        Log.d(d(s), String.format(s2, array));
    }
    
    public static void c(final String s, final String s2, final Throwable t) {
        Log.e(d(s), s2, t);
    }
    
    private static String d(final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append("TransportRuntime.");
        sb.append(s);
        return sb.toString();
    }
    
    public static void e(final String s, final String s2) {
        Log.i(d(s), s2);
    }
    
    public static void f(final String s, final String s2, final Object o) {
        Log.w(d(s), String.format(s2, new Object[] { o }));
    }
}
