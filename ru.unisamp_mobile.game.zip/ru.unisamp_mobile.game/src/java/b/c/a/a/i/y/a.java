package b.c.a.a.i.y;

public class a extends RuntimeException
{
    public a(final String s, final Throwable t) {
        super(s, t);
    }
}
