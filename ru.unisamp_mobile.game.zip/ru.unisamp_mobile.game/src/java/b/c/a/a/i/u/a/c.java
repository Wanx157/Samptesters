package b.c.a.a.i.u.a;

public final class c<T> implements b<T>, Object<T>
{
    private final T a;
    
    private c(final T a) {
        this.a = a;
    }
    
    public static <T> b<T> a(final T t) {
        d.c((Object)t, "instance cannot be null");
        return new c<T>(t);
    }
    
    public T get() {
        return this.a;
    }
}
