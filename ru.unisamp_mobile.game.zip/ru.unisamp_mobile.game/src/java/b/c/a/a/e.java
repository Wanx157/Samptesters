package b.c.a.a;

public interface e<T, U>
{
    U a(final T p0);
}
