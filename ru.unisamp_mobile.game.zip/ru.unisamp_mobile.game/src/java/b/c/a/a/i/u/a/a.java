package b.c.a.a.i.u.a;

public final class a<T> implements c.a.a<T>, Object<T>
{
    private static final Object c;
    private volatile c.a.a<T> a;
    private volatile Object b;
    
    static {
        c = new Object();
    }
    
    private a(final c.a.a<T> a) {
        this.b = b.c.a.a.i.u.a.a.c;
        this.a = a;
    }
    
    public static <P extends c.a.a<T>, T> c.a.a<T> a(final P p) {
        d.b((Object)p);
        if (p instanceof a) {
            return p;
        }
        return (c.a.a<T>)new a((c.a.a<Object>)p);
    }
    
    public static Object b(final Object o, final Object o2) {
        if (o != a.c && o != o2) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Scoped provider was invoked recursively returning different results: ");
            sb.append(o);
            sb.append(" & ");
            sb.append(o2);
            sb.append(". This is likely due to a circular dependency.");
            throw new IllegalStateException(sb.toString());
        }
        return o2;
    }
    
    public T get() {
        final Object b;
        if ((b = this.b) == b.c.a.a.i.u.a.a.c) {
            synchronized (this) {
                if (this.b == b.c.a.a.i.u.a.a.c) {
                    final Object value = this.a.get();
                    b(this.b, value);
                    this.b = value;
                    this.a = null;
                }
            }
        }
        return (T)b;
    }
}
