package b.c.a.a.i;

import b.c.a.a.f;
import b.c.a.a.e;
import b.c.a.a.b;
import java.util.Set;
import b.c.a.a.g;

final class n implements g
{
    private final Set<b> a;
    private final m b;
    private final q c;
    
    n(final Set<b> a, final m b, final q c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public <T> f<T> a(final String s, final Class<T> clazz, final b b, final e<T, byte[]> e) {
        if (this.a.contains((Object)b)) {
            return (f<T>)new p(this.b, s, b, (b.c.a.a.e<Object, byte[]>)e, this.c);
        }
        throw new IllegalArgumentException(String.format("%s is not supported byt this factory. Supported encodings are: %s.", new Object[] { b, this.a }));
    }
}
