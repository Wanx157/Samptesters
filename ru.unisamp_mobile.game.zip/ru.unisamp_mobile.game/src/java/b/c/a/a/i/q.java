package b.c.a.a.i;

import b.c.a.a.h;

interface q
{
    void a(final l p0, final h p1);
}
