package b.c.a.a.i.u.a;

public final class d
{
    public static <T> void a(final T t, final Class<T> clazz) {
        if (t != null) {
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(clazz.getCanonicalName());
        sb.append(" must be set");
        throw new IllegalStateException(sb.toString());
    }
    
    public static <T> T b(final T t) {
        if (t != null) {
            return t;
        }
        throw null;
    }
    
    public static <T> T c(final T t, final String s) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(s);
    }
}
