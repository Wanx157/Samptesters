package b.c.a.a.i;

import b.c.a.a.h;
import b.c.a.a.c;
import b.c.a.a.e;
import b.c.a.a.b;
import b.c.a.a.f;

final class p<T> implements f<T>
{
    private final m a;
    private final String b;
    private final b c;
    private final e<T, byte[]> d;
    private final q e;
    
    p(final m a, final String b, final b c, final e<T, byte[]> d, final q e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public void a(final c<T> c) {
        this.b(c, o.b());
    }
    
    public void b(final c<T> c, final h h) {
        final q e = this.e;
        final l$a a = l.a();
        a.e(this.a);
        a.c((c)c);
        a.f(this.b);
        a.d((e)this.d);
        a.b(this.c);
        e.a(a.a(), h);
    }
}
