package b.c.a.a.i;

import com.google.android.datatransport.runtime.scheduling.jobscheduling.q;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.m;
import b.c.a.a.i.x.e;
import c.a.a;
import b.c.a.a.i.u.a.b;

public final class t implements b<r>
{
    private final a<b.c.a.a.i.z.a> a;
    private final a<b.c.a.a.i.z.a> b;
    private final a<e> c;
    private final a<m> d;
    private final a<q> e;
    
    public t(final a<b.c.a.a.i.z.a> a, final a<b.c.a.a.i.z.a> b, final a<e> c, final a<m> d, final a<q> e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public static t a(final a<b.c.a.a.i.z.a> a, final a<b.c.a.a.i.z.a> a2, final a<e> a3, final a<m> a4, final a<q> a5) {
        return new t(a, a2, a3, a4, a5);
    }
    
    public static r c(final b.c.a.a.i.z.a a, final b.c.a.a.i.z.a a2, final e e, final m m, final q q) {
        return new r(a, a2, e, m, q);
    }
    
    public r b() {
        return c((b.c.a.a.i.z.a)this.a.get(), (b.c.a.a.i.z.a)this.b.get(), (e)this.c.get(), (m)this.d.get(), (q)this.e.get());
    }
}
