package b.c.a.a.i.x.j;

import com.google.auto.value.AutoValue$Builder;
import com.google.auto.value.AutoValue;

@AutoValue
abstract class d
{
    static final d a;
    
    static {
        final a a2 = a();
        a2.f(10485760L);
        a2.d(200);
        a2.b(10000);
        a2.c(604800000L);
        a2.e(81920);
        a = a2.a();
    }
    
    static a a() {
        return (a)new a$b();
    }
    
    abstract int b();
    
    abstract long c();
    
    abstract int d();
    
    abstract int e();
    
    abstract long f();
    
    @AutoValue$Builder
    abstract static class a
    {
        abstract d a();
        
        abstract a b(final int p0);
        
        abstract a c(final long p0);
        
        abstract a d(final int p0);
        
        abstract a e(final int p0);
        
        abstract a f(final long p0);
    }
}
