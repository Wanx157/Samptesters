package b.c.a.a.i;

import java.util.concurrent.Executors;
import java.util.concurrent.Executor;

abstract class i
{
    static Executor a() {
        return (Executor)new k((Executor)Executors.newSingleThreadExecutor());
    }
}
