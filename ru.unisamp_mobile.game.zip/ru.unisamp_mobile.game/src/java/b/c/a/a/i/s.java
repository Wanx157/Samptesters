package b.c.a.a.i;

import android.content.Context;
import b.c.a.a.i.x.j.c;
import java.io.Closeable;

abstract class s implements Closeable
{
    abstract c a();
    
    public void close() {
        ((Closeable)this.a()).close();
    }
    
    abstract r d();
    
    interface a
    {
        s d();
        
        a e(final Context p0);
    }
}
