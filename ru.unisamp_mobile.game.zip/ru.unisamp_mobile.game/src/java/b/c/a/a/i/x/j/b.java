package b.c.a.a.i.x.j;

import b.c.a.a.i.h;
import b.c.a.a.i.m;

final class b extends i
{
    private final long a;
    private final m b;
    private final h c;
    
    b(final long a, final m b, final h c) {
        this.a = a;
        if (b == null) {
            throw new NullPointerException("Null transportContext");
        }
        this.b = b;
        if (c != null) {
            this.c = c;
            return;
        }
        throw new NullPointerException("Null event");
    }
    
    public h b() {
        return this.c;
    }
    
    public long c() {
        return this.a;
    }
    
    public m d() {
        return this.b;
    }
    
    public boolean equals(final Object o) {
        boolean b = true;
        if (o == this) {
            return true;
        }
        if (o instanceof i) {
            final i i = (i)o;
            if (this.a != i.c() || !this.b.equals(i.d()) || !this.c.equals(i.b())) {
                b = false;
            }
            return b;
        }
        return false;
    }
    
    public int hashCode() {
        final long a = this.a;
        return this.c.hashCode() ^ (((int)(a ^ a >>> 32) ^ 0xF4243) * 1000003 ^ this.b.hashCode()) * 1000003;
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("PersistedEvent{id=");
        sb.append(this.a);
        sb.append(", transportContext=");
        sb.append((Object)this.b);
        sb.append(", event=");
        sb.append((Object)this.c);
        sb.append("}");
        return sb.toString();
    }
}
