package b.c.a.a.i.x;

import b.c.a.a.i.u.a.d;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.g;
import b.c.a.a.i.x.j.c;
import android.content.Context;
import c.a.a;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.s;
import b.c.a.a.i.u.a.b;

public final class i implements b<s>
{
    private final a<Context> a;
    private final a<c> b;
    private final a<g> c;
    private final a<b.c.a.a.i.z.a> d;
    
    public i(final a<Context> a, final a<c> b, final a<g> c, final a<b.c.a.a.i.z.a> d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public static i a(final a<Context> a, final a<c> a2, final a<g> a3, final a<b.c.a.a.i.z.a> a4) {
        return new i(a, a2, a3, a4);
    }
    
    public static s c(final Context context, final c c, final g g, final b.c.a.a.i.z.a a) {
        final s a2 = h.a(context, c, g, a);
        d.c((Object)a2, "Cannot return null from a non-@Nullable @Provides method");
        return a2;
    }
    
    public s b() {
        return c((Context)this.a.get(), (c)this.b.get(), (g)this.c.get(), (b.c.a.a.i.z.a)this.d.get());
    }
}
