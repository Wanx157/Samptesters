package b.c.a.a.i;

import android.content.Context;
import java.util.Collections;
import b.c.a.a.b;
import java.util.Set;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.m;
import b.c.a.a.i.x.e;
import b.c.a.a.i.z.a;

public class r implements q
{
    private static volatile s e;
    private final a a;
    private final a b;
    private final e c;
    private final m d;
    
    r(final a a, final a b, final e c, final m d, final com.google.android.datatransport.runtime.scheduling.jobscheduling.q q) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        q.a();
    }
    
    private h b(final l l) {
        final h$a a = h.a();
        a.i(this.a.a());
        a.k(this.b.a());
        a.j(l.g());
        a.h(new g(l.b(), l.d()));
        a.g(l.c().a());
        return a.d();
    }
    
    public static r c() {
        final s e = r.e;
        if (e != null) {
            return e.d();
        }
        throw new IllegalStateException("Not initialized!");
    }
    
    private static Set<b> d(final b.c.a.a.i.e e) {
        if (e instanceof f) {
            return (Set<b>)Collections.unmodifiableSet((Set)((f)e).b());
        }
        return (Set<b>)Collections.singleton((Object)b.b("proto"));
    }
    
    public static void f(final Context context) {
        if (r.e == null) {
            synchronized (r.class) {
                if (r.e == null) {
                    final s$a i = d.i();
                    i.e(context);
                    r.e = i.d();
                }
            }
        }
    }
    
    public void a(final l l, final b.c.a.a.h h) {
        this.c.a(l.f().e(l.c().c()), this.b(l), h);
    }
    
    public m e() {
        return this.d;
    }
    
    public b.c.a.a.g g(final b.c.a.a.i.e e) {
        final Set<b> d = d(e);
        final m$a a = b.c.a.a.i.m.a();
        a.b(e.c());
        a.c(e.a());
        return (b.c.a.a.g)new n(d, a.a(), (q)this);
    }
}
