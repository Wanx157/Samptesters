package b.c.a.a.i.w;

public interface c<TInput, TResult>
{
    TInput a(final TInput p0, final TResult p1);
}
