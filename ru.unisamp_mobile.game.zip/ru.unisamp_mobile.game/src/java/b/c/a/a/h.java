package b.c.a.a;

public interface h
{
    void a(final Exception p0);
}
