package b.c.a.a.i.x.j;

final class a extends d
{
    private final long b;
    private final int c;
    private final int d;
    private final long e;
    private final int f;
    
    private a(final long b, final int c, final int d, final long e, final int f) {
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    int b() {
        return this.d;
    }
    
    long c() {
        return this.e;
    }
    
    int d() {
        return this.c;
    }
    
    int e() {
        return this.f;
    }
    
    public boolean equals(final Object o) {
        boolean b = true;
        if (o == this) {
            return true;
        }
        if (o instanceof d) {
            final d d = (d)o;
            if (this.b != d.f() || this.c != d.d() || this.d != d.b() || this.e != d.c() || this.f != d.e()) {
                b = false;
            }
            return b;
        }
        return false;
    }
    
    long f() {
        return this.b;
    }
    
    public int hashCode() {
        final long b = this.b;
        final int n = (int)(b ^ b >>> 32);
        final int c = this.c;
        final int d = this.d;
        final long e = this.e;
        return this.f ^ ((((n ^ 0xF4243) * 1000003 ^ c) * 1000003 ^ d) * 1000003 ^ (int)(e ^ e >>> 32)) * 1000003;
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("EventStoreConfig{maxStorageSizeInBytes=");
        sb.append(this.b);
        sb.append(", loadBatchSize=");
        sb.append(this.c);
        sb.append(", criticalSectionEnterTimeoutMs=");
        sb.append(this.d);
        sb.append(", eventCleanUpAge=");
        sb.append(this.e);
        sb.append(", maxBlobByteSizePerRow=");
        sb.append(this.f);
        sb.append("}");
        return sb.toString();
    }
    
    static final class b extends d$a
    {
        private Long a;
        private Integer b;
        private Integer c;
        private Long d;
        private Integer e;
        
        d a() {
            final Long a = this.a;
            String string = "";
            if (a == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(" maxStorageSizeInBytes");
                string = sb.toString();
            }
            String string2 = string;
            if (this.b == null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append(" loadBatchSize");
                string2 = sb2.toString();
            }
            String string3 = string2;
            if (this.c == null) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append(string2);
                sb3.append(" criticalSectionEnterTimeoutMs");
                string3 = sb3.toString();
            }
            String string4 = string3;
            if (this.d == null) {
                final StringBuilder sb4 = new StringBuilder();
                sb4.append(string3);
                sb4.append(" eventCleanUpAge");
                string4 = sb4.toString();
            }
            String string5 = string4;
            if (this.e == null) {
                final StringBuilder sb5 = new StringBuilder();
                sb5.append(string4);
                sb5.append(" maxBlobByteSizePerRow");
                string5 = sb5.toString();
            }
            if (string5.isEmpty()) {
                return new a(this.a, this.b, this.c, this.d, this.e, null);
            }
            final StringBuilder sb6 = new StringBuilder();
            sb6.append("Missing required properties:");
            sb6.append(string5);
            throw new IllegalStateException(sb6.toString());
        }
        
        d$a b(final int n) {
            this.c = n;
            return this;
        }
        
        d$a c(final long n) {
            this.d = n;
            return this;
        }
        
        d$a d(final int n) {
            this.b = n;
            return this;
        }
        
        d$a e(final int n) {
            this.e = n;
            return this;
        }
        
        d$a f(final long n) {
            this.a = n;
            return this;
        }
    }
}
