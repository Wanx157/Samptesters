package b.c.a.a.i.x.j;

import c.a.a;
import b.c.a.a.i.u.a.b;

public final class c0 implements b<b0>
{
    private final a<b.c.a.a.i.z.a> a;
    private final a<b.c.a.a.i.z.a> b;
    private final a<d> c;
    private final a<h0> d;
    
    public c0(final a<b.c.a.a.i.z.a> a, final a<b.c.a.a.i.z.a> b, final a<d> c, final a<h0> d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public static c0 a(final a<b.c.a.a.i.z.a> a, final a<b.c.a.a.i.z.a> a2, final a<d> a3, final a<h0> a4) {
        return new c0(a, a2, a3, a4);
    }
    
    public static b0 c(final b.c.a.a.i.z.a a, final b.c.a.a.i.z.a a2, final Object o, final Object o2) {
        return new b0(a, a2, (d)o, (h0)o2);
    }
    
    public b0 b() {
        return c((b.c.a.a.i.z.a)this.a.get(), (b.c.a.a.i.z.a)this.b.get(), this.c.get(), this.d.get());
    }
}
