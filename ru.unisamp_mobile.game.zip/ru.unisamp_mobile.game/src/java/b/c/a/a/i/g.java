package b.c.a.a.i;

import java.util.Arrays;
import b.c.a.a.b;

public final class g
{
    private final b a;
    private final byte[] b;
    
    public g(final b a, final byte[] b) {
        if (a == null) {
            throw new NullPointerException("encoding is null");
        }
        if (b != null) {
            this.a = a;
            this.b = b;
            return;
        }
        throw new NullPointerException("bytes is null");
    }
    
    public byte[] a() {
        return this.b;
    }
    
    public b b() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof g)) {
            return false;
        }
        final g g = (g)o;
        return this.a.equals(g.a) && Arrays.equals(this.b, g.b);
    }
    
    @Override
    public int hashCode() {
        return (this.a.hashCode() ^ 0xF4243) * 1000003 ^ Arrays.hashCode(this.b);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("EncodedPayload{encoding=");
        sb.append((Object)this.a);
        sb.append(", bytes=[...]}");
        return sb.toString();
    }
}
