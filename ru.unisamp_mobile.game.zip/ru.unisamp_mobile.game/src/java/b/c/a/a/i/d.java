package b.c.a.a.i;

import com.google.android.datatransport.runtime.scheduling.jobscheduling.n;
import b.c.a.a.i.y.b;
import com.google.android.datatransport.runtime.backends.e;
import b.c.a.a.i.x.i;
import b.c.a.a.i.x.j.h0;
import b.c.a.a.i.x.j.c0;
import b.c.a.a.i.x.j.h;
import b.c.a.a.i.x.j.i0;
import b.c.a.a.i.x.j.f;
import com.google.android.datatransport.runtime.backends.l;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.q;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.m;
import b.c.a.a.i.x.c;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.g;
import b.c.a.a.i.x.j.b0;
import android.content.Context;
import java.util.concurrent.Executor;
import c.a.a;

final class d extends s
{
    private a<Executor> b;
    private a<Context> c;
    private a d;
    private a e;
    private a f;
    private a<b0> g;
    private a<g> h;
    private a<com.google.android.datatransport.runtime.scheduling.jobscheduling.s> i;
    private a<c> j;
    private a<m> k;
    private a<q> l;
    private a<r> m;
    
    private d(final Context context) {
        this.j(context);
    }
    
    public static s$a i() {
        return (s$a)new b(null);
    }
    
    private void j(final Context context) {
        this.b = b.c.a.a.i.u.a.a.a(b.c.a.a.i.j.a());
        final b.c.a.a.i.u.a.b<Context> a = b.c.a.a.i.u.a.c.a(context);
        this.c = (a<Context>)a;
        final com.google.android.datatransport.runtime.backends.j a2 = com.google.android.datatransport.runtime.backends.j.a((a)a, (a)b.c.a.a.i.z.c.a(), (a)b.c.a.a.i.z.d.a());
        this.d = (a)a2;
        this.e = b.c.a.a.i.u.a.a.a(com.google.android.datatransport.runtime.backends.l.a((a)this.c, (a)a2));
        this.f = (a)i0.a(this.c, (a<String>)b.c.a.a.i.x.j.f.a(), (a<Integer>)b.c.a.a.i.x.j.g.a());
        this.g = b.c.a.a.i.u.a.a.a(c0.a((a<b.c.a.a.i.z.a>)b.c.a.a.i.z.c.a(), (a<b.c.a.a.i.z.a>)b.c.a.a.i.z.d.a(), (a<b.c.a.a.i.x.j.d>)b.c.a.a.i.x.j.h.a(), (a<h0>)this.f));
        final b.c.a.a.i.x.g b = b.c.a.a.i.x.g.b((a<b.c.a.a.i.z.a>)b.c.a.a.i.z.c.a());
        this.h = (a<g>)b;
        final i a3 = b.c.a.a.i.x.i.a(this.c, (a<b.c.a.a.i.x.j.c>)this.g, (a<g>)b, (a<b.c.a.a.i.z.a>)b.c.a.a.i.z.d.a());
        this.i = (a<com.google.android.datatransport.runtime.scheduling.jobscheduling.s>)a3;
        final a<Executor> b2 = this.b;
        final a e = this.e;
        final a<b0> g = this.g;
        this.j = (a<c>)b.c.a.a.i.x.d.a(b2, (a<e>)e, (a<com.google.android.datatransport.runtime.scheduling.jobscheduling.s>)a3, (a<b.c.a.a.i.x.j.c>)g, (a<b.c.a.a.i.y.b>)g);
        final a<Context> c = this.c;
        final a e2 = this.e;
        final a<b0> g2 = this.g;
        this.k = (a<m>)n.a((a)c, e2, (a)g2, (a)this.i, (a)this.b, (a)g2, (a)b.c.a.a.i.z.c.a());
        final a<Executor> b3 = this.b;
        final a<b0> g3 = this.g;
        this.l = (a<q>)com.google.android.datatransport.runtime.scheduling.jobscheduling.r.a((a)b3, (a)g3, (a)this.i, (a)g3);
        this.m = b.c.a.a.i.u.a.a.a(t.a((a<b.c.a.a.i.z.a>)b.c.a.a.i.z.c.a(), (a<b.c.a.a.i.z.a>)b.c.a.a.i.z.d.a(), (a<b.c.a.a.i.x.e>)this.j, this.k, this.l));
    }
    
    b.c.a.a.i.x.j.c a() {
        return (b.c.a.a.i.x.j.c)this.g.get();
    }
    
    r d() {
        return (r)this.m.get();
    }
    
    private static final class b implements s$a
    {
        private Context a;
        
        public b a(final Context context) {
            b.c.a.a.i.u.a.d.b((Object)context);
            this.a = context;
            return this;
        }
        
        public s d() {
            b.c.a.a.i.u.a.d.a((Object)this.a, (Class)Context.class);
            return new d(this.a, null);
        }
    }
}
