package b.c.a.a.i.z;

public interface a
{
    long a();
}
