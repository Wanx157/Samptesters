package b.c.a.a.i.x.j;

import b.c.a.a.i.h;
import b.c.a.a.i.m;
import java.io.Closeable;

public interface c extends Closeable
{
    int b();
    
    void c(final Iterable<i> p0);
    
    long e(final m p0);
    
    boolean f(final m p0);
    
    Iterable<i> g(final m p0);
    
    void h(final Iterable<i> p0);
    
    void k(final m p0, final long p1);
    
    i l(final m p0, final h p1);
    
    Iterable<m> r();
}
