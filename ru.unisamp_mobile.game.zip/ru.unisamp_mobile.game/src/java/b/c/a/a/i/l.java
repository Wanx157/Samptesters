package b.c.a.a.i;

import com.google.auto.value.AutoValue$Builder;
import b.c.a.a.e;
import b.c.a.a.c;
import b.c.a.a.b;
import com.google.auto.value.AutoValue;

@AutoValue
abstract class l
{
    public static a a() {
        return (a)new b$b();
    }
    
    public abstract b b();
    
    abstract c<?> c();
    
    public byte[] d() {
        return this.e().a(this.c().b());
    }
    
    abstract e<?, byte[]> e();
    
    public abstract m f();
    
    public abstract String g();
    
    @AutoValue$Builder
    public abstract static class a
    {
        public abstract l a();
        
        abstract a b(final b p0);
        
        abstract a c(final c<?> p0);
        
        abstract a d(final e<?, byte[]> p0);
        
        public abstract a e(final m p0);
        
        public abstract a f(final String p0);
    }
}
