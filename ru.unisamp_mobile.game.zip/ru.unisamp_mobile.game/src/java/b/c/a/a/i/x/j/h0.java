package b.c.a.a.i.x.j;

import android.os.Build$VERSION;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase$CursorFactory;
import android.content.Context;
import java.util.Arrays;
import java.util.List;
import android.database.sqlite.SQLiteOpenHelper;

final class h0 extends SQLiteOpenHelper
{
    static int d = 4;
    private static final a e;
    private static final a f;
    private static final a g;
    private static final a h;
    private static final List<a> i;
    private final int b;
    private boolean c;
    
    static {
        e = d0.b();
        f = e0.b();
        g = f0.b();
        i = Arrays.asList((Object[])new a[] { h0.e, h0.f, h0.g, h = g0.b() });
    }
    
    h0(final Context context, final String s, final int b) {
        super(context, s, (SQLiteDatabase$CursorFactory)null, b);
        this.c = false;
        this.b = b;
    }
    
    private void a(final SQLiteDatabase sqLiteDatabase) {
        if (!this.c) {
            this.onConfigure(sqLiteDatabase);
        }
    }
    
    private void n(final SQLiteDatabase sqLiteDatabase, final int n) {
        this.a(sqLiteDatabase);
        this.o(sqLiteDatabase, 0, n);
    }
    
    private void o(final SQLiteDatabase sqLiteDatabase, int i, final int n) {
        if (n <= h0.i.size()) {
            while (i < n) {
                ((a)h0.i.get(i)).a(sqLiteDatabase);
                ++i;
            }
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Migration from ");
        sb.append(i);
        sb.append(" to ");
        sb.append(n);
        sb.append(" was requested, but cannot be performed. Only ");
        sb.append(h0.i.size());
        sb.append(" migrations are provided");
        throw new IllegalArgumentException(sb.toString());
    }
    
    public void onConfigure(final SQLiteDatabase sqLiteDatabase) {
        this.c = true;
        sqLiteDatabase.rawQuery("PRAGMA busy_timeout=0;", new String[0]).close();
        if (Build$VERSION.SDK_INT >= 16) {
            sqLiteDatabase.setForeignKeyConstraintsEnabled(true);
        }
    }
    
    public void onCreate(final SQLiteDatabase sqLiteDatabase) {
        this.n(sqLiteDatabase, this.b);
    }
    
    public void onDowngrade(final SQLiteDatabase sqLiteDatabase, final int n, final int n2) {
        sqLiteDatabase.execSQL("DROP TABLE events");
        sqLiteDatabase.execSQL("DROP TABLE event_metadata");
        sqLiteDatabase.execSQL("DROP TABLE transport_contexts");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS event_payloads");
        this.n(sqLiteDatabase, n2);
    }
    
    public void onOpen(final SQLiteDatabase sqLiteDatabase) {
        this.a(sqLiteDatabase);
    }
    
    public void onUpgrade(final SQLiteDatabase sqLiteDatabase, final int n, final int n2) {
        this.a(sqLiteDatabase);
        this.o(sqLiteDatabase, n, n2);
    }
    
    public interface a
    {
        void a(final SQLiteDatabase p0);
    }
}
