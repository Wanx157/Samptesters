package b.c.a.a.i.x.j;

import b.c.a.a.i.u.a.b;

public final class h implements b<d>
{
    public static h a() {
        return h.h$a.a();
    }
    
    public static d c() {
        final d c = e.c();
        b.c.a.a.i.u.a.d.c((Object)c, "Cannot return null from a non-@Nullable @Provides method");
        return c;
    }
    
    public d b() {
        return c();
    }
}
