package b.c.a.a.i.x.j;

import b.c.a.a.i.h;
import b.c.a.a.i.m;
import com.google.auto.value.AutoValue;

@AutoValue
public abstract class i
{
    public static i a(final long n, final m m, final h h) {
        return (i)new b(n, m, h);
    }
    
    public abstract h b();
    
    public abstract long c();
    
    public abstract m d();
}
