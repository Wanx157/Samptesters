package b.c.a.a.i.x;

import com.google.android.datatransport.runtime.scheduling.jobscheduling.e;
import android.os.Build$VERSION;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.s;
import b.c.a.a.i.z.a;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.g;
import b.c.a.a.i.x.j.c;
import android.content.Context;

public abstract class h
{
    static s a(final Context context, final c c, final g g, final a a) {
        if (Build$VERSION.SDK_INT >= 21) {
            return (s)new e(context, c, g);
        }
        return (s)new com.google.android.datatransport.runtime.scheduling.jobscheduling.a(context, c, a, g);
    }
}
