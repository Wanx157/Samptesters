package b.c.a.a.i.u.a;

import c.a.a;

public interface b<T> extends a<T>
{
}
