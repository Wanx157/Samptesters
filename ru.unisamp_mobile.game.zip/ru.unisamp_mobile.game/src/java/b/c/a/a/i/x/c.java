package b.c.a.a.i.x;

import b.c.a.a.i.h;
import b.c.a.a.i.m;
import b.c.a.a.i.r;
import b.c.a.a.i.y.b;
import java.util.concurrent.Executor;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.s;
import java.util.logging.Logger;

public class c implements e
{
    private static final Logger f;
    private final s a;
    private final Executor b;
    private final com.google.android.datatransport.runtime.backends.e c;
    private final b.c.a.a.i.x.j.c d;
    private final b e;
    
    static {
        f = Logger.getLogger(r.class.getName());
    }
    
    public c(final Executor b, final com.google.android.datatransport.runtime.backends.e c, final s a, final b.c.a.a.i.x.j.c d, final b e) {
        this.b = b;
        this.c = c;
        this.a = a;
        this.d = d;
        this.e = e;
    }
    
    public void a(final m m, final h h, final b.c.a.a.h h2) {
        this.b.execute(b.c.a.a.i.x.a.a(this, m, h2, h));
    }
}
