package b.c.a.a.i.z;

public abstract class b
{
    static a a() {
        return (a)new f();
    }
    
    static a b() {
        return (a)new e();
    }
}
