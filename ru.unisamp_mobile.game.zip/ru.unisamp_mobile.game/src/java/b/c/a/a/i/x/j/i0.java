package b.c.a.a.i.x.j;

import android.content.Context;
import c.a.a;
import b.c.a.a.i.u.a.b;

public final class i0 implements b<h0>
{
    private final a<Context> a;
    private final a<String> b;
    private final a<Integer> c;
    
    public i0(final a<Context> a, final a<String> b, final a<Integer> c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public static i0 a(final a<Context> a, final a<String> a2, final a<Integer> a3) {
        return new i0(a, a2, a3);
    }
    
    public static h0 c(final Context context, final String s, final int n) {
        return new h0(context, s, n);
    }
    
    public h0 b() {
        return c((Context)this.a.get(), (String)this.b.get(), (int)this.c.get());
    }
}
