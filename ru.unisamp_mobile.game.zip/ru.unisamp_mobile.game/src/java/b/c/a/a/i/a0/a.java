package b.c.a.a.i.a0;

import java.util.Iterator;
import java.util.HashMap;
import b.c.a.a.d;
import android.util.SparseArray;

public final class a
{
    private static SparseArray<d> a;
    private static HashMap<d, Integer> b;
    
    static {
        b.c.a.a.i.a0.a.a = (SparseArray<d>)new SparseArray();
        (b.c.a.a.i.a0.a.b = (HashMap<d, Integer>)new HashMap()).put((Object)d.b, (Object)0);
        b.c.a.a.i.a0.a.b.put((Object)d.c, (Object)1);
        b.c.a.a.i.a0.a.b.put((Object)d.d, (Object)2);
        for (final d d : b.c.a.a.i.a0.a.b.keySet()) {
            b.c.a.a.i.a0.a.a.append((int)b.c.a.a.i.a0.a.b.get((Object)d), (Object)d);
        }
    }
    
    public static int a(final d d) {
        final Integer n = (Integer)b.c.a.a.i.a0.a.b.get((Object)d);
        if (n != null) {
            return n;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("PriorityMapping is missing known Priority value ");
        sb.append((Object)d);
        throw new IllegalStateException(sb.toString());
    }
    
    public static d b(final int n) {
        final d d = (d)b.c.a.a.i.a0.a.a.get(n);
        if (d != null) {
            return d;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Unknown Priority for value ");
        sb.append(n);
        throw new IllegalArgumentException(sb.toString());
    }
}
