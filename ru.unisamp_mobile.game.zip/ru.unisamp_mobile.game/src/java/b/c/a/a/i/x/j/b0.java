package b.c.a.a.i.x.j;

import android.database.sqlite.SQLiteOpenHelper;
import b.c.a.a.i.y.b$a;
import java.util.ListIterator;
import java.util.Collection;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.os.SystemClock;
import android.util.Base64;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import java.util.Map$Entry;
import java.util.Arrays;
import android.content.ContentValues;
import java.util.HashSet;
import java.util.Map;
import b.c.a.a.i.h$a;
import b.c.a.a.i.g;
import b.c.a.a.i.h;
import android.database.sqlite.SQLiteDatabase;
import b.c.a.a.i.m$a;
import b.c.a.a.i.m;
import java.util.ArrayList;
import java.util.List;
import android.database.Cursor;
import b.c.a.a.i.z.a;
import b.c.a.a.i.y.b;

public class b0 implements c, b
{
    private static final b.c.a.a.b f;
    private final h0 b;
    private final a c;
    private final a d;
    private final d e;
    
    static {
        f = b.c.a.a.b.b("proto");
    }
    
    b0(final a c, final a d, final d e, final h0 b) {
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    private List<i> J(final SQLiteDatabase sqLiteDatabase, final m m) {
        final ArrayList list = new ArrayList();
        final Long o = this.o(sqLiteDatabase, m);
        if (o == null) {
            return (List<i>)list;
        }
        Q(sqLiteDatabase.query("events", new String[] { "_id", "transport_name", "timestamp_ms", "uptime_ms", "payload_encoding", "payload", "code", "inline" }, "context_id = ?", new String[] { o.toString() }, (String)null, (String)null, (String)null, String.valueOf(this.e.d())), (b0.b0$b<Cursor, Object>)n.b(this, (List)list, m));
        return (List<i>)list;
    }
    
    private Map<Long, Set<b0.b0$c>> K(final SQLiteDatabase sqLiteDatabase, final List<i> list) {
        final HashMap hashMap = new HashMap();
        final StringBuilder sb = new StringBuilder("event_id IN (");
        for (int i = 0; i < list.size(); ++i) {
            sb.append(((i)list.get(i)).c());
            if (i < list.size() - 1) {
                sb.append(',');
            }
        }
        sb.append(')');
        Q(sqLiteDatabase.query("event_metadata", new String[] { "event_id", "name", "value" }, sb.toString(), (String[])null, (String)null, (String)null, (String)null), (b0.b0$b<Cursor, Object>)p.b((Map)hashMap));
        return (Map<Long, Set<b0.b0$c>>)hashMap;
    }
    
    private static byte[] L(final String s) {
        if (s == null) {
            return null;
        }
        return Base64.decode(s, 0);
    }
    
    private byte[] M(final long n) {
        return Q(this.j().query("event_payloads", new String[] { "bytes" }, "event_id = ?", new String[] { String.valueOf(n) }, (String)null, (String)null, "sequence_num"), (b0.b0$b<Cursor, byte[]>)o.b());
    }
    
    private <T> T N(final b0.b0$d<T> b0$d, final b0.b0$b<Throwable, T> b0$b) {
        final long a = this.d.a();
        try {
            return (T)b0$d.a();
        }
        catch (final SQLiteDatabaseLockedException ex) {
            if (this.d.a() >= this.e.b() + a) {
                return (T)b0$b.a((Object)ex);
            }
            SystemClock.sleep(50L);
            return (T)b0$d.a();
        }
    }
    
    private static b.c.a.a.b O(final String s) {
        if (s == null) {
            return b0.f;
        }
        return b.c.a.a.b.b(s);
    }
    
    private static String P(final Iterable<i> iterable) {
        final StringBuilder sb = new StringBuilder("(");
        final Iterator iterator = iterable.iterator();
        while (iterator.hasNext()) {
            sb.append(((i)iterator.next()).c());
            if (iterator.hasNext()) {
                sb.append(',');
            }
        }
        sb.append(')');
        return sb.toString();
    }
    
    static <T> T Q(final Cursor cursor, final b0.b0$b<Cursor, T> b0$b) {
        try {
            return (T)b0$b.a((Object)cursor);
        }
        finally {
            cursor.close();
        }
    }
    
    private void d(final SQLiteDatabase sqLiteDatabase) {
        this.N((b0.b0$d<Object>)q.b(sqLiteDatabase), (b0.b0$b<Throwable, Object>)r.b());
    }
    
    private long i(final SQLiteDatabase sqLiteDatabase, final m m) {
        final Long o = this.o(sqLiteDatabase, m);
        if (o != null) {
            return o;
        }
        final ContentValues contentValues = new ContentValues();
        contentValues.put("backend_name", m.b());
        contentValues.put("priority", Integer.valueOf(b.c.a.a.i.a0.a.a(m.d())));
        contentValues.put("next_request_ms", Integer.valueOf(0));
        if (m.c() != null) {
            contentValues.put("extras", Base64.encodeToString(m.c(), 0));
        }
        return sqLiteDatabase.insert("transport_contexts", (String)null, contentValues);
    }
    
    private long m() {
        return this.j().compileStatement("PRAGMA page_count").simpleQueryForLong();
    }
    
    private long n() {
        return this.j().compileStatement("PRAGMA page_size").simpleQueryForLong();
    }
    
    private Long o(final SQLiteDatabase sqLiteDatabase, final m m) {
        final StringBuilder sb = new StringBuilder("backend_name = ? and priority = ?");
        final ArrayList list = new ArrayList((Collection)Arrays.asList((Object[])new String[] { m.b(), String.valueOf(b.c.a.a.i.a0.a.a(m.d())) }));
        if (m.c() != null) {
            sb.append(" and extras = ?");
            list.add((Object)Base64.encodeToString(m.c(), 0));
        }
        else {
            sb.append(" and extras is null");
        }
        return Q(sqLiteDatabase.query("transport_contexts", new String[] { "_id" }, sb.toString(), (String[])list.toArray((Object[])new String[0]), (String)null, (String)null, (String)null), (b0.b0$b<Cursor, Long>)x.b());
    }
    
    private boolean q() {
        return this.m() * this.n() >= this.e.f();
    }
    
    private List<i> s(final List<i> list, final Map<Long, Set<b0.b0$c>> map) {
        final ListIterator listIterator = list.listIterator();
        while (listIterator.hasNext()) {
            final i i = (i)listIterator.next();
            if (!map.containsKey((Object)i.c())) {
                continue;
            }
            final h$a l = i.b().l();
            for (final b0.b0$c b0$c : (Set)map.get((Object)i.c())) {
                l.c(b0$c.a, b0$c.b);
            }
            listIterator.set((Object)b.c.a.a.i.x.j.i.a(i.c(), i.d(), l.d()));
        }
        return list;
    }
    
    public <T> T a(final b$a<T> b$a) {
        final SQLiteDatabase j = this.j();
        this.d(j);
        try {
            final Object i = b$a.i();
            j.setTransactionSuccessful();
            return (T)i;
        }
        finally {
            j.endTransaction();
        }
    }
    
    public int b() {
        return this.p((b0.b0$b<SQLiteDatabase, Integer>)b.c.a.a.i.x.j.m.b(this.c.a() - this.e.c()));
    }
    
    public void c(final Iterable<i> iterable) {
        if (!iterable.iterator().hasNext()) {
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("DELETE FROM events WHERE _id in ");
        sb.append(P(iterable));
        this.j().compileStatement(sb.toString()).execute();
    }
    
    public void close() {
        ((SQLiteOpenHelper)this.b).close();
    }
    
    public long e(final m m) {
        return Q(this.j().rawQuery("SELECT next_request_ms FROM transport_contexts WHERE backend_name = ? and priority = ?", new String[] { m.b(), String.valueOf(b.c.a.a.i.a0.a.a(m.d())) }), (b0.b0$b<Cursor, Long>)z.b());
    }
    
    public boolean f(final m m) {
        return this.p((b0.b0$b<SQLiteDatabase, Boolean>)a0.b(this, m));
    }
    
    public Iterable<i> g(final m m) {
        return (Iterable<i>)this.p((b0.b0$b<SQLiteDatabase, Iterable>)k.b(this, m));
    }
    
    public void h(final Iterable<i> iterable) {
        if (!iterable.iterator().hasNext()) {
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("UPDATE events SET num_attempts = num_attempts + 1 WHERE _id in ");
        sb.append(P(iterable));
        this.p((b0.b0$b<SQLiteDatabase, Object>)y.b(sb.toString()));
    }
    
    SQLiteDatabase j() {
        final h0 b = this.b;
        b.getClass();
        return this.N((b0.b0$d<SQLiteDatabase>)s.b(b), (b0.b0$b<Throwable, SQLiteDatabase>)v.b());
    }
    
    public void k(final m m, final long n) {
        this.p((b0.b0$b<SQLiteDatabase, Object>)j.b(n, m));
    }
    
    public i l(final m m, final h h) {
        b.c.a.a.i.v.a.b("SQLiteEventStore", "Storing event with priority=%s, name=%s for destination %s", new Object[] { m.d(), h.j(), m.b() });
        final long longValue = this.p((b0.b0$b<SQLiteDatabase, Long>)w.b(this, m, h));
        if (longValue < 1L) {
            return null;
        }
        return i.a(longValue, m, h);
    }
    
     <T> T p(final b0.b0$b<SQLiteDatabase, T> b0$b) {
        final SQLiteDatabase j = this.j();
        j.beginTransaction();
        try {
            final Object a = b0$b.a((Object)j);
            j.setTransactionSuccessful();
            return (T)a;
        }
        finally {
            j.endTransaction();
        }
    }
    
    public Iterable<m> r() {
        return (Iterable<m>)this.p((b0.b0$b<SQLiteDatabase, Iterable>)l.b());
    }
}
