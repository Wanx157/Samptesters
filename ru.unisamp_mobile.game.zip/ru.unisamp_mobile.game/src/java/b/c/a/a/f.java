package b.c.a.a;

public interface f<T>
{
    void a(final c<T> p0);
    
    void b(final c<T> p0, final h p1);
}
