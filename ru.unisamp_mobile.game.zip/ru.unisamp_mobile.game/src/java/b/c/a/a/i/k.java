package b.c.a.a.i;

import b.c.a.a.i.v.a;
import java.util.concurrent.Executor;

class k implements Executor
{
    private final Executor a;
    
    k(final Executor a) {
        this.a = a;
    }
    
    public void execute(final Runnable runnable) {
        this.a.execute((Runnable)new a(runnable));
    }
    
    static class a implements Runnable
    {
        private final Runnable b;
        
        a(final Runnable b) {
            this.b = b;
        }
        
        public void run() {
            try {
                this.b.run();
            }
            catch (final Exception ex) {
                b.c.a.a.i.v.a.c("Executor", "Background execution failure.", (Throwable)ex);
            }
        }
    }
}
