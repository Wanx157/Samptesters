package b.c.a.a;

public interface g
{
     <T> f<T> a(final String p0, final Class<T> p1, final b p2, final e<T, byte[]> p3);
}
