package b.c.a.a.i.z;

import android.os.SystemClock;

public class e implements a
{
    public long a() {
        return SystemClock.elapsedRealtime();
    }
}
