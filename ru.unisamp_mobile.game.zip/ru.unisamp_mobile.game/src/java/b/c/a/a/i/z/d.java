package b.c.a.a.i.z;

import b.c.a.a.i.u.a.b;

public final class d implements b<a>
{
    public static d a() {
        return d.d$a.a();
    }
    
    public static a c() {
        final a b = b.c.a.a.i.z.b.b();
        b.c.a.a.i.u.a.d.c((Object)b, "Cannot return null from a non-@Nullable @Provides method");
        return b;
    }
    
    public a b() {
        return c();
    }
}
