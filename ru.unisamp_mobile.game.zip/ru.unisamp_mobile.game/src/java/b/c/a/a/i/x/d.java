package b.c.a.a.i.x;

import com.google.android.datatransport.runtime.scheduling.jobscheduling.s;
import com.google.android.datatransport.runtime.backends.e;
import java.util.concurrent.Executor;
import c.a.a;
import b.c.a.a.i.u.a.b;

public final class d implements b<c>
{
    private final a<Executor> a;
    private final a<e> b;
    private final a<s> c;
    private final a<b.c.a.a.i.x.j.c> d;
    private final a<b.c.a.a.i.y.b> e;
    
    public d(final a<Executor> a, final a<e> b, final a<s> c, final a<b.c.a.a.i.x.j.c> d, final a<b.c.a.a.i.y.b> e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public static d a(final a<Executor> a, final a<e> a2, final a<s> a3, final a<b.c.a.a.i.x.j.c> a4, final a<b.c.a.a.i.y.b> a5) {
        return new d(a, a2, a3, a4, a5);
    }
    
    public static c c(final Executor executor, final e e, final s s, final b.c.a.a.i.x.j.c c, final b.c.a.a.i.y.b b) {
        return new c(executor, e, s, c, b);
    }
    
    public c b() {
        return c((Executor)this.a.get(), (e)this.b.get(), (s)this.c.get(), (b.c.a.a.i.x.j.c)this.d.get(), (b.c.a.a.i.y.b)this.e.get());
    }
}
