package b.c.a.a.i.x.j;

import b.c.a.a.i.u.a.d;
import b.c.a.a.i.u.a.b;

public final class f implements b<String>
{
    public static f a() {
        return f.f$a.a();
    }
    
    public static String b() {
        final String a = e.a();
        d.c((Object)a, "Cannot return null from a non-@Nullable @Provides method");
        return a;
    }
    
    public String c() {
        return b();
    }
}
