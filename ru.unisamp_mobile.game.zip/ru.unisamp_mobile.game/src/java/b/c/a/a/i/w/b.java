package b.c.a.a.i.w;

public final class b
{
    public static <TInput, TResult, TException extends Throwable> TResult a(int n, final TInput tInput, final a<TInput, TResult, TException> a, final c<TInput, TResult> c) throws TException {
        int n2 = n;
        TInput a2 = tInput;
        if (n < 1) {
            return a.a(tInput);
        }
        TResult a3;
        do {
            a3 = a.a(a2);
            a2 = c.a(a2, a3);
            if (a2 == null) {
                break;
            }
            n = n2 - 1;
        } while ((n2 = n) >= 1);
        return a3;
    }
}
