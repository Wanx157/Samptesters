package b.c.a.a.i;

public interface e
{
    byte[] a();
    
    String c();
}
