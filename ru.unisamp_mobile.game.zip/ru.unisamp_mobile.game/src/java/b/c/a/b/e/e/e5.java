package b.c.a.b.e.e;

import java.util.Locale;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.io.Serializable;

public abstract class e5 implements Iterable<Byte>, Serializable
{
    public static final e5 c;
    private int b;
    
    static {
        c = (e5)new d5(l6.b);
        final int a = t4.a;
    }
    
    e5() {
        this.b = 0;
    }
    
    public static e5 p(final byte[] array, final int n, final int n2) {
        u(n, n + n2, array.length);
        final byte[] array2 = new byte[n2];
        System.arraycopy((Object)array, n, (Object)array2, 0, n2);
        return (e5)new d5(array2);
    }
    
    public static e5 q(final String s) {
        return (e5)new d5(s.getBytes(l6.a));
    }
    
    static int u(final int n, final int n2, final int n3) {
        final int n4 = n2 - n;
        if ((n | n2 | n4 | n3 - n2) >= 0) {
            return n4;
        }
        if (n < 0) {
            final StringBuilder sb = new StringBuilder(32);
            sb.append("Beginning index: ");
            sb.append(n);
            sb.append(" < 0");
            throw new IndexOutOfBoundsException(sb.toString());
        }
        if (n2 < n) {
            final StringBuilder sb2 = new StringBuilder(66);
            sb2.append("Beginning index larger than ending index: ");
            sb2.append(n);
            sb2.append(", ");
            sb2.append(n2);
            throw new IndexOutOfBoundsException(sb2.toString());
        }
        final StringBuilder sb3 = new StringBuilder(37);
        sb3.append("End index: ");
        sb3.append(n2);
        sb3.append(" >= ");
        sb3.append(n3);
        throw new IndexOutOfBoundsException(sb3.toString());
    }
    
    public abstract byte c(final int p0);
    
    abstract byte d(final int p0);
    
    @Override
    public abstract boolean equals(final Object p0);
    
    public abstract int h();
    
    @Override
    public final int hashCode() {
        int b;
        if ((b = this.b) == 0) {
            final int h = this.h();
            if ((b = this.o(h, 0, h)) == 0) {
                b = 1;
            }
            this.b = b;
        }
        return b;
    }
    
    public abstract e5 i(final int p0, final int p1);
    
    abstract void j(final x4 p0);
    
    protected abstract String m(final Charset p0);
    
    public abstract boolean n();
    
    protected abstract int o(final int p0, final int p1, final int p2);
    
    public final String r(final Charset charset) {
        String m;
        if (this.h() == 0) {
            m = "";
        }
        else {
            m = this.m(charset);
        }
        return m;
    }
    
    protected final int s() {
        return this.b;
    }
    
    @Override
    public final String toString() {
        final Locale root = Locale.ROOT;
        final String hexString = Integer.toHexString(System.identityHashCode((Object)this));
        final int h = this.h();
        String s;
        if (this.h() <= 50) {
            s = g8.a(this);
        }
        else {
            s = String.valueOf((Object)g8.a(this.i(0, 47))).concat("...");
        }
        return String.format(root, "<ByteString@%s size=%d contents=\"%s\">", new Object[] { hexString, h, s });
    }
}
