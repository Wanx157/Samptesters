package b.c.a.b.e.e;

public interface ha
{
    boolean a();
    
    boolean b();
    
    boolean c();
    
    boolean d();
}
