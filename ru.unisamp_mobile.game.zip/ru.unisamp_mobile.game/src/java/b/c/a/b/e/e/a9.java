package b.c.a.b.e.e;

public enum a9
{
    c((Object)0), 
    d((Object)0L), 
    e((Object)0.0f), 
    f((Object)0.0), 
    g((Object)Boolean.FALSE), 
    h((Object)""), 
    i((Object)e5.c), 
    j((Object)null), 
    k((Object)null);
    
    private static final a9[] l;
    private final Object b;
    
    private a9(final Object b) {
        this.b = b;
    }
}
