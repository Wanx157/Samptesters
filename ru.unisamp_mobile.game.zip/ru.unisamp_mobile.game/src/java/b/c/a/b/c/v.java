package b.c.a.b.c;

import android.util.Log;
import com.google.android.gms.common.util.k;
import com.google.android.gms.common.util.a;
import java.util.concurrent.Callable;
import javax.annotation.Nullable;
import javax.annotation.CheckReturnValue;

@CheckReturnValue
class v
{
    private static final v d;
    final boolean a;
    @Nullable
    private final String b;
    @Nullable
    private final Throwable c;
    
    static {
        d = new v(true, null, null);
    }
    
    v(final boolean a, @Nullable final String b, @Nullable final Throwable c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    static v a() {
        return v.d;
    }
    
    static v b(final String s) {
        return new v(false, s, null);
    }
    
    static v c(final String s, final Throwable t) {
        return new v(false, s, t);
    }
    
    static v d(final Callable<String> callable) {
        return (v)new x((Callable)callable, (y)null);
    }
    
    static String e(final String s, final n n, final boolean b, final boolean b2) {
        String s2;
        if (b2) {
            s2 = "debug cert rejected";
        }
        else {
            s2 = "not whitelisted";
        }
        return String.format("%s: pkg=%s, sha1=%s, atk=%s, ver=%s", new Object[] { s2, s, k.a(a.b("SHA-1").digest(n.P())), b, "12451009.false" });
    }
    
    @Nullable
    String f() {
        return this.b;
    }
    
    final void g() {
        if (!this.a && Log.isLoggable("GoogleCertificatesRslt", 3)) {
            if (this.c != null) {
                Log.d("GoogleCertificatesRslt", this.f(), this.c);
                return;
            }
            Log.d("GoogleCertificatesRslt", this.f());
        }
    }
}
