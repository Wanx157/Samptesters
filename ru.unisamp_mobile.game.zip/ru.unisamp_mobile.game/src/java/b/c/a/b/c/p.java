package b.c.a.b.c;

import java.lang.ref.WeakReference;

abstract class p extends n
{
    private static final WeakReference<byte[]> c;
    private WeakReference<byte[]> b;
    
    static {
        c = new WeakReference((Object)null);
    }
    
    p(final byte[] array) {
        super(array);
        this.b = p.c;
    }
    
    final byte[] P() {
        synchronized (this) {
            byte[] r;
            if ((r = (byte[])this.b.get()) == null) {
                r = this.R();
                this.b = (WeakReference<byte[]>)new WeakReference((Object)r);
            }
            return r;
        }
    }
    
    protected abstract byte[] R();
}
