package b.c.a.b.e.e;

public interface fc
{
    boolean a();
}
