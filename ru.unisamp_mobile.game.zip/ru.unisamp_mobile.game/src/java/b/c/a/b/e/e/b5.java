package b.c.a.b.e.e;

import java.util.Iterator;

public interface b5 extends Iterator<Byte>
{
    byte a();
}
