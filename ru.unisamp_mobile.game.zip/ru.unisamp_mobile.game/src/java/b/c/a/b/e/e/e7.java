package b.c.a.b.e.e;

final class e7
{
    private static final d7 a;
    private static final d7 b;
    
    static {
        d7 a2;
        try {
            a2 = (d7)Class.forName("com.google.protobuf.MapFieldSchemaFull").getDeclaredConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
        }
        catch (final Exception ex) {
            a2 = null;
        }
        a = a2;
        b = new d7();
    }
    
    static d7 a() {
        return e7.a;
    }
    
    static d7 b() {
        return e7.b;
    }
}
