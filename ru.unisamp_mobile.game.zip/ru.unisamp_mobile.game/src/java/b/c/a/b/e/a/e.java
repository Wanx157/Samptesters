package b.c.a.b.e.a;

import android.os.IInterface;
import android.os.IBinder;

public abstract class e extends b implements d
{
    public static d N(final IBinder binder) {
        if (binder == null) {
            return null;
        }
        final IInterface queryLocalInterface = binder.queryLocalInterface("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        if (queryLocalInterface instanceof d) {
            return (d)queryLocalInterface;
        }
        return (d)new f(binder);
    }
}
