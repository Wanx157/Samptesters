package b.c.a.b.c;

import java.util.Arrays;

final class q extends n
{
    private final byte[] b;
    
    q(final byte[] b) {
        super(Arrays.copyOfRange(b, 0, 25));
        this.b = b;
    }
    
    final byte[] P() {
        return this.b;
    }
}
