package b.c.a.b.e.e;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class b implements Parcelable$Creator<ed>
{
}
