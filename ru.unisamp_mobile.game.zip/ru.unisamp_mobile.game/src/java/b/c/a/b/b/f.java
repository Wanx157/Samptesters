package b.c.a.b.b;

import android.content.Intent;
import com.google.android.gms.common.internal.l.b;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class f implements Parcelable$Creator<a>
{
}
