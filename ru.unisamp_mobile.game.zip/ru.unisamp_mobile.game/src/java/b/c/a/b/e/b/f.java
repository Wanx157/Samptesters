package b.c.a.b.e.b;

public final class f
{
    public static final enum int a = 1;
    public static final enum int b = 2;
}
