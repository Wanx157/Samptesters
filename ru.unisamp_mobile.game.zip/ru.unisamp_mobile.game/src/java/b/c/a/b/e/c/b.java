package b.c.a.b.e.c;

import android.os.Parcel;
import android.os.IBinder;
import android.os.IInterface;

public class b implements IInterface
{
    private final IBinder a;
    private final String b;
    
    protected b(final IBinder a, final String b) {
        this.a = a;
        this.b = b;
    }
    
    protected final Parcel N() {
        final Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken(this.b);
        return obtain;
    }
    
    protected final Parcel O(final int n, final Parcel parcel) {
        final Parcel obtain = Parcel.obtain();
        try {
            try {
                this.a.transact(n, parcel, obtain, 0);
                obtain.readException();
                parcel.recycle();
                return obtain;
            }
            finally {}
        }
        catch (final RuntimeException ex) {
            final Parcel parcel2;
            parcel2.recycle();
            throw ex;
        }
        parcel.recycle();
    }
    
    public IBinder asBinder() {
        return this.a;
    }
}
