package b.c.a.b.c;

import android.content.Context;

public class d
{
    public static final int a;
    private static final d b;
    
    static {
        a = f.a;
        b = new d();
    }
    
    d() {
    }
    
    public static d b() {
        return d.b;
    }
    
    public int a(final Context context) {
        return f.a(context);
    }
    
    public int c(final Context context, int d) {
        if (f.e(context, d = f.d(context, d))) {
            d = 18;
        }
        return d;
    }
}
