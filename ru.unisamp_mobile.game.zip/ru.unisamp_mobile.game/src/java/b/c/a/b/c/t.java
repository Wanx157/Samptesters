package b.c.a.b.c;

import com.google.android.gms.common.internal.l.c;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import b.c.a.b.d.b;
import com.google.android.gms.common.internal.x;
import android.os.IBinder;
import javax.annotation.Nullable;
import android.os.Parcelable$Creator;
import com.google.android.gms.common.internal.l.a;

public final class t extends a
{
    public static final Parcelable$Creator<t> CREATOR;
    private final String b;
    @Nullable
    private final n c;
    private final boolean d;
    private final boolean e;
    
    static {
        CREATOR = (Parcelable$Creator)new w();
    }
    
    t(final String b, @Nullable final IBinder binder, final boolean d, final boolean e) {
        this.b = b;
        this.c = c(binder);
        this.d = d;
        this.e = e;
    }
    
    t(final String b, @Nullable final n c, final boolean d, final boolean e) {
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    @Nullable
    private static n c(@Nullable final IBinder binder) {
        final n n = null;
        if (binder == null) {
            return null;
        }
        try {
            final b.c.a.b.d.a b = x.O(binder).b();
            byte[] array;
            if (b == null) {
                array = null;
            }
            else {
                array = b.c.a.b.d.b.P(b);
            }
            Object o;
            if (array != null) {
                o = new q(array);
            }
            else {
                Log.e("GoogleCertificatesQuery", "Could not unwrap certificate");
                o = n;
            }
            return (n)o;
        }
        catch (final RemoteException ex) {
            Log.e("GoogleCertificatesQuery", "Could not unwrap certificate", (Throwable)ex);
            return null;
        }
    }
    
    public final void writeToParcel(final Parcel parcel, int a) {
        a = com.google.android.gms.common.internal.l.c.a(parcel);
        com.google.android.gms.common.internal.l.c.n(parcel, 1, this.b, false);
        Object c = this.c;
        if (c == null) {
            Log.w("GoogleCertificatesQuery", "certificate binder is null");
            c = null;
        }
        else {
            ((b.c.a.b.e.c.a)c).asBinder();
        }
        com.google.android.gms.common.internal.l.c.i(parcel, 2, (IBinder)c, false);
        com.google.android.gms.common.internal.l.c.c(parcel, 3, this.d);
        com.google.android.gms.common.internal.l.c.c(parcel, 4, this.e);
        com.google.android.gms.common.internal.l.c.b(parcel, a);
    }
}
