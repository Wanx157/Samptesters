package b.c.a.b.c;

import java.util.Iterator;
import android.content.pm.PackageInstaller$SessionInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import com.google.android.gms.common.util.t;
import com.google.android.gms.common.util.p;
import android.annotation.TargetApi;
import android.os.Bundle;
import android.os.UserManager;
import com.google.android.gms.common.util.m;
import com.google.android.gms.common.internal.b0;
import android.content.pm.PackageInfo;
import com.google.android.gms.common.util.j;
import b.c.a.b.c.j.c;
import android.content.pm.PackageManager$NameNotFoundException;
import android.util.Log;
import android.content.Context;
import java.util.concurrent.atomic.AtomicBoolean;

public class f
{
    @Deprecated
    public static final int a = 12451000;
    private static boolean b;
    private static boolean c;
    private static final AtomicBoolean d;
    
    static {
        new AtomicBoolean();
        d = new AtomicBoolean();
    }
    
    @Deprecated
    public static int a(final Context context) {
        try {
            return context.getPackageManager().getPackageInfo("com.google.android.gms", 0).versionCode;
        }
        catch (final PackageManager$NameNotFoundException ex) {
            Log.w("GooglePlayServicesUtil", "Google Play services is missing.");
            return 0;
        }
    }
    
    public static Context b(Context packageContext) {
        try {
            packageContext = packageContext.createPackageContext("com.google.android.gms", 3);
            return packageContext;
        }
        catch (final PackageManager$NameNotFoundException ex) {
            return null;
        }
    }
    
    public static boolean c(final Context context) {
        if (!f.c) {
            try {
                try {
                    final PackageInfo d = b.c.a.b.c.j.c.a(context).d("com.google.android.gms", 64);
                    g.a(context);
                    if (d != null && !g.f(d, false) && g.f(d, true)) {
                        f.b = true;
                    }
                    f.b = false;
                }
                finally {}
            }
            catch (final PackageManager$NameNotFoundException ex) {
                Log.w("GooglePlayServicesUtil", "Cannot find Google Play services package name.", (Throwable)ex);
            }
            f.c = true;
            return f.b || !j.a();
            f.c = true;
        }
        return f.b || !j.a();
    }
    
    @Deprecated
    public static int d(final Context context, int a) {
        try {
            context.getResources().getString(h.common_google_play_services_unknown_issue);
        }
        finally {
            Log.e("GooglePlayServicesUtil", "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included.");
        }
        if (!"com.google.android.gms".equals((Object)context.getPackageName()) && !f.d.get()) {
            final int a2 = b0.a(context);
            if (a2 == 0) {
                throw new IllegalStateException("A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />");
            }
            if (a2 != f.a) {
                a = f.a;
                final StringBuilder sb = new StringBuilder(320);
                sb.append("The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected ");
                sb.append(a);
                sb.append(" but found ");
                sb.append(a2);
                sb.append(".  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />");
                throw new IllegalStateException(sb.toString());
            }
        }
        return h(context, !j.d(context) && !j.e(context), a);
    }
    
    @Deprecated
    public static boolean e(final Context context, final int n) {
        return n == 18 || (n == 1 && i(context, "com.google.android.gms"));
    }
    
    @TargetApi(18)
    public static boolean f(final Context context) {
        if (m.c()) {
            final Bundle applicationRestrictions = ((UserManager)context.getSystemService("user")).getApplicationRestrictions(context.getPackageName());
            if (applicationRestrictions != null && "true".equals((Object)applicationRestrictions.getString("restricted_profile"))) {
                return true;
            }
        }
        return false;
    }
    
    @Deprecated
    @TargetApi(19)
    public static boolean g(final Context context, final int n, final String s) {
        return p.b(context, n, s);
    }
    
    private static int h(final Context context, final boolean b, final int n) {
        com.google.android.gms.common.internal.j.a(n >= 0);
        final String packageName = context.getPackageName();
        final PackageManager packageManager = context.getPackageManager();
        PackageInfo packageInfo = null;
        Label_0078: {
            if (!b) {
                break Label_0078;
            }
            String s;
            String s2;
            try {
                packageInfo = packageManager.getPackageInfo("com.android.vending", 8256);
                break Label_0078;
            }
            catch (final PackageManager$NameNotFoundException ex) {
                s = String.valueOf((Object)packageName);
                s2 = " requires the Google Play Store, but it is missing.";
            }
            while (true) {
                Log.w("GooglePlayServicesUtil", s.concat(s2));
                return 9;
                try {
                    final PackageInfo packageInfo2 = packageManager.getPackageInfo("com.google.android.gms", 64);
                    g.a(context);
                    if (!g.f(packageInfo2, true)) {
                        s = String.valueOf((Object)packageName);
                        s2 = " requires Google Play services, but their signature is invalid.";
                        continue;
                    }
                    if (b) {
                        com.google.android.gms.common.internal.j.h((Object)packageInfo);
                        if (!g.f(packageInfo, true) || !packageInfo.signatures[0].equals((Object)packageInfo2.signatures[0])) {
                            s = String.valueOf((Object)packageName);
                            s2 = " requires Google Play Store, but its signature is invalid.";
                            continue;
                        }
                    }
                    if (t.a(packageInfo2.versionCode) < t.a(n)) {
                        final int versionCode = packageInfo2.versionCode;
                        final StringBuilder sb = new StringBuilder(String.valueOf((Object)packageName).length() + 82);
                        sb.append("Google Play services out of date for ");
                        sb.append(packageName);
                        sb.append(".  Requires ");
                        sb.append(n);
                        sb.append(" but found ");
                        sb.append(versionCode);
                        Log.w("GooglePlayServicesUtil", sb.toString());
                        return 2;
                    }
                    ApplicationInfo applicationInfo;
                    if ((applicationInfo = packageInfo2.applicationInfo) == null) {
                        try {
                            applicationInfo = packageManager.getApplicationInfo("com.google.android.gms", 0);
                        }
                        catch (final PackageManager$NameNotFoundException ex2) {
                            Log.wtf("GooglePlayServicesUtil", String.valueOf((Object)packageName).concat(" requires Google Play services, but they're missing when getting application info."), (Throwable)ex2);
                            return 1;
                        }
                    }
                    if (!applicationInfo.enabled) {
                        return 3;
                    }
                    return 0;
                }
                catch (final PackageManager$NameNotFoundException ex3) {
                    Log.w("GooglePlayServicesUtil", String.valueOf((Object)packageName).concat(" requires Google Play services, but they are missing."));
                    return 1;
                }
                break;
            }
        }
    }
    
    @TargetApi(21)
    static boolean i(final Context context, final String s) {
        final boolean equals = s.equals((Object)"com.google.android.gms");
        if (m.f()) {
            try {
                final Iterator iterator = context.getPackageManager().getPackageInstaller().getAllSessions().iterator();
                while (iterator.hasNext()) {
                    if (s.equals((Object)((PackageInstaller$SessionInfo)iterator.next()).getAppPackageName())) {
                        return true;
                    }
                }
            }
            catch (final Exception ex) {
                return false;
            }
        }
        final PackageManager packageManager = context.getPackageManager();
        try {
            final ApplicationInfo applicationInfo = packageManager.getApplicationInfo(s, 8192);
            if (equals) {
                return applicationInfo.enabled;
            }
            if (applicationInfo.enabled && !f(context)) {
                return true;
            }
            return false;
        }
        catch (final PackageManager$NameNotFoundException ex2) {
            return false;
        }
    }
}
