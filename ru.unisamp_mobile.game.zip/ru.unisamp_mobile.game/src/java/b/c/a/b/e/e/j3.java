package b.c.a.b.e.e;

import javax.annotation.Nullable;
import android.net.Uri;
import java.util.Map;

public final class j3
{
    private final Map<String, Map<String, String>> a;
    
    j3(final Map<String, Map<String, String>> a) {
        this.a = a;
    }
    
    @Nullable
    public final String a(@Nullable final Uri uri, @Nullable final String s, @Nullable final String s2, final String s3) {
        if (uri == null) {
            return null;
        }
        final Map map = (Map)this.a.get((Object)uri.toString());
        if (map == null) {
            return null;
        }
        final String value = String.valueOf((Object)s3);
        String concat;
        if (value.length() != 0) {
            concat = "".concat(value);
        }
        else {
            concat = new String("");
        }
        return (String)map.get((Object)concat);
    }
}
