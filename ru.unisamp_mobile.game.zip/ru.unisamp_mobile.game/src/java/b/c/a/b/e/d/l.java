package b.c.a.b.e.d;

final class l extends i
{
    private final k a;
    
    l() {
        this.a = new k();
    }
    
    public final void a(final Throwable t, final Throwable t2) {
        if (t2 != t) {
            this.a.a(t, true).add((Object)t2);
            return;
        }
        throw new IllegalArgumentException("Self suppression is not allowed.", t2);
    }
}
