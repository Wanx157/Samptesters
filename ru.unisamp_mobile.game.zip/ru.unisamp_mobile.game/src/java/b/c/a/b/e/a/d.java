package b.c.a.b.e.a;

import android.os.IInterface;

public interface d extends IInterface
{
    String d();
    
    boolean j(final boolean p0);
}
