package b.c.a.b.c;

import android.os.Parcel;
import com.google.android.gms.common.internal.i$a;
import com.google.android.gms.common.internal.i;
import android.os.Parcelable$Creator;
import com.google.android.gms.common.internal.l.a;

public class c extends a
{
    public static final Parcelable$Creator<c> CREATOR;
    private final String b;
    @Deprecated
    private final int c;
    private final long d;
    
    static {
        CREATOR = (Parcelable$Creator)new l();
    }
    
    public c(final String b, final int c, final long d) {
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public String c() {
        return this.b;
    }
    
    public long d() {
        long d;
        if ((d = this.d) == -1L) {
            d = this.c;
        }
        return d;
    }
    
    public boolean equals(final Object o) {
        if (o instanceof c) {
            final c c = (c)o;
            if (((this.c() != null && this.c().equals((Object)c.c())) || (this.c() == null && c.c() == null)) && this.d() == c.d()) {
                return true;
            }
        }
        return false;
    }
    
    public int hashCode() {
        return i.b(new Object[] { this.c(), this.d() });
    }
    
    public String toString() {
        final i$a c = i.c((Object)this);
        c.a("name", (Object)this.c());
        c.a("version", (Object)this.d());
        return c.toString();
    }
    
    public void writeToParcel(final Parcel parcel, int a) {
        a = com.google.android.gms.common.internal.l.c.a(parcel);
        com.google.android.gms.common.internal.l.c.n(parcel, 1, this.c(), false);
        com.google.android.gms.common.internal.l.c.j(parcel, 2, this.c);
        com.google.android.gms.common.internal.l.c.k(parcel, 3, this.d());
        com.google.android.gms.common.internal.l.c.b(parcel, a);
    }
}
