package b.c.a.b.e.e;

interface f7
{
    boolean a();
    
    i7 b();
    
    int c();
}
