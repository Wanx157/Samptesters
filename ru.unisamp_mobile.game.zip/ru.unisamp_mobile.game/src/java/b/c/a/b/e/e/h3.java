package b.c.a.b.e.e;

import android.os.Handler;
import android.database.ContentObserver;

final class h3 extends ContentObserver
{
    h3(final i3 i3, final Handler handler) {
        super((Handler)null);
    }
    
    public final void onChange(final boolean b) {
        v3.c();
    }
}
