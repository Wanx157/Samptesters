package b.c.a.b.e.e;

public interface j7
{
    i7 a();
}
