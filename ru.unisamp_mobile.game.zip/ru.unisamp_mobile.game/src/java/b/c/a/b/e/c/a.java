package b.c.a.b.e.c;

import android.os.IBinder;
import android.os.Parcel;
import android.os.IInterface;
import android.os.Binder;

public class a extends Binder implements IInterface
{
    protected a(final String s) {
        this.attachInterface((IInterface)this, s);
    }
    
    protected boolean N(final int n, final Parcel parcel, final Parcel parcel2, final int n2) {
        return false;
    }
    
    public IBinder asBinder() {
        return (IBinder)this;
    }
    
    public boolean onTransact(final int n, final Parcel parcel, final Parcel parcel2, final int n2) {
        boolean onTransact;
        if (n > 16777215) {
            onTransact = super.onTransact(n, parcel, parcel2, n2);
        }
        else {
            parcel.enforceInterface(this.getInterfaceDescriptor());
            onTransact = false;
        }
        return onTransact || this.N(n, parcel, parcel2, n2);
    }
}
