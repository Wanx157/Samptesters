package b.c.a.b.e.e;

import java.util.Map$Entry;

final class b8 implements Map$Entry, Comparable<b8>
{
    private final Comparable b;
    private Object c;
    final e8 d;
    
    b8(final e8 d, final Comparable b, final Object c) {
        this.d = d;
        this.b = b;
        this.c = c;
    }
    
    private static final boolean e(final Object o, final Object obj) {
        boolean equals;
        if (o == null) {
            if (obj == null) {
                return true;
            }
            equals = false;
        }
        else {
            equals = o.equals(obj);
        }
        return equals;
    }
    
    public final Comparable d() {
        return this.b;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Map$Entry)) {
            return false;
        }
        final Map$Entry map$Entry = (Map$Entry)o;
        return e(this.b, map$Entry.getKey()) && e(this.c, map$Entry.getValue());
    }
    
    public final Object getValue() {
        return this.c;
    }
    
    @Override
    public final int hashCode() {
        final Comparable b = this.b;
        int hashCode = 0;
        int hashCode2;
        if (b == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = b.hashCode();
        }
        final Object c = this.c;
        if (c != null) {
            hashCode = c.hashCode();
        }
        return hashCode2 ^ hashCode;
    }
    
    public final Object setValue(final Object c) {
        this.d.m();
        final Object c2 = this.c;
        this.c = c;
        return c2;
    }
    
    @Override
    public final String toString() {
        final String value = String.valueOf((Object)this.b);
        final String value2 = String.valueOf(this.c);
        final StringBuilder sb = new StringBuilder(String.valueOf((Object)value).length() + 1 + String.valueOf((Object)value2).length());
        sb.append(value);
        sb.append("=");
        sb.append(value2);
        return sb.toString();
    }
}
