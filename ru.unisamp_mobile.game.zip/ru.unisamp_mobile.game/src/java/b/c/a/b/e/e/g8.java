package b.c.a.b.e.e;

final class g8
{
    static String a(final e5 e5) {
        final StringBuilder sb = new StringBuilder(e5.h());
        for (int i = 0; i < e5.h(); ++i) {
            int c = e5.c(i);
            String s;
            if (c != 34) {
                if (c != 39) {
                    if (c != 92) {
                        switch (c) {
                            default: {
                                if (c < 32 || c > 126) {
                                    sb.append('\\');
                                    sb.append((char)((c >>> 6 & 0x3) + 48));
                                    sb.append((char)((c >>> 3 & 0x7) + 48));
                                    c = (c & 0x7) + 48;
                                }
                                sb.append((char)c);
                                continue;
                            }
                            case 13: {
                                s = "\\r";
                                break;
                            }
                            case 12: {
                                s = "\\f";
                                break;
                            }
                            case 11: {
                                s = "\\v";
                                break;
                            }
                            case 10: {
                                s = "\\n";
                                break;
                            }
                            case 9: {
                                s = "\\t";
                                break;
                            }
                            case 8: {
                                s = "\\b";
                                break;
                            }
                            case 7: {
                                s = "\\a";
                                break;
                            }
                        }
                    }
                    else {
                        s = "\\\\";
                    }
                }
                else {
                    s = "\\'";
                }
            }
            else {
                s = "\\\"";
            }
            sb.append(s);
        }
        return sb.toString();
    }
}
