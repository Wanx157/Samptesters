package b.c.a.b.e.e;

import java.util.Iterator;
import java.util.Map$Entry;

final class d7
{
    public static final int a(final int n, final Object o, final Object o2) {
        final c7 c7 = (c7)o;
        final b7 b7 = (b7)o2;
        if (!c7.isEmpty()) {
            final Iterator iterator = c7.entrySet().iterator();
            if (iterator.hasNext()) {
                final Map$Entry map$Entry = (Map$Entry)iterator.next();
                map$Entry.getKey();
                map$Entry.getValue();
                throw null;
            }
        }
        return 0;
    }
    
    public static final Object b(final Object o, final Object o2) {
        final c7 c7 = (c7)o;
        final c7 c8 = (c7)o2;
        c7 c9 = c7;
        if (!c8.isEmpty()) {
            c9 = c7;
            if (!c7.f()) {
                c9 = c7.c();
            }
            c9.b(c8);
        }
        return c9;
    }
}
