package b.c.a.b.e.e;

interface g7
{
    boolean a(final Class<?> p0);
    
    f7 b(final Class<?> p0);
}
