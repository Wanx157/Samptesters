package b.c.a.b.c.j;

import android.content.Context;

public class c
{
    private static c b;
    private b a;
    
    static {
        c.b = new c();
    }
    
    public c() {
        this.a = null;
    }
    
    public static b a(final Context context) {
        return c.b.b(context);
    }
    
    private final b b(Context applicationContext) {
        synchronized (this) {
            if (this.a == null) {
                if (applicationContext.getApplicationContext() != null) {
                    applicationContext = applicationContext.getApplicationContext();
                }
                this.a = new b(applicationContext);
            }
            return this.a;
        }
    }
}
