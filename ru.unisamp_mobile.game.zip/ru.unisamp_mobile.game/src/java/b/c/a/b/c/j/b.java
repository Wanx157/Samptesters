package b.c.a.b.c.j;

import android.annotation.TargetApi;
import android.app.AppOpsManager;
import com.google.android.gms.common.util.m;
import android.os.Process;
import android.os.Binder;
import android.content.pm.PackageInfo;
import android.content.pm.ApplicationInfo;
import android.content.Context;

public class b
{
    private final Context a;
    
    public b(final Context a) {
        this.a = a;
    }
    
    public int a(final String s) {
        return this.a.checkCallingOrSelfPermission(s);
    }
    
    public int b(final String s, final String s2) {
        return this.a.getPackageManager().checkPermission(s, s2);
    }
    
    public ApplicationInfo c(final String s, final int n) {
        return this.a.getPackageManager().getApplicationInfo(s, n);
    }
    
    public PackageInfo d(final String s, final int n) {
        return this.a.getPackageManager().getPackageInfo(s, n);
    }
    
    public boolean e() {
        if (Binder.getCallingUid() == Process.myUid()) {
            return b.c.a.b.c.j.a.a(this.a);
        }
        if (m.h()) {
            final String nameForUid = this.a.getPackageManager().getNameForUid(Binder.getCallingUid());
            if (nameForUid != null) {
                return this.a.getPackageManager().isInstantApp(nameForUid);
            }
        }
        return false;
    }
    
    public final PackageInfo f(final String s, final int n, final int n2) {
        return this.a.getPackageManager().getPackageInfo(s, 64);
    }
    
    @TargetApi(19)
    public final boolean g(int i, final String s) {
        if (m.d()) {
            try {
                ((AppOpsManager)this.a.getSystemService("appops")).checkPackage(i, s);
                return true;
            }
            catch (final SecurityException ex) {
                return false;
            }
        }
        final String[] packagesForUid = this.a.getPackageManager().getPackagesForUid(i);
        if (s != null && packagesForUid != null) {
            for (i = 0; i < packagesForUid.length; ++i) {
                if (s.equals((Object)packagesForUid[i])) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public final String[] h(final int n) {
        return this.a.getPackageManager().getPackagesForUid(n);
    }
}
