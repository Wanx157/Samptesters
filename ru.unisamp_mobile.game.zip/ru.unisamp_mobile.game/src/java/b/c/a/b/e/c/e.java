package b.c.a.b.e.c;

import java.util.concurrent.ScheduledExecutorService;

public interface e
{
    ScheduledExecutorService a(final int p0, final int p1);
}
