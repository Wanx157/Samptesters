package b.c.a.b.e.e;

abstract class i8<T, B>
{
    abstract void a(final B p0, final int p1, final long p2);
    
    abstract B b();
    
    abstract void c(final Object p0, final T p1);
    
    abstract T d(final Object p0);
    
    abstract void e(final Object p0);
    
    abstract T f(final T p0, final T p1);
    
    abstract int g(final T p0);
    
    abstract int h(final T p0);
    
    abstract void i(final T p0, final m5 p1);
}
