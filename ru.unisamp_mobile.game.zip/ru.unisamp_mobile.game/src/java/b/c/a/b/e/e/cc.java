package b.c.a.b.e.e;

public interface cc
{
    boolean a();
}
