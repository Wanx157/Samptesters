package b.c.a.b.e.c;

public interface l<T>
{
    T a();
}
