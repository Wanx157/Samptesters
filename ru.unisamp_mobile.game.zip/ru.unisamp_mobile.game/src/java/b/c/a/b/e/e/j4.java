package b.c.a.b.e.e;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

final class j4 extends WeakReference<Throwable>
{
    private final int a;
    
    public j4(final Throwable t, final ReferenceQueue<Throwable> referenceQueue) {
        super((Object)t, (ReferenceQueue)referenceQueue);
        this.a = System.identityHashCode((Object)t);
    }
    
    public final boolean equals(final Object o) {
        if (o != null) {
            if (o.getClass() == j4.class) {
                if (this == o) {
                    return true;
                }
                final j4 j4 = (j4)o;
                if (this.a == j4.a && this.get() == j4.get()) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public final int hashCode() {
        return this.a;
    }
}
