package b.c.a.b.b;

import android.os.Bundle;
import android.util.Log;
import java.util.concurrent.ThreadFactory;
import b.c.a.b.e.b.f;
import b.c.a.b.e.b.a;
import java.util.concurrent.ScheduledExecutorService;
import android.content.Context;
import javax.annotation.concurrent.GuardedBy;

public final class i
{
    @GuardedBy("MessengerIpcClient.class")
    private static i e;
    private final Context a;
    private final ScheduledExecutorService b;
    @GuardedBy("this")
    private j c;
    @GuardedBy("this")
    private int d;
    
    private i(final Context context, final ScheduledExecutorService b) {
        this.c = new j(this, null);
        this.d = 1;
        this.b = b;
        this.a = context.getApplicationContext();
    }
    
    private final int a() {
        synchronized (this) {
            return this.d++;
        }
    }
    
    public static i c(final Context context) {
        synchronized (i.class) {
            if (i.e == null) {
                i.e = new i(context, a.a().a(1, (ThreadFactory)new com.google.android.gms.common.util.r.a("MessengerIpcClient"), f.b));
            }
            return i.e;
        }
    }
    
    private final <T> b.c.a.b.g.i<T> e(final u<T> u) {
        synchronized (this) {
            if (Log.isLoggable("MessengerIpcClient", 3)) {
                final String value = String.valueOf((Object)u);
                final StringBuilder sb = new StringBuilder(String.valueOf((Object)value).length() + 9);
                sb.append("Queueing ");
                sb.append(value);
                Log.d("MessengerIpcClient", sb.toString());
            }
            if (!this.c.e(u)) {
                (this.c = new j(this, null)).e(u);
            }
            return (b.c.a.b.g.i<T>)u.b.a();
        }
    }
    
    public final b.c.a.b.g.i<Void> d(final int n, final Bundle bundle) {
        return this.e((u<Void>)new r(this.a(), 2, bundle));
    }
    
    public final b.c.a.b.g.i<Bundle> f(final int n, final Bundle bundle) {
        return this.e((u<Bundle>)new w(this.a(), 1, bundle));
    }
}
