package b.c.a.b.e.d;

import java.io.OutputStream;

final class e extends OutputStream
{
    public final String toString() {
        return "ByteStreams.nullOutputStream()";
    }
    
    public final void write(final int n) {
    }
    
    public final void write(final byte[] array) {
        if (array != null) {
            return;
        }
        throw null;
    }
    
    public final void write(final byte[] array, final int n, final int n2) {
        if (array != null) {
            return;
        }
        throw null;
    }
}
