package b.c.a.b.e.c;

import java.io.Serializable;

public final class k
{
    public static <T> l<T> a(final l<T> l) {
        if (l instanceof m || l instanceof n) {
            return l;
        }
        if (l instanceof Serializable) {
            return (l<T>)new n((l)l);
        }
        return (l<T>)new m((l)l);
    }
}
