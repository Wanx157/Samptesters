package b.c.a.b.e.c;

public final class d
{
    private static volatile e a;
    
    static {
        d.a = (e)new f((g)null);
    }
    
    public static e a() {
        return d.a;
    }
}
