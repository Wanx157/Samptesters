package b.c.a.b.e.e;

import java.io.Serializable;

public abstract class b4<T> implements Serializable
{
    b4() {
    }
    
    public static <T> b4<T> c() {
        return (b4<T>)z3.b;
    }
    
    public static <T> b4<T> d(final T t) {
        return (b4<T>)new c4((Object)t);
    }
    
    public abstract boolean a();
    
    public abstract T b();
}
