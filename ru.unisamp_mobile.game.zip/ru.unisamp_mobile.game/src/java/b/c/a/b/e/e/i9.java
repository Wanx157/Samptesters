package b.c.a.b.e.e;

public interface i9
{
    boolean a();
    
    boolean b();
}
