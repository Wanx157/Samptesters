package b.c.a.b.e.c;

import org.checkerframework.checker.nullness.compatqual.NullableDecl;
import java.io.Serializable;

final class n<T> implements l<T>, Serializable
{
    private final l<T> b;
    private transient volatile boolean c;
    @NullableDecl
    private transient T d;
    
    n(final l<T> l) {
        j.a((Object)l);
        this.b = l;
    }
    
    public final T a() {
        if (!this.c) {
            synchronized (this) {
                if (!this.c) {
                    final Object a = this.b.a();
                    this.d = (T)a;
                    this.c = true;
                    return (T)a;
                }
            }
        }
        return this.d;
    }
    
    @Override
    public final String toString() {
        Object o;
        if (this.c) {
            final String value = String.valueOf((Object)this.d);
            final StringBuilder sb = new StringBuilder(String.valueOf((Object)value).length() + 25);
            sb.append("<supplier that returned ");
            sb.append(value);
            sb.append(">");
            o = sb.toString();
        }
        else {
            o = this.b;
        }
        final String value2 = String.valueOf(o);
        final StringBuilder sb2 = new StringBuilder(String.valueOf((Object)value2).length() + 19);
        sb2.append("Suppliers.memoize(");
        sb2.append(value2);
        sb2.append(")");
        return sb2.toString();
    }
}
