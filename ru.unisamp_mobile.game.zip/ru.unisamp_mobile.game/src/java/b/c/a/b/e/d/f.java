package b.c.a.b.e.d;

import java.io.IOException;
import java.io.InputStream;
import java.io.FilterInputStream;

final class f extends FilterInputStream
{
    private long b;
    private long c;
    
    f(final InputStream inputStream, final long n) {
        super(inputStream);
        this.c = -1L;
        if (inputStream != null) {
            this.b = 1048577L;
            return;
        }
        throw null;
    }
    
    public final int available() {
        return (int)Math.min((long)super.in.available(), this.b);
    }
    
    public final void mark(final int n) {
        synchronized (this) {
            super.in.mark(n);
            this.c = this.b;
        }
    }
    
    public final int read() {
        if (this.b == 0L) {
            return -1;
        }
        final int read = super.in.read();
        if (read != -1) {
            --this.b;
        }
        return read;
    }
    
    public final int read(final byte[] array, int read, final int n) {
        final long b = this.b;
        if (b == 0L) {
            return -1;
        }
        read = super.in.read(array, read, (int)Math.min((long)n, b));
        if (read != -1) {
            this.b -= read;
        }
        return read;
    }
    
    public final void reset() {
        synchronized (this) {
            if (!super.in.markSupported()) {
                throw new IOException("Mark not supported");
            }
            if (this.c != -1L) {
                super.in.reset();
                this.b = this.c;
                return;
            }
            throw new IOException("Mark not set");
        }
    }
    
    public final long skip(long n) {
        n = Math.min(n, this.b);
        n = super.in.skip(n);
        this.b -= n;
        return n;
    }
}
