package b.c.a.b.e.e;

import org.checkerframework.checker.nullness.compatqual.NullableDecl;
import java.io.Serializable;

public final class h4
{
    public static <T> d4<T> a(final d4<T> d4) {
        if (!(d4 instanceof f4) && !(d4 instanceof e4)) {
            Object o;
            if (d4 instanceof Serializable) {
                o = new e4((d4)d4);
            }
            else {
                o = new f4((d4)d4);
            }
            return (d4<T>)o;
        }
        return d4;
    }
    
    public static <T> d4<T> b(@NullableDecl final T t) {
        return (d4<T>)new g4((Object)t);
    }
}
