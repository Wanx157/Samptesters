package b.c.a.b.e.e;

public interface c9
{
    boolean a();
}
