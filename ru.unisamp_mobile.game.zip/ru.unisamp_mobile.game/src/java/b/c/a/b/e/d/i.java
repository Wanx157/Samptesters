package b.c.a.b.e.d;

abstract class i
{
    public abstract void a(final Throwable p0, final Throwable p1);
}
