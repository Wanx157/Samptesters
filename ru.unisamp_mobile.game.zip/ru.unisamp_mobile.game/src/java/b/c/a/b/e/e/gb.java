package b.c.a.b.e.e;

public interface gb
{
    boolean a();
    
    boolean b();
    
    boolean c();
}
