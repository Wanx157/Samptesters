package b.c.a.b.e.d;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

final class j extends WeakReference<Throwable>
{
    private final int a;
    
    public j(final Throwable t, final ReferenceQueue<Throwable> referenceQueue) {
        super((Object)t, (ReferenceQueue)referenceQueue);
        this.a = System.identityHashCode((Object)t);
    }
    
    public final boolean equals(final Object o) {
        if (o != null) {
            if (o.getClass() == j.class) {
                if (this == o) {
                    return true;
                }
                final j j = (j)o;
                if (this.a == j.a && this.get() == j.get()) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public final int hashCode() {
        return this.a;
    }
}
