package b.c.a.b.e.d;

import java.io.Closeable;
import java.io.IOException;
import java.util.logging.Level;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;
import java.io.InputStream;
import java.util.logging.Logger;

public final class h
{
    static final Logger a;
    
    static {
        a = Logger.getLogger(h.class.getName());
    }
    
    private h() {
    }
    
    public static void a(@NullableDecl final InputStream inputStream) {
        if (inputStream == null) {
            return;
        }
        try {
            ((Closeable)inputStream).close();
        }
        catch (final IOException ex) {
            try {
                h.a.logp(Level.WARNING, "com.google.common.io.Closeables", "close", "IOException thrown while closing Closeable.", (Throwable)ex);
            }
            catch (final IOException ex2) {
                throw new AssertionError((Object)ex2);
            }
        }
    }
}
