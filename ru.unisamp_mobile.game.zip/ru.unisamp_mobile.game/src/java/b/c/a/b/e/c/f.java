package b.c.a.b.e.c;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

final class f implements e
{
    private f() {
    }
    
    public final ScheduledExecutorService a(final int n, final int n2) {
        return Executors.unconfigurableScheduledExecutorService(Executors.newScheduledThreadPool(1));
    }
}
