package b.c.a.b.e.e;

public interface c3
{
    void a();
}
