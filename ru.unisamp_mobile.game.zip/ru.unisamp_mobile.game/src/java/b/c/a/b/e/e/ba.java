package b.c.a.b.e.e;

public interface ba
{
    boolean a();
    
    boolean b();
}
