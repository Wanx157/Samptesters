package b.c.a.b.e.d;

import java.lang.ref.Reference;
import java.util.Vector;
import java.lang.ref.ReferenceQueue;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

final class k
{
    private final ConcurrentHashMap<j, List<Throwable>> a;
    private final ReferenceQueue<Throwable> b;
    
    k() {
        this.a = (ConcurrentHashMap<j, List<Throwable>>)new ConcurrentHashMap(16, 0.75f, 10);
        this.b = (ReferenceQueue<Throwable>)new ReferenceQueue();
    }
    
    public final List<Throwable> a(final Throwable t, final boolean b) {
        while (true) {
            final Reference poll = this.b.poll();
            if (poll == null) {
                break;
            }
            this.a.remove((Object)poll);
        }
        final List list = (List)this.a.get((Object)new j(t, null));
        if (list != null) {
            return (List<Throwable>)list;
        }
        final Vector vector = new Vector(2);
        final List list2 = (List)this.a.putIfAbsent((Object)new j(t, this.b), (Object)vector);
        if (list2 == null) {
            return (List<Throwable>)vector;
        }
        return (List<Throwable>)list2;
    }
}
