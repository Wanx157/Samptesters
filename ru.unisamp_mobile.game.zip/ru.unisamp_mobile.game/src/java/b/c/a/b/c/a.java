package b.c.a.b.c;

import android.content.ComponentName;
import java.util.concurrent.TimeoutException;
import com.google.android.gms.common.internal.j;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.LinkedBlockingQueue;
import android.os.IBinder;
import java.util.concurrent.BlockingQueue;
import android.content.ServiceConnection;

public class a implements ServiceConnection
{
    private boolean a;
    private final BlockingQueue<IBinder> b;
    
    public a() {
        this.a = false;
        this.b = (BlockingQueue<IBinder>)new LinkedBlockingQueue();
    }
    
    public IBinder a(final long n, final TimeUnit timeUnit) {
        j.g("BlockingServiceConnection.getServiceWithTimeout() called on main thread");
        if (this.a) {
            throw new IllegalStateException("Cannot call get on this connection more than once");
        }
        this.a = true;
        final IBinder binder = (IBinder)this.b.poll(n, timeUnit);
        if (binder != null) {
            return binder;
        }
        throw new TimeoutException("Timed out waiting for the service connection");
    }
    
    public void onServiceConnected(final ComponentName componentName, final IBinder binder) {
        this.b.add((Object)binder);
    }
    
    public void onServiceDisconnected(final ComponentName componentName) {
    }
}
