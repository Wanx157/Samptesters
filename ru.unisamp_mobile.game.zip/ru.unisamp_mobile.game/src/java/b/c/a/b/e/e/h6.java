package b.c.a.b.e.e;

public interface h6
{
    boolean a(final int p0);
}
