package b.c.a.b.a.a;

import java.util.Iterator;
import android.net.Uri$Builder;
import java.io.IOException;
import android.util.Log;
import java.net.HttpURLConnection;
import java.net.URL;
import android.net.Uri;
import java.util.Map;

final class b extends Thread
{
    private final Map b;
    
    b(final a a, final Map b) {
        this.b = b;
    }
    
    public final void run() {
        Object b = this.b;
        final Uri$Builder buildUpon = Uri.parse("https://pagead2.googlesyndication.com/pagead/gen_204?id=gmob-apps").buildUpon();
        for (final String s : ((Map)b).keySet()) {
            buildUpon.appendQueryParameter(s, (String)((Map)b).get((Object)s));
        }
        final String string = buildUpon.build().toString();
        try {
            b = new URL(string);
            b = ((URL)b).openConnection();
            try {
                final int responseCode = ((HttpURLConnection)b).getResponseCode();
                if (responseCode < 200 || responseCode >= 300) {
                    final StringBuilder sb = new StringBuilder(String.valueOf((Object)string).length() + 65);
                    sb.append("Received non-success response code ");
                    sb.append(responseCode);
                    sb.append(" from pinging URL: ");
                    sb.append(string);
                    Log.w("HttpUrlPinger", sb.toString());
                }
            }
            finally {
                ((HttpURLConnection)b).disconnect();
            }
        }
        catch (final RuntimeException b) {
            goto Label_0203;
        }
        catch (final IOException ex) {}
        catch (final IndexOutOfBoundsException b) {
            final StringBuilder sb2 = new StringBuilder(String.valueOf((Object)string).length() + 32 + String.valueOf((Object)((IndexOutOfBoundsException)b).getMessage()).length());
            goto Label_0242;
        }
    }
}
