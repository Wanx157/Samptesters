package b.c.a.b.e.e;

public interface e3<V>
{
    V a();
}
