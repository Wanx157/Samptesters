package b.c.a.b.e.e;

import android.os.NetworkOnMainThreadException;
import android.os.BadParcelableException;
import android.os.RemoteException;
import com.google.android.gms.dynamite.DynamiteModule$a;
import com.google.android.gms.dynamite.DynamiteModule;
import java.util.Iterator;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import android.app.Activity;
import com.google.android.gms.common.internal.j;
import android.app.Application$ActivityLifecycleCallbacks;
import android.app.Application;
import android.util.Log;
import com.google.android.gms.measurement.internal.e7;
import com.google.android.gms.measurement.internal.o4;
import java.util.ArrayList;
import java.util.concurrent.ThreadFactory;
import com.google.android.gms.common.util.i;
import android.os.Bundle;
import android.content.Context;
import com.google.android.gms.measurement.internal.x5;
import android.util.Pair;
import java.util.List;
import com.google.android.gms.measurement.a.a;
import java.util.concurrent.ExecutorService;
import com.google.android.gms.common.util.f;

public final class h0
{
    private static volatile h0 i;
    private final String a;
    protected final f b;
    protected final ExecutorService c;
    private final a d;
    private final List<Pair<x5, y>> e;
    private int f;
    private boolean g;
    private volatile vc h;
    
    protected h0(final Context context, String a, final String s, final String s2, final Bundle bundle) {
        if (a == null || !q(s, s2)) {
            a = "FA";
        }
        this.a = a;
        this.b = com.google.android.gms.common.util.i.d();
        final m6 a2 = o9.a();
        final q q = new q(this);
        int n = true ? 1 : 0;
        this.c = a2.a((ThreadFactory)q, 1);
        this.d = new a(this);
        this.e = (List<Pair<x5, y>>)new ArrayList();
        try {
            a = e7.a(context, "google_app_id", o4.a(context));
            if (a != null) {
                if (!m()) {
                    this.g = true;
                    Log.w(this.a, "Disabling data collection. Found google_app_id in strings.xml but Google Analytics for Firebase is missing. Remove this value or add Google Analytics for Firebase to resume data collection.");
                    return;
                }
            }
        }
        catch (final IllegalStateException ex) {}
        if (!q(s, s2)) {
            if (s != null && s2 != null) {
                Log.v(this.a, "Deferring to Google Analytics for Firebase for event data collection. https://goo.gl/J1sWQy");
            }
            else {
                final boolean b = s == null;
                if (s2 != null) {
                    n = (false ? 1 : 0);
                }
                if (((b ? 1 : 0) ^ n) != 0x0) {
                    Log.w(this.a, "Specified origin or custom app id is null. Both parameters will be ignored.");
                }
            }
        }
        this.n((x)new g(this, s, s2, context, bundle));
        final Application application = (Application)context.getApplicationContext();
        if (application == null) {
            Log.w(this.a, "Unable to register lifecycle notifications. Application null.");
            return;
        }
        application.registerActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)new g0(this));
    }
    
    protected static final boolean m() {
        try {
            Class.forName("com.google.firebase.analytics.FirebaseAnalytics");
            return true;
        }
        catch (final ClassNotFoundException ex) {
            return false;
        }
    }
    
    private final void n(final x x) {
        this.c.execute((Runnable)x);
    }
    
    private final void o(final Exception ex, final boolean b, final boolean b2) {
        this.g |= b;
        if (b) {
            Log.w(this.a, "Data collection startup failed. No data will be collected.", (Throwable)ex);
            return;
        }
        if (b2) {
            this.c(5, "Error with data collection. Data lost.", ex, null, null);
        }
        Log.w(this.a, "Error with data collection. Data lost.", (Throwable)ex);
    }
    
    private final void p(final String s, final String s2, final Bundle bundle, final boolean b, final boolean b2, final Long n) {
        this.n((x)new v(this, n, s, s2, bundle, b, b2));
    }
    
    private static final boolean q(final String s, final String s2) {
        return s2 != null && s != null && !m();
    }
    
    public static h0 r(final Context context, final String s, final String s2, final String s3, final Bundle bundle) {
        j.h((Object)context);
        if (h0.i == null) {
            synchronized (h0.class) {
                if (h0.i == null) {
                    h0.i = new h0(context, s, s2, s3, bundle);
                }
            }
        }
        return h0.i;
    }
    
    public final void A(final Activity activity, final String s, final String s2) {
        this.n((x)new b.c.a.b.e.e.f(this, activity, s, s2));
    }
    
    public final void B(final String s) {
        this.n((x)new h(this, s));
    }
    
    public final void C(final String s) {
        this.n((x)new b.c.a.b.e.e.i(this, s));
    }
    
    public final String D() {
        final qb qb = new qb();
        this.n((x)new b.c.a.b.e.e.j(this, qb));
        return qb.O(500L);
    }
    
    public final String E() {
        final qb qb = new qb();
        this.n((x)new k(this, qb));
        return qb.O(50L);
    }
    
    public final long F() {
        final qb qb = new qb();
        this.n((x)new l(this, qb));
        final Long n = (Long)b.c.a.b.e.e.qb.Q(qb.P(500L), (Class)Long.class);
        long longValue;
        if (n == null) {
            final long nextLong = new Random(System.nanoTime() ^ this.b.a()).nextLong();
            final int f = this.f + 1;
            this.f = f;
            longValue = nextLong + f;
        }
        else {
            longValue = n;
        }
        return longValue;
    }
    
    public final String G() {
        final qb qb = new qb();
        this.n((x)new m(this, qb));
        return qb.O(500L);
    }
    
    public final String a() {
        final qb qb = new qb();
        this.n((x)new n(this, qb));
        return qb.O(500L);
    }
    
    public final Map<String, Object> b(final String s, final String s2, final boolean b) {
        final qb qb = new qb();
        this.n((x)new o(this, s, s2, b, qb));
        final Bundle p3 = qb.P(5000L);
        if (p3 != null && p3.size() != 0) {
            final HashMap hashMap = new HashMap(p3.size());
            for (final String s3 : p3.keySet()) {
                final Object value = p3.get(s3);
                if (value instanceof Double || value instanceof Long || value instanceof String) {
                    ((Map)hashMap).put((Object)s3, value);
                }
            }
            return (Map<String, Object>)hashMap;
        }
        return (Map<String, Object>)Collections.emptyMap();
    }
    
    public final void c(final int n, final String s, final Object o, final Object o2, final Object o3) {
        this.n((x)new p(this, false, 5, s, o, (Object)null, (Object)null));
    }
    
    public final int d(final String s) {
        final qb qb = new qb();
        this.n((x)new r(this, s, qb));
        final Integer n = (Integer)b.c.a.b.e.e.qb.Q(qb.P(10000L), (Class)Integer.class);
        if (n == null) {
            return 25;
        }
        return n;
    }
    
    public final void e(final boolean b) {
        this.n((x)new t(this, b));
    }
    
    public final a s() {
        return this.d;
    }
    
    protected final vc t(final Context context, final boolean b) {
        try {
            return uc.asInterface(DynamiteModule.d(context, DynamiteModule.j, "com.google.android.gms.measurement.dynamite").c("com.google.android.gms.measurement.internal.AppMeasurementDynamiteService"));
        }
        catch (final DynamiteModule$a dynamiteModule$a) {
            this.o((Exception)dynamiteModule$a, true, false);
            return null;
        }
    }
    
    public final void u(final x5 x5) {
        j.h((Object)x5);
        final List<Pair<x5, y>> e;
        monitorenter(e = this.e);
        int i = 0;
        try {
            while (i < this.e.size()) {
                if (x5.equals(((Pair)this.e.get(i)).first)) {
                    Log.w(this.a, "OnEventListener already registered.");
                    monitorexit(e);
                    return;
                }
                ++i;
            }
            final y y = new y(x5);
            this.e.add((Object)new Pair((Object)x5, (Object)y));
            monitorexit(e);
            if (this.h != null) {
                try {
                    this.h.registerOnMeasurementEventListener((bd)y);
                    return;
                }
                catch (final RemoteException | BadParcelableException | IllegalArgumentException | IllegalStateException | NetworkOnMainThreadException | NullPointerException | SecurityException | UnsupportedOperationException ex) {
                    Log.w(this.a, "Failed to register event listener on calling thread. Trying again on the dynamite thread.");
                }
            }
            this.n((x)new u(this, y));
        }
        finally {
            monitorexit(e);
            while (true) {}
        }
    }
    
    public final void v(final String s, final String s2, final Bundle bundle) {
        this.p(s, s2, bundle, true, true, null);
    }
    
    public final void w(final String s, final String s2, final Object o, final boolean b) {
        this.n((x)new w(this, s, s2, o, b));
    }
    
    public final void x(final Bundle bundle) {
        this.n((x)new c(this, bundle));
    }
    
    public final void y(final String s, final String s2, final Bundle bundle) {
        this.n((x)new d(this, s, s2, bundle));
    }
    
    public final List<Bundle> z(final String s, final String s2) {
        final qb qb = new qb();
        this.n((x)new e(this, s, s2, qb));
        List emptyList;
        if ((emptyList = (List)b.c.a.b.e.e.qb.Q(qb.P(5000L), (Class)List.class)) == null) {
            emptyList = Collections.emptyList();
        }
        return (List<Bundle>)emptyList;
    }
}
