package b.c.a.b.e.e;

import java.util.Map$Entry;
import java.util.Iterator;

final class c8 implements Iterator<Map$Entry>
{
    private int b = -1;
    private boolean c;
    private Iterator<Map$Entry> d;
    final e8 e;
    
    private final Iterator<Map$Entry> b() {
        if (this.d == null) {
            this.d = (Iterator<Map$Entry>)this.e.d.entrySet().iterator();
        }
        return this.d;
    }
    
    public final boolean hasNext() {
        final int b = this.b;
        boolean b2 = true;
        if (b + 1 >= this.e.c.size()) {
            if (!this.e.d.isEmpty()) {
                if (!this.b().hasNext()) {
                    return false;
                }
                b2 = b2;
            }
            else {
                b2 = false;
            }
        }
        return b2;
    }
    
    public final void remove() {
        if (!this.c) {
            throw new IllegalStateException("remove() was called before next()");
        }
        this.c = false;
        this.e.m();
        if (this.b < this.e.c.size()) {
            this.e.k(this.b--);
            return;
        }
        this.b().remove();
    }
}
