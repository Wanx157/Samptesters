package b.c.a.b.c;

public final class e extends Exception
{
    public e(final int n) {
    }
}
