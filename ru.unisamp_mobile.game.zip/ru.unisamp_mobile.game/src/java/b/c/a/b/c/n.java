package b.c.a.b.c;

import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.internal.v;
import b.c.a.b.d.b;
import b.c.a.b.d.a;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import com.google.android.gms.common.internal.j;
import com.google.android.gms.common.internal.x;

abstract class n extends x
{
    private int a;
    
    protected n(final byte[] array) {
        j.a(array.length == 25);
        this.a = Arrays.hashCode(array);
    }
    
    protected static byte[] Q(final String s) {
        try {
            return s.getBytes("ISO-8859-1");
        }
        catch (final UnsupportedEncodingException ex) {
            throw new AssertionError((Object)ex);
        }
    }
    
    abstract byte[] P();
    
    public final a b() {
        return b.Q(this.P());
    }
    
    public final int c() {
        return this.hashCode();
    }
    
    public boolean equals(final Object o) {
        if (o != null) {
            if (o instanceof v) {
                try {
                    final v v = (v)o;
                    if (v.c() != this.hashCode()) {
                        return false;
                    }
                    final a b = v.b();
                    return b != null && Arrays.equals(this.P(), (byte[])b.c.a.b.d.b.P(b));
                }
                catch (final RemoteException ex) {
                    Log.e("GoogleCertificates", "Failed to get Google certificates from remote", (Throwable)ex);
                }
            }
        }
        return false;
    }
    
    public int hashCode() {
        return this.a;
    }
}
