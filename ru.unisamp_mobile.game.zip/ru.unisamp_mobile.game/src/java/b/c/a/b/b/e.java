package b.c.a.b.b;

import android.os.IInterface;
import android.util.Log;
import android.os.Parcel;
import android.os.Message;
import android.os.Build$VERSION;
import android.os.IBinder;
import android.os.Messenger;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public class e implements Parcelable
{
    public static final Parcelable$Creator<e> CREATOR;
    private Messenger b;
    private c c;
    
    static {
        CREATOR = (Parcelable$Creator)new g();
    }
    
    public e(final IBinder binder) {
        if (Build$VERSION.SDK_INT >= 21) {
            this.b = new Messenger(binder);
            return;
        }
        this.c = (c)new c$a(binder);
    }
    
    private final IBinder a() {
        final Messenger b = this.b;
        if (b != null) {
            return b.getBinder();
        }
        return ((IInterface)this.c).asBinder();
    }
    
    public final void b(final Message message) {
        final Messenger b = this.b;
        if (b != null) {
            b.send(message);
            return;
        }
        this.c.w(message);
    }
    
    public int describeContents() {
        return 0;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == null) {
            return false;
        }
        try {
            return this.a().equals(((e)o).a());
        }
        catch (final ClassCastException ex) {
            return false;
        }
    }
    
    @Override
    public int hashCode() {
        return this.a().hashCode();
    }
    
    public void writeToParcel(final Parcel parcel, final int n) {
        final Messenger b = this.b;
        IBinder binder;
        if (b != null) {
            binder = b.getBinder();
        }
        else {
            binder = ((IInterface)this.c).asBinder();
        }
        parcel.writeStrongBinder(binder);
    }
    
    public static final class a extends ClassLoader
    {
        protected final Class<?> loadClass(final String s, final boolean b) {
            if ("com.google.android.gms.iid.MessengerCompat".equals((Object)s)) {
                if (Log.isLoggable("CloudMessengerCompat", 3) || (Build$VERSION.SDK_INT == 23 && Log.isLoggable("CloudMessengerCompat", 3))) {
                    Log.d("CloudMessengerCompat", "Using renamed FirebaseIidMessengerCompat class");
                }
                return e.class;
            }
            return super.loadClass(s, b);
        }
    }
}
