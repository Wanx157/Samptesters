package b.c.a.b.e.a;

import android.os.Parcel;

public class c
{
    static {
        c.class.getClassLoader();
    }
    
    private c() {
    }
    
    public static void a(final Parcel parcel, final boolean b) {
        parcel.writeInt(1);
    }
    
    public static boolean b(final Parcel parcel) {
        return parcel.readInt() != 0;
    }
}
