package b.c.a.b.e.e;

import android.os.Handler;
import android.database.ContentObserver;

final class a3 extends ContentObserver
{
    final b3 a;
    
    a3(final b3 a, final Handler handler) {
        this.a = a;
        super((Handler)null);
    }
    
    public final void onChange(final boolean b) {
        this.a.d();
    }
}
