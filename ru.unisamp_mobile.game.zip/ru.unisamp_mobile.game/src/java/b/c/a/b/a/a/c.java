package b.c.a.b.a.a;

import android.util.Log;
import b.c.a.b.c.f;
import android.content.Context;
import android.content.SharedPreferences;

public final class c
{
    private SharedPreferences a;
    
    public c(Context b) {
        try {
            b = f.b(b);
            SharedPreferences sharedPreferences;
            if (b == null) {
                sharedPreferences = null;
            }
            else {
                sharedPreferences = b.getSharedPreferences("google_ads_flags", 0);
            }
            this.a = sharedPreferences;
        }
        finally {
            final Throwable t;
            Log.w("GmscoreFlag", "Error while getting SharedPreferences ", t);
            this.a = null;
        }
    }
    
    public final boolean a(final String s, final boolean b) {
        try {
            return this.a != null && this.a.getBoolean(s, false);
        }
        finally {
            final Throwable t;
            Log.w("GmscoreFlag", "Error while reading from SharedPreferences ", t);
            return false;
        }
    }
    
    final float b(final String s, float float1) {
        try {
            if (this.a == null) {
                return 0.0f;
            }
            float1 = this.a.getFloat(s, 0.0f);
            return float1;
        }
        finally {
            final Throwable t;
            Log.w("GmscoreFlag", "Error while reading from SharedPreferences ", t);
            return 0.0f;
        }
    }
    
    final String c(String string, final String s) {
        try {
            if (this.a == null) {
                return s;
            }
            string = this.a.getString(string, s);
            return string;
        }
        finally {
            final Throwable t;
            Log.w("GmscoreFlag", "Error while reading from SharedPreferences ", t);
            return s;
        }
    }
}
