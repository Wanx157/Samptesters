package b.c.a.b.e.e;

public interface d4<T>
{
    T a();
}
