package b.c.a.b.e.d;

public final class d
{
    private static final a a;
    private static volatile a b;
    
    static {
        d.b = (a = (a)new c((b)null));
    }
    
    public static a a() {
        return d.b;
    }
}
