package b.c.a.b.b;

public final class t extends Exception
{
    public t(final int n, final String s) {
        super(s);
    }
}
