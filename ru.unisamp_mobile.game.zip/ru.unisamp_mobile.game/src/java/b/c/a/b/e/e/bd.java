package b.c.a.b.e.e;

import android.os.Bundle;
import android.os.IInterface;

public interface bd extends IInterface
{
    int e();
    
    void z(final String p0, final String p1, final Bundle p2, final long p3);
}
