package b.c.a.b.e.e;

public interface ab
{
    boolean a();
    
    boolean b();
    
    boolean c();
    
    boolean d();
}
