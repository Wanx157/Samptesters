package b.c.a.b.b;

import android.os.Bundle;

final class r extends u<Void>
{
    r(final int n, final int n2, final Bundle bundle) {
        super(n, 2, bundle);
    }
    
    final void a(final Bundle bundle) {
        if (bundle.getBoolean("ack", false)) {
            this.c((Object)null);
            return;
        }
        this.b(new t(4, "Invalid response to one way request"));
    }
    
    final boolean d() {
        return true;
    }
}
