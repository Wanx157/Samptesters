package b.c.a.b.e.e;

public interface a4<F, T>
{
}
