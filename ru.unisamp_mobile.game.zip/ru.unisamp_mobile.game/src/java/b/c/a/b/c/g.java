package b.c.a.b.c;

import android.content.pm.PackageManager$NameNotFoundException;
import b.c.a.b.c.j.c;
import android.content.pm.Signature;
import android.util.Log;
import android.content.pm.PackageInfo;
import com.google.android.gms.common.internal.j;
import android.content.Context;
import javax.annotation.Nullable;
import javax.annotation.CheckReturnValue;

@CheckReturnValue
public class g
{
    @Nullable
    private static g b;
    private final Context a;
    
    private g(final Context context) {
        this.a = context.getApplicationContext();
    }
    
    public static g a(final Context context) {
        j.h((Object)context);
        synchronized (g.class) {
            if (g.b == null) {
                m.c(context);
                g.b = new g(context);
            }
            return g.b;
        }
    }
    
    @Nullable
    private static n d(final PackageInfo packageInfo, final n... array) {
        final Signature[] signatures = packageInfo.signatures;
        if (signatures == null) {
            return null;
        }
        if (signatures.length != 1) {
            Log.w("GoogleSignatureVerifier", "Package has more than one signature.");
            return null;
        }
        final Signature[] signatures2 = packageInfo.signatures;
        int i = 0;
        final q q = new q(signatures2[0].toByteArray());
        while (i < array.length) {
            if (array[i].equals((Object)q)) {
                return array[i];
            }
            ++i;
        }
        return null;
    }
    
    private final v e(String s, final int n) {
        try {
            final PackageInfo f = c.a(this.a).f(s, 64, n);
            final boolean c = b.c.a.b.c.f.c(this.a);
            if (f == null) {
                return v.b("null pkg");
            }
            if (f.signatures == null || f.signatures.length != 1) {
                return v.b("single cert required");
            }
            final q q = new q(f.signatures[0].toByteArray());
            final String packageName = f.packageName;
            final v a = m.a(packageName, (n)q, c, false);
            if (a.a && f.applicationInfo != null && (f.applicationInfo.flags & 0x2) != 0x0 && m.a(packageName, (n)q, false, true).a) {
                return v.b("debuggable release cert app rejected");
            }
            return a;
        }
        catch (final PackageManager$NameNotFoundException ex) {
            s = String.valueOf((Object)s);
            if (s.length() != 0) {
                s = "no pkg ".concat(s);
            }
            else {
                s = new String("no pkg ");
            }
            return v.b(s);
        }
    }
    
    public static boolean f(final PackageInfo packageInfo, final boolean b) {
        if (packageInfo != null && packageInfo.signatures != null) {
            n n;
            if (b) {
                n = d(packageInfo, s.a);
            }
            else {
                n = d(packageInfo, s.a[0]);
            }
            if (n != null) {
                return true;
            }
        }
        return false;
    }
    
    public boolean b(final PackageInfo packageInfo) {
        if (packageInfo == null) {
            return false;
        }
        if (f(packageInfo, false)) {
            return true;
        }
        if (f(packageInfo, true)) {
            if (f.c(this.a)) {
                return true;
            }
            Log.w("GoogleSignatureVerifier", "Test-keys aren't accepted on this build.");
        }
        return false;
    }
    
    public boolean c(final int n) {
        final String[] h = c.a(this.a).h(n);
        v v = null;
        Label_0092: {
            if (h != null && h.length != 0) {
                v = null;
                for (int length = h.length, i = 0; i < length; ++i) {
                    v = this.e(h[i], n);
                    if (v.a) {
                        break Label_0092;
                    }
                }
                j.h((Object)v);
                v = v;
            }
            else {
                v = b.c.a.b.c.v.b("no pkgs");
            }
        }
        v.g();
        return v.a;
    }
}
