package b.c.a.b.b;

import android.os.Parcel;
import android.os.Parcelable$Creator;

final class g implements Parcelable$Creator<e>
{
}
