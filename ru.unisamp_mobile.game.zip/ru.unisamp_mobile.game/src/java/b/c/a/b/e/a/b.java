package b.c.a.b.e.a;

import android.os.IInterface;
import android.os.Binder;

public class b extends Binder implements IInterface
{
}
