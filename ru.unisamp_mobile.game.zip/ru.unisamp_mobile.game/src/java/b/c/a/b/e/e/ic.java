package b.c.a.b.e.e;

public interface ic
{
    boolean a();
    
    boolean b();
}
