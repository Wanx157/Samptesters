package b.c.a.b.e.e;

import java.util.Iterator;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map$Entry;
import java.util.Set;
import java.util.Map;
import java.util.LinkedHashMap;

public final class c7<K, V> extends LinkedHashMap<K, V>
{
    private static final c7 c;
    private boolean b;
    
    static {
        (c = new c7()).b = false;
    }
    
    private c7() {
        this.b = true;
    }
    
    private c7(final Map<K, V> map) {
        super((Map)map);
        this.b = true;
    }
    
    public static <K, V> c7<K, V> a() {
        return c7.c;
    }
    
    private static int g(final Object o) {
        if (o instanceof byte[]) {
            return l6.g((byte[])o);
        }
        if (!(o instanceof g6)) {
            return o.hashCode();
        }
        throw new UnsupportedOperationException();
    }
    
    private final void h() {
        if (this.b) {
            return;
        }
        throw new UnsupportedOperationException();
    }
    
    public final void b(final c7<K, V> c7) {
        this.h();
        if (!c7.isEmpty()) {
            this.putAll((Map<? extends K, ? extends V>)c7);
        }
    }
    
    public final c7<K, V> c() {
        c7 c7;
        if (this.isEmpty()) {
            c7 = new c7();
        }
        else {
            c7 = new c7((Map<K, V>)this);
        }
        return c7;
    }
    
    public final void clear() {
        this.h();
        super.clear();
    }
    
    public final void e() {
        this.b = false;
    }
    
    public final Set<Map$Entry<K, V>> entrySet() {
        Set set;
        if (this.isEmpty()) {
            set = Collections.emptySet();
        }
        else {
            set = super.entrySet();
        }
        return (Set<Map$Entry<K, V>>)set;
    }
    
    public final boolean equals(final Object o) {
        if (o instanceof Map) {
            final Map map = (Map)o;
            if (this != map) {
                if (((Map)this).size() != map.size()) {
                    return false;
                }
                for (final Map$Entry map$Entry : ((Map)this).entrySet()) {
                    if (!map.containsKey(map$Entry.getKey())) {
                        return false;
                    }
                    final Object value = map$Entry.getValue();
                    final Object value2 = map.get(map$Entry.getKey());
                    boolean b;
                    if (value instanceof byte[] && value2 instanceof byte[]) {
                        b = Arrays.equals((byte[])value, (byte[])value2);
                    }
                    else {
                        b = value.equals(value2);
                    }
                    if (!b) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }
    
    public final boolean f() {
        return this.b;
    }
    
    public final int hashCode() {
        final Iterator iterator = ((Map)this).entrySet().iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final Map$Entry map$Entry = (Map$Entry)iterator.next();
            n += (g(map$Entry.getValue()) ^ g(map$Entry.getKey()));
        }
        return n;
    }
    
    public final V put(final K k, final V v) {
        this.h();
        l6.a(k);
        l6.a(v);
        return (V)super.put((Object)k, (Object)v);
    }
    
    public final void putAll(final Map<? extends K, ? extends V> map) {
        this.h();
        for (final Object next : map.keySet()) {
            l6.a(next);
            l6.a(map.get(next));
        }
        super.putAll((Map)map);
    }
    
    public final V remove(final Object o) {
        this.h();
        return (V)super.remove(o);
    }
}
