package b.c.a.b.e.c;

import org.checkerframework.checker.nullness.compatqual.NullableDecl;

final class m<T> implements l<T>
{
    private volatile l<T> b;
    private volatile boolean c;
    @NullableDecl
    private T d;
    
    m(final l<T> l) {
        j.a((Object)l);
        this.b = l;
    }
    
    public final T a() {
        if (!this.c) {
            synchronized (this) {
                if (!this.c) {
                    final Object a = this.b.a();
                    this.d = (T)a;
                    this.c = true;
                    this.b = null;
                    return (T)a;
                }
            }
        }
        return this.d;
    }
    
    @Override
    public final String toString() {
        Object o;
        if ((o = this.b) == null) {
            final String value = String.valueOf((Object)this.d);
            final StringBuilder sb = new StringBuilder(String.valueOf((Object)value).length() + 25);
            sb.append("<supplier that returned ");
            sb.append(value);
            sb.append(">");
            o = sb.toString();
        }
        final String value2 = String.valueOf(o);
        final StringBuilder sb2 = new StringBuilder(String.valueOf((Object)value2).length() + 19);
        sb2.append("Suppliers.memoize(");
        sb2.append(value2);
        sb2.append(")");
        return sb2.toString();
    }
}
