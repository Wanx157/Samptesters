package b.c.a.b.e.a;

import android.os.Parcel;
import android.os.IBinder;

public final class f extends a implements d
{
    f(final IBinder binder) {
        super(binder, "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
    }
    
    public final String d() {
        final Parcel o = this.O(1, this.N());
        final String string = o.readString();
        o.recycle();
        return string;
    }
    
    public final boolean j(final boolean b) {
        final Parcel n = this.N();
        c.a(n, true);
        final Parcel o = this.O(2, n);
        final boolean b2 = c.b(o);
        o.recycle();
        return b2;
    }
}
