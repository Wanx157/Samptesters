package b.c.a.b.d;

import android.os.IInterface;
import java.lang.reflect.Field;
import android.os.IBinder;

public final class b<T> extends a.a
{
    private final T a;
    
    private b(final T a) {
        this.a = a;
    }
    
    public static <T> T P(final a a) {
        if (a instanceof b) {
            return (T)((b)a).a;
        }
        final IBinder binder = ((IInterface)a).asBinder();
        final Field[] declaredFields = binder.getClass().getDeclaredFields();
        Field field = null;
        final int length = declaredFields.length;
        int i = 0;
        int n = 0;
        while (i < length) {
            final Field field2 = declaredFields[i];
            int n2 = n;
            if (!field2.isSynthetic()) {
                n2 = n + 1;
                field = field2;
            }
            ++i;
            n = n2;
        }
        if (n == 1) {
            if (!field.isAccessible()) {
                field.setAccessible(true);
                try {
                    return (T)field.get((Object)binder);
                }
                catch (final IllegalAccessException ex) {
                    throw new IllegalArgumentException("Could not access the field in remoteBinder.", (Throwable)ex);
                }
                catch (final NullPointerException ex2) {
                    throw new IllegalArgumentException("Binder object is null.", (Throwable)ex2);
                }
            }
            throw new IllegalArgumentException("IObjectWrapper declared field not private!");
        }
        final int length2 = declaredFields.length;
        final StringBuilder sb = new StringBuilder(64);
        sb.append("Unexpected number of IObjectWrapper declared fields: ");
        sb.append(length2);
        throw new IllegalArgumentException(sb.toString());
    }
    
    public static <T> a Q(final T t) {
        return (a)new b(t);
    }
}
