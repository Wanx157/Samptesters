package b.c.a.b.e.e;

public interface ea
{
    boolean a();
    
    boolean b();
}
