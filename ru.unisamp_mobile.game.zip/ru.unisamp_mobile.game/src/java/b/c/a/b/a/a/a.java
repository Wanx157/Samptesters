package b.c.a.b.a.a;

import java.util.concurrent.CountDownLatch;
import java.lang.ref.WeakReference;
import android.os.RemoteException;
import android.util.Log;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import android.content.pm.PackageManager$NameNotFoundException;
import b.c.a.b.c.e;
import android.content.ServiceConnection;
import android.content.Intent;
import java.io.IOException;
import android.os.SystemClock;
import com.google.android.gms.common.internal.j;
import android.content.Context;
import b.c.a.b.e.a.d;
import javax.annotation.concurrent.GuardedBy;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class a
{
    @GuardedBy("this")
    private a a;
    @GuardedBy("this")
    private d b;
    @GuardedBy("this")
    private boolean c;
    private final Object d;
    @GuardedBy("mAutoDisconnectTaskLock")
    private b e;
    @GuardedBy("this")
    private final Context f;
    private final boolean g;
    private final long h;
    
    private a(final Context context, final long h, final boolean b, final boolean g) {
        this.d = new Object();
        j.h((Object)context);
        Context applicationContext = context;
        if (b) {
            applicationContext = context.getApplicationContext();
            if (applicationContext == null) {
                applicationContext = context;
            }
        }
        this.f = applicationContext;
        this.c = false;
        this.h = h;
        this.g = g;
    }
    
    public static a b(Context context) {
        final c c = new c(context);
        final boolean a = c.a("gads:ad_id_app_context:enabled", false);
        final float b = c.b("gads:ad_id_app_context:ping_ratio", 0.0f);
        final String c2 = c.c("gads:ad_id_use_shared_preference:experiment_id", "");
        context = (Context)new a(context, -1L, a, c.a("gads:ad_id_use_persistent_service:enabled", false));
        try {
            final long elapsedRealtime = SystemClock.elapsedRealtime();
            ((a)context).h(false);
            final a c3 = ((a)context).c();
            ((a)context).i(c3, a, b, SystemClock.elapsedRealtime() - elapsedRealtime, c2, null);
            ((a)context).a();
            return c3;
        }
        finally {
            try {
                final Throwable t;
                ((a)context).i(null, a, b, -1L, c2, t);
            }
            finally {
                ((a)context).a();
            }
        }
    }
    
    public static void d(final boolean b) {
    }
    
    private static a e(final Context context, final boolean b) {
        try {
            context.getPackageManager().getPackageInfo("com.android.vending", 0);
            final int c = b.c.a.b.c.d.b().c(context, 12451000);
            if (c != 0 && c != 2) {
                throw new IOException("Google Play services not available");
            }
            String s;
            if (b) {
                s = "com.google.android.gms.ads.identifier.service.PERSISTENT_START";
            }
            else {
                s = "com.google.android.gms.ads.identifier.service.START";
            }
            final a a = new a();
            final Intent intent = new Intent(s);
            intent.setPackage("com.google.android.gms");
            try {
                if (com.google.android.gms.common.stats.a.b().a(context, intent, (ServiceConnection)a, 1)) {
                    return a;
                }
                throw new IOException("Connection failure");
            }
            finally {
                final Throwable t;
                throw new IOException(t);
            }
        }
        catch (final PackageManager$NameNotFoundException ex) {
            throw new e(9);
        }
    }
    
    private static d f(final Context context, final a a) {
        try {
            return b.c.a.b.e.a.e.N(a.a(10000L, TimeUnit.MILLISECONDS));
        }
        catch (final InterruptedException ex) {
            throw new IOException("Interrupted exception");
        }
        finally {
            final Throwable t;
            throw new IOException(t);
        }
    }
    
    private final void g() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        b/c/a/b/a/a/a.d:Ljava/lang/Object;
        //     4: astore_1       
        //     5: aload_1        
        //     6: dup            
        //     7: astore_3       
        //     8: monitorenter   
        //     9: aload_0        
        //    10: getfield        b/c/a/b/a/a/a.e:Lb/c/a/b/a/a/a$b;
        //    13: ifnull          33
        //    16: aload_0        
        //    17: getfield        b/c/a/b/a/a/a.e:Lb/c/a/b/a/a/a$b;
        //    20: getfield        b/c/a/b/a/a/a$b.d:Ljava/util/concurrent/CountDownLatch;
        //    23: invokevirtual   java/util/concurrent/CountDownLatch.countDown:()V
        //    26: aload_0        
        //    27: getfield        b/c/a/b/a/a/a.e:Lb/c/a/b/a/a/a$b;
        //    30: invokevirtual   java/lang/Thread.join:()V
        //    33: aload_0        
        //    34: getfield        b/c/a/b/a/a/a.h:J
        //    37: lconst_0       
        //    38: lcmp           
        //    39: ifle            60
        //    42: new             Lb/c/a/b/a/a/a$b;
        //    45: astore_2       
        //    46: aload_2        
        //    47: aload_0        
        //    48: aload_0        
        //    49: getfield        b/c/a/b/a/a/a.h:J
        //    52: invokespecial   b/c/a/b/a/a/a$b.<init>:(Lb/c/a/b/a/a/a;J)V
        //    55: aload_0        
        //    56: aload_2        
        //    57: putfield        b/c/a/b/a/a/a.e:Lb/c/a/b/a/a/a$b;
        //    60: aload_3        
        //    61: monitorexit    
        //    62: return         
        //    63: astore_2       
        //    64: aload_3        
        //    65: monitorexit    
        //    66: aload_2        
        //    67: athrow         
        //    68: astore_2       
        //    69: goto            33
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  9      26     63     68     Any
        //  26     33     68     72     Ljava/lang/InterruptedException;
        //  26     33     63     68     Any
        //  33     60     63     68     Any
        //  60     62     63     68     Any
        //  64     66     63     68     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0033:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private final void h(final boolean b) {
        j.g("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (this.c) {
                this.a();
            }
            final a e = e(this.f, this.g);
            this.a = e;
            this.b = f(this.f, e);
            this.c = true;
            if (b) {
                this.g();
            }
        }
    }
    
    private final boolean i(final a a, final boolean b, final float n, final long n2, final String s, final Throwable t) {
        if (Math.random() > n) {
            return false;
        }
        final HashMap hashMap = new HashMap();
        final String s2 = "1";
        String s3;
        if (b) {
            s3 = "1";
        }
        else {
            s3 = "0";
        }
        ((Map)hashMap).put((Object)"app_context", (Object)s3);
        if (a != null) {
            String s4;
            if (a.b()) {
                s4 = s2;
            }
            else {
                s4 = "0";
            }
            ((Map)hashMap).put((Object)"limit_ad_tracking", (Object)s4);
        }
        if (a != null && a.a() != null) {
            ((Map)hashMap).put((Object)"ad_id_size", (Object)Integer.toString(a.a().length()));
        }
        if (t != null) {
            ((Map)hashMap).put((Object)"error", (Object)t.getClass().getName());
        }
        if (s != null && !s.isEmpty()) {
            ((Map)hashMap).put((Object)"experiment_id", (Object)s);
        }
        ((Map)hashMap).put((Object)"tag", (Object)"AdvertisingIdClient");
        ((Map)hashMap).put((Object)"time_spent", (Object)Long.toString(n2));
        new b.c.a.b.a.a.b(this, (Map)hashMap).start();
        return true;
    }
    
    public final void a() {
        j.g("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (this.f != null && this.a != null) {
                try {
                    if (this.c) {
                        com.google.android.gms.common.stats.a.b().c(this.f, (ServiceConnection)this.a);
                    }
                }
                finally {
                    final Throwable t;
                    Log.i("AdvertisingIdClient", "AdvertisingIdClient unbindService failed.", t);
                }
                this.c = false;
                this.b = null;
                this.a = null;
            }
        }
    }
    
    public a c() {
        j.g("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            Label_0108: {
                if (!this.c) {
                    final Object d = this.d;
                    synchronized (d) {
                        if (this.e != null && this.e.e) {
                            monitorexit(d);
                            try {
                                this.h(false);
                                if (this.c) {
                                    break Label_0108;
                                }
                                throw new IOException("AdvertisingIdClient cannot reconnect.");
                            }
                            catch (final Exception ex) {
                                throw new IOException("AdvertisingIdClient cannot reconnect.", (Throwable)ex);
                            }
                        }
                        throw new IOException("AdvertisingIdClient is not connected.");
                    }
                }
            }
            j.h((Object)this.a);
            j.h((Object)this.b);
            try {
                final a a = new a(this.b.d(), this.b.j(true));
                monitorexit(this);
                this.g();
                return a;
            }
            catch (final RemoteException ex2) {
                Log.i("AdvertisingIdClient", "GMS remote exception ", (Throwable)ex2);
                throw new IOException("Remote exception");
            }
        }
    }
    
    @Override
    protected void finalize() {
        this.a();
        super.finalize();
    }
    
    public static final class a
    {
        private final String a;
        private final boolean b;
        
        public a(final String a, final boolean b) {
            this.a = a;
            this.b = b;
        }
        
        public final String a() {
            return this.a;
        }
        
        public final boolean b() {
            return this.b;
        }
        
        @Override
        public final String toString() {
            final String a = this.a;
            final boolean b = this.b;
            final StringBuilder sb = new StringBuilder(String.valueOf((Object)a).length() + 7);
            sb.append("{");
            sb.append(a);
            sb.append("}");
            sb.append(b);
            return sb.toString();
        }
    }
    
    static final class b extends Thread
    {
        private WeakReference<a> b;
        private long c;
        CountDownLatch d;
        boolean e;
        
        public b(final a a, final long c) {
            this.b = (WeakReference<a>)new WeakReference((Object)a);
            this.c = c;
            this.d = new CountDownLatch(1);
            this.e = false;
            this.start();
        }
        
        private final void a() {
            final a a = (a)this.b.get();
            if (a != null) {
                a.a();
                this.e = true;
            }
        }
        
        public final void run() {
            try {
                if (!this.d.await(this.c, TimeUnit.MILLISECONDS)) {
                    this.a();
                }
            }
            catch (final InterruptedException ex) {
                this.a();
            }
        }
    }
}
