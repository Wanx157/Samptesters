package b.c.a.b.c.j;

import com.google.android.gms.common.util.m;
import android.content.Context;

public class a
{
    private static Context a;
    private static Boolean b;
    
    public static boolean a(final Context context) {
        final Class<a> clazz;
        monitorenter(clazz = a.class);
        try {
            final Context applicationContext = context.getApplicationContext();
            if (b.c.a.b.c.j.a.a != null && b.c.a.b.c.j.a.b != null && b.c.a.b.c.j.a.a == applicationContext) {
                final boolean booleanValue = b.c.a.b.c.j.a.b;
                monitorexit(clazz);
                return booleanValue;
            }
            b.c.a.b.c.j.a.b = null;
            Label_0095: {
                Boolean b = null;
                Label_0061: {
                    if (!m.h()) {
                        try {
                            context.getClassLoader().loadClass("com.google.android.instantapps.supervisor.InstantAppsRuntime");
                            b.c.a.b.c.j.a.b = Boolean.TRUE;
                        }
                        catch (final ClassNotFoundException ex) {
                            b = Boolean.FALSE;
                            break Label_0061;
                        }
                        break Label_0095;
                    }
                    b = applicationContext.getPackageManager().isInstantApp();
                }
                b.c.a.b.c.j.a.b = b;
            }
            b.c.a.b.c.j.a.a = applicationContext;
            final boolean booleanValue2 = b.c.a.b.c.j.a.b;
            monitorexit(clazz);
            return booleanValue2;
        }
        finally {
            monitorexit(clazz);
            while (true) {}
        }
    }
}
