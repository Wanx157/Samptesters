package b.c.a.b.e.e;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeMap;
import java.util.SortedMap;
import java.util.Iterator;
import java.util.Map$Entry;
import java.util.Collections;
import java.util.Map;
import java.util.List;
import java.util.AbstractMap;

class e8<K extends Comparable<K>, V> extends AbstractMap<K, V>
{
    private final int b = b;
    private List<b8> c = Collections.emptyList();
    private Map<K, V> d = Collections.emptyMap();
    private boolean e;
    private volatile d8 f;
    private Map<K, V> g = Collections.emptyMap();
    
    private final V k(final int n) {
        this.m();
        final Object value = ((b8)this.c.remove(n)).getValue();
        if (!this.d.isEmpty()) {
            final Iterator iterator = this.n().entrySet().iterator();
            final List<b8> c = this.c;
            final Map$Entry map$Entry = (Map$Entry)iterator.next();
            c.add((Object)new b8(this, (Comparable)map$Entry.getKey(), map$Entry.getValue()));
            iterator.remove();
        }
        return (V)value;
    }
    
    private final int l(final K k) {
        final int n = this.c.size() - 1;
        final int n2 = 0;
        int n3 = n;
        int i = n2;
        if (n >= 0) {
            final int compareTo = k.compareTo((Object)((b8)this.c.get(n)).d());
            if (compareTo > 0) {
                return -(n + 2);
            }
            if (compareTo == 0) {
                return n;
            }
            n3 = n;
            i = n2;
        }
        while (i <= n3) {
            final int n4 = (i + n3) / 2;
            final int compareTo2 = k.compareTo((Object)((b8)this.c.get(n4)).d());
            if (compareTo2 < 0) {
                n3 = n4 - 1;
            }
            else {
                if (compareTo2 <= 0) {
                    return n4;
                }
                i = n4 + 1;
            }
        }
        return -(i + 1);
    }
    
    private final void m() {
        if (!this.e) {
            return;
        }
        throw new UnsupportedOperationException();
    }
    
    private final SortedMap<K, V> n() {
        this.m();
        if (this.d.isEmpty() && !(this.d instanceof TreeMap)) {
            final TreeMap d = new TreeMap();
            this.d = (Map<K, V>)d;
            this.g = (Map<K, V>)d.descendingMap();
        }
        return (SortedMap<K, V>)this.d;
    }
    
    public void a() {
        if (!this.e) {
            Map d;
            if (this.d.isEmpty()) {
                d = Collections.emptyMap();
            }
            else {
                d = Collections.unmodifiableMap((Map)this.d);
            }
            this.d = (Map<K, V>)d;
            Map g;
            if (this.g.isEmpty()) {
                g = Collections.emptyMap();
            }
            else {
                g = Collections.unmodifiableMap((Map)this.g);
            }
            this.g = (Map<K, V>)g;
            this.e = true;
        }
    }
    
    public final boolean b() {
        return this.e;
    }
    
    public final int c() {
        return this.c.size();
    }
    
    public final void clear() {
        this.m();
        if (!this.c.isEmpty()) {
            this.c.clear();
        }
        if (!this.d.isEmpty()) {
            this.d.clear();
        }
    }
    
    public final boolean containsKey(final Object o) {
        final Comparable comparable = (Comparable)o;
        return this.l((K)comparable) >= 0 || this.d.containsKey((Object)comparable);
    }
    
    public final Map$Entry<K, V> d(final int n) {
        return (Map$Entry<K, V>)this.c.get(n);
    }
    
    public final Iterable<Map$Entry<K, V>> e() {
        Object o;
        if (this.d.isEmpty()) {
            o = a8.a();
        }
        else {
            o = this.d.entrySet();
        }
        return (Iterable<Map$Entry<K, V>>)o;
    }
    
    public final Set<Map$Entry<K, V>> entrySet() {
        if (this.f == null) {
            this.f = new d8(this, null);
        }
        return (Set<Map$Entry<K, V>>)this.f;
    }
    
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof e8)) {
            return super.equals(o);
        }
        final e8 e8 = (e8)o;
        final int size = this.size();
        if (size != e8.size()) {
            return false;
        }
        final int c = this.c();
        if (c == e8.c()) {
            for (int i = 0; i < c; ++i) {
                if (!this.d(i).equals((Object)e8.d(i))) {
                    return false;
                }
            }
            return c == size || this.d.equals((Object)e8.d);
        }
        return this.entrySet().equals((Object)e8.entrySet());
    }
    
    public final V f(final K k, final V value) {
        this.m();
        final int l = this.l(k);
        if (l >= 0) {
            return (V)((b8)this.c.get(l)).setValue(value);
        }
        this.m();
        if (this.c.isEmpty() && !(this.c instanceof ArrayList)) {
            this.c = (List<b8>)new ArrayList(this.b);
        }
        final int n = -(l + 1);
        if (n >= this.b) {
            return (V)this.n().put((Object)k, (Object)value);
        }
        final int size = this.c.size();
        final int b = this.b;
        if (size == b) {
            final b8 b2 = (b8)this.c.remove(b - 1);
            this.n().put((Object)b2.d(), b2.getValue());
        }
        this.c.add(n, (Object)new b8(this, k, value));
        return null;
    }
    
    public final V get(final Object o) {
        final Comparable comparable = (Comparable)o;
        final int l = this.l((K)comparable);
        if (l >= 0) {
            return (V)((b8)this.c.get(l)).getValue();
        }
        return (V)this.d.get((Object)comparable);
    }
    
    public final int hashCode() {
        final int c = this.c();
        int i = 0;
        int n = 0;
        while (i < c) {
            n += ((b8)this.c.get(i)).hashCode();
            ++i;
        }
        int n2 = n;
        if (this.d.size() > 0) {
            n2 = n + this.d.hashCode();
        }
        return n2;
    }
    
    public final V remove(final Object o) {
        this.m();
        final Comparable comparable = (Comparable)o;
        final int l = this.l((K)comparable);
        if (l >= 0) {
            return this.k(l);
        }
        if (this.d.isEmpty()) {
            return null;
        }
        return (V)this.d.remove((Object)comparable);
    }
    
    public final int size() {
        return this.c.size() + this.d.size();
    }
}
