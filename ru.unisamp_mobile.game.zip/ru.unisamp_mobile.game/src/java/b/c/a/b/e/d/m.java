package b.c.a.b.e.d;

final class m extends i
{
    public final void a(final Throwable t, final Throwable t2) {
    }
}
