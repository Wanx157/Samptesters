package b.c.a.b.b;

import android.os.Bundle;

final class w extends u<Bundle>
{
    w(final int n, final int n2, final Bundle bundle) {
        super(n, 1, bundle);
    }
    
    final void a(Bundle bundle) {
        if ((bundle = bundle.getBundle("data")) == null) {
            bundle = Bundle.EMPTY;
        }
        this.c((Object)bundle);
    }
    
    final boolean d() {
        return false;
    }
}
