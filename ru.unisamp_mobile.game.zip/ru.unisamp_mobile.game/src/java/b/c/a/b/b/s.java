package b.c.a.b.b;

import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.os.IBinder;
import android.os.Messenger;

final class s
{
    private final Messenger a;
    private final e b;
    
    s(final IBinder binder) {
        final String interfaceDescriptor = binder.getInterfaceDescriptor();
        if ("android.os.IMessenger".equals((Object)interfaceDescriptor)) {
            this.a = new Messenger(binder);
            this.b = null;
            return;
        }
        if ("com.google.android.gms.iid.IMessengerCompat".equals((Object)interfaceDescriptor)) {
            this.b = new e(binder);
            this.a = null;
            return;
        }
        final String value = String.valueOf((Object)interfaceDescriptor);
        String concat;
        if (value.length() != 0) {
            concat = "Invalid interface descriptor: ".concat(value);
        }
        else {
            concat = new String("Invalid interface descriptor: ");
        }
        Log.w("MessengerIpcClient", concat);
        throw new RemoteException();
    }
    
    final void a(final Message message) {
        final Messenger a = this.a;
        if (a != null) {
            a.send(message);
            return;
        }
        final e b = this.b;
        if (b != null) {
            b.b(message);
            return;
        }
        throw new IllegalStateException("Both messengers are null");
    }
}
