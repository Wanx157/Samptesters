package b.c.a.b.b;

import android.os.IBinder;
import android.content.ComponentName;
import java.util.concurrent.TimeUnit;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import java.util.Iterator;
import com.google.android.gms.common.stats.a;
import android.util.Log;
import java.util.ArrayDeque;
import android.os.Handler;
import android.os.Handler$Callback;
import b.c.a.b.e.b.e;
import android.os.Looper;
import android.util.SparseArray;
import java.util.Queue;
import android.os.Messenger;
import javax.annotation.concurrent.GuardedBy;
import android.content.ServiceConnection;

final class j implements ServiceConnection
{
    @GuardedBy("this")
    int a;
    final Messenger b;
    s c;
    @GuardedBy("this")
    final Queue<u<?>> d;
    @GuardedBy("this")
    final SparseArray<u<?>> e;
    final i f;
    
    private j(final i f) {
        this.f = f;
        this.a = 0;
        this.b = new Messenger((Handler)new e(Looper.getMainLooper(), (Handler$Callback)new m(this)));
        this.d = (Queue<u<?>>)new ArrayDeque();
        this.e = (SparseArray<u<?>>)new SparseArray();
    }
    
    final void a() {
        this.f.b.execute((Runnable)new n(this));
    }
    
    final void b(final int n) {
        synchronized (this) {
            final u u = (u)this.e.get(n);
            if (u != null) {
                final StringBuilder sb = new StringBuilder(31);
                sb.append("Timing out request: ");
                sb.append(n);
                Log.w("MessengerIpcClient", sb.toString());
                this.e.remove(n);
                u.b(new t(3, "Timed out waiting for response"));
                this.f();
            }
        }
    }
    
    final void c(int i, final String s) {
        monitorenter(this);
        try {
            if (Log.isLoggable("MessengerIpcClient", 3)) {
                final String value = String.valueOf((Object)s);
                String concat;
                if (value.length() != 0) {
                    concat = "Disconnected: ".concat(value);
                }
                else {
                    concat = new String("Disconnected: ");
                }
                Log.d("MessengerIpcClient", concat);
            }
            final int a = this.a;
            if (a == 0) {
                throw new IllegalStateException();
            }
            if (a == 1 || a == 2) {
                if (Log.isLoggable("MessengerIpcClient", 2)) {
                    Log.v("MessengerIpcClient", "Unbinding service");
                }
                this.a = 4;
                com.google.android.gms.common.stats.a.b().c(this.f.a, (ServiceConnection)this);
                final t t = new t(i, s);
                final Iterator iterator = this.d.iterator();
                while (iterator.hasNext()) {
                    ((u)iterator.next()).b(t);
                }
                this.d.clear();
                for (i = 0; i < this.e.size(); ++i) {
                    ((u)this.e.valueAt(i)).b(t);
                }
                this.e.clear();
                monitorexit(this);
                return;
            }
            if (a == 3) {
                this.a = 4;
                monitorexit(this);
                return;
            }
            if (a == 4) {
                monitorexit(this);
                return;
            }
            i = this.a;
            final StringBuilder sb = new StringBuilder(26);
            sb.append("Unknown state: ");
            sb.append(i);
            throw new IllegalStateException(sb.toString());
        }
        finally {
            monitorexit(this);
            while (true) {}
        }
    }
    
    final boolean d(final Message message) {
        final int arg1 = message.arg1;
        if (Log.isLoggable("MessengerIpcClient", 3)) {
            final StringBuilder sb = new StringBuilder(41);
            sb.append("Received response to request: ");
            sb.append(arg1);
            Log.d("MessengerIpcClient", sb.toString());
        }
        synchronized (this) {
            final u u = (u)this.e.get(arg1);
            if (u == null) {
                final StringBuilder sb2 = new StringBuilder(50);
                sb2.append("Received response for unknown request: ");
                sb2.append(arg1);
                Log.w("MessengerIpcClient", sb2.toString());
                return true;
            }
            this.e.remove(arg1);
            this.f();
            monitorexit(this);
            final Bundle data = message.getData();
            if (data.getBoolean("unsupported", false)) {
                u.b(new t(4, "Not supported by GmsCore"));
            }
            else {
                u.a(data);
            }
            return true;
        }
    }
    
    final boolean e(final u<?> u) {
        synchronized (this) {
            final int a = this.a;
            if (a == 0) {
                this.d.add((Object)u);
                com.google.android.gms.common.internal.j.k(this.a == 0);
                if (Log.isLoggable("MessengerIpcClient", 2)) {
                    Log.v("MessengerIpcClient", "Starting bind to GmsCore");
                }
                this.a = 1;
                final Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
                intent.setPackage("com.google.android.gms");
                if (!com.google.android.gms.common.stats.a.b().a(this.f.a, intent, (ServiceConnection)this, 1)) {
                    this.c(0, "Unable to bind to service");
                }
                else {
                    this.f.b.schedule((Runnable)new l(this), 30L, TimeUnit.SECONDS);
                }
                return true;
            }
            if (a == 1) {
                this.d.add((Object)u);
                return true;
            }
            if (a == 2) {
                this.d.add((Object)u);
                this.a();
                return true;
            }
            if (a != 3 && a != 4) {
                final int a2 = this.a;
                final StringBuilder sb = new StringBuilder(26);
                sb.append("Unknown state: ");
                sb.append(a2);
                throw new IllegalStateException(sb.toString());
            }
            return false;
        }
    }
    
    final void f() {
        synchronized (this) {
            if (this.a == 2 && this.d.isEmpty() && this.e.size() == 0) {
                if (Log.isLoggable("MessengerIpcClient", 2)) {
                    Log.v("MessengerIpcClient", "Finished handling requests, unbinding");
                }
                this.a = 3;
                com.google.android.gms.common.stats.a.b().c(this.f.a, (ServiceConnection)this);
            }
        }
    }
    
    final void g() {
        synchronized (this) {
            if (this.a == 1) {
                this.c(1, "Timed out while binding");
            }
        }
    }
    
    public final void onServiceConnected(final ComponentName componentName, final IBinder binder) {
        if (Log.isLoggable("MessengerIpcClient", 2)) {
            Log.v("MessengerIpcClient", "Service connected");
        }
        this.f.b.execute((Runnable)new o(this, binder));
    }
    
    public final void onServiceDisconnected(final ComponentName componentName) {
        if (Log.isLoggable("MessengerIpcClient", 2)) {
            Log.v("MessengerIpcClient", "Service disconnected");
        }
        this.f.b.execute((Runnable)new q(this));
    }
}
