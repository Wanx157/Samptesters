package b.c.a.b.c;

import android.os.Parcelable;
import com.google.android.gms.common.internal.l.c;
import android.os.Parcel;
import com.google.android.gms.common.internal.i$a;
import com.google.android.gms.common.internal.i;
import android.app.PendingIntent;
import android.os.Parcelable$Creator;
import com.google.android.gms.common.internal.l.a;

public final class b extends a
{
    public static final Parcelable$Creator<b> CREATOR;
    public static final b f;
    private final int b;
    private final int c;
    private final PendingIntent d;
    private final String e;
    
    static {
        f = new b(0);
        CREATOR = (Parcelable$Creator)new k();
    }
    
    public b(final int n) {
        this(n, null, null);
    }
    
    b(final int b, final int c, final PendingIntent d, final String e) {
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public b(final int n, final PendingIntent pendingIntent) {
        this(n, pendingIntent, null);
    }
    
    public b(final int n, final PendingIntent pendingIntent, final String s) {
        this(1, n, pendingIntent, s);
    }
    
    static String j(final int n) {
        if (n == 99) {
            return "UNFINISHED";
        }
        if (n == 1500) {
            return "DRIVE_EXTERNAL_STORAGE_REQUIRED";
        }
        switch (n) {
            default: {
                switch (n) {
                    default: {
                        final StringBuilder sb = new StringBuilder(31);
                        sb.append("UNKNOWN_ERROR_CODE(");
                        sb.append(n);
                        sb.append(")");
                        return sb.toString();
                    }
                    case 21: {
                        return "API_VERSION_UPDATE_REQUIRED";
                    }
                    case 20: {
                        return "RESTRICTED_PROFILE";
                    }
                    case 19: {
                        return "SERVICE_MISSING_PERMISSION";
                    }
                    case 18: {
                        return "SERVICE_UPDATING";
                    }
                    case 17: {
                        return "SIGN_IN_FAILED";
                    }
                    case 16: {
                        return "API_UNAVAILABLE";
                    }
                    case 15: {
                        return "INTERRUPTED";
                    }
                    case 14: {
                        return "TIMEOUT";
                    }
                    case 13: {
                        return "CANCELED";
                    }
                }
                break;
            }
            case 11: {
                return "LICENSE_CHECK_FAILED";
            }
            case 10: {
                return "DEVELOPER_ERROR";
            }
            case 9: {
                return "SERVICE_INVALID";
            }
            case 8: {
                return "INTERNAL_ERROR";
            }
            case 7: {
                return "NETWORK_ERROR";
            }
            case 6: {
                return "RESOLUTION_REQUIRED";
            }
            case 5: {
                return "INVALID_ACCOUNT";
            }
            case 4: {
                return "SIGN_IN_REQUIRED";
            }
            case 3: {
                return "SERVICE_DISABLED";
            }
            case 2: {
                return "SERVICE_VERSION_UPDATE_REQUIRED";
            }
            case 1: {
                return "SERVICE_MISSING";
            }
            case 0: {
                return "SUCCESS";
            }
            case -1: {
                return "UNKNOWN";
            }
        }
    }
    
    public final int c() {
        return this.c;
    }
    
    public final String d() {
        return this.e;
    }
    
    public final boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof b)) {
            return false;
        }
        final b b = (b)o;
        return this.c == b.c && i.a((Object)this.d, (Object)b.d) && i.a((Object)this.e, (Object)b.e);
    }
    
    public final PendingIntent h() {
        return this.d;
    }
    
    public final int hashCode() {
        return i.b(new Object[] { this.c, this.d, this.e });
    }
    
    public final boolean i() {
        return this.c == 0;
    }
    
    public final String toString() {
        final i$a c = i.c((Object)this);
        c.a("statusCode", (Object)j(this.c));
        c.a("resolution", (Object)this.d);
        c.a("message", (Object)this.e);
        return c.toString();
    }
    
    public final void writeToParcel(final Parcel parcel, final int n) {
        final int a = com.google.android.gms.common.internal.l.c.a(parcel);
        com.google.android.gms.common.internal.l.c.j(parcel, 1, this.b);
        com.google.android.gms.common.internal.l.c.j(parcel, 2, this.c());
        com.google.android.gms.common.internal.l.c.m(parcel, 3, (Parcelable)this.h(), n, false);
        com.google.android.gms.common.internal.l.c.n(parcel, 4, this.d(), false);
        com.google.android.gms.common.internal.l.c.b(parcel, a);
    }
}
