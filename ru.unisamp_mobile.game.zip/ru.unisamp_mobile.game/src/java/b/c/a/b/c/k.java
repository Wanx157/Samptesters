package b.c.a.b.c;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class k implements Parcelable$Creator<b>
{
}
