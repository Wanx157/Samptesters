package b.c.a.b.c.i;

import b.c.a.b.e.c.i;
import b.c.a.b.e.c.d;
import java.util.concurrent.ScheduledExecutorService;

final class b implements a$a
{
    public final ScheduledExecutorService a() {
        return d.a().a(1, i.a);
    }
}
