package b.c.a.b.b;

import java.util.concurrent.ScheduledFuture;
import b.c.a.b.g.a;
import android.os.RemoteException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.os.Message;
import android.os.Parcelable;
import android.content.Intent;
import b.c.a.b.g.l;
import java.io.IOException;
import android.util.Log;
import b.c.a.b.g.i;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import android.os.Handler;
import android.os.Looper;
import android.os.Messenger;
import java.util.concurrent.ScheduledExecutorService;
import android.content.Context;
import javax.annotation.concurrent.GuardedBy;
import android.os.Bundle;
import b.c.a.b.g.j;
import a.d.g;
import java.util.concurrent.Executor;
import android.app.PendingIntent;

public class d
{
    private static int h;
    private static PendingIntent i;
    private static final Executor j;
    @GuardedBy("responseCallbacks")
    private final g<String, j<Bundle>> a;
    private final Context b;
    private final v c;
    private final ScheduledExecutorService d;
    private Messenger e;
    private Messenger f;
    private e g;
    
    static {
        j = d0.a;
    }
    
    public d(final Context b) {
        this.a = new g<String, j<Bundle>>();
        this.b = b;
        this.c = new v(b);
        this.e = new Messenger((Handler)new c0(this, Looper.getMainLooper()));
        final ScheduledThreadPoolExecutor d = new ScheduledThreadPoolExecutor(1);
        d.setKeepAliveTime(60L, TimeUnit.SECONDS);
        d.allowCoreThreadTimeOut(true);
        this.d = (ScheduledExecutorService)d;
    }
    
    private static String e() {
        synchronized (d.class) {
            final int h = d.h;
            d.h = h + 1;
            return Integer.toString(h);
        }
    }
    
    private static void f(final Context context, final Intent intent) {
        synchronized (d.class) {
            if (d.i == null) {
                final Intent intent2 = new Intent();
                intent2.setPackage("com.google.example.invalidpackage");
                d.i = PendingIntent.getBroadcast(context, 0, intent2, 0);
            }
            intent.putExtra("app", (Parcelable)d.i);
        }
    }
    
    private final void g(final Message message) {
        if (message != null) {
            final Object obj = message.obj;
            if (obj instanceof Intent) {
                final Intent intent = (Intent)obj;
                intent.setExtrasClassLoader((ClassLoader)new e.a());
                if (intent.hasExtra("google.messenger")) {
                    final Parcelable parcelableExtra = intent.getParcelableExtra("google.messenger");
                    if (parcelableExtra instanceof e) {
                        this.g = (e)parcelableExtra;
                    }
                    if (parcelableExtra instanceof Messenger) {
                        this.f = (Messenger)parcelableExtra;
                    }
                }
                final Intent intent2 = (Intent)message.obj;
                final String action = intent2.getAction();
                if (!"com.google.android.c2dm.intent.REGISTRATION".equals((Object)action)) {
                    if (Log.isLoggable("Rpc", 3)) {
                        final String value = String.valueOf((Object)action);
                        String concat;
                        if (value.length() != 0) {
                            concat = "Unexpected response action: ".concat(value);
                        }
                        else {
                            concat = new String("Unexpected response action: ");
                        }
                        Log.d("Rpc", concat);
                    }
                    return;
                }
                String s;
                if ((s = intent2.getStringExtra("registration_id")) == null) {
                    s = intent2.getStringExtra("unregistered");
                }
                if (s == null) {
                    final String stringExtra = intent2.getStringExtra("error");
                    if (stringExtra == null) {
                        final String value2 = String.valueOf((Object)intent2.getExtras());
                        final StringBuilder sb = new StringBuilder(String.valueOf((Object)value2).length() + 49);
                        sb.append("Unexpected response, no error or registration id ");
                        sb.append(value2);
                        Log.w("Rpc", sb.toString());
                        return;
                    }
                    if (Log.isLoggable("Rpc", 3)) {
                        final String value3 = String.valueOf((Object)stringExtra);
                        String concat2;
                        if (value3.length() != 0) {
                            concat2 = "Received InstanceID error ".concat(value3);
                        }
                        else {
                            concat2 = new String("Received InstanceID error ");
                        }
                        Log.d("Rpc", concat2);
                    }
                    if (stringExtra.startsWith("|")) {
                        final String[] split = stringExtra.split("\\|");
                        if (split.length > 2 && "ID".equals((Object)split[1])) {
                            final String s2 = split[2];
                            String substring;
                            final String s3 = substring = split[3];
                            if (s3.startsWith(":")) {
                                substring = s3.substring(1);
                            }
                            this.j(s2, intent2.putExtra("error", substring).getExtras());
                            return;
                        }
                        final String value4 = String.valueOf((Object)stringExtra);
                        String concat3;
                        if (value4.length() != 0) {
                            concat3 = "Unexpected structured response ".concat(value4);
                        }
                        else {
                            concat3 = new String("Unexpected structured response ");
                        }
                        Log.w("Rpc", concat3);
                        return;
                    }
                    else {
                        final g<String, j<Bundle>> a;
                        monitorenter(a = this.a);
                        int i = 0;
                        try {
                            while (i < this.a.size()) {
                                this.j(this.a.i(i), intent2.getExtras());
                                ++i;
                            }
                            return;
                        }
                        finally {
                            monitorexit(a);
                        }
                    }
                }
                final Matcher matcher = Pattern.compile("\\|ID\\|([^|]+)\\|:?+(.*)").matcher((CharSequence)s);
                if (!matcher.matches()) {
                    if (Log.isLoggable("Rpc", 3)) {
                        final String value5 = String.valueOf((Object)s);
                        String concat4;
                        if (value5.length() != 0) {
                            concat4 = "Unexpected response string: ".concat(value5);
                        }
                        else {
                            concat4 = new String("Unexpected response string: ");
                        }
                        Log.d("Rpc", concat4);
                    }
                    return;
                }
                final String group = matcher.group(1);
                final String group2 = matcher.group(2);
                if (group != null) {
                    final Bundle extras = intent2.getExtras();
                    extras.putString("registration_id", group2);
                    this.j(group, extras);
                }
                return;
            }
        }
        Log.w("Rpc", "Dropping invalid message");
    }
    
    private final void j(String s, final Bundle bundle) {
        final g<String, j<Bundle>> a = this.a;
        synchronized (a) {
            final j j = this.a.remove(s);
            if (j == null) {
                s = String.valueOf((Object)s);
                if (s.length() != 0) {
                    s = "Missing callback for ".concat(s);
                }
                else {
                    s = new String("Missing callback for ");
                }
                Log.w("Rpc", s);
                return;
            }
            j.c((Object)bundle);
        }
    }
    
    private static boolean l(final Bundle bundle) {
        return bundle != null && bundle.containsKey("google.messenger");
    }
    
    private final i<Bundle> m(final Bundle bundle) {
        final String e = e();
        final j j = new j();
        final g<String, j<Bundle>> a = this.a;
        synchronized (a) {
            this.a.put(e, (j<Bundle>)j);
            monitorexit(a);
            final Intent obj = new Intent();
            obj.setPackage("com.google.android.gms");
            String action;
            if (this.c.a() == 2) {
                action = "com.google.iid.TOKEN_REQUEST";
            }
            else {
                action = "com.google.android.c2dm.intent.REGISTER";
            }
            obj.setAction(action);
            obj.putExtras(bundle);
            f(this.b, obj);
            final StringBuilder sb = new StringBuilder(String.valueOf((Object)e).length() + 5);
            sb.append("|ID|");
            sb.append(e);
            sb.append("|");
            obj.putExtra("kid", sb.toString());
            if (Log.isLoggable("Rpc", 3)) {
                final String value = String.valueOf((Object)obj.getExtras());
                final StringBuilder sb2 = new StringBuilder(String.valueOf((Object)value).length() + 8);
                sb2.append("Sending ");
                sb2.append(value);
                Log.d("Rpc", sb2.toString());
            }
            obj.putExtra("google.messenger", (Parcelable)this.e);
            Label_0331: {
                if (this.f != null || this.g != null) {
                    final Message obtain = Message.obtain();
                    obtain.obj = obj;
                    try {
                        if (this.f != null) {
                            this.f.send(obtain);
                            break Label_0331;
                        }
                        this.g.b(obtain);
                        break Label_0331;
                    }
                    catch (final RemoteException ex) {
                        if (Log.isLoggable("Rpc", 3)) {
                            Log.d("Rpc", "Messenger failed, fallback to startService");
                        }
                    }
                }
                if (this.c.a() == 2) {
                    this.b.sendBroadcast(obj);
                }
                else {
                    this.b.startService(obj);
                }
            }
            j.a().c(b.c.a.b.b.d.j, (b.c.a.b.g.d)new b0(this, e, this.d.schedule((Runnable)new y(j), 30L, TimeUnit.SECONDS)));
            return (i<Bundle>)j.a();
        }
    }
    
    public i<Bundle> a(final Bundle bundle) {
        final int c = this.c.c();
        boolean b = true;
        if (c >= 12000000) {
            return (i<Bundle>)b.c.a.b.b.i.c(this.b).f(1, bundle).g(b.c.a.b.b.d.j, x.a);
        }
        if (this.c.a() == 0) {
            b = false;
        }
        if (!b) {
            return (i<Bundle>)l.d((Exception)new IOException("MISSING_INSTANCEID_SERVICE"));
        }
        return (i<Bundle>)this.m(bundle).i(b.c.a.b.b.d.j, (a)new z(this, bundle));
    }
}
