package b.c.a.b.e.e;

import android.os.Bundle;
import android.app.Activity;
import android.app.Application$ActivityLifecycleCallbacks;

final class g0 implements Application$ActivityLifecycleCallbacks
{
    final h0 b;
    
    g0(final h0 b) {
        this.b = b;
    }
    
    public final void onActivityCreated(final Activity activity, final Bundle bundle) {
        this.b.n((x)new z(this, bundle, activity));
    }
    
    public final void onActivityDestroyed(final Activity activity) {
        this.b.n((x)new f0(this, activity));
    }
    
    public final void onActivityPaused(final Activity activity) {
        this.b.n((x)new c0(this, activity));
    }
    
    public final void onActivityResumed(final Activity activity) {
        this.b.n((x)new b0(this, activity));
    }
    
    public final void onActivitySaveInstanceState(final Activity activity, final Bundle bundle) {
        final qb qb = new qb();
        this.b.n((x)new e0(this, activity, qb));
        final Bundle p2 = qb.P(50L);
        if (p2 != null) {
            bundle.putAll(p2);
        }
    }
    
    public final void onActivityStarted(final Activity activity) {
        this.b.n((x)new a0(this, activity));
    }
    
    public final void onActivityStopped(final Activity activity) {
        this.b.n((x)new d0(this, activity));
    }
}
