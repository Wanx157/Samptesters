package b.c.a.b.e.d;

import java.util.Queue;
import java.util.ArrayDeque;
import java.io.InputStream;

public final class g
{
    static {
        new e();
    }
    
    public static byte[] a(final InputStream inputStream) {
        final ArrayDeque arrayDeque = new ArrayDeque(20);
        int n = 8192;
        int i = 0;
        while (i < 2147483639) {
            final int min = Math.min(n, 2147483639 - i);
            final byte[] array = new byte[min];
            ((Queue)arrayDeque).add((Object)array);
            int read;
            for (int j = 0; j < min; j += read, i += read) {
                read = inputStream.read(array, j, min - j);
                if (read == -1) {
                    return c((Queue<byte[]>)arrayDeque, i);
                }
            }
            final long n2 = n;
            final long n3 = n2 + n2;
            if (n3 > 2147483647L) {
                n = Integer.MAX_VALUE;
                continue;
            }
            if (n3 < -2147483648L) {
                n = Integer.MIN_VALUE;
                continue;
            }
            n = (int)n3;
        }
        if (inputStream.read() == -1) {
            return c((Queue<byte[]>)arrayDeque, 2147483639);
        }
        throw new OutOfMemoryError("input is too large to fit in a byte array");
    }
    
    public static InputStream b(final InputStream inputStream, final long n) {
        return (InputStream)new f(inputStream, 1048577L);
    }
    
    private static byte[] c(final Queue<byte[]> queue, final int n) {
        final byte[] array = new byte[n];
        int min;
        for (int i = n; i > 0; i -= min) {
            final byte[] array2 = (byte[])queue.remove();
            min = Math.min(i, array2.length);
            System.arraycopy((Object)array2, 0, (Object)array, n - i, min);
        }
        return array;
    }
}
