package b.c.a.b.e.d;

public interface a
{
}
