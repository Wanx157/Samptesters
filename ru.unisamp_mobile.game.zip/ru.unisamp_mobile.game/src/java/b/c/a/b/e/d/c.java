package b.c.a.b.e.d;

final class c implements a
{
}
