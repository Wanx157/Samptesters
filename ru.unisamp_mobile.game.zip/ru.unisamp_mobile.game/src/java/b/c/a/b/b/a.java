package b.c.a.b.b;

import android.os.Parcelable;
import com.google.android.gms.common.internal.l.c;
import android.os.Parcel;
import android.content.Intent;
import android.os.Parcelable$Creator;

public final class a extends com.google.android.gms.common.internal.l.a
{
    public static final Parcelable$Creator<a> CREATOR;
    private Intent b;
    
    static {
        CREATOR = (Parcelable$Creator)new f();
    }
    
    public a(final Intent b) {
        this.b = b;
    }
    
    public final Intent c() {
        return this.b;
    }
    
    public final void writeToParcel(final Parcel parcel, final int n) {
        final int a = c.a(parcel);
        c.m(parcel, 1, (Parcelable)this.b, n, false);
        c.b(parcel, a);
    }
}
