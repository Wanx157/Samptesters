package b.c.a.b.d;

import android.os.IInterface;

public interface a extends IInterface
{
}
