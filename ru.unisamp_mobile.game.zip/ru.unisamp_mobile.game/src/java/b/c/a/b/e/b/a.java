package b.c.a.b.e.b;

public final class a
{
    private static volatile b a;
    
    static {
        b.c.a.b.e.b.a.a = (b)new c((d)null);
    }
    
    public static b a() {
        return b.c.a.b.e.b.a.a;
    }
}
