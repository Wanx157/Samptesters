package b.c.a.b.e.e;

public interface f9
{
    boolean a();
}
