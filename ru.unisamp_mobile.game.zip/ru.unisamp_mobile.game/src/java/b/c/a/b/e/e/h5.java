package b.c.a.b.e.e;

public class h5
{
    public static int a(final int n) {
        return -(n & 0x1) ^ n >>> 1;
    }
    
    public static long b(final long n) {
        return -(n & 0x1L) ^ n >>> 1;
    }
}
