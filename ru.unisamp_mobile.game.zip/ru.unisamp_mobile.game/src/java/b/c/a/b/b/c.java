package b.c.a.b.b;

import android.os.Message;
import android.os.IInterface;

interface c extends IInterface
{
    void w(final Message p0);
}
