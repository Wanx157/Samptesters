package b.c.a.b.e.e;

import java.util.Iterator;

final class a8
{
    private static final Iterator<Object> a;
    private static final Iterable<Object> b;
    
    static {
        a = (Iterator)new y7();
        b = (Iterable)new z7();
    }
    
    static <T> Iterable<T> a() {
        return (Iterable<T>)a8.b;
    }
}
