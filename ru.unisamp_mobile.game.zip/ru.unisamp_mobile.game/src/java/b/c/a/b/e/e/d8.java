package b.c.a.b.e.e;

import java.util.Iterator;
import java.util.Map$Entry;
import java.util.AbstractSet;

final class d8 extends AbstractSet<Map$Entry>
{
    final e8 b;
    
    public final void clear() {
        this.b.clear();
    }
    
    public final boolean contains(Object value) {
        final Map$Entry map$Entry = (Map$Entry)value;
        value = this.b.get(map$Entry.getKey());
        final Object value2 = map$Entry.getValue();
        boolean b = false;
        if (value != value2) {
            if (value == null) {
                return b;
            }
            if (!value.equals(value2)) {
                return false;
            }
        }
        b = true;
        return b;
    }
    
    public final Iterator<Map$Entry> iterator() {
        return (Iterator<Map$Entry>)new c8(this.b, null);
    }
    
    public final boolean remove(final Object o) {
        final Map$Entry map$Entry = (Map$Entry)o;
        if (this.contains(map$Entry)) {
            this.b.remove(map$Entry.getKey());
            return true;
        }
        return false;
    }
    
    public final int size() {
        return this.b.size();
    }
}
