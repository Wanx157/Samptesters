package b.c.a.b.e.e;

public final class h8 extends RuntimeException
{
    public h8(final i7 i7) {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}
