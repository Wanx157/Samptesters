package b.c.a.b.e.e;

abstract class i4
{
    public abstract void a(final Throwable p0, final Throwable p1);
}
