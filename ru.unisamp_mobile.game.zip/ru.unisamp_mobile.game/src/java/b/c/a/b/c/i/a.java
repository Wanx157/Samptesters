package b.c.a.b.c.i;

import java.util.concurrent.ScheduledExecutorService;

@Deprecated
public class a
{
    private static a a;
    
    @Deprecated
    public static a a() {
        synchronized (a.class) {
            if (b.c.a.b.c.i.a.a == null) {
                b.c.a.b.c.i.a.a = (a)new b();
            }
            return b.c.a.b.c.i.a.a;
        }
    }
    
    public interface a
    {
        @Deprecated
        ScheduledExecutorService a();
    }
}
