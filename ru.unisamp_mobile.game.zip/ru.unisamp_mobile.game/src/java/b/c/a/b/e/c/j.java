package b.c.a.b.e.c;

import org.checkerframework.checker.nullness.compatqual.NonNullDecl;

public final class j
{
    @NonNullDecl
    public static <T> T a(@NonNullDecl final T t) {
        if (t != null) {
            return t;
        }
        throw null;
    }
}
