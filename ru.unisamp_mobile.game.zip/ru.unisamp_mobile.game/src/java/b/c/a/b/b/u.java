package b.c.a.b.b;

import android.util.Log;
import android.os.Bundle;
import b.c.a.b.g.j;

abstract class u<T>
{
    final int a;
    final j<T> b;
    final int c;
    final Bundle d;
    
    u(final int a, final int c, final Bundle d) {
        this.b = (j<T>)new j();
        this.a = a;
        this.c = c;
        this.d = d;
    }
    
    abstract void a(final Bundle p0);
    
    final void b(final t t) {
        if (Log.isLoggable("MessengerIpcClient", 3)) {
            final String value = String.valueOf((Object)this);
            final String value2 = String.valueOf((Object)t);
            final StringBuilder sb = new StringBuilder(String.valueOf((Object)value).length() + 14 + String.valueOf((Object)value2).length());
            sb.append("Failing ");
            sb.append(value);
            sb.append(" with ");
            sb.append(value2);
            Log.d("MessengerIpcClient", sb.toString());
        }
        this.b.b((Exception)t);
    }
    
    final void c(final T t) {
        if (Log.isLoggable("MessengerIpcClient", 3)) {
            final String value = String.valueOf((Object)this);
            final String value2 = String.valueOf((Object)t);
            final StringBuilder sb = new StringBuilder(String.valueOf((Object)value).length() + 16 + String.valueOf((Object)value2).length());
            sb.append("Finishing ");
            sb.append(value);
            sb.append(" with ");
            sb.append(value2);
            Log.d("MessengerIpcClient", sb.toString());
        }
        this.b.c((Object)t);
    }
    
    abstract boolean d();
    
    @Override
    public String toString() {
        final int c = this.c;
        final int a = this.a;
        final boolean d = this.d();
        final StringBuilder sb = new StringBuilder(55);
        sb.append("Request { what=");
        sb.append(c);
        sb.append(" id=");
        sb.append(a);
        sb.append(" oneWay=");
        sb.append(d);
        sb.append("}");
        return sb.toString();
    }
}
