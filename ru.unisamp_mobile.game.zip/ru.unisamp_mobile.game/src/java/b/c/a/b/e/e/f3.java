package b.c.a.b.e.e;

interface f3
{
    Object a(final String p0);
}
