package b.c.a.b.b;

import java.util.List;
import android.content.pm.PackageManager;
import android.content.Intent;
import com.google.android.gms.common.util.m;
import android.content.pm.PackageManager$NameNotFoundException;
import android.util.Log;
import b.c.a.b.c.j.c;
import android.content.pm.PackageInfo;
import javax.annotation.concurrent.GuardedBy;
import android.content.Context;

public final class v
{
    private final Context a;
    @GuardedBy("this")
    private int b;
    @GuardedBy("this")
    private int c;
    
    public v(final Context a) {
        this.c = 0;
        this.a = a;
    }
    
    private final PackageInfo b(String value) {
        try {
            return b.c.a.b.c.j.c.a(this.a).d(value, 0);
        }
        catch (final PackageManager$NameNotFoundException ex) {
            value = String.valueOf((Object)ex);
            final StringBuilder sb = new StringBuilder(String.valueOf((Object)value).length() + 23);
            sb.append("Failed to find package ");
            sb.append(value);
            Log.w("Metadata", sb.toString());
            return null;
        }
    }
    
    public final int a() {
        synchronized (this) {
            if (this.c != 0) {
                return this.c;
            }
            final PackageManager packageManager = this.a.getPackageManager();
            if (b.c.a.b.c.j.c.a(this.a).b("com.google.android.c2dm.permission.SEND", "com.google.android.gms") == -1) {
                Log.e("Metadata", "Google Play services missing or without correct permission.");
                return 0;
            }
            if (!m.h()) {
                final Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
                intent.setPackage("com.google.android.gms");
                final List queryIntentServices = packageManager.queryIntentServices(intent, 0);
                if (queryIntentServices != null && queryIntentServices.size() > 0) {
                    return this.c = 1;
                }
            }
            final Intent intent2 = new Intent("com.google.iid.TOKEN_REQUEST");
            intent2.setPackage("com.google.android.gms");
            final List queryBroadcastReceivers = packageManager.queryBroadcastReceivers(intent2, 0);
            if (queryBroadcastReceivers != null && queryBroadcastReceivers.size() > 0) {
                return this.c = 2;
            }
            Log.w("Metadata", "Failed to resolve IID implementation package, falling back");
            if (m.h()) {
                this.c = 2;
            }
            else {
                this.c = 1;
            }
            return this.c;
        }
    }
    
    public final int c() {
        synchronized (this) {
            if (this.b == 0) {
                final PackageInfo b = this.b("com.google.android.gms");
                if (b != null) {
                    this.b = b.versionCode;
                }
            }
            return this.b;
        }
    }
}
