package b.c.a.b.c;

import com.google.android.gms.dynamite.DynamiteModule$a;
import android.os.RemoteException;
import java.util.concurrent.Callable;
import b.c.a.b.d.b;
import com.google.android.gms.common.internal.y;
import com.google.android.gms.dynamite.DynamiteModule;
import com.google.android.gms.common.internal.j;
import android.util.Log;
import android.os.StrictMode$ThreadPolicy;
import android.os.StrictMode;
import android.content.Context;
import com.google.android.gms.common.internal.z;
import javax.annotation.CheckReturnValue;

@CheckReturnValue
final class m
{
    private static volatile z a;
    private static final Object b;
    private static Context c;
    
    static {
        b = new Object();
    }
    
    static v a(final String s, final n n, final boolean b, final boolean b2) {
        final StrictMode$ThreadPolicy allowThreadDiskReads = StrictMode.allowThreadDiskReads();
        try {
            return d(s, n, b, b2);
        }
        finally {
            StrictMode.setThreadPolicy(allowThreadDiskReads);
        }
    }
    
    static void c(final Context context) {
        synchronized (m.class) {
            if (m.c == null) {
                if (context != null) {
                    m.c = context.getApplicationContext();
                }
            }
            else {
                Log.w("GoogleCertificates", "GoogleCertificates has been initialized already");
            }
        }
    }
    
    private static v d(String s, final n n, final boolean b, final boolean b2) {
        try {
            if (m.a == null) {
                j.h((Object)m.c);
                final Object b3 = m.b;
                synchronized (b3) {
                    if (m.a == null) {
                        m.a = y.O(DynamiteModule.d(m.c, DynamiteModule.i, "com.google.android.gms.googlecertificates").c("com.google.android.gms.common.GoogleCertificatesImpl"));
                    }
                }
            }
            j.h((Object)m.c);
            final t t = new t(s, n, b, b2);
            try {
                if (m.a.o(t, b.Q((Object)m.c.getPackageManager()))) {
                    return v.a();
                }
                return v.d((Callable<String>)new o(b, s, n));
            }
            catch (final RemoteException ex) {
                Log.e("GoogleCertificates", "Failed to get Google certificates from remote", (Throwable)ex);
                return v.c("module call", (Throwable)ex);
            }
        }
        catch (final DynamiteModule$a dynamiteModule$a) {
            Log.e("GoogleCertificates", "Failed to get Google certificates from remote", (Throwable)dynamiteModule$a);
            s = String.valueOf((Object)((Exception)dynamiteModule$a).getMessage());
            if (s.length() != 0) {
                s = "module init: ".concat(s);
            }
            else {
                s = new String("module init: ");
            }
            return v.c(s, (Throwable)dynamiteModule$a);
        }
    }
}
