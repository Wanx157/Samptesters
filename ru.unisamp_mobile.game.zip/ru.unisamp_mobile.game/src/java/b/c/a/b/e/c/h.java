package b.c.a.b.e.c;

import android.os.Message;
import android.os.Handler$Callback;
import android.os.Looper;
import android.os.Handler;

public class h extends Handler
{
    public h(final Looper looper) {
        super(looper);
    }
    
    public h(final Looper looper, final Handler$Callback handler$Callback) {
        super(looper, handler$Callback);
    }
    
    public final void dispatchMessage(final Message message) {
        super.dispatchMessage(message);
    }
}
