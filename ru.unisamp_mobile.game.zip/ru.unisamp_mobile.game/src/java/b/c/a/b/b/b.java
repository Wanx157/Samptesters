package b.c.a.b.b;

import android.os.Parcelable;
import android.content.BroadcastReceiver$PendingResult;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.TimeUnit;
import b.c.a.b.g.l;
import android.text.TextUtils;
import android.os.Bundle;
import android.app.PendingIntent$CanceledException;
import android.util.Log;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.Context;
import java.util.concurrent.ThreadFactory;
import b.c.a.b.e.b.f;
import b.c.a.b.e.b.a;
import java.util.concurrent.ExecutorService;
import android.content.BroadcastReceiver;

public abstract class b extends BroadcastReceiver
{
    private final ExecutorService a;
    
    public b() {
        this.a = b.c.a.b.e.b.a.a().b((ThreadFactory)new com.google.android.gms.common.util.r.a("firebase-iid-executor"), f.a);
    }
    
    private final int e(final Context context, final Intent intent) {
        final PendingIntent pendingIntent = (PendingIntent)intent.getParcelableExtra("pending_intent");
        if (pendingIntent != null) {
            try {
                pendingIntent.send();
            }
            catch (final PendingIntent$CanceledException ex) {
                Log.e("CloudMessagingReceiver", "Notification pending intent canceled");
            }
        }
        Bundle extras = intent.getExtras();
        if (extras != null) {
            extras.remove("pending_intent");
        }
        else {
            extras = new Bundle();
        }
        if ("com.google.firebase.messaging.NOTIFICATION_OPEN".equals((Object)intent.getAction())) {
            this.d(context, extras);
        }
        else {
            if (!"com.google.firebase.messaging.NOTIFICATION_DISMISS".equals((Object)intent.getAction())) {
                Log.e("CloudMessagingReceiver", "Unknown notification action");
                return 500;
            }
            this.c(context, extras);
        }
        return -1;
    }
    
    private final int g(final Context ex, final Intent intent) {
        if (intent.getExtras() == null) {
            return 500;
        }
        final String stringExtra = intent.getStringExtra("google.message_id");
        b.c.a.b.g.i i;
        if (TextUtils.isEmpty((CharSequence)stringExtra)) {
            i = l.e((Object)null);
        }
        else {
            final Bundle bundle = new Bundle();
            bundle.putString("google.message_id", stringExtra);
            i = b.c.a.b.b.i.c((Context)ex).d(2, bundle);
        }
        final int b = this.b((Context)ex, new b.c.a.b.b.a(intent));
        try {
            l.b(i, TimeUnit.SECONDS.toMillis(1L), TimeUnit.MILLISECONDS);
            return b;
        }
        catch (final TimeoutException ex) {}
        catch (final InterruptedException ex) {}
        catch (final ExecutionException ex2) {}
        final String value = String.valueOf((Object)ex);
        final StringBuilder sb = new StringBuilder(String.valueOf((Object)value).length() + 20);
        sb.append("Message ack failed: ");
        sb.append(value);
        Log.w("CloudMessagingReceiver", sb.toString());
        return b;
    }
    
    protected Executor a() {
        return (Executor)this.a;
    }
    
    protected abstract int b(final Context p0, final b.c.a.b.b.a p1);
    
    protected abstract void c(final Context p0, final Bundle p1);
    
    protected abstract void d(final Context p0, final Bundle p1);
    
    public final void onReceive(final Context context, final Intent intent) {
        if (intent == null) {
            return;
        }
        this.a().execute((Runnable)new h(this, intent, context, this.isOrderedBroadcast(), this.goAsync()));
    }
}
