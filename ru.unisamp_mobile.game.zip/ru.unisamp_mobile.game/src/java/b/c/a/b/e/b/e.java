package b.c.a.b.e.b;

import android.os.Handler$Callback;
import android.os.Looper;
import android.os.Handler;

public class e extends Handler
{
    public e(final Looper looper) {
        super(looper);
    }
    
    public e(final Looper looper, final Handler$Callback handler$Callback) {
        super(looper, handler$Callback);
    }
}
