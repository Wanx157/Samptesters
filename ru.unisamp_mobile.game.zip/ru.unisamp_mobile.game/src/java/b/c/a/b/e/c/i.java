package b.c.a.b.e.c;

public final class i
{
    public static final enum int a = 2;
}
