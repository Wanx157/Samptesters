package b.c.a.b.c;

import java.util.concurrent.Callable;

final class x extends v
{
    private final Callable<String> e;
    
    private x(final Callable<String> e) {
        super(false, (String)null, (Throwable)null);
        this.e = e;
    }
    
    final String f() {
        try {
            return (String)this.e.call();
        }
        catch (final Exception ex) {
            throw new RuntimeException((Throwable)ex);
        }
    }
}
