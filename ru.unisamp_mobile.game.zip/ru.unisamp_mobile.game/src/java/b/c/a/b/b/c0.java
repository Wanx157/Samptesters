package b.c.a.b.b;

import android.os.Message;
import android.os.Looper;
import b.c.a.b.e.b.e;

final class c0 extends e
{
    private final d a;
    
    c0(final d a, final Looper looper) {
        this.a = a;
        super(looper);
    }
    
    public final void handleMessage(final Message message) {
        d.h(this.a, message);
    }
}
