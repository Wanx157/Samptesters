package b.a.a;

public class d extends r
{
    public d(final k k) {
        super(k);
    }
}
