package b.a.a;

import java.util.concurrent.BlockingQueue;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.HashSet;
import android.os.Handler;
import android.os.Looper;
import java.util.List;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public class n
{
    private final AtomicInteger a;
    private final Set<m<?>> b;
    private final PriorityBlockingQueue<m<?>> c;
    private final PriorityBlockingQueue<m<?>> d;
    private final b e;
    private final h f;
    private final p g;
    private final i[] h;
    private c i;
    private final List<a> j;
    
    public n(final b b, final h h) {
        this(b, h, 4);
    }
    
    public n(final b b, final h h, final int n) {
        this(b, h, n, (p)new f(new Handler(Looper.getMainLooper())));
    }
    
    public n(final b e, final h f, final int n, final p g) {
        this.a = new AtomicInteger();
        this.b = (Set<m<?>>)new HashSet();
        this.c = (PriorityBlockingQueue<m<?>>)new PriorityBlockingQueue();
        this.d = (PriorityBlockingQueue<m<?>>)new PriorityBlockingQueue();
        this.j = (List<a>)new ArrayList();
        this.e = e;
        this.f = f;
        this.h = new i[n];
        this.g = g;
    }
    
    public <T> m<T> a(final m<T> m) {
        m.Q(this);
        final Set<m<?>> b;
        monitorenter(b = this.b);
        try {
            this.b.add((Object)m);
            monitorexit(b);
            m.S(this.c());
            m.e("add-to-queue");
            PriorityBlockingQueue<m<?>> priorityBlockingQueue;
            if (!m.T()) {
                priorityBlockingQueue = this.d;
            }
            else {
                priorityBlockingQueue = this.c;
            }
            priorityBlockingQueue.add((Object)m);
            return m;
        }
        finally {
            monitorexit(b);
            while (true) {}
        }
    }
    
     <T> void b(final m<T> m) {
        final Set<m<?>> b;
        monitorenter(b = this.b);
        try {
            this.b.remove((Object)m);
            monitorexit(b);
            final List<a> j = this.j;
            synchronized (j) {
                final Iterator iterator = this.j.iterator();
                while (iterator.hasNext()) {
                    ((a)iterator.next()).a(m);
                }
            }
        }
        finally {
            monitorexit(b);
            while (true) {}
        }
    }
    
    public int c() {
        return this.a.incrementAndGet();
    }
    
    public void d() {
        this.e();
        (this.i = new c((BlockingQueue<m<?>>)this.c, (BlockingQueue<m<?>>)this.d, this.e, this.g)).start();
        for (int i = 0; i < this.h.length; ++i) {
            (this.h[i] = new i((BlockingQueue<m<?>>)this.d, this.f, this.e, this.g)).start();
        }
    }
    
    public void e() {
        final c i = this.i;
        if (i != null) {
            i.e();
        }
        for (final i k : this.h) {
            if (k != null) {
                k.e();
            }
        }
    }
    
    public interface a<T>
    {
        void a(final m<T> p0);
    }
}
