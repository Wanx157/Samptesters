package b.a.a;

public class e implements q
{
    private int a;
    private int b;
    private final int c;
    private final float d;
    
    public e() {
        this(2500, 1, 1.0f);
    }
    
    public e(final int a, final int c, final float d) {
        this.a = a;
        this.c = c;
        this.d = d;
    }
    
    public int a() {
        return this.a;
    }
    
    public void b(final t t) {
        ++this.b;
        final int a = this.a;
        this.a = a + (int)(a * this.d);
        if (this.d()) {
            return;
        }
        throw t;
    }
    
    public int c() {
        return this.b;
    }
    
    protected boolean d() {
        return this.b <= this.c;
    }
}
