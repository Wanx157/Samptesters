package b.a.a;

public interface h
{
    k a(final m<?> p0);
}
