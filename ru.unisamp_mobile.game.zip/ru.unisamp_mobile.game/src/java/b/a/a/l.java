package b.a.a;

public class l extends j
{
    public l(final Throwable t) {
        super(t);
    }
}
