package b.a.a;

import android.os.Handler;
import java.util.concurrent.Executor;

public class f implements p
{
    private final Executor a;
    
    public f(final Handler handler) {
        this.a = (Executor)new f$a(this, handler);
    }
    
    public void a(final m<?> m, final t t) {
        m.e("post-error");
        this.a.execute((Runnable)new f.f$b((m)m, o.a(t), (Runnable)null));
    }
    
    public void b(final m<?> m, final o<?> o) {
        this.c(m, o, null);
    }
    
    public void c(final m<?> m, final o<?> o, final Runnable runnable) {
        m.J();
        m.e("post-response");
        this.a.execute((Runnable)new f.f$b((m)m, (o)o, runnable));
    }
}
