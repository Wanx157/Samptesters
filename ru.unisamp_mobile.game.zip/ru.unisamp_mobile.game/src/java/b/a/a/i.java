package b.a.a;

import android.os.Process;
import android.os.SystemClock;
import android.annotation.TargetApi;
import android.net.TrafficStats;
import android.os.Build$VERSION;
import java.util.concurrent.BlockingQueue;

public class i extends Thread
{
    private final BlockingQueue<m<?>> b;
    private final h c;
    private final b d;
    private final p e;
    private volatile boolean f;
    
    public i(final BlockingQueue<m<?>> b, final h c, final b d, final p e) {
        this.f = false;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    @TargetApi(14)
    private void a(final m<?> m) {
        if (Build$VERSION.SDK_INT >= 14) {
            TrafficStats.setThreadStatsTag(m.D());
        }
    }
    
    private void b(final m<?> m, final t t) {
        m.M(t);
        this.e.a(m, t);
    }
    
    private void c() {
        this.d((m<?>)this.b.take());
    }
    
    void d(final m<?> m) {
        final long elapsedRealtime = SystemClock.elapsedRealtime();
        try {
            m.e("network-queue-take");
            if (m.H()) {
                m.l("network-discard-cancelled");
                m.K();
                return;
            }
            this.a(m);
            final k a = this.c.a(m);
            m.e("network-http-complete");
            if (a.d && m.F()) {
                m.l("not-modified");
                m.K();
                return;
            }
            final o n = m.N(a);
            m.e("network-parse-complete");
            if (m.T() && n.b != null) {
                this.d.c(m.p(), n.b);
                m.e("network-cache-written");
            }
            m.J();
            this.e.b(m, n);
            m.L(n);
            return;
        }
        catch (final Exception ex) {
            u.d((Throwable)ex, "Unhandled exception %s", ex.toString());
            final t t = new t((Throwable)ex);
            t.a(SystemClock.elapsedRealtime() - elapsedRealtime);
            this.e.a(m, t);
        }
        catch (final t t2) {
            t2.a(SystemClock.elapsedRealtime() - elapsedRealtime);
            this.b(m, t2);
        }
        m.K();
    }
    
    public void e() {
        this.f = true;
        this.interrupt();
    }
    
    public void run() {
        Process.setThreadPriority(10);
    Label_0005_Outer:
        while (true) {
            while (true) {
                try {
                    while (true) {
                        this.c();
                    }
                }
                catch (final InterruptedException ex) {
                    if (this.f) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                    u.c("Ignoring spurious interrupt of NetworkDispatcher thread; use quit() to terminate it", new Object[0]);
                    continue Label_0005_Outer;
                }
                continue;
            }
        }
    }
}
