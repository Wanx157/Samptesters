package b.a.a;

public class t extends Exception
{
    public t() {
    }
    
    public t(final k k) {
    }
    
    public t(final Throwable t) {
        super(t);
    }
    
    void a(final long n) {
    }
}
