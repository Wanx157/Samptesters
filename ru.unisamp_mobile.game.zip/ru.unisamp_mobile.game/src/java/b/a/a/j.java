package b.a.a;

public class j extends t
{
    public j() {
    }
    
    public j(final Throwable t) {
        super(t);
    }
}
