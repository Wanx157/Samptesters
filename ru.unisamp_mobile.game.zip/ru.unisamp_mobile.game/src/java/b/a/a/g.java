package b.a.a;

import android.text.TextUtils;

public final class g
{
    private final String a;
    private final String b;
    
    public g(final String a, final String b) {
        this.a = a;
        this.b = b;
    }
    
    public final String a() {
        return this.a;
    }
    
    public final String b() {
        return this.b;
    }
    
    @Override
    public boolean equals(final Object o) {
        boolean b = true;
        if (this == o) {
            return true;
        }
        if (o != null && g.class == o.getClass()) {
            final g g = (g)o;
            if (!TextUtils.equals((CharSequence)this.a, (CharSequence)g.a) || !TextUtils.equals((CharSequence)this.b, (CharSequence)g.b)) {
                b = false;
            }
            return b;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.a.hashCode() * 31 + this.b.hashCode();
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("Header[name=");
        sb.append(this.a);
        sb.append(",value=");
        sb.append(this.b);
        sb.append("]");
        return sb.toString();
    }
}
