package b.a.a;

import android.os.Process;
import java.util.concurrent.BlockingQueue;

public class c extends Thread
{
    private static final boolean h;
    private final BlockingQueue<m<?>> b;
    private final BlockingQueue<m<?>> c;
    private final b d;
    private final p e;
    private volatile boolean f;
    private final c.c$b g;
    
    static {
        h = u.b;
    }
    
    public c(final BlockingQueue<m<?>> b, final BlockingQueue<m<?>> c, final b d, final p e) {
        this.f = false;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.g = new c.c$b(this);
    }
    
    private void c() {
        this.d((m<?>)this.b.take());
    }
    
    void d(final m<?> m) {
        m.e("cache-queue-take");
        if (m.H()) {
            m.l("cache-discard-canceled");
            return;
        }
        final b.a a = this.d.a(m.p());
        if (a == null) {
            m.e("cache-miss");
            if (!b.a.a.c.c$b.c(this.g, (m)m)) {
                this.c.put((Object)m);
            }
            return;
        }
        if (a.a()) {
            m.e("cache-hit-expired");
            m.O(a);
            if (!b.a.a.c.c$b.c(this.g, (m)m)) {
                this.c.put((Object)m);
            }
            return;
        }
        m.e("cache-hit");
        final o n = m.N(new k(a.a, a.g));
        m.e("cache-hit-parsed");
        if (a.b()) {
            m.e("cache-hit-refresh-needed");
            m.O(a);
            n.d = true;
            if (!b.a.a.c.c$b.c(this.g, (m)m)) {
                this.e.c(m, n, (Runnable)new Runnable(this, m) {
                    final m b;
                    final c c;
                    
                    public void run() {
                        try {
                            this.c.c.put((Object)this.b);
                        }
                        catch (final InterruptedException ex) {
                            Thread.currentThread().interrupt();
                        }
                    }
                });
                return;
            }
        }
        this.e.b(m, n);
    }
    
    public void e() {
        this.f = true;
        this.interrupt();
    }
    
    public void run() {
        if (b.a.a.c.h) {
            u.e("start new dispatcher", new Object[0]);
        }
        Process.setThreadPriority(10);
        this.d.b();
    Label_0029_Outer:
        while (true) {
            while (true) {
                try {
                    while (true) {
                        this.c();
                    }
                }
                catch (final InterruptedException ex) {
                    if (this.f) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                    u.c("Ignoring spurious interrupt of CacheDispatcher thread; use quit() to terminate it", new Object[0]);
                    continue Label_0029_Outer;
                }
                continue;
            }
        }
    }
}
