package b.a.a;

import java.util.Collections;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.text.TextUtils;
import java.util.Iterator;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map$Entry;
import java.util.Map;

public abstract class m<T> implements Comparable<m<T>>
{
    private final u.a b;
    private final int c;
    private final String d;
    private final int e;
    private final Object f;
    private o.a g;
    private Integer h;
    private n i;
    private boolean j;
    private boolean k;
    private boolean l;
    private boolean m;
    private q n;
    private b.a.a.b.a o;
    private b p;
    
    public m(final int c, final String d, final o.a g) {
        u.a b;
        if (u.a.c) {
            b = new u.a();
        }
        else {
            b = null;
        }
        this.b = b;
        this.f = new Object();
        this.j = true;
        this.k = false;
        this.l = false;
        this.m = false;
        this.o = null;
        this.c = c;
        this.d = d;
        this.g = g;
        this.R((q)new e());
        this.e = k(d);
    }
    
    private byte[] j(final Map<String, String> map, final String s) {
        final StringBuilder sb = new StringBuilder();
        try {
            for (final Map$Entry map$Entry : map.entrySet()) {
                if (map$Entry.getKey() == null || map$Entry.getValue() == null) {
                    throw new IllegalArgumentException(String.format("Request#getParams() or Request#getPostParams() returned a map containing a null key or value: (%s, %s). All keys and values must be non-null.", new Object[] { map$Entry.getKey(), map$Entry.getValue() }));
                }
                sb.append(URLEncoder.encode((String)map$Entry.getKey(), s));
                sb.append('=');
                sb.append(URLEncoder.encode((String)map$Entry.getValue(), s));
                sb.append('&');
            }
            return sb.toString().getBytes(s);
        }
        catch (final UnsupportedEncodingException ex) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("Encoding not supported: ");
            sb2.append(s);
            throw new RuntimeException(sb2.toString(), (Throwable)ex);
        }
    }
    
    private static int k(String host) {
        if (!TextUtils.isEmpty((CharSequence)host)) {
            final Uri parse = Uri.parse(host);
            if (parse != null) {
                host = parse.getHost();
                if (host != null) {
                    return host.hashCode();
                }
            }
        }
        return 0;
    }
    
    public c A() {
        return b.a.a.m.c.c;
    }
    
    public q B() {
        return this.n;
    }
    
    public final int C() {
        return this.B().a();
    }
    
    public int D() {
        return this.e;
    }
    
    public String E() {
        return this.d;
    }
    
    public boolean F() {
        final Object f = this.f;
        synchronized (f) {
            return this.l;
        }
    }
    
    public boolean H() {
        final Object f = this.f;
        synchronized (f) {
            return this.k;
        }
    }
    
    public void J() {
        final Object f = this.f;
        synchronized (f) {
            this.l = true;
        }
    }
    
    void K() {
        final Object f = this.f;
        synchronized (f) {
            final b p = this.p;
            monitorexit(f);
            if (p != null) {
                p.a(this);
            }
        }
    }
    
    void L(final o<?> o) {
        final Object f = this.f;
        synchronized (f) {
            final b p = this.p;
            monitorexit(f);
            if (p != null) {
                p.b(this, o);
            }
        }
    }
    
    protected t M(final t t) {
        return t;
    }
    
    protected abstract o<T> N(final k p0);
    
    public m<?> O(final b.a.a.b.a o) {
        this.o = o;
        return this;
    }
    
    void P(final b p) {
        final Object f = this.f;
        synchronized (f) {
            this.p = p;
        }
    }
    
    public m<?> Q(final n i) {
        this.i = i;
        return this;
    }
    
    public m<?> R(final q n) {
        this.n = n;
        return this;
    }
    
    public final m<?> S(final int n) {
        this.h = n;
        return this;
    }
    
    public final boolean T() {
        return this.j;
    }
    
    public final boolean U() {
        return this.m;
    }
    
    public void e(final String s) {
        if (u.a.c) {
            this.b.a(s, Thread.currentThread().getId());
        }
    }
    
    public int f(final m<T> m) {
        this.A();
        m.A();
        return this.h - m.h;
    }
    
    public void g(final t t) {
        final Object f = this.f;
        synchronized (f) {
            final o.a g = this.g;
            monitorexit(f);
            if (g != null) {
                g.a(t);
            }
        }
    }
    
    protected abstract void i(final T p0);
    
    void l(final String s) {
        final n i = this.i;
        if (i != null) {
            i.b((m<Object>)this);
        }
        if (u.a.c) {
            final long id = Thread.currentThread().getId();
            if (Looper.myLooper() != Looper.getMainLooper()) {
                new Handler(Looper.getMainLooper()).post((Runnable)new Runnable(this, s, id) {
                    final String b;
                    final long c;
                    final m d;
                    
                    public void run() {
                        this.d.b.a(this.b, this.c);
                        this.d.b.b(this.d.toString());
                    }
                });
                return;
            }
            this.b.a(s, id);
            this.b.b(this.toString());
        }
    }
    
    public byte[] m() {
        final Map<String, String> t = this.t();
        if (t != null && t.size() > 0) {
            return this.j(t, this.u());
        }
        return null;
    }
    
    public String n() {
        final StringBuilder sb = new StringBuilder();
        sb.append("application/x-www-form-urlencoded; charset=");
        sb.append(this.u());
        return sb.toString();
    }
    
    public b.a.a.b.a o() {
        return this.o;
    }
    
    public String p() {
        final String e = this.E();
        final int s = this.s();
        String string = e;
        if (s != 0) {
            if (s == -1) {
                string = e;
            }
            else {
                final StringBuilder sb = new StringBuilder();
                sb.append(Integer.toString(s));
                sb.append('-');
                sb.append(e);
                string = sb.toString();
            }
        }
        return string;
    }
    
    public Map<String, String> q() {
        return (Map<String, String>)Collections.emptyMap();
    }
    
    public int s() {
        return this.c;
    }
    
    protected Map<String, String> t() {
        return null;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("0x");
        sb.append(Integer.toHexString(this.D()));
        final String string = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        String s;
        if (this.H()) {
            s = "[X] ";
        }
        else {
            s = "[ ] ";
        }
        sb2.append(s);
        sb2.append(this.E());
        sb2.append(" ");
        sb2.append(string);
        sb2.append(" ");
        sb2.append((Object)this.A());
        sb2.append(" ");
        sb2.append((Object)this.h);
        return sb2.toString();
    }
    
    protected String u() {
        return "UTF-8";
    }
    
    @Deprecated
    public byte[] v() {
        final Map<String, String> y = this.y();
        if (y != null && y.size() > 0) {
            return this.j(y, this.z());
        }
        return null;
    }
    
    @Deprecated
    public String w() {
        return this.n();
    }
    
    @Deprecated
    protected Map<String, String> y() {
        return this.t();
    }
    
    @Deprecated
    protected String z() {
        return this.u();
    }
    
    interface b
    {
        void a(final m<?> p0);
        
        void b(final m<?> p0, final o<?> p1);
    }
    
    public enum c
    {
        b, 
        c, 
        d, 
        e;
        
        private static final c[] f;
    }
}
