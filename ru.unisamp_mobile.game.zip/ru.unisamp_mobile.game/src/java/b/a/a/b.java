package b.a.a;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public interface b
{
    a a(final String p0);
    
    void b();
    
    void c(final String p0, final a p1);
    
    public static class a
    {
        public byte[] a;
        public String b;
        public long c;
        public long d;
        public long e;
        public long f;
        public Map<String, String> g;
        public List<g> h;
        
        public a() {
            this.g = (Map<String, String>)Collections.emptyMap();
        }
        
        public boolean a() {
            return this.e < System.currentTimeMillis();
        }
        
        public boolean b() {
            return this.f < System.currentTimeMillis();
        }
    }
}
