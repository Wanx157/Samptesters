package b.a.a;

public class s extends t
{
}
