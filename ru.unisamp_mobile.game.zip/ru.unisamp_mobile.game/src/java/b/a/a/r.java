package b.a.a;

public class r extends t
{
    public r() {
    }
    
    public r(final k k) {
        super(k);
    }
}
