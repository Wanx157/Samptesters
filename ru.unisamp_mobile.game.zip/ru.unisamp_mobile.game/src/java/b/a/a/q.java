package b.a.a;

public interface q
{
    int a();
    
    void b(final t p0);
    
    int c();
}
