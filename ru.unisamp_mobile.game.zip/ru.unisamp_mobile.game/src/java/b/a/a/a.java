package b.a.a;

import android.content.Intent;

public class a extends t
{
    private Intent b;
    
    public a(final k k) {
        super(k);
    }
    
    public String getMessage() {
        if (this.b != null) {
            return "User needs to (re)enter credentials.";
        }
        return super.getMessage();
    }
}
