package b.a.a;

public class o<T>
{
    public final T a;
    public final b.a.a.b.a b;
    public final t c;
    public boolean d;
    
    private o(final t c) {
        this.d = false;
        this.a = null;
        this.b = null;
        this.c = c;
    }
    
    private o(final T a, final b.a.a.b.a b) {
        this.d = false;
        this.a = a;
        this.b = b;
        this.c = null;
    }
    
    public static <T> o<T> a(final t t) {
        return new o<T>(t);
    }
    
    public static <T> o<T> c(final T t, final b.a.a.b.a a) {
        return new o<T>(t, a);
    }
    
    public boolean b() {
        return this.c == null;
    }
    
    public interface a
    {
        void a(final t p0);
    }
    
    public interface b<T>
    {
        void a(final T p0);
    }
}
