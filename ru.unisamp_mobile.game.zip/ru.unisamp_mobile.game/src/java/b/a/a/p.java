package b.a.a;

public interface p
{
    void a(final m<?> p0, final t p1);
    
    void b(final m<?> p0, final o<?> p1);
    
    void c(final m<?> p0, final o<?> p1, final Runnable p2);
}
