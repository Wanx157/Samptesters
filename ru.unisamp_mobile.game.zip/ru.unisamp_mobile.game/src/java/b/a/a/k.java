package b.a.a;

import java.util.TreeMap;
import java.util.Iterator;
import java.util.Map$Entry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class k
{
    public final byte[] a;
    public final Map<String, String> b;
    public final List<g> c;
    public final boolean d;
    
    private k(final int n, final byte[] a, final Map<String, String> b, final List<g> list, final boolean d, final long n2) {
        this.a = a;
        this.b = b;
        List unmodifiableList;
        if (list == null) {
            unmodifiableList = null;
        }
        else {
            unmodifiableList = Collections.unmodifiableList((List)list);
        }
        this.c = (List<g>)unmodifiableList;
        this.d = d;
    }
    
    @Deprecated
    public k(final int n, final byte[] array, final Map<String, String> map, final boolean b, final long n2) {
        this(n, array, map, a(map), b, n2);
    }
    
    public k(final int n, final byte[] array, final boolean b, final long n2, final List<g> list) {
        this(n, array, b(list), list, b, n2);
    }
    
    @Deprecated
    public k(final byte[] array, final Map<String, String> map) {
        this(200, array, map, false, 0L);
    }
    
    private static List<g> a(final Map<String, String> map) {
        if (map == null) {
            return null;
        }
        if (map.isEmpty()) {
            return (List<g>)Collections.emptyList();
        }
        final ArrayList list = new ArrayList(map.size());
        for (final Map$Entry map$Entry : map.entrySet()) {
            ((List)list).add((Object)new g((String)map$Entry.getKey(), (String)map$Entry.getValue()));
        }
        return (List<g>)list;
    }
    
    private static Map<String, String> b(final List<g> list) {
        if (list == null) {
            return null;
        }
        if (list.isEmpty()) {
            return (Map<String, String>)Collections.emptyMap();
        }
        final TreeMap treeMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        for (final g g : list) {
            ((Map)treeMap).put((Object)g.a(), (Object)g.b());
        }
        return (Map<String, String>)treeMap;
    }
}
