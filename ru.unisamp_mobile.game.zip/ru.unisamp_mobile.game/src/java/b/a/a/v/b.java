package b.a.a.v;

import java.util.List;
import java.io.InputStream;
import java.util.Iterator;
import org.apache.http.HttpEntity;
import org.apache.http.entity.BasicHttpEntity;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import b.a.a.g;
import java.util.ArrayList;
import org.apache.http.StatusLine;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.message.BasicStatusLine;
import org.apache.http.ProtocolVersion;
import org.apache.http.HttpResponse;
import java.util.Map;
import b.a.a.m;

public abstract class b implements i
{
    @Deprecated
    public final HttpResponse a(final m<?> m, final Map<String, String> map) {
        final h b = this.b(m, map);
        final BasicHttpResponse basicHttpResponse = new BasicHttpResponse((StatusLine)new BasicStatusLine(new ProtocolVersion("HTTP", 1, 1), b.d(), ""));
        final ArrayList list = new ArrayList();
        for (final g g : b.c()) {
            ((List)list).add((Object)new BasicHeader(g.a(), g.b()));
        }
        basicHttpResponse.setHeaders((Header[])((List)list).toArray((Object[])new Header[((List)list).size()]));
        final InputStream a = b.a();
        if (a != null) {
            final BasicHttpEntity entity = new BasicHttpEntity();
            entity.setContent(a);
            entity.setContentLength((long)b.b());
            basicHttpResponse.setEntity((HttpEntity)entity);
        }
        return (HttpResponse)basicHttpResponse;
    }
    
    public abstract h b(final m<?> p0, final Map<String, String> p1);
}
