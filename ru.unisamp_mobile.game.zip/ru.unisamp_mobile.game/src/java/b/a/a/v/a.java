package b.a.a.v;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.conn.ConnectTimeoutException;
import java.net.SocketTimeoutException;
import java.io.IOException;
import java.util.List;
import b.a.a.g;
import java.util.ArrayList;
import java.util.Map;
import b.a.a.m;

class a extends b
{
    private final i a;
    
    a(final i a) {
        this.a = a;
    }
    
    @Override
    public h b(final m<?> m, final Map<String, String> map) {
        try {
            final HttpResponse a = this.a.a((m)m, (Map)map);
            final int statusCode = a.getStatusLine().getStatusCode();
            final Header[] allHeaders = a.getAllHeaders();
            final ArrayList list = new ArrayList(allHeaders.length);
            for (final Header header : allHeaders) {
                ((List)list).add((Object)new g(header.getName(), header.getValue()));
            }
            if (a.getEntity() == null) {
                return new h(statusCode, (List)list);
            }
            final long contentLength = a.getEntity().getContentLength();
            if ((int)contentLength == contentLength) {
                return new h(statusCode, (List)list, (int)a.getEntity().getContentLength(), a.getEntity().getContent());
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("Response too large: ");
            sb.append(contentLength);
            throw new IOException(sb.toString());
        }
        catch (final ConnectTimeoutException ex) {
            throw new SocketTimeoutException(ex.getMessage());
        }
    }
}
