package b.a.a.v;

import java.io.ByteArrayOutputStream;

public class k extends ByteArrayOutputStream
{
    private final d b;
    
    public k(final d b, final int n) {
        this.b = b;
        super.buf = b.a(Math.max(n, 256));
    }
    
    private void a(final int n) {
        final int count = super.count;
        if (count + n <= super.buf.length) {
            return;
        }
        final byte[] a = this.b.a((count + n) * 2);
        System.arraycopy((Object)super.buf, 0, (Object)a, 0, super.count);
        this.b.b(super.buf);
        super.buf = a;
    }
    
    public void close() {
        this.b.b(super.buf);
        super.buf = null;
        super.close();
    }
    
    public void finalize() {
        this.b.b(super.buf);
    }
    
    public void write(final int n) {
        synchronized (this) {
            this.a(1);
            super.write(n);
        }
    }
    
    public void write(final byte[] array, final int n, final int n2) {
        synchronized (this) {
            this.a(n2);
            super.write(array, n, n2);
        }
    }
}
