package b.a.a.v;

import java.util.HashMap;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map$Entry;
import java.util.ArrayList;
import b.a.a.g;
import java.util.List;
import java.util.Map;
import java.io.DataOutputStream;
import b.a.a.m;
import java.io.InputStream;
import java.net.HttpURLConnection;
import javax.net.ssl.SSLSocketFactory;

public class j extends b
{
    private final j.j$b a;
    private final SSLSocketFactory b;
    
    public j() {
        this(null);
    }
    
    public j(final j.j$b j$b) {
        this(j$b, null);
    }
    
    public j(final j.j$b a, final SSLSocketFactory b) {
        this.a = a;
        this.b = b;
    }
    
    private static void d(final HttpURLConnection httpURLConnection, final m<?> m, final byte[] array) {
        httpURLConnection.setDoOutput(true);
        if (!httpURLConnection.getRequestProperties().containsKey((Object)"Content-Type")) {
            httpURLConnection.setRequestProperty("Content-Type", m.n());
        }
        final DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
        dataOutputStream.write(array);
        dataOutputStream.close();
    }
    
    private static void e(final HttpURLConnection httpURLConnection, final m<?> m) {
        final byte[] i = m.m();
        if (i != null) {
            d(httpURLConnection, m, i);
        }
    }
    
    static List<g> f(final Map<String, List<String>> map) {
        final ArrayList list = new ArrayList(map.size());
        for (final Map$Entry map$Entry : map.entrySet()) {
            if (map$Entry.getKey() != null) {
                final Iterator iterator2 = ((List)map$Entry.getValue()).iterator();
                while (iterator2.hasNext()) {
                    ((List)list).add((Object)new g((String)map$Entry.getKey(), (String)iterator2.next()));
                }
            }
        }
        return (List<g>)list;
    }
    
    private static boolean h(final int n, final int n2) {
        return n != 4 && (100 > n2 || n2 >= 200) && n2 != 204 && n2 != 304;
    }
    
    private static InputStream i(HttpURLConnection httpURLConnection) {
        try {
            httpURLConnection = (HttpURLConnection)httpURLConnection.getInputStream();
        }
        catch (final IOException ex) {
            httpURLConnection = (HttpURLConnection)httpURLConnection.getErrorStream();
        }
        return (InputStream)httpURLConnection;
    }
    
    private HttpURLConnection j(final URL url, final m<?> m) {
        final HttpURLConnection g = this.g(url);
        final int c = m.C();
        g.setConnectTimeout(c);
        g.setReadTimeout(c);
        g.setUseCaches(false);
        g.setDoInput(true);
        if ("https".equals((Object)url.getProtocol())) {
            final SSLSocketFactory b = this.b;
            if (b != null) {
                ((HttpsURLConnection)g).setSSLSocketFactory(b);
            }
        }
        return g;
    }
    
    static void k(final HttpURLConnection httpURLConnection, final m<?> m) {
        String requestMethod2 = null;
        Label_0124: {
            Label_0113: {
                String requestMethod = null;
                switch (m.s()) {
                    default: {
                        throw new IllegalStateException("Unknown method type.");
                    }
                    case 7: {
                        requestMethod = "PATCH";
                        break;
                    }
                    case 6: {
                        requestMethod2 = "TRACE";
                        break Label_0124;
                    }
                    case 5: {
                        requestMethod2 = "OPTIONS";
                        break Label_0124;
                    }
                    case 4: {
                        requestMethod2 = "HEAD";
                        break Label_0124;
                    }
                    case 3: {
                        requestMethod2 = "DELETE";
                        break Label_0124;
                    }
                    case 2: {
                        requestMethod = "PUT";
                        break;
                    }
                    case 1: {
                        httpURLConnection.setRequestMethod("POST");
                        break Label_0113;
                    }
                    case 0: {
                        requestMethod2 = "GET";
                        break Label_0124;
                    }
                    case -1: {
                        final byte[] v = m.v();
                        if (v != null) {
                            httpURLConnection.setRequestMethod("POST");
                            d(httpURLConnection, m, v);
                        }
                        return;
                    }
                }
                httpURLConnection.setRequestMethod(requestMethod);
            }
            e(httpURLConnection, m);
            return;
        }
        httpURLConnection.setRequestMethod(requestMethod2);
    }
    
    @Override
    public h b(final m<?> m, Map<String, String> j) {
        final String e = m.E();
        final HashMap hashMap = new HashMap();
        hashMap.putAll((Map)j);
        hashMap.putAll(m.q());
        final j.j$b a = this.a;
        String a2 = e;
        if (a != null) {
            a2 = a.a(e);
            if (a2 == null) {
                final StringBuilder sb = new StringBuilder();
                sb.append("URL blocked by rewriter: ");
                sb.append(e);
                throw new IOException(sb.toString());
            }
        }
        j = this.j(new URL(a2), m);
        int n2;
        final int n = n2 = 0;
        try {
            final Iterator iterator = hashMap.keySet().iterator();
            while (true) {
                n2 = n;
                if (!iterator.hasNext()) {
                    break;
                }
                n2 = n;
                final String s = (String)iterator.next();
                n2 = n;
                j.setRequestProperty(s, (String)hashMap.get((Object)s));
            }
            n2 = n;
            k(j, m);
            n2 = n;
            final int responseCode = j.getResponseCode();
            if (responseCode == -1) {
                n2 = n;
                n2 = n;
                final IOException ex = new IOException("Could not retrieve response code from HttpUrlConnection.");
                n2 = n;
                throw ex;
            }
            n2 = n;
            if (!h(m.s(), responseCode)) {
                n2 = n;
                final h h = new h(responseCode, (List)f((Map<String, List<String>>)j.getHeaderFields()));
                j.disconnect();
                return h;
            }
            final int n3 = n2 = 1;
            final List<g> f = f((Map<String, List<String>>)j.getHeaderFields());
            n2 = n3;
            final int contentLength = j.getContentLength();
            n2 = n3;
            n2 = n3;
            final j.j$a j$a = new j.j$a(j);
            n2 = n3;
            return new h(responseCode, (List)f, contentLength, (InputStream)j$a);
        }
        finally {
            Label_0330: {
                if (n2 == 0) {
                    j.disconnect();
                    break Label_0330;
                }
                break Label_0330;
            }
            while (true) {}
        }
    }
    
    protected HttpURLConnection g(final URL url) {
        final HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
        httpURLConnection.setInstanceFollowRedirects(HttpURLConnection.getFollowRedirects());
        return httpURLConnection;
    }
}
