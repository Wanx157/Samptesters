package b.a.a.v;

import java.io.ByteArrayOutputStream;
import java.util.Set;
import java.net.SocketTimeoutException;
import b.a.a.s;
import java.net.MalformedURLException;
import b.a.a.j;
import b.a.a.l;
import android.os.SystemClock;
import b.a.a.r;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Collections;
import java.util.Map;
import java.util.Iterator;
import java.util.Map$Entry;
import java.util.Collection;
import java.util.ArrayList;
import java.util.TreeSet;
import b.a.a.b$a;
import b.a.a.g;
import java.util.List;
import b.a.a.q;
import b.a.a.t;
import b.a.a.m;
import b.a.a.u;
import b.a.a.h;

public class c implements h
{
    protected static final boolean c;
    private final b a;
    protected final d b;
    
    static {
        c = u.b;
    }
    
    public c(final b b) {
        this(b, new d(4096));
    }
    
    public c(final b a, final d b) {
        this.a = a;
        this.b = b;
    }
    
    @Deprecated
    public c(final i i) {
        this(i, new d(4096));
    }
    
    @Deprecated
    public c(final i i, final d b) {
        this.a = new a(i);
        this.b = b;
    }
    
    private static void b(final String s, final m<?> m, final t t) {
        final q b = m.B();
        final int c = m.C();
        try {
            b.b(t);
            m.e(String.format("%s-retry [timeout=%s]", new Object[] { s, c }));
        }
        catch (final t t) {
            m.e(String.format("%s-timeout-giveup [timeout=%s]", new Object[] { s, c }));
            throw t;
        }
    }
    
    private static List<g> c(final List<g> list, final b$a b$a) {
        final TreeSet set = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        if (!list.isEmpty()) {
            final Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((Set)set).add((Object)((g)iterator.next()).a());
            }
        }
        final ArrayList list2 = new ArrayList((Collection)list);
        final List h = b$a.h;
        if (h != null) {
            if (!h.isEmpty()) {
                for (final g g : b$a.h) {
                    if (!((Set)set).contains((Object)g.a())) {
                        ((List)list2).add((Object)g);
                    }
                }
            }
        }
        else if (!b$a.g.isEmpty()) {
            for (final Map$Entry map$Entry : b$a.g.entrySet()) {
                if (!((Set)set).contains(map$Entry.getKey())) {
                    ((List)list2).add((Object)new g((String)map$Entry.getKey(), (String)map$Entry.getValue()));
                }
            }
        }
        return (List<g>)list2;
    }
    
    private Map<String, String> d(final b$a b$a) {
        if (b$a == null) {
            return (Map<String, String>)Collections.emptyMap();
        }
        final HashMap hashMap = new HashMap();
        final String b = b$a.b;
        if (b != null) {
            ((Map)hashMap).put((Object)"If-None-Match", (Object)b);
        }
        final long d = b$a.d;
        if (d > 0L) {
            ((Map)hashMap).put((Object)"If-Modified-Since", (Object)b.a.a.v.g.a(d));
        }
        return (Map<String, String>)hashMap;
    }
    
    private byte[] e(final InputStream ex, int read) {
        final k k = new k(this.b, read);
        final byte[] array = null;
        Label_0119: {
            if (ex == null) {
                break Label_0119;
            }
            byte[] array2 = array;
            try {
                final byte[] a = this.b.a(1024);
                while (true) {
                    array2 = a;
                    read = ((InputStream)ex).read(a);
                    if (read == -1) {
                        break;
                    }
                    array2 = a;
                    k.write(a, 0, read);
                }
                array2 = a;
                final byte[] byteArray = ((ByteArrayOutputStream)k).toByteArray();
                if (ex != null) {
                    try {
                        ((InputStream)ex).close();
                    }
                    catch (final IOException ex) {
                        u.e("Error occurred when closing InputStream", new Object[0]);
                    }
                }
                this.b.b(a);
                k.close();
                return byteArray;
            }
            finally {
                if (ex != null) {
                    try {
                        ((InputStream)ex).close();
                    }
                    catch (final IOException ex2) {
                        u.e("Error occurred when closing InputStream", new Object[0]);
                    }
                }
                this.b.b(array2);
                k.close();
                while (true) {}
                throw new r();
            }
        }
    }
    
    private void f(final long n, final m<?> m, final byte[] array, final int n2) {
        if (b.a.a.v.c.c || n > 3000L) {
            Object value;
            if (array != null) {
                value = array.length;
            }
            else {
                value = "null";
            }
            u.b("HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]", new Object[] { m, n, value, n2, m.B().c() });
        }
    }
    
    public b.a.a.k a(final m<?> m) {
        final long elapsedRealtime = SystemClock.elapsedRealtime();
        while (true) {
            Object o = Collections.emptyList();
            Object c = null;
            t t;
            String s;
            try {
                Object b = null;
                Object o2 = null;
                Label_0330: {
                    try {
                        b = this.a.b(m, this.d(m.o()));
                        try {
                            final int d = ((b.a.a.v.h)b).d();
                            c = ((b.a.a.v.h)b).c();
                            if (d == 304) {
                                try {
                                    o2 = m.o();
                                    if (o2 == null) {
                                        return new b.a.a.k(304, (byte[])null, true, SystemClock.elapsedRealtime() - elapsedRealtime, (List)c);
                                    }
                                    o = c((List<g>)c, (b$a)o2);
                                    o = new b.a.a.k(304, ((b$a)o2).a, true, SystemClock.elapsedRealtime() - elapsedRealtime, (List)o);
                                    return (b.a.a.k)o;
                                }
                                catch (final IOException ex) {
                                    final byte[] array = null;
                                    o = b;
                                    o2 = c;
                                    b = ex;
                                    c = o;
                                    o = array;
                                    break Label_0330;
                                }
                            }
                            try {
                                final InputStream a = ((b.a.a.v.h)b).a();
                                if (a != null) {
                                    o = this.e(a, ((b.a.a.v.h)b).b());
                                }
                                else {
                                    o = new byte[0];
                                }
                                try {
                                    this.f(SystemClock.elapsedRealtime() - elapsedRealtime, m, (byte[])o, d);
                                    Label_0233: {
                                        if (d < 200 || d > 299) {
                                            break Label_0233;
                                        }
                                        final long elapsedRealtime2 = SystemClock.elapsedRealtime();
                                        try {
                                            return new b.a.a.k(d, (byte[])o, false, elapsedRealtime2 - elapsedRealtime, (List)c);
                                            throw new IOException();
                                        }
                                        catch (final IOException o2) {}
                                    }
                                }
                                catch (final IOException ex2) {}
                                final List<g> list = (List<g>)c;
                                c = b;
                                b = o2;
                                o2 = list;
                            }
                            catch (IOException o) {
                                o2 = c;
                                c = o;
                                o = o2;
                            }
                        }
                        catch (final IOException ex3) {}
                        o2 = o;
                        final List<g> list2 = null;
                        o = b;
                        b = c;
                        c = o;
                        o = list2;
                    }
                    catch (final IOException b) {
                        final List<g> list3 = null;
                        o2 = o;
                        o = list3;
                    }
                }
                if (c == null) {
                    throw new l((Throwable)b);
                }
                final int d2 = ((b.a.a.v.h)c).d();
                u.c("Unexpected response code %d for %s", new Object[] { d2, m.E() });
                if (o != null) {
                    final b.a.a.k k = new b.a.a.k(d2, (byte[])o, false, SystemClock.elapsedRealtime() - elapsedRealtime, (List)o2);
                    if (d2 != 401 && d2 != 403) {
                        if (d2 >= 400 && d2 <= 499) {
                            throw new b.a.a.d(k);
                        }
                        if (d2 < 500 || d2 > 599) {
                            throw new r(k);
                        }
                        if (!m.U()) {
                            throw new r(k);
                        }
                        t = new r(k);
                        s = "server";
                    }
                    else {
                        t = new b.a.a.a(k);
                        s = "auth";
                    }
                }
                else {
                    t = new j();
                    s = "network";
                }
            }
            catch (final MalformedURLException ex4) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Bad URL ");
                sb.append(m.E());
                throw new RuntimeException(sb.toString(), (Throwable)ex4);
            }
            catch (final SocketTimeoutException ex5) {
                t = new s();
                s = "socket";
            }
            b(s, m, t);
        }
    }
}
