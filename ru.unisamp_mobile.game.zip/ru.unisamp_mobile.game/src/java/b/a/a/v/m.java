package b.a.a.v;

import android.content.pm.PackageInfo;
import org.apache.http.client.HttpClient;
import android.net.http.AndroidHttpClient;
import android.content.pm.PackageManager$NameNotFoundException;
import android.os.Build$VERSION;
import java.io.File;
import b.a.a.h;
import b.a.a.n;
import android.content.Context;

public class m
{
    public static n a(final Context context) {
        return c(context, null);
    }
    
    private static n b(final Context context, final h h) {
        final n n = new n((b.a.a.b)new e(new File(context.getCacheDir(), "volley")), h);
        n.d();
        return n;
    }
    
    public static n c(final Context context, final b b) {
        c c;
        if (b == null) {
            if (Build$VERSION.SDK_INT >= 9) {
                c = new c((b)new j());
            }
            else {
                String string;
                try {
                    final String packageName = context.getPackageName();
                    final PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
                    final StringBuilder sb = new StringBuilder();
                    sb.append(packageName);
                    sb.append("/");
                    sb.append(packageInfo.versionCode);
                    string = sb.toString();
                }
                catch (final PackageManager$NameNotFoundException ex) {
                    string = "volley/0";
                }
                c = new c((i)new f((HttpClient)AndroidHttpClient.newInstance(string)));
            }
        }
        else {
            c = new c(b);
        }
        return b(context, (h)c);
    }
}
