package b.a.a.v;

import java.util.Collections;
import java.io.InputStream;
import b.a.a.g;
import java.util.List;

public final class h
{
    private final int a;
    private final List<g> b;
    private final int c;
    private final InputStream d;
    
    public h(final int n, final List<g> list) {
        this(n, list, -1, null);
    }
    
    public h(final int a, final List<g> b, final int c, final InputStream d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final InputStream a() {
        return this.d;
    }
    
    public final int b() {
        return this.c;
    }
    
    public final List<g> c() {
        return (List<g>)Collections.unmodifiableList((List)this.b);
    }
    
    public final int d() {
        return this.a;
    }
}
