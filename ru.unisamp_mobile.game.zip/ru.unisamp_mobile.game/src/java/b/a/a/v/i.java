package b.a.a.v;

import org.apache.http.HttpResponse;
import java.util.Map;
import b.a.a.m;

@Deprecated
public interface i
{
    HttpResponse a(final m<?> p0, final Map<String, String> p1);
}
