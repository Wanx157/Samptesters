package b.a.a.v;

import java.io.UnsupportedEncodingException;
import b.a.a.o;
import b.a.a.k;
import b.a.a.o$a;
import b.a.a.o$b;
import b.a.a.m;

public class l extends m<String>
{
    private final Object q;
    private o$b<String> r;
    
    public l(final int n, final String s, final o$b<String> r, final o$a o$a) {
        super(n, s, o$a);
        this.q = new Object();
        this.r = r;
    }
    
    public l(final String s, final o$b<String> o$b, final o$a o$a) {
        this(0, s, o$b, o$a);
    }
    
    protected o<String> N(final k k) {
        String s;
        try {
            s = new String(k.a, g.d(k.b));
        }
        catch (final UnsupportedEncodingException ex) {
            s = new String(k.a);
        }
        return (o<String>)o.c((Object)s, g.c(k));
    }
    
    protected void W(final String s) {
        final Object q = this.q;
        synchronized (q) {
            final o$b<String> r = this.r;
            monitorexit(q);
            if (r != null) {
                r.a((Object)s);
            }
        }
    }
}
