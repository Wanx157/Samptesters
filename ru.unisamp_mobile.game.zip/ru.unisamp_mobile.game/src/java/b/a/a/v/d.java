package b.a.a.v;

import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;

public class d
{
    protected static final Comparator<byte[]> e;
    private final List<byte[]> a;
    private final List<byte[]> b;
    private int c;
    private final int d;
    
    static {
        e = (Comparator)new Comparator<byte[]>() {
            public int a(final byte[] array, final byte[] array2) {
                return array.length - array2.length;
            }
        };
    }
    
    public d(final int d) {
        this.a = (List<byte[]>)new ArrayList();
        this.b = (List<byte[]>)new ArrayList(64);
        this.c = 0;
        this.d = d;
    }
    
    private void c() {
        monitorenter(this);
        try {
            while (this.c > this.d) {
                final byte[] array = (byte[])this.a.remove(0);
                this.b.remove((Object)array);
                this.c -= array.length;
            }
            monitorexit(this);
        }
        finally {
            monitorexit(this);
            while (true) {}
        }
    }
    
    public byte[] a(final int n) {
        monitorenter(this);
        int i = 0;
        try {
            while (i < this.b.size()) {
                final byte[] array = (byte[])this.b.get(i);
                if (array.length >= n) {
                    this.c -= array.length;
                    this.b.remove(i);
                    this.a.remove((Object)array);
                    monitorexit(this);
                    return array;
                }
                ++i;
            }
            final byte[] array2 = new byte[n];
            monitorexit(this);
            return array2;
        }
        finally {
            monitorexit(this);
            while (true) {}
        }
    }
    
    public void b(final byte[] array) {
        monitorenter(this);
        if (array != null) {
            try {
                if (array.length <= this.d) {
                    this.a.add((Object)array);
                    final int binarySearch = Collections.binarySearch((List)this.b, (Object)array, (Comparator)b.a.a.v.d.e);
                    int n;
                    if ((n = binarySearch) < 0) {
                        n = -binarySearch - 1;
                    }
                    this.b.add(n, (Object)array);
                    this.c += array.length;
                    this.c();
                    return;
                }
            }
            finally {
                monitorexit(this);
            }
        }
        monitorexit(this);
    }
}
