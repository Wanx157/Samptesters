package b.a.a.v;

import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.HttpResponse;
import java.util.Iterator;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpOptions;
import org.apache.http.client.methods.HttpTrace;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import java.util.Map;
import b.a.a.m;
import org.apache.http.client.HttpClient;

@Deprecated
public class f implements i
{
    protected final HttpClient a;
    
    public f(final HttpClient a) {
        this.a = a;
    }
    
    static HttpUriRequest b(final m<?> m, final Map<String, String> map) {
        switch (m.s()) {
            default: {
                throw new IllegalStateException("Unknown request method.");
            }
            case 7: {
                final f.f$a f$a = new f.f$a(m.E());
                ((HttpEntityEnclosingRequestBase)f$a).addHeader("Content-Type", m.n());
                d((HttpEntityEnclosingRequestBase)f$a, m);
                return (HttpUriRequest)f$a;
            }
            case 6: {
                return (HttpUriRequest)new HttpTrace(m.E());
            }
            case 5: {
                return (HttpUriRequest)new HttpOptions(m.E());
            }
            case 4: {
                return (HttpUriRequest)new HttpHead(m.E());
            }
            case 3: {
                return (HttpUriRequest)new HttpDelete(m.E());
            }
            case 2: {
                final HttpPut httpPut = new HttpPut(m.E());
                httpPut.addHeader("Content-Type", m.n());
                d((HttpEntityEnclosingRequestBase)httpPut, m);
                return (HttpUriRequest)httpPut;
            }
            case 1: {
                final HttpPost httpPost = new HttpPost(m.E());
                httpPost.addHeader("Content-Type", m.n());
                d((HttpEntityEnclosingRequestBase)httpPost, m);
                return (HttpUriRequest)httpPost;
            }
            case 0: {
                return (HttpUriRequest)new HttpGet(m.E());
            }
            case -1: {
                final byte[] v = m.v();
                if (v != null) {
                    final HttpPost httpPost2 = new HttpPost(m.E());
                    httpPost2.addHeader("Content-Type", m.w());
                    httpPost2.setEntity((HttpEntity)new ByteArrayEntity(v));
                    return (HttpUriRequest)httpPost2;
                }
                return (HttpUriRequest)new HttpGet(m.E());
            }
        }
    }
    
    private static void d(final HttpEntityEnclosingRequestBase httpEntityEnclosingRequestBase, final m<?> m) {
        final byte[] i = m.m();
        if (i != null) {
            httpEntityEnclosingRequestBase.setEntity((HttpEntity)new ByteArrayEntity(i));
        }
    }
    
    private static void e(final HttpUriRequest httpUriRequest, final Map<String, String> map) {
        for (final String s : map.keySet()) {
            httpUriRequest.setHeader(s, (String)map.get((Object)s));
        }
    }
    
    public HttpResponse a(final m<?> m, final Map<String, String> map) {
        final HttpUriRequest b = b(m, map);
        e(b, map);
        e(b, (Map<String, String>)m.q());
        this.c(b);
        final HttpParams params = b.getParams();
        final int c = m.C();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, c);
        return this.a.execute(b);
    }
    
    protected void c(final HttpUriRequest httpUriRequest) {
    }
}
