package b.a.a.v;

import java.io.FilterInputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.BufferedOutputStream;
import android.text.TextUtils;
import java.io.BufferedInputStream;
import b.a.a.b$a;
import java.io.OutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import b.a.a.g;
import java.util.List;
import java.io.EOFException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map$Entry;
import android.os.SystemClock;
import b.a.a.u;
import java.util.LinkedHashMap;
import java.io.File;
import java.util.Map;
import b.a.a.b;

public class e implements b
{
    private final Map<String, e.e$a> a;
    private long b;
    private final File c;
    private final int d;
    
    public e(final File file) {
        this(file, 5242880);
    }
    
    public e(final File c, final int d) {
        this.a = (Map<String, e.e$a>)new LinkedHashMap(16, 0.75f, true);
        this.b = 0L;
        this.c = c;
        this.d = d;
    }
    
    private String g(final String s) {
        final int n = s.length() / 2;
        final int hashCode = s.substring(0, n).hashCode();
        final StringBuilder sb = new StringBuilder();
        sb.append(String.valueOf(hashCode));
        sb.append(String.valueOf(s.substring(n).hashCode()));
        return sb.toString();
    }
    
    private void h(int n) {
        final long b = this.b;
        final long n2 = n;
        if (b + n2 < this.d) {
            return;
        }
        if (u.b) {
            u.e("Pruning old cache entries.", new Object[0]);
        }
        final long b2 = this.b;
        final long elapsedRealtime = SystemClock.elapsedRealtime();
        final Iterator iterator = this.a.entrySet().iterator();
        n = 0;
        int n3;
        while (true) {
            n3 = n;
            if (!iterator.hasNext()) {
                break;
            }
            final e.e$a e$a = (e.e$a)((Map$Entry)iterator.next()).getValue();
            if (this.f(e$a.b).delete()) {
                this.b -= e$a.a;
            }
            else {
                final String b3 = e$a.b;
                u.b("Could not delete cache entry for key=%s, filename=%s", new Object[] { b3, this.g(b3) });
            }
            iterator.remove();
            ++n;
            if (this.b + n2 < this.d * 0.9f) {
                n3 = n;
                break;
            }
        }
        if (u.b) {
            u.e("pruned %d files, %d bytes, %d ms", new Object[] { n3, this.b - b2, SystemClock.elapsedRealtime() - elapsedRealtime });
        }
    }
    
    private void i(final String s, final e.e$a e$a) {
        if (!this.a.containsKey((Object)s)) {
            this.b += e$a.a;
        }
        else {
            this.b += e$a.a - ((e.e$a)this.a.get((Object)s)).a;
        }
        this.a.put((Object)s, (Object)e$a);
    }
    
    private static int j(final InputStream inputStream) {
        final int read = inputStream.read();
        if (read != -1) {
            return read;
        }
        throw new EOFException();
    }
    
    static List<g> k(final e.e$b e$b) {
        final int l = l((InputStream)e$b);
        if (l >= 0) {
            Object emptyList;
            if (l == 0) {
                emptyList = Collections.emptyList();
            }
            else {
                emptyList = new ArrayList();
            }
            for (int i = 0; i < l; ++i) {
                ((List)emptyList).add((Object)new g(n(e$b).intern(), n(e$b).intern()));
            }
            return (List<g>)emptyList;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("readHeaderList size=");
        sb.append(l);
        throw new IOException(sb.toString());
    }
    
    static int l(final InputStream inputStream) {
        return j(inputStream) << 24 | (j(inputStream) << 0 | 0x0 | j(inputStream) << 8 | j(inputStream) << 16);
    }
    
    static long m(final InputStream inputStream) {
        return ((long)j(inputStream) & 0xFFL) << 0 | 0x0L | ((long)j(inputStream) & 0xFFL) << 8 | ((long)j(inputStream) & 0xFFL) << 16 | ((long)j(inputStream) & 0xFFL) << 24 | ((long)j(inputStream) & 0xFFL) << 32 | ((long)j(inputStream) & 0xFFL) << 40 | ((long)j(inputStream) & 0xFFL) << 48 | (0xFFL & (long)j(inputStream)) << 56;
    }
    
    static String n(final e.e$b e$b) {
        return new String(q(e$b, m((InputStream)e$b)), "UTF-8");
    }
    
    private void p(final String s) {
        final e.e$a e$a = (e.e$a)this.a.remove((Object)s);
        if (e$a != null) {
            this.b -= e$a.a;
        }
    }
    
    static byte[] q(final e.e$b e$b, final long n) {
        final long a = e$b.a();
        if (n >= 0L && n <= a) {
            final int n2 = (int)n;
            if (n2 == n) {
                final byte[] array = new byte[n2];
                new DataInputStream((InputStream)e$b).readFully(array);
                return array;
            }
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("streamToBytes length=");
        sb.append(n);
        sb.append(", maxLength=");
        sb.append(a);
        throw new IOException(sb.toString());
    }
    
    static void r(final List<g> list, final OutputStream outputStream) {
        if (list != null) {
            s(outputStream, list.size());
            for (final g g : list) {
                u(outputStream, g.a());
                u(outputStream, g.b());
            }
        }
        else {
            s(outputStream, 0);
        }
    }
    
    static void s(final OutputStream outputStream, final int n) {
        outputStream.write(n >> 0 & 0xFF);
        outputStream.write(n >> 8 & 0xFF);
        outputStream.write(n >> 16 & 0xFF);
        outputStream.write(n >> 24 & 0xFF);
    }
    
    static void t(final OutputStream outputStream, final long n) {
        outputStream.write((int)(byte)(n >>> 0));
        outputStream.write((int)(byte)(n >>> 8));
        outputStream.write((int)(byte)(n >>> 16));
        outputStream.write((int)(byte)(n >>> 24));
        outputStream.write((int)(byte)(n >>> 32));
        outputStream.write((int)(byte)(n >>> 40));
        outputStream.write((int)(byte)(n >>> 48));
        outputStream.write((int)(byte)(n >>> 56));
    }
    
    static void u(final OutputStream outputStream, final String s) {
        final byte[] bytes = s.getBytes("UTF-8");
        t(outputStream, bytes.length);
        outputStream.write(bytes, 0, bytes.length);
    }
    
    public b$a a(final String s) {
        synchronized (this) {
            final e.e$a e$a = (e.e$a)this.a.get((Object)s);
            if (e$a == null) {
                return null;
            }
            final File f = this.f(s);
            try {
                final e.e$b e$b = new e.e$b((InputStream)new BufferedInputStream(this.d(f)), f.length());
                try {
                    final e.e$a b = e.e$a.b(e$b);
                    if (!TextUtils.equals((CharSequence)s, (CharSequence)b.b)) {
                        u.b("%s: key=%s, found=%s", new Object[] { f.getAbsolutePath(), s, b.b });
                        this.p(s);
                        return null;
                    }
                    return e$a.c(q(e$b, e$b.a()));
                }
                finally {
                    ((FilterInputStream)e$b).close();
                }
            }
            catch (final IOException ex) {
                u.b("%s: %s", new Object[] { f.getAbsolutePath(), ex.toString() });
                this.o(s);
                return null;
            }
        }
    }
    
    public void b() {
        monitorenter(this);
        try {
            final boolean exists = this.c.exists();
            int i = 0;
            if (!exists) {
                if (!this.c.mkdirs()) {
                    u.c("Unable to create cache dir %s", new Object[] { this.c.getAbsolutePath() });
                }
                monitorexit(this);
                return;
            }
            final File[] listFiles = this.c.listFiles();
            if (listFiles == null) {
                monitorexit(this);
                return;
            }
            while (i < listFiles.length) {
                final File file = listFiles[i];
                try {
                    final long length = file.length();
                    final e.e$b e$b = new e.e$b((InputStream)new BufferedInputStream(this.d(file)), length);
                    try {
                        final e.e$a b = e.e$a.b(e$b);
                        b.a = length;
                        this.i(b.b, b);
                    }
                    finally {
                        ((FilterInputStream)e$b).close();
                    }
                }
                catch (final IOException ex) {
                    file.delete();
                }
                ++i;
            }
            monitorexit(this);
        }
        finally {
            monitorexit(this);
            while (true) {}
        }
    }
    
    public void c(final String s, final b$a b$a) {
        synchronized (this) {
            this.h(b$a.a.length);
            final File f = this.f(s);
            try {
                final BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(this.e(f));
                final e.e$a e$a = new e.e$a(s, b$a);
                if (e$a.d((OutputStream)bufferedOutputStream)) {
                    bufferedOutputStream.write(b$a.a);
                    bufferedOutputStream.close();
                    this.i(s, e$a);
                    return;
                }
                bufferedOutputStream.close();
                u.b("Failed to write header for %s", new Object[] { f.getAbsolutePath() });
                throw new IOException();
            }
            catch (final IOException ex) {
                if (!f.delete()) {
                    u.b("Could not clean up file %s", new Object[] { f.getAbsolutePath() });
                }
            }
        }
    }
    
    InputStream d(final File file) {
        return (InputStream)new FileInputStream(file);
    }
    
    OutputStream e(final File file) {
        return (OutputStream)new FileOutputStream(file);
    }
    
    public File f(final String s) {
        return new File(this.c, this.g(s));
    }
    
    public void o(final String s) {
        synchronized (this) {
            final boolean delete = this.f(s).delete();
            this.p(s);
            if (!delete) {
                u.b("Could not delete cache entry for key=%s, filename=%s", new Object[] { s, this.g(s) });
            }
        }
    }
}
