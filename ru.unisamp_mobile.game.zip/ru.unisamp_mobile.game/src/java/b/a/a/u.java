package b.a.a;

import java.util.Iterator;
import android.os.SystemClock;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import android.util.Log;

public class u
{
    public static String a = "Volley";
    public static boolean b;
    private static final String c;
    
    static {
        u.b = Log.isLoggable("Volley", 2);
        c = u.class.getName();
    }
    
    private static String a(String format, final Object... array) {
        if (array != null) {
            format = String.format(Locale.US, format, array);
        }
        final StackTraceElement[] stackTrace = new Throwable().fillInStackTrace().getStackTrace();
        for (int i = 2; i < stackTrace.length; ++i) {
            if (!stackTrace[i].getClassName().equals((Object)u.c)) {
                final String className = stackTrace[i].getClassName();
                final String substring = className.substring(className.lastIndexOf(46) + 1);
                final String substring2 = substring.substring(substring.lastIndexOf(36) + 1);
                final StringBuilder sb = new StringBuilder();
                sb.append(substring2);
                sb.append(".");
                sb.append(stackTrace[i].getMethodName());
                final String string = sb.toString();
                return String.format(Locale.US, "[%d] %s: %s", new Object[] { Thread.currentThread().getId(), string, format });
            }
        }
        final String string = "<unknown>";
        return String.format(Locale.US, "[%d] %s: %s", new Object[] { Thread.currentThread().getId(), string, format });
    }
    
    public static void b(final String s, final Object... array) {
        Log.d(u.a, a(s, array));
    }
    
    public static void c(final String s, final Object... array) {
        Log.e(u.a, a(s, array));
    }
    
    public static void d(final Throwable t, final String s, final Object... array) {
        Log.e(u.a, a(s, array), t);
    }
    
    public static void e(final String s, final Object... array) {
        if (u.b) {
            Log.v(u.a, a(s, array));
        }
    }
    
    static class a
    {
        public static final boolean c;
        private final List<u.a.a> a;
        private boolean b;
        
        static {
            c = u.b;
        }
        
        a() {
            this.a = (List<u.a.a>)new ArrayList();
            this.b = false;
        }
        
        private long c() {
            if (this.a.size() == 0) {
                return 0L;
            }
            final long c = ((u.a.a)this.a.get(0)).c;
            final List<u.a.a> a = this.a;
            return ((u.a.a)a.get(a.size() - 1)).c - c;
        }
        
        public void a(final String s, final long n) {
            synchronized (this) {
                if (!this.b) {
                    this.a.add((Object)new u.a.a(s, n, SystemClock.elapsedRealtime()));
                    return;
                }
                throw new IllegalStateException("Marker added to finished log");
            }
        }
        
        public void b(final String s) {
            monitorenter(this);
            try {
                this.b = true;
                final long c = this.c();
                if (c <= 0L) {
                    monitorexit(this);
                    return;
                }
                long c2 = ((u.a.a)this.a.get(0)).c;
                u.b("(%-4d ms) %s", c, s);
                for (final u.a.a a : this.a) {
                    final long c3 = a.c;
                    u.b("(+%-4d) [%2d] %s", c3 - c2, a.b, a.a);
                    c2 = c3;
                }
                monitorexit(this);
            }
            finally {
                monitorexit(this);
                while (true) {}
            }
        }
        
        @Override
        protected void finalize() {
            if (!this.b) {
                this.b("Request on the loose");
                u.c("Marker log finalized without finish() - uncaught exit point for request", new Object[0]);
            }
        }
        
        private static class a
        {
            public final String a;
            public final long b;
            public final long c;
            
            public a(final String a, final long b, final long c) {
                this.a = a;
                this.b = b;
                this.c = c;
            }
        }
    }
}
