package a.f;

public final class a
{
    public static final int alpha = 2130903080;
    public static final int coordinatorLayoutStyle = 2130903265;
    public static final int font = 2130903397;
    public static final int fontProviderAuthority = 2130903399;
    public static final int fontProviderCerts = 2130903400;
    public static final int fontProviderFetchStrategy = 2130903401;
    public static final int fontProviderFetchTimeout = 2130903402;
    public static final int fontProviderPackage = 2130903403;
    public static final int fontProviderQuery = 2130903404;
    public static final int fontStyle = 2130903405;
    public static final int fontVariationSettings = 2130903406;
    public static final int fontWeight = 2130903407;
    public static final int keylines = 2130903480;
    public static final int layout_anchor = 2130903489;
    public static final int layout_anchorGravity = 2130903490;
    public static final int layout_behavior = 2130903491;
    public static final int layout_dodgeInsetEdges = 2130903536;
    public static final int layout_insetEdge = 2130903545;
    public static final int layout_keyline = 2130903546;
    public static final int statusBarBackground = 2130903757;
    public static final int ttcIndex = 2130903895;
}
