package a.f;

public final class b
{
    public static final int TextAppearance_Compat_Notification = 2131755367;
    public static final int TextAppearance_Compat_Notification_Info = 2131755368;
    public static final int TextAppearance_Compat_Notification_Line2 = 2131755369;
    public static final int TextAppearance_Compat_Notification_Time = 2131755370;
    public static final int TextAppearance_Compat_Notification_Title = 2131755371;
    public static final int Widget_Compat_NotificationActionContainer = 2131755603;
    public static final int Widget_Compat_NotificationActionText = 2131755604;
    public static final int Widget_Support_CoordinatorLayout = 2131755730;
}
