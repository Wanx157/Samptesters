package a.o.a.a;

class a
{
    static final int[] a;
    static final int[] b;
    static final int[] c;
    static final int[] d;
    static final int[] e;
    static final int[] f;
    public static final int[] g;
    public static final int[] h;
    public static final int[] i;
    public static final int[] j;
    public static final int[] k;
    public static final int[] l;
    
    static {
        a = new int[] { 16842755, 16843041, 16843093, 16843097, 16843551, 16843754, 16843771, 16843778, 16843779 };
        b = new int[] { 16842755, 16843189, 16843190, 16843556, 16843557, 16843558, 16843866, 16843867 };
        c = new int[] { 16842755, 16843780, 16843781, 16843782, 16843783, 16843784, 16843785, 16843786, 16843787, 16843788, 16843789, 16843979, 16843980, 16844062 };
        d = new int[] { 16842755, 16843781, 16844062 };
        e = new int[] { 16843161 };
        f = new int[] { 16842755, 16843213 };
        g = new int[] { 16843073, 16843160, 16843198, 16843199, 16843200, 16843486, 16843487, 16843488 };
        h = new int[] { 16843490 };
        i = new int[] { 16843486, 16843487, 16843488, 16843489 };
        j = new int[] { 16842788, 16843073, 16843488, 16843992 };
        k = new int[] { 16843489, 16843781, 16843892, 16843893 };
        l = new int[] { 16843772, 16843773, 16843774, 16843775, 16843781 };
    }
}
