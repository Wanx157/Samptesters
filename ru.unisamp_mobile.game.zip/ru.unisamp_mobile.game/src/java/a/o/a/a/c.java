package a.o.a.a;

import android.content.res.XmlResourceParser;
import org.xmlpull.v1.XmlPullParserException;
import java.io.IOException;
import android.content.res.Resources$NotFoundException;
import a.j.a.a.b;
import a.j.a.a.a;
import android.view.animation.AnimationUtils;
import android.os.Build$VERSION;
import android.util.AttributeSet;
import android.view.animation.BounceInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.CycleInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.util.Xml;
import android.view.animation.Interpolator;
import org.xmlpull.v1.XmlPullParser;
import android.content.res.Resources$Theme;
import android.content.res.Resources;
import android.content.Context;

public class c
{
    private static Interpolator a(final Context context, final Resources resources, final Resources$Theme resources$Theme, final XmlPullParser xmlPullParser) {
        final int depth = xmlPullParser.getDepth();
        Object o = null;
        while (true) {
            final int next = xmlPullParser.next();
            if ((next == 3 && xmlPullParser.getDepth() <= depth) || next == 1) {
                return (Interpolator)o;
            }
            if (next != 2) {
                continue;
            }
            final AttributeSet attributeSet = Xml.asAttributeSet(xmlPullParser);
            final String name = xmlPullParser.getName();
            if (name.equals((Object)"linearInterpolator")) {
                o = new LinearInterpolator();
            }
            else if (name.equals((Object)"accelerateInterpolator")) {
                o = new AccelerateInterpolator(context, attributeSet);
            }
            else if (name.equals((Object)"decelerateInterpolator")) {
                o = new DecelerateInterpolator(context, attributeSet);
            }
            else if (name.equals((Object)"accelerateDecelerateInterpolator")) {
                o = new AccelerateDecelerateInterpolator();
            }
            else if (name.equals((Object)"cycleInterpolator")) {
                o = new CycleInterpolator(context, attributeSet);
            }
            else if (name.equals((Object)"anticipateInterpolator")) {
                o = new AnticipateInterpolator(context, attributeSet);
            }
            else if (name.equals((Object)"overshootInterpolator")) {
                o = new OvershootInterpolator(context, attributeSet);
            }
            else if (name.equals((Object)"anticipateOvershootInterpolator")) {
                o = new AnticipateOvershootInterpolator(context, attributeSet);
            }
            else if (name.equals((Object)"bounceInterpolator")) {
                o = new BounceInterpolator();
            }
            else {
                if (!name.equals((Object)"pathInterpolator")) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Unknown interpolator name: ");
                    sb.append(xmlPullParser.getName());
                    throw new RuntimeException(sb.toString());
                }
                o = new f(context, attributeSet, xmlPullParser);
            }
        }
    }
    
    public static Interpolator b(final Context context, final int n) {
        if (Build$VERSION.SDK_INT >= 21) {
            return AnimationUtils.loadInterpolator(context, n);
        }
        final XmlResourceParser xmlResourceParser = null;
        Label_0047: {
            if (n != 17563663) {
                break Label_0047;
            }
            try {
                try {
                    return (Interpolator)new a();
                }
                finally {
                    if (xmlResourceParser != null) {
                        xmlResourceParser.close();
                    }
                    Label_0122: {
                        return;
                    }
                    iftrue(Label_0061:)(n != 17563661);
                    return (Interpolator)new b();
                    final XmlResourceParser animation;
                    animation.close();
                    return;
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Can't load animation resource ID #0x");
                    sb.append(Integer.toHexString(n));
                    final Resources$NotFoundException ex = new Resources$NotFoundException(sb.toString());
                    final Throwable t;
                    ex.initCause(t);
                    throw ex;
                    Label_0061:
                    iftrue(Label_0075:)(n != 17563662);
                    return (Interpolator)new a.j.a.a.c();
                    Label_0075:
                    animation = context.getResources().getAnimation(n);
                    a = a(context, context.getResources(), context.getTheme(), (XmlPullParser)animation);
                    iftrue(Label_0122:)(animation == null);
                }
            }
            catch (final IOException ex2) {}
            catch (final XmlPullParserException ex3) {}
        }
    }
}
