package a.o.a.a;

import android.graphics.PorterDuff$Mode;
import android.graphics.Region;
import android.graphics.Rect;
import androidx.core.graphics.drawable.a;
import android.content.res.Resources$Theme;
import androidx.core.graphics.drawable.b;
import android.graphics.drawable.Drawable;

abstract class g extends Drawable implements b
{
    Drawable b;
    
    public void applyTheme(final Resources$Theme resources$Theme) {
        final Drawable b = this.b;
        if (b != null) {
            a.a(b, resources$Theme);
        }
    }
    
    public void clearColorFilter() {
        final Drawable b = this.b;
        if (b != null) {
            b.clearColorFilter();
            return;
        }
        super.clearColorFilter();
    }
    
    public Drawable getCurrent() {
        final Drawable b = this.b;
        if (b != null) {
            return b.getCurrent();
        }
        return super.getCurrent();
    }
    
    public int getMinimumHeight() {
        final Drawable b = this.b;
        if (b != null) {
            return b.getMinimumHeight();
        }
        return super.getMinimumHeight();
    }
    
    public int getMinimumWidth() {
        final Drawable b = this.b;
        if (b != null) {
            return b.getMinimumWidth();
        }
        return super.getMinimumWidth();
    }
    
    public boolean getPadding(final Rect rect) {
        final Drawable b = this.b;
        if (b != null) {
            return b.getPadding(rect);
        }
        return super.getPadding(rect);
    }
    
    public int[] getState() {
        final Drawable b = this.b;
        if (b != null) {
            return b.getState();
        }
        return super.getState();
    }
    
    public Region getTransparentRegion() {
        final Drawable b = this.b;
        if (b != null) {
            return b.getTransparentRegion();
        }
        return super.getTransparentRegion();
    }
    
    public void jumpToCurrentState() {
        final Drawable b = this.b;
        if (b != null) {
            a.i(b);
        }
    }
    
    protected boolean onLevelChange(final int level) {
        final Drawable b = this.b;
        if (b != null) {
            return b.setLevel(level);
        }
        return super.onLevelChange(level);
    }
    
    public void setChangingConfigurations(final int n) {
        final Drawable b = this.b;
        if (b != null) {
            b.setChangingConfigurations(n);
            return;
        }
        super.setChangingConfigurations(n);
    }
    
    public void setColorFilter(final int n, final PorterDuff$Mode porterDuff$Mode) {
        final Drawable b = this.b;
        if (b != null) {
            b.setColorFilter(n, porterDuff$Mode);
            return;
        }
        super.setColorFilter(n, porterDuff$Mode);
    }
    
    public void setFilterBitmap(final boolean filterBitmap) {
        final Drawable b = this.b;
        if (b != null) {
            b.setFilterBitmap(filterBitmap);
        }
    }
    
    public void setHotspot(final float n, final float n2) {
        final Drawable b = this.b;
        if (b != null) {
            a.k(b, n, n2);
        }
    }
    
    public void setHotspotBounds(final int n, final int n2, final int n3, final int n4) {
        final Drawable b = this.b;
        if (b != null) {
            a.l(b, n, n2, n3, n4);
        }
    }
    
    public boolean setState(final int[] array) {
        final Drawable b = this.b;
        if (b != null) {
            return b.setState(array);
        }
        return super.setState(array);
    }
}
