package a.o.a.a;

import java.util.List;
import android.graphics.PorterDuff$Mode;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable$ConstantState;
import android.graphics.ColorFilter;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.animation.TypeEvaluator;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import a.d.a;
import java.util.ArrayList;
import android.os.Build$VERSION;
import android.animation.Animator;
import android.content.res.Resources$Theme;
import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParser;
import android.content.res.Resources;
import android.graphics.drawable.Drawable$Callback;
import android.animation.ArgbEvaluator;
import android.content.Context;
import android.graphics.drawable.Animatable;

public class b extends g implements Animatable
{
    private b.b$b c;
    private Context d;
    private ArgbEvaluator e;
    final Drawable$Callback f;
    
    b() {
        this(null, null, null);
    }
    
    private b(final Context context) {
        this(context, null, null);
    }
    
    private b(final Context d, final b.b$b c, final Resources resources) {
        this.e = null;
        this.f = (Drawable$Callback)new b$a(this);
        this.d = d;
        if (c != null) {
            this.c = c;
        }
        else {
            this.c = new b.b$b(d, c, this.f, resources);
        }
    }
    
    public static b a(final Context context, final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final b b = new b(context);
        b.inflate(resources, xmlPullParser, set, resources$Theme);
        return b;
    }
    
    private void b(final String s, final Animator animator) {
        animator.setTarget(this.c.b.d(s));
        if (Build$VERSION.SDK_INT < 21) {
            this.c(animator);
        }
        final b.b$b c = this.c;
        if (c.d == null) {
            c.d = new ArrayList();
            this.c.e = new a();
        }
        this.c.d.add((Object)animator);
        ((a.d.g)this.c.e).put((Object)animator, (Object)s);
    }
    
    private void c(final Animator animator) {
        if (animator instanceof AnimatorSet) {
            final ArrayList childAnimations = ((AnimatorSet)animator).getChildAnimations();
            if (childAnimations != null) {
                for (int i = 0; i < ((List)childAnimations).size(); ++i) {
                    this.c((Animator)((List)childAnimations).get(i));
                }
            }
        }
        if (animator instanceof ObjectAnimator) {
            final ObjectAnimator objectAnimator = (ObjectAnimator)animator;
            final String propertyName = objectAnimator.getPropertyName();
            if ("fillColor".equals((Object)propertyName) || "strokeColor".equals((Object)propertyName)) {
                if (this.e == null) {
                    this.e = new ArgbEvaluator();
                }
                objectAnimator.setEvaluator((TypeEvaluator)this.e);
            }
        }
    }
    
    @Override
    public void applyTheme(final Resources$Theme resources$Theme) {
        final Drawable b = super.b;
        if (b != null) {
            androidx.core.graphics.drawable.a.a(b, resources$Theme);
        }
    }
    
    public boolean canApplyTheme() {
        final Drawable b = super.b;
        return b != null && androidx.core.graphics.drawable.a.b(b);
    }
    
    public void draw(final Canvas canvas) {
        final Drawable b = super.b;
        if (b != null) {
            b.draw(canvas);
            return;
        }
        this.c.b.draw(canvas);
        if (this.c.c.isStarted()) {
            this.invalidateSelf();
        }
    }
    
    public int getAlpha() {
        final Drawable b = super.b;
        if (b != null) {
            return androidx.core.graphics.drawable.a.d(b);
        }
        return this.c.b.getAlpha();
    }
    
    public int getChangingConfigurations() {
        final Drawable b = super.b;
        if (b != null) {
            return b.getChangingConfigurations();
        }
        return super.getChangingConfigurations() | this.c.a;
    }
    
    public ColorFilter getColorFilter() {
        final Drawable b = super.b;
        if (b != null) {
            return androidx.core.graphics.drawable.a.e(b);
        }
        return this.c.b.getColorFilter();
    }
    
    public Drawable$ConstantState getConstantState() {
        if (super.b != null && Build$VERSION.SDK_INT >= 24) {
            return (Drawable$ConstantState)new b.b$c(super.b.getConstantState());
        }
        return null;
    }
    
    public int getIntrinsicHeight() {
        final Drawable b = super.b;
        if (b != null) {
            return b.getIntrinsicHeight();
        }
        return this.c.b.getIntrinsicHeight();
    }
    
    public int getIntrinsicWidth() {
        final Drawable b = super.b;
        if (b != null) {
            return b.getIntrinsicWidth();
        }
        return this.c.b.getIntrinsicWidth();
    }
    
    public int getOpacity() {
        final Drawable b = super.b;
        if (b != null) {
            return b.getOpacity();
        }
        return this.c.b.getOpacity();
    }
    
    public void inflate(final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set) {
        this.inflate(resources, xmlPullParser, set, null);
    }
    
    public void inflate(final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final Drawable b = super.b;
        if (b != null) {
            androidx.core.graphics.drawable.a.g(b, resources, xmlPullParser, set, resources$Theme);
            return;
        }
        for (int n = xmlPullParser.getEventType(), depth = xmlPullParser.getDepth(); n != 1 && (xmlPullParser.getDepth() >= depth + 1 || n != 3); n = xmlPullParser.next()) {
            if (n == 2) {
                final String name = xmlPullParser.getName();
                TypedArray typedArray;
                if ("animated-vector".equals((Object)name)) {
                    final TypedArray k = androidx.core.content.d.g.k(resources, resources$Theme, set, a.o.a.a.a.e);
                    final int resourceId = k.getResourceId(0, 0);
                    typedArray = k;
                    if (resourceId != 0) {
                        final h b2 = h.b(resources, resourceId, resources$Theme);
                        b2.h(false);
                        b2.setCallback(this.f);
                        final h b3 = this.c.b;
                        if (b3 != null) {
                            b3.setCallback((Drawable$Callback)null);
                        }
                        this.c.b = b2;
                        typedArray = k;
                    }
                }
                else {
                    if (!"target".equals((Object)name)) {
                        continue;
                    }
                    final TypedArray obtainAttributes = resources.obtainAttributes(set, a.o.a.a.a.f);
                    final String string = obtainAttributes.getString(0);
                    final int resourceId2 = obtainAttributes.getResourceId(1, 0);
                    typedArray = obtainAttributes;
                    if (resourceId2 != 0) {
                        final Context d = this.d;
                        if (d == null) {
                            obtainAttributes.recycle();
                            throw new IllegalStateException("Context can't be null when inflating animators");
                        }
                        this.b(string, a.o.a.a.d.i(d, resourceId2));
                        typedArray = obtainAttributes;
                    }
                }
                typedArray.recycle();
            }
        }
        this.c.a();
    }
    
    public boolean isAutoMirrored() {
        final Drawable b = super.b;
        if (b != null) {
            return androidx.core.graphics.drawable.a.h(b);
        }
        return this.c.b.isAutoMirrored();
    }
    
    public boolean isRunning() {
        final Drawable b = super.b;
        if (b != null) {
            return ((AnimatedVectorDrawable)b).isRunning();
        }
        return this.c.c.isRunning();
    }
    
    public boolean isStateful() {
        final Drawable b = super.b;
        if (b != null) {
            return b.isStateful();
        }
        return this.c.b.isStateful();
    }
    
    public Drawable mutate() {
        final Drawable b = super.b;
        if (b != null) {
            b.mutate();
        }
        return this;
    }
    
    protected void onBoundsChange(final Rect rect) {
        final Drawable b = super.b;
        if (b != null) {
            b.setBounds(rect);
            return;
        }
        this.c.b.setBounds(rect);
    }
    
    @Override
    protected boolean onLevelChange(final int n) {
        final Drawable b = super.b;
        if (b != null) {
            return b.setLevel(n);
        }
        return this.c.b.setLevel(n);
    }
    
    protected boolean onStateChange(final int[] array) {
        final Drawable b = super.b;
        if (b != null) {
            return b.setState(array);
        }
        return this.c.b.setState(array);
    }
    
    public void setAlpha(final int n) {
        final Drawable b = super.b;
        if (b != null) {
            b.setAlpha(n);
            return;
        }
        this.c.b.setAlpha(n);
    }
    
    public void setAutoMirrored(final boolean autoMirrored) {
        final Drawable b = super.b;
        if (b != null) {
            androidx.core.graphics.drawable.a.j(b, autoMirrored);
            return;
        }
        this.c.b.setAutoMirrored(autoMirrored);
    }
    
    public void setColorFilter(final ColorFilter colorFilter) {
        final Drawable b = super.b;
        if (b != null) {
            b.setColorFilter(colorFilter);
            return;
        }
        this.c.b.setColorFilter(colorFilter);
    }
    
    public void setTint(final int tint) {
        final Drawable b = super.b;
        if (b != null) {
            androidx.core.graphics.drawable.a.n(b, tint);
            return;
        }
        this.c.b.setTint(tint);
    }
    
    public void setTintList(final ColorStateList tintList) {
        final Drawable b = super.b;
        if (b != null) {
            androidx.core.graphics.drawable.a.o(b, tintList);
            return;
        }
        this.c.b.setTintList(tintList);
    }
    
    public void setTintMode(final PorterDuff$Mode tintMode) {
        final Drawable b = super.b;
        if (b != null) {
            androidx.core.graphics.drawable.a.p(b, tintMode);
            return;
        }
        this.c.b.setTintMode(tintMode);
    }
    
    public boolean setVisible(final boolean b, final boolean b2) {
        final Drawable b3 = super.b;
        if (b3 != null) {
            return b3.setVisible(b, b2);
        }
        this.c.b.setVisible(b, b2);
        return super.setVisible(b, b2);
    }
    
    public void start() {
        final Drawable b = super.b;
        if (b != null) {
            ((AnimatedVectorDrawable)b).start();
            return;
        }
        if (this.c.c.isStarted()) {
            return;
        }
        this.c.c.start();
        this.invalidateSelf();
    }
    
    public void stop() {
        final Drawable b = super.b;
        if (b != null) {
            ((AnimatedVectorDrawable)b).stop();
            return;
        }
        this.c.c.end();
    }
}
