package a.o.a.a;

import java.util.ArrayList;
import android.graphics.Paint$Join;
import android.graphics.Paint$Cap;
import androidx.core.content.d.b;
import android.graphics.Path;
import a.g.e.c$b;
import a.g.e.c;
import android.graphics.drawable.Drawable$ConstantState;
import android.graphics.Canvas;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import androidx.core.graphics.drawable.a;
import java.util.ArrayDeque;
import android.util.AttributeSet;
import android.content.res.XmlResourceParser;
import android.util.Log;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;
import androidx.core.content.d.f;
import android.os.Build$VERSION;
import android.content.res.Resources$Theme;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Matrix;
import android.graphics.ColorFilter;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuff$Mode;

public class h extends g
{
    static final PorterDuff$Mode k;
    private h.h$h c;
    private PorterDuffColorFilter d;
    private ColorFilter e;
    private boolean f;
    private boolean g;
    private final float[] h;
    private final Matrix i;
    private final Rect j;
    
    static {
        k = PorterDuff$Mode.SRC_IN;
    }
    
    h() {
        this.g = true;
        this.h = new float[9];
        this.i = new Matrix();
        this.j = new Rect();
        this.c = new h.h$h();
    }
    
    h(final h.h$h c) {
        this.g = true;
        this.h = new float[9];
        this.i = new Matrix();
        this.j = new Rect();
        this.c = c;
        this.d = this.j(this.d, c.c, c.d);
    }
    
    static int a(final int n, final float n2) {
        return (n & 0xFFFFFF) | (int)(Color.alpha(n) * n2) << 24;
    }
    
    public static h b(Resources ex, int next, final Resources$Theme resources$Theme) {
        if (Build$VERSION.SDK_INT >= 24) {
            final h h = new h();
            h.b = androidx.core.content.d.f.a((Resources)ex, next, resources$Theme);
            new h.h$i(h.b.getConstantState());
            return h;
        }
        try {
            final XmlResourceParser xml = ((Resources)ex).getXml(next);
            final AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xml);
            do {
                next = ((XmlPullParser)xml).next();
            } while (next != 2 && next != 1);
            if (next == 2) {
                return c((Resources)ex, (XmlPullParser)xml, attributeSet, resources$Theme);
            }
            ex = (IOException)new XmlPullParserException("No start tag found");
            throw ex;
        }
        catch (final IOException ex) {}
        catch (final XmlPullParserException ex2) {}
        Log.e("VectorDrawableCompat", "parser error", (Throwable)ex);
        return null;
    }
    
    public static h c(final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final h h = new h();
        h.inflate(resources, xmlPullParser, set, resources$Theme);
        return h;
    }
    
    private void e(final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final h.h$h c = this.c;
        final h.h$g b = c.b;
        final ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.push((Object)b.h);
        int n = xmlPullParser.getEventType();
        final int depth = xmlPullParser.getDepth();
        int n2 = 1;
        while (n != 1 && (xmlPullParser.getDepth() >= depth + 1 || n != 3)) {
            int n4 = 0;
            Label_0419: {
                if (n == 2) {
                    final String name = xmlPullParser.getName();
                    final d d = (d)arrayDeque.peek();
                    int n5 = 0;
                    int k = 0;
                    Label_0272: {
                        f f;
                        int n3;
                        if ("path".equals((Object)name)) {
                            f = new c();
                            ((c)f).g(resources, set, resources$Theme, xmlPullParser);
                            d.b.add((Object)f);
                            if (f.getPathName() != null) {
                                ((a.d.g)b.p).put((Object)f.getPathName(), (Object)f);
                            }
                            n3 = 0;
                        }
                        else if ("clip-path".equals((Object)name)) {
                            final b b2 = new b();
                            b2.e(resources, set, resources$Theme, xmlPullParser);
                            d.b.add((Object)b2);
                            f = b2;
                            n3 = n2;
                            if (((f)b2).getPathName() != null) {
                                ((a.d.g)b.p).put((Object)((f)b2).getPathName(), (Object)b2);
                                n3 = n2;
                                f = b2;
                            }
                        }
                        else {
                            n4 = n2;
                            if ("group".equals((Object)name)) {
                                final d d2 = new d();
                                d2.c(resources, set, resources$Theme, xmlPullParser);
                                d.b.add((Object)d2);
                                arrayDeque.push((Object)d2);
                                if (d2.getGroupName() != null) {
                                    ((a.d.g)b.p).put((Object)d2.getGroupName(), (Object)d2);
                                }
                                n5 = c.a;
                                k = d2.k;
                                break Label_0272;
                            }
                            break Label_0419;
                        }
                        n5 = c.a;
                        final int d3 = f.d;
                        n2 = n3;
                        k = d3;
                    }
                    c.a = (k | n5);
                    n4 = n2;
                }
                else {
                    n4 = n2;
                    if (n == 3) {
                        n4 = n2;
                        if ("group".equals((Object)xmlPullParser.getName())) {
                            arrayDeque.pop();
                            n4 = n2;
                        }
                    }
                }
            }
            n = xmlPullParser.next();
            n2 = n4;
        }
        if (n2 == 0) {
            return;
        }
        throw new XmlPullParserException("no path defined");
    }
    
    private boolean f() {
        final int sdk_INT = Build$VERSION.SDK_INT;
        boolean b2;
        final boolean b = b2 = false;
        if (sdk_INT >= 17) {
            b2 = b;
            if (this.isAutoMirrored()) {
                b2 = b;
                if (a.f((Drawable)this) == 1) {
                    b2 = true;
                }
            }
        }
        return b2;
    }
    
    private static PorterDuff$Mode g(final int n, final PorterDuff$Mode porterDuff$Mode) {
        if (n == 3) {
            return PorterDuff$Mode.SRC_OVER;
        }
        if (n == 5) {
            return PorterDuff$Mode.SRC_IN;
        }
        if (n == 9) {
            return PorterDuff$Mode.SRC_ATOP;
        }
        switch (n) {
            default: {
                return porterDuff$Mode;
            }
            case 16: {
                return PorterDuff$Mode.ADD;
            }
            case 15: {
                return PorterDuff$Mode.SCREEN;
            }
            case 14: {
                return PorterDuff$Mode.MULTIPLY;
            }
        }
    }
    
    private void i(final TypedArray typedArray, final XmlPullParser xmlPullParser, final Resources$Theme resources$Theme) {
        final h.h$h c = this.c;
        final h.h$g b = c.b;
        c.d = g(androidx.core.content.d.g.g(typedArray, xmlPullParser, "tintMode", 6, -1), PorterDuff$Mode.SRC_IN);
        final ColorStateList c2 = androidx.core.content.d.g.c(typedArray, xmlPullParser, resources$Theme, "tint", 1);
        if (c2 != null) {
            c.c = c2;
        }
        c.e = androidx.core.content.d.g.a(typedArray, xmlPullParser, "autoMirrored", 5, c.e);
        b.k = androidx.core.content.d.g.f(typedArray, xmlPullParser, "viewportWidth", 7, b.k);
        final float f = androidx.core.content.d.g.f(typedArray, xmlPullParser, "viewportHeight", 8, b.l);
        b.l = f;
        if (b.k <= 0.0f) {
            final StringBuilder sb = new StringBuilder();
            sb.append(typedArray.getPositionDescription());
            sb.append("<vector> tag requires viewportWidth > 0");
            throw new XmlPullParserException(sb.toString());
        }
        if (f <= 0.0f) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(typedArray.getPositionDescription());
            sb2.append("<vector> tag requires viewportHeight > 0");
            throw new XmlPullParserException(sb2.toString());
        }
        b.i = typedArray.getDimension(3, b.i);
        final float dimension = typedArray.getDimension(2, b.j);
        b.j = dimension;
        if (b.i <= 0.0f) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(typedArray.getPositionDescription());
            sb3.append("<vector> tag requires width > 0");
            throw new XmlPullParserException(sb3.toString());
        }
        if (dimension > 0.0f) {
            b.setAlpha(androidx.core.content.d.g.f(typedArray, xmlPullParser, "alpha", 4, b.getAlpha()));
            final String string = typedArray.getString(0);
            if (string != null) {
                b.n = string;
                ((a.d.g)b.p).put((Object)string, (Object)b);
            }
            return;
        }
        final StringBuilder sb4 = new StringBuilder();
        sb4.append(typedArray.getPositionDescription());
        sb4.append("<vector> tag requires height > 0");
        throw new XmlPullParserException(sb4.toString());
    }
    
    public boolean canApplyTheme() {
        final Drawable b = super.b;
        if (b != null) {
            a.b(b);
        }
        return false;
    }
    
    Object d(final String s) {
        return ((a.d.g)this.c.b.p).get((Object)s);
    }
    
    public void draw(final Canvas canvas) {
        final Drawable b = super.b;
        if (b != null) {
            b.draw(canvas);
            return;
        }
        this.copyBounds(this.j);
        if (this.j.width() > 0) {
            if (this.j.height() > 0) {
                Object o;
                if ((o = this.e) == null) {
                    o = this.d;
                }
                canvas.getMatrix(this.i);
                this.i.getValues(this.h);
                float abs = Math.abs(this.h[0]);
                float abs2 = Math.abs(this.h[4]);
                final float abs3 = Math.abs(this.h[1]);
                final float abs4 = Math.abs(this.h[3]);
                if (abs3 != 0.0f || abs4 != 0.0f) {
                    abs = 1.0f;
                    abs2 = 1.0f;
                }
                final int n = (int)(this.j.width() * abs);
                final int n2 = (int)(this.j.height() * abs2);
                final int min = Math.min(2048, n);
                final int min2 = Math.min(2048, n2);
                if (min > 0) {
                    if (min2 > 0) {
                        final int save = canvas.save();
                        final Rect j = this.j;
                        canvas.translate((float)j.left, (float)j.top);
                        if (this.f()) {
                            canvas.translate((float)this.j.width(), 0.0f);
                            canvas.scale(-1.0f, 1.0f);
                        }
                        this.j.offsetTo(0, 0);
                        this.c.c(min, min2);
                        if (!this.g) {
                            this.c.j(min, min2);
                        }
                        else if (!this.c.b()) {
                            this.c.j(min, min2);
                            this.c.i();
                        }
                        this.c.d(canvas, (ColorFilter)o, this.j);
                        canvas.restoreToCount(save);
                    }
                }
            }
        }
    }
    
    public int getAlpha() {
        final Drawable b = super.b;
        if (b != null) {
            return a.d(b);
        }
        return this.c.b.getRootAlpha();
    }
    
    public int getChangingConfigurations() {
        final Drawable b = super.b;
        if (b != null) {
            return b.getChangingConfigurations();
        }
        return super.getChangingConfigurations() | this.c.getChangingConfigurations();
    }
    
    public ColorFilter getColorFilter() {
        final Drawable b = super.b;
        if (b != null) {
            return a.e(b);
        }
        return this.e;
    }
    
    public Drawable$ConstantState getConstantState() {
        if (super.b != null && Build$VERSION.SDK_INT >= 24) {
            return (Drawable$ConstantState)new h.h$i(super.b.getConstantState());
        }
        this.c.a = this.getChangingConfigurations();
        return (Drawable$ConstantState)this.c;
    }
    
    public int getIntrinsicHeight() {
        final Drawable b = super.b;
        if (b != null) {
            return b.getIntrinsicHeight();
        }
        return (int)this.c.b.j;
    }
    
    public int getIntrinsicWidth() {
        final Drawable b = super.b;
        if (b != null) {
            return b.getIntrinsicWidth();
        }
        return (int)this.c.b.i;
    }
    
    public int getOpacity() {
        final Drawable b = super.b;
        if (b != null) {
            return b.getOpacity();
        }
        return -3;
    }
    
    void h(final boolean g) {
        this.g = g;
    }
    
    public void inflate(final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set) {
        final Drawable b = super.b;
        if (b != null) {
            b.inflate(resources, xmlPullParser, set);
            return;
        }
        this.inflate(resources, xmlPullParser, set, null);
    }
    
    public void inflate(final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final Drawable b = super.b;
        if (b != null) {
            a.g(b, resources, xmlPullParser, set, resources$Theme);
            return;
        }
        final h.h$h c = this.c;
        c.b = new h.h$g();
        final TypedArray k = androidx.core.content.d.g.k(resources, resources$Theme, set, a.o.a.a.a.a);
        this.i(k, xmlPullParser, resources$Theme);
        k.recycle();
        c.a = this.getChangingConfigurations();
        c.k = true;
        this.e(resources, xmlPullParser, set, resources$Theme);
        this.d = this.j(this.d, c.c, c.d);
    }
    
    public void invalidateSelf() {
        final Drawable b = super.b;
        if (b != null) {
            b.invalidateSelf();
            return;
        }
        super.invalidateSelf();
    }
    
    public boolean isAutoMirrored() {
        final Drawable b = super.b;
        if (b != null) {
            return a.h(b);
        }
        return this.c.e;
    }
    
    public boolean isStateful() {
        final Drawable b = super.b;
        if (b != null) {
            return b.isStateful();
        }
        if (!super.isStateful()) {
            final h.h$h c = this.c;
            if (c != null) {
                if (c.g()) {
                    return true;
                }
                final ColorStateList c2 = this.c.c;
                if (c2 != null && c2.isStateful()) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }
    
    PorterDuffColorFilter j(final PorterDuffColorFilter porterDuffColorFilter, final ColorStateList list, final PorterDuff$Mode porterDuff$Mode) {
        if (list != null && porterDuff$Mode != null) {
            return new PorterDuffColorFilter(list.getColorForState(this.getState(), 0), porterDuff$Mode);
        }
        return null;
    }
    
    public Drawable mutate() {
        final Drawable b = super.b;
        if (b != null) {
            b.mutate();
            return this;
        }
        if (!this.f && super.mutate() == this) {
            this.c = new h.h$h(this.c);
            this.f = true;
        }
        return this;
    }
    
    protected void onBoundsChange(final Rect bounds) {
        final Drawable b = super.b;
        if (b != null) {
            b.setBounds(bounds);
        }
    }
    
    protected boolean onStateChange(final int[] state) {
        final Drawable b = super.b;
        if (b != null) {
            return b.setState(state);
        }
        final boolean b2 = false;
        final h.h$h c = this.c;
        final ColorStateList c2 = c.c;
        final boolean b3 = true;
        boolean b4 = b2;
        if (c2 != null) {
            final PorterDuff$Mode d = c.d;
            b4 = b2;
            if (d != null) {
                this.d = this.j(this.d, c2, d);
                this.invalidateSelf();
                b4 = true;
            }
        }
        if (c.g() && c.h(state)) {
            this.invalidateSelf();
            b4 = b3;
        }
        return b4;
    }
    
    public void scheduleSelf(final Runnable runnable, final long n) {
        final Drawable b = super.b;
        if (b != null) {
            b.scheduleSelf(runnable, n);
            return;
        }
        super.scheduleSelf(runnable, n);
    }
    
    public void setAlpha(final int n) {
        final Drawable b = super.b;
        if (b != null) {
            b.setAlpha(n);
            return;
        }
        if (this.c.b.getRootAlpha() != n) {
            this.c.b.setRootAlpha(n);
            this.invalidateSelf();
        }
    }
    
    public void setAutoMirrored(final boolean e) {
        final Drawable b = super.b;
        if (b != null) {
            a.j(b, e);
            return;
        }
        this.c.e = e;
    }
    
    public void setColorFilter(final ColorFilter colorFilter) {
        final Drawable b = super.b;
        if (b != null) {
            b.setColorFilter(colorFilter);
            return;
        }
        this.e = colorFilter;
        this.invalidateSelf();
    }
    
    public void setTint(final int n) {
        final Drawable b = super.b;
        if (b != null) {
            a.n(b, n);
            return;
        }
        this.setTintList(ColorStateList.valueOf(n));
    }
    
    public void setTintList(final ColorStateList c) {
        final Drawable b = super.b;
        if (b != null) {
            a.o(b, c);
            return;
        }
        final h.h$h c2 = this.c;
        if (c2.c != c) {
            c2.c = c;
            this.d = this.j(this.d, c, c2.d);
            this.invalidateSelf();
        }
    }
    
    public void setTintMode(final PorterDuff$Mode d) {
        final Drawable b = super.b;
        if (b != null) {
            a.p(b, d);
            return;
        }
        final h.h$h c = this.c;
        if (c.d != d) {
            c.d = d;
            this.d = this.j(this.d, c.c, d);
            this.invalidateSelf();
        }
    }
    
    public boolean setVisible(final boolean b, final boolean b2) {
        final Drawable b3 = super.b;
        if (b3 != null) {
            return b3.setVisible(b, b2);
        }
        return super.setVisible(b, b2);
    }
    
    public void unscheduleSelf(final Runnable runnable) {
        final Drawable b = super.b;
        if (b != null) {
            b.unscheduleSelf(runnable);
            return;
        }
        super.unscheduleSelf(runnable);
    }
    
    private static class b extends f
    {
        b() {
        }
        
        b(final b b) {
            super((f)b);
        }
        
        private void f(final TypedArray typedArray, final XmlPullParser xmlPullParser) {
            final String string = typedArray.getString(0);
            if (string != null) {
                super.b = string;
            }
            final String string2 = typedArray.getString(1);
            if (string2 != null) {
                super.a = c.d(string2);
            }
            super.c = androidx.core.content.d.g.g(typedArray, xmlPullParser, "fillType", 2, 0);
        }
        
        @Override
        public boolean c() {
            return true;
        }
        
        public void e(final Resources resources, final AttributeSet set, final Resources$Theme resources$Theme, final XmlPullParser xmlPullParser) {
            if (!androidx.core.content.d.g.j(xmlPullParser, "pathData")) {
                return;
            }
            final TypedArray k = androidx.core.content.d.g.k(resources, resources$Theme, set, a.o.a.a.a.d);
            this.f(k, xmlPullParser);
            k.recycle();
        }
    }
    
    private abstract static class f extends h$e
    {
        protected c$b[] a;
        String b;
        int c;
        int d;
        
        public f() {
            super((h$a)null);
            this.a = null;
            this.c = 0;
        }
        
        public f(final f f) {
            super((h$a)null);
            this.a = null;
            this.c = 0;
            this.b = f.b;
            this.d = f.d;
            this.a = a.g.e.c.f(f.a);
        }
        
        public boolean c() {
            return false;
        }
        
        public void d(final Path path) {
            path.reset();
            final c$b[] a = this.a;
            if (a != null) {
                c$b.e(a, path);
            }
        }
        
        public c$b[] getPathData() {
            return this.a;
        }
        
        public String getPathName() {
            return this.b;
        }
        
        public void setPathData(final c$b[] array) {
            if (!a.g.e.c.b(this.a, array)) {
                this.a = a.g.e.c.f(array);
            }
            else {
                a.g.e.c.j(this.a, array);
            }
        }
    }
    
    private static class c extends f
    {
        private int[] e;
        androidx.core.content.d.b f;
        float g;
        androidx.core.content.d.b h;
        float i;
        float j;
        float k;
        float l;
        float m;
        Paint$Cap n;
        Paint$Join o;
        float p;
        
        c() {
            this.g = 0.0f;
            this.i = 1.0f;
            this.j = 1.0f;
            this.k = 0.0f;
            this.l = 1.0f;
            this.m = 0.0f;
            this.n = Paint$Cap.BUTT;
            this.o = Paint$Join.MITER;
            this.p = 4.0f;
        }
        
        c(final c c) {
            super((f)c);
            this.g = 0.0f;
            this.i = 1.0f;
            this.j = 1.0f;
            this.k = 0.0f;
            this.l = 1.0f;
            this.m = 0.0f;
            this.n = Paint$Cap.BUTT;
            this.o = Paint$Join.MITER;
            this.p = 4.0f;
            this.e = c.e;
            this.f = c.f;
            this.g = c.g;
            this.i = c.i;
            this.h = c.h;
            super.c = c.c;
            this.j = c.j;
            this.k = c.k;
            this.l = c.l;
            this.m = c.m;
            this.n = c.n;
            this.o = c.o;
            this.p = c.p;
        }
        
        private Paint$Cap e(final int n, final Paint$Cap paint$Cap) {
            if (n == 0) {
                return Paint$Cap.BUTT;
            }
            if (n == 1) {
                return Paint$Cap.ROUND;
            }
            if (n != 2) {
                return paint$Cap;
            }
            return Paint$Cap.SQUARE;
        }
        
        private Paint$Join f(final int n, final Paint$Join paint$Join) {
            if (n == 0) {
                return Paint$Join.MITER;
            }
            if (n == 1) {
                return Paint$Join.ROUND;
            }
            if (n != 2) {
                return paint$Join;
            }
            return Paint$Join.BEVEL;
        }
        
        private void h(final TypedArray typedArray, final XmlPullParser xmlPullParser, final Resources$Theme resources$Theme) {
            this.e = null;
            if (!androidx.core.content.d.g.j(xmlPullParser, "pathData")) {
                return;
            }
            final String string = typedArray.getString(0);
            if (string != null) {
                super.b = string;
            }
            final String string2 = typedArray.getString(2);
            if (string2 != null) {
                super.a = a.g.e.c.d(string2);
            }
            this.h = androidx.core.content.d.g.e(typedArray, xmlPullParser, resources$Theme, "fillColor", 1, 0);
            this.j = androidx.core.content.d.g.f(typedArray, xmlPullParser, "fillAlpha", 12, this.j);
            this.n = this.e(androidx.core.content.d.g.g(typedArray, xmlPullParser, "strokeLineCap", 8, -1), this.n);
            this.o = this.f(androidx.core.content.d.g.g(typedArray, xmlPullParser, "strokeLineJoin", 9, -1), this.o);
            this.p = androidx.core.content.d.g.f(typedArray, xmlPullParser, "strokeMiterLimit", 10, this.p);
            this.f = androidx.core.content.d.g.e(typedArray, xmlPullParser, resources$Theme, "strokeColor", 3, 0);
            this.i = androidx.core.content.d.g.f(typedArray, xmlPullParser, "strokeAlpha", 11, this.i);
            this.g = androidx.core.content.d.g.f(typedArray, xmlPullParser, "strokeWidth", 4, this.g);
            this.l = androidx.core.content.d.g.f(typedArray, xmlPullParser, "trimPathEnd", 6, this.l);
            this.m = androidx.core.content.d.g.f(typedArray, xmlPullParser, "trimPathOffset", 7, this.m);
            this.k = androidx.core.content.d.g.f(typedArray, xmlPullParser, "trimPathStart", 5, this.k);
            super.c = androidx.core.content.d.g.g(typedArray, xmlPullParser, "fillType", 13, super.c);
        }
        
        public boolean a() {
            return this.h.i() || this.f.i();
        }
        
        public boolean b(final int[] array) {
            return this.f.j(array) | this.h.j(array);
        }
        
        public void g(final Resources resources, final AttributeSet set, final Resources$Theme resources$Theme, final XmlPullParser xmlPullParser) {
            final TypedArray k = androidx.core.content.d.g.k(resources, resources$Theme, set, a.o.a.a.a.c);
            this.h(k, xmlPullParser, resources$Theme);
            k.recycle();
        }
        
        float getFillAlpha() {
            return this.j;
        }
        
        int getFillColor() {
            return this.h.e();
        }
        
        float getStrokeAlpha() {
            return this.i;
        }
        
        int getStrokeColor() {
            return this.f.e();
        }
        
        float getStrokeWidth() {
            return this.g;
        }
        
        float getTrimPathEnd() {
            return this.l;
        }
        
        float getTrimPathOffset() {
            return this.m;
        }
        
        float getTrimPathStart() {
            return this.k;
        }
        
        void setFillAlpha(final float j) {
            this.j = j;
        }
        
        void setFillColor(final int n) {
            this.h.k(n);
        }
        
        void setStrokeAlpha(final float i) {
            this.i = i;
        }
        
        void setStrokeColor(final int n) {
            this.f.k(n);
        }
        
        void setStrokeWidth(final float g) {
            this.g = g;
        }
        
        void setTrimPathEnd(final float l) {
            this.l = l;
        }
        
        void setTrimPathOffset(final float m) {
            this.m = m;
        }
        
        void setTrimPathStart(final float k) {
            this.k = k;
        }
    }
    
    private static class d extends h$e
    {
        final Matrix a;
        final ArrayList<h$e> b;
        float c;
        private float d;
        private float e;
        private float f;
        private float g;
        private float h;
        private float i;
        final Matrix j;
        int k;
        private int[] l;
        private String m;
        
        public d() {
            super((h$a)null);
            this.a = new Matrix();
            this.b = (ArrayList<h$e>)new ArrayList();
            this.c = 0.0f;
            this.d = 0.0f;
            this.e = 0.0f;
            this.f = 1.0f;
            this.g = 1.0f;
            this.h = 0.0f;
            this.i = 0.0f;
            this.j = new Matrix();
            this.m = null;
        }
        
        public d(d d, final a.d.a<String, Object> a) {
            super((h$a)null);
            this.a = new Matrix();
            this.b = (ArrayList<h$e>)new ArrayList();
            this.c = 0.0f;
            this.d = 0.0f;
            this.e = 0.0f;
            this.f = 1.0f;
            this.g = 1.0f;
            this.h = 0.0f;
            this.i = 0.0f;
            this.j = new Matrix();
            this.m = null;
            this.c = d.c;
            this.d = d.d;
            this.e = d.e;
            this.f = d.f;
            this.g = d.g;
            this.h = d.h;
            this.i = d.i;
            this.l = d.l;
            final String m = d.m;
            this.m = m;
            this.k = d.k;
            if (m != null) {
                ((a.d.g)a).put((Object)m, (Object)this);
            }
            this.j.set(d.j);
            final ArrayList<h$e> b = d.b;
            for (int i = 0; i < b.size(); ++i) {
                final Object value = b.get(i);
                if (value instanceof d) {
                    d = (d)value;
                    this.b.add((Object)new d(d, a));
                }
                else {
                    f f;
                    if (value instanceof c) {
                        f = new c((c)value);
                    }
                    else {
                        if (!(value instanceof b)) {
                            throw new IllegalStateException("Unknown object in the tree!");
                        }
                        f = new b((b)value);
                    }
                    this.b.add((Object)f);
                    final String b2 = f.b;
                    if (b2 != null) {
                        ((a.d.g)a).put((Object)b2, (Object)f);
                    }
                }
            }
        }
        
        private void d() {
            this.j.reset();
            this.j.postTranslate(-this.d, -this.e);
            this.j.postScale(this.f, this.g);
            this.j.postRotate(this.c, 0.0f, 0.0f);
            this.j.postTranslate(this.h + this.d, this.i + this.e);
        }
        
        private void e(final TypedArray typedArray, final XmlPullParser xmlPullParser) {
            this.l = null;
            this.c = androidx.core.content.d.g.f(typedArray, xmlPullParser, "rotation", 5, this.c);
            this.d = typedArray.getFloat(1, this.d);
            this.e = typedArray.getFloat(2, this.e);
            this.f = androidx.core.content.d.g.f(typedArray, xmlPullParser, "scaleX", 3, this.f);
            this.g = androidx.core.content.d.g.f(typedArray, xmlPullParser, "scaleY", 4, this.g);
            this.h = androidx.core.content.d.g.f(typedArray, xmlPullParser, "translateX", 6, this.h);
            this.i = androidx.core.content.d.g.f(typedArray, xmlPullParser, "translateY", 7, this.i);
            final String string = typedArray.getString(0);
            if (string != null) {
                this.m = string;
            }
            this.d();
        }
        
        public boolean a() {
            for (int i = 0; i < this.b.size(); ++i) {
                if (((h$e)this.b.get(i)).a()) {
                    return true;
                }
            }
            return false;
        }
        
        public boolean b(final int[] array) {
            int i = 0;
            boolean b = false;
            while (i < this.b.size()) {
                b |= ((h$e)this.b.get(i)).b(array);
                ++i;
            }
            return b;
        }
        
        public void c(final Resources resources, final AttributeSet set, final Resources$Theme resources$Theme, final XmlPullParser xmlPullParser) {
            final TypedArray k = androidx.core.content.d.g.k(resources, resources$Theme, set, a.o.a.a.a.b);
            this.e(k, xmlPullParser);
            k.recycle();
        }
        
        public String getGroupName() {
            return this.m;
        }
        
        public Matrix getLocalMatrix() {
            return this.j;
        }
        
        public float getPivotX() {
            return this.d;
        }
        
        public float getPivotY() {
            return this.e;
        }
        
        public float getRotation() {
            return this.c;
        }
        
        public float getScaleX() {
            return this.f;
        }
        
        public float getScaleY() {
            return this.g;
        }
        
        public float getTranslateX() {
            return this.h;
        }
        
        public float getTranslateY() {
            return this.i;
        }
        
        public void setPivotX(final float d) {
            if (d != this.d) {
                this.d = d;
                this.d();
            }
        }
        
        public void setPivotY(final float e) {
            if (e != this.e) {
                this.e = e;
                this.d();
            }
        }
        
        public void setRotation(final float c) {
            if (c != this.c) {
                this.c = c;
                this.d();
            }
        }
        
        public void setScaleX(final float f) {
            if (f != this.f) {
                this.f = f;
                this.d();
            }
        }
        
        public void setScaleY(final float g) {
            if (g != this.g) {
                this.g = g;
                this.d();
            }
        }
        
        public void setTranslateX(final float h) {
            if (h != this.h) {
                this.h = h;
                this.d();
            }
        }
        
        public void setTranslateY(final float i) {
            if (i != this.i) {
                this.i = i;
                this.d();
            }
        }
    }
}
