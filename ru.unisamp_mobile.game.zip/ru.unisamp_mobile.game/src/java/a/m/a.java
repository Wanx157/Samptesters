package a.m;

public final class a
{
    public static final int alpha = 2130903080;
    public static final int fastScrollEnabled = 2130903371;
    public static final int fastScrollHorizontalThumbDrawable = 2130903372;
    public static final int fastScrollHorizontalTrackDrawable = 2130903373;
    public static final int fastScrollVerticalThumbDrawable = 2130903374;
    public static final int fastScrollVerticalTrackDrawable = 2130903375;
    public static final int font = 2130903397;
    public static final int fontProviderAuthority = 2130903399;
    public static final int fontProviderCerts = 2130903400;
    public static final int fontProviderFetchStrategy = 2130903401;
    public static final int fontProviderFetchTimeout = 2130903402;
    public static final int fontProviderPackage = 2130903403;
    public static final int fontProviderQuery = 2130903404;
    public static final int fontStyle = 2130903405;
    public static final int fontVariationSettings = 2130903406;
    public static final int fontWeight = 2130903407;
    public static final int layoutManager = 2130903488;
    public static final int recyclerViewStyle = 2130903695;
    public static final int reverseLayout = 2130903700;
    public static final int spanCount = 2130903738;
    public static final int stackFromEnd = 2130903744;
    public static final int ttcIndex = 2130903895;
}
