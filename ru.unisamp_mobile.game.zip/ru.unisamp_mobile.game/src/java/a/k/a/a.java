package a.k.a;

import android.os.PowerManager;
import android.content.ComponentName;
import android.content.Context;
import android.util.Log;
import android.content.Intent;
import android.os.PowerManager$WakeLock;
import android.util.SparseArray;
import android.content.BroadcastReceiver;

@Deprecated
public abstract class a extends BroadcastReceiver
{
    private static final SparseArray<PowerManager$WakeLock> a;
    private static int b;
    
    static {
        a = new SparseArray();
        a.k.a.a.b = 1;
    }
    
    public static boolean b(final Intent intent) {
        final int intExtra = intent.getIntExtra("androidx.contentpager.content.wakelockid", 0);
        if (intExtra == 0) {
            return false;
        }
        final SparseArray<PowerManager$WakeLock> a = a.k.a.a.a;
        synchronized (a) {
            final PowerManager$WakeLock powerManager$WakeLock = (PowerManager$WakeLock)a.k.a.a.a.get(intExtra);
            if (powerManager$WakeLock != null) {
                powerManager$WakeLock.release();
                a.k.a.a.a.remove(intExtra);
                return true;
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("No active wake lock id #");
            sb.append(intExtra);
            Log.w("WakefulBroadcastReceiv.", sb.toString());
            return true;
        }
    }
    
    public static ComponentName c(final Context context, final Intent intent) {
        final SparseArray<PowerManager$WakeLock> a = a.k.a.a.a;
        synchronized (a) {
            final int b = a.k.a.a.b;
            if (++a.k.a.a.b <= 0) {
                a.k.a.a.b = 1;
            }
            intent.putExtra("androidx.contentpager.content.wakelockid", b);
            final ComponentName startService = context.startService(intent);
            if (startService == null) {
                return null;
            }
            final PowerManager powerManager = (PowerManager)context.getSystemService("power");
            final StringBuilder sb = new StringBuilder();
            sb.append("androidx.core:wake:");
            sb.append(startService.flattenToShortString());
            final PowerManager$WakeLock wakeLock = powerManager.newWakeLock(1, sb.toString());
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(60000L);
            a.k.a.a.a.put(b, (Object)wakeLock);
            return startService;
        }
    }
}
