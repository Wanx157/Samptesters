package a.i.a;

import android.os.Parcel;
import android.os.Parcelable$ClassLoaderCreator;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public abstract class a implements Parcelable
{
    public static final Parcelable$Creator<a> CREATOR;
    public static final a c;
    private final Parcelable b;
    
    static {
        c = (a)new a$a();
        CREATOR = (Parcelable$Creator)new Parcelable$ClassLoaderCreator<a>() {
            public a a(final Parcel parcel) {
                return this.b(parcel, null);
            }
            
            public a b(final Parcel parcel, final ClassLoader classLoader) {
                if (parcel.readParcelable(classLoader) == null) {
                    return a.c;
                }
                throw new IllegalStateException("superState must be null");
            }
            
            public a[] c(final int n) {
                return new a[n];
            }
        };
    }
    
    private a() {
        this.b = null;
    }
    
    protected a(final Parcel parcel, final ClassLoader classLoader) {
        Object b = parcel.readParcelable(classLoader);
        if (b == null) {
            b = a.c;
        }
        this.b = (Parcelable)b;
    }
    
    protected a(Parcelable b) {
        if (b != null) {
            if (b == a.c) {
                b = null;
            }
            this.b = b;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }
    
    public final Parcelable a() {
        return this.b;
    }
    
    public int describeContents() {
        return 0;
    }
    
    public void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeParcelable(this.b, n);
    }
}
