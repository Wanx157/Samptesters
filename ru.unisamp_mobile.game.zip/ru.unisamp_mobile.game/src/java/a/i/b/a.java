package a.i.b;

import android.view.KeyEvent;
import android.view.MotionEvent;
import a.g.l.c0.d;
import a.g.l.w;
import java.util.List;
import java.util.ArrayList;
import android.view.accessibility.AccessibilityRecord;
import a.g.l.c0.e;
import android.view.accessibility.AccessibilityEvent;
import android.os.Bundle;
import android.view.ViewParent;
import a.g.l.t;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import a.d.h;
import a.g.l.c0.c;
import android.graphics.Rect;

public abstract class a extends a.g.l.a
{
    private static final Rect n;
    private static final b$a<a.g.l.c0.c> o;
    private static final b$b<h<a.g.l.c0.c>, a.g.l.c0.c> p;
    private final Rect d;
    private final Rect e;
    private final Rect f;
    private final int[] g;
    private final AccessibilityManager h;
    private final View i;
    private c j;
    int k;
    int l;
    private int m;
    
    static {
        n = new Rect(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
        o = (b$a)new b$a<a.g.l.c0.c>() {
            public void b(final a.g.l.c0.c c, final Rect rect) {
                c.l(rect);
            }
        };
        p = (b$b)new b$b<h<a.g.l.c0.c>, a.g.l.c0.c>() {
            public a.g.l.c0.c c(final h<a.g.l.c0.c> h, final int n) {
                return (a.g.l.c0.c)h.v(n);
            }
            
            public int d(final h<a.g.l.c0.c> h) {
                return h.t();
            }
        };
    }
    
    public a(final View i) {
        this.d = new Rect();
        this.e = new Rect();
        this.f = new Rect();
        this.g = new int[2];
        this.k = Integer.MIN_VALUE;
        this.l = Integer.MIN_VALUE;
        this.m = Integer.MIN_VALUE;
        if (i != null) {
            this.i = i;
            this.h = (AccessibilityManager)i.getContext().getSystemService("accessibility");
            i.setFocusable(true);
            if (t.z(i) == 0) {
                t.t0(i, 1);
            }
            return;
        }
        throw new IllegalArgumentException("View may not be null");
    }
    
    private static Rect D(final View view, final int n, final Rect rect) {
        final int width = view.getWidth();
        final int height = view.getHeight();
        if (n != 17) {
            if (n != 33) {
                if (n != 66) {
                    if (n != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                    rect.set(0, -1, width, -1);
                }
                else {
                    rect.set(-1, 0, -1, height);
                }
            }
            else {
                rect.set(0, height, width, height);
            }
        }
        else {
            rect.set(width, 0, width, height);
        }
        return rect;
    }
    
    private boolean E(final Rect rect) {
        boolean b2;
        final boolean b = b2 = false;
        if (rect != null) {
            if (rect.isEmpty()) {
                b2 = b;
            }
            else {
                if (this.i.getWindowVisibility() != 0) {
                    return false;
                }
                View i = this.i;
                View view;
                do {
                    final ViewParent parent = i.getParent();
                    if (parent instanceof View) {
                        view = (View)parent;
                        if (view.getAlpha() <= 0.0f) {
                            break;
                        }
                        i = view;
                    }
                    else {
                        b2 = b;
                        if (parent != null) {
                            b2 = true;
                            return b2;
                        }
                        return b2;
                    }
                } while (view.getVisibility() == 0);
                return false;
            }
        }
        return b2;
    }
    
    private static int F(final int n) {
        if (n == 19) {
            return 33;
        }
        if (n == 21) {
            return 17;
        }
        if (n != 22) {
            return 130;
        }
        return 66;
    }
    
    private boolean G(int l, final Rect rect) {
        final h<a.g.l.c0.c> y = this.y();
        final int i = this.l;
        final int n = Integer.MIN_VALUE;
        Object o;
        if (i == Integer.MIN_VALUE) {
            o = null;
        }
        else {
            o = y.f(i);
        }
        Object o2;
        if (l != 1 && l != 2) {
            if (l != 17 && l != 33 && l != 66 && l != 130) {
                throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD, FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
            }
            final Rect rect2 = new Rect();
            final int j = this.l;
            if (j != Integer.MIN_VALUE) {
                this.z(j, rect2);
            }
            else if (rect != null) {
                rect2.set(rect);
            }
            else {
                D(this.i, l, rect2);
            }
            o2 = b.c((Object)y, (b$b)a.p, (b$a)a.o, o, rect2, l);
        }
        else {
            o2 = b.d((Object)y, (b$b)a.p, (b$a)a.o, o, l, t.B(this.i) == 1, false);
        }
        final a.g.l.c0.c c = (a.g.l.c0.c)o2;
        if (c == null) {
            l = n;
        }
        else {
            l = y.l(y.k((Object)c));
        }
        return this.T(l);
    }
    
    private boolean Q(final int n, final int n2, final Bundle bundle) {
        if (n2 == 1) {
            return this.T(n);
        }
        if (n2 == 2) {
            return this.o(n);
        }
        if (n2 == 64) {
            return this.S(n);
        }
        if (n2 != 128) {
            return this.J(n, n2, bundle);
        }
        return this.n(n);
    }
    
    private boolean R(final int n, final Bundle bundle) {
        return t.a0(this.i, n, bundle);
    }
    
    private boolean S(final int k) {
        if (this.h.isEnabled()) {
            if (this.h.isTouchExplorationEnabled()) {
                final int i = this.k;
                if (i != k) {
                    if (i != Integer.MIN_VALUE) {
                        this.n(i);
                    }
                    this.k = k;
                    this.i.invalidate();
                    this.U(k, 32768);
                    return true;
                }
            }
        }
        return false;
    }
    
    private void V(final int m) {
        final int i = this.m;
        if (i == m) {
            return;
        }
        this.U(this.m = m, 128);
        this.U(i, 256);
    }
    
    private boolean n(final int n) {
        if (this.k == n) {
            this.k = Integer.MIN_VALUE;
            this.i.invalidate();
            this.U(n, 65536);
            return true;
        }
        return false;
    }
    
    private boolean p() {
        final int l = this.l;
        return l != Integer.MIN_VALUE && this.J(l, 16, null);
    }
    
    private AccessibilityEvent q(final int n, final int n2) {
        if (n != -1) {
            return this.r(n, n2);
        }
        return this.s(n2);
    }
    
    private AccessibilityEvent r(final int n, final int n2) {
        final AccessibilityEvent obtain = AccessibilityEvent.obtain(n2);
        final a.g.l.c0.c h = this.H(n);
        obtain.getText().add((Object)h.v());
        obtain.setContentDescription(h.q());
        obtain.setScrollable(h.H());
        obtain.setPassword(h.G());
        obtain.setEnabled(h.C());
        obtain.setChecked(h.A());
        this.L(n, obtain);
        if (obtain.getText().isEmpty() && obtain.getContentDescription() == null) {
            throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
        }
        obtain.setClassName(h.o());
        a.g.l.c0.e.c((AccessibilityRecord)obtain, this.i, n);
        obtain.setPackageName((CharSequence)this.i.getContext().getPackageName());
        return obtain;
    }
    
    private AccessibilityEvent s(final int n) {
        final AccessibilityEvent obtain = AccessibilityEvent.obtain(n);
        this.i.onInitializeAccessibilityEvent(obtain);
        return obtain;
    }
    
    private a.g.l.c0.c t(int i) {
        final a.g.l.c0.c k = a.g.l.c0.c.K();
        k.c0(true);
        k.e0(true);
        k.X((CharSequence)"android.view.View");
        k.T(a.n);
        k.U(a.n);
        k.l0(this.i);
        this.N(i, k);
        if (k.v() == null && k.q() == null) {
            throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
        }
        k.l(this.e);
        if (this.e.equals((Object)a.n)) {
            throw new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
        }
        final int j = k.j();
        if ((j & 0x40) != 0x0) {
            throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        }
        if ((j & 0x80) == 0x0) {
            k.j0((CharSequence)this.i.getContext().getPackageName());
            k.r0(this.i, i);
            if (this.k == i) {
                k.R(true);
                k.a(128);
            }
            else {
                k.R(false);
                k.a(64);
            }
            final boolean b = this.l == i;
            if (b) {
                k.a(2);
            }
            else if (k.D()) {
                k.a(1);
            }
            k.f0(b);
            this.i.getLocationOnScreen(this.g);
            k.m(this.d);
            if (this.d.equals((Object)a.n)) {
                k.l(this.d);
                if (k.b != -1) {
                    a.g.l.c0.c l;
                    Rect d;
                    Rect e;
                    for (l = a.g.l.c0.c.K(), i = k.b; i != -1; i = l.b) {
                        l.m0(this.i, -1);
                        l.T(a.n);
                        this.N(i, l);
                        l.l(this.e);
                        d = this.d;
                        e = this.e;
                        d.offset(e.left, e.top);
                    }
                    l.O();
                }
                this.d.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
            }
            if (this.i.getLocalVisibleRect(this.f)) {
                this.f.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
                if (this.d.intersect(this.f)) {
                    k.U(this.d);
                    if (this.E(this.d)) {
                        k.u0(true);
                    }
                }
            }
            return k;
        }
        throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
    }
    
    private a.g.l.c0.c u() {
        final a.g.l.c0.c l = a.g.l.c0.c.L(this.i);
        t.Y(this.i, l);
        final ArrayList list = new ArrayList();
        this.C((List<Integer>)list);
        if (l.n() > 0 && list.size() > 0) {
            throw new RuntimeException("Views cannot have both real and virtual children");
        }
        for (int i = 0; i < list.size(); ++i) {
            l.c(this.i, (int)list.get(i));
        }
        return l;
    }
    
    private h<a.g.l.c0.c> y() {
        final ArrayList list = new ArrayList();
        this.C((List<Integer>)list);
        final h h = new h();
        for (int i = 0; i < ((List)list).size(); ++i) {
            h.p(i, (Object)this.t(i));
        }
        return (h<a.g.l.c0.c>)h;
    }
    
    private void z(final int n, final Rect rect) {
        this.H(n).l(rect);
    }
    
    public final int A() {
        return this.l;
    }
    
    protected abstract int B(final float p0, final float p1);
    
    protected abstract void C(final List<Integer> p0);
    
    a.g.l.c0.c H(final int n) {
        if (n == -1) {
            return this.u();
        }
        return this.t(n);
    }
    
    public final void I(final boolean b, final int n, final Rect rect) {
        final int l = this.l;
        if (l != Integer.MIN_VALUE) {
            this.o(l);
        }
        if (b) {
            this.G(n, rect);
        }
    }
    
    protected abstract boolean J(final int p0, final int p1, final Bundle p2);
    
    protected void K(final AccessibilityEvent accessibilityEvent) {
    }
    
    protected void L(final int n, final AccessibilityEvent accessibilityEvent) {
    }
    
    protected void M(final a.g.l.c0.c c) {
    }
    
    protected abstract void N(final int p0, final a.g.l.c0.c p1);
    
    protected void O(final int n, final boolean b) {
    }
    
    boolean P(final int n, final int n2, final Bundle bundle) {
        if (n != -1) {
            return this.Q(n, n2, bundle);
        }
        return this.R(n2, bundle);
    }
    
    public final boolean T(final int l) {
        if (!this.i.isFocused() && !this.i.requestFocus()) {
            return false;
        }
        final int i = this.l;
        if (i == l) {
            return false;
        }
        if (i != Integer.MIN_VALUE) {
            this.o(i);
        }
        this.O(this.l = l, true);
        this.U(l, 8);
        return true;
    }
    
    public final boolean U(final int n, final int n2) {
        if (n != Integer.MIN_VALUE && this.h.isEnabled()) {
            final ViewParent parent = this.i.getParent();
            return parent != null && w.h(parent, this.i, this.q(n, n2));
        }
        return false;
    }
    
    public d b(final View view) {
        if (this.j == null) {
            this.j = new c();
        }
        return this.j;
    }
    
    public void f(final View view, final AccessibilityEvent accessibilityEvent) {
        super.f(view, accessibilityEvent);
        this.K(accessibilityEvent);
    }
    
    public void g(final View view, final a.g.l.c0.c c) {
        super.g(view, c);
        this.M(c);
    }
    
    public final boolean o(final int n) {
        if (this.l != n) {
            return false;
        }
        this.l = Integer.MIN_VALUE;
        this.O(n, false);
        this.U(n, 8);
        return true;
    }
    
    public final boolean v(final MotionEvent motionEvent) {
        final boolean enabled = this.h.isEnabled();
        boolean b2;
        final boolean b = b2 = false;
        if (enabled) {
            if (!this.h.isTouchExplorationEnabled()) {
                b2 = b;
            }
            else {
                final int action = motionEvent.getAction();
                if (action != 7 && action != 9) {
                    if (action != 10) {
                        return false;
                    }
                    if (this.m != Integer.MIN_VALUE) {
                        this.V(Integer.MIN_VALUE);
                        return true;
                    }
                    return false;
                }
                else {
                    final int b3 = this.B(motionEvent.getX(), motionEvent.getY());
                    this.V(b3);
                    b2 = b;
                    if (b3 != Integer.MIN_VALUE) {
                        b2 = true;
                    }
                }
            }
        }
        return b2;
    }
    
    public final boolean w(final KeyEvent keyEvent) {
        final int action = keyEvent.getAction();
        final boolean b = false;
        int n = 0;
        boolean b2 = b;
        if (action != 1) {
            final int keyCode = keyEvent.getKeyCode();
            if (keyCode != 61) {
                if (keyCode != 66) {
                    switch (keyCode) {
                        default: {
                            b2 = b;
                            return b2;
                        }
                        case 19:
                        case 20:
                        case 21:
                        case 22: {
                            b2 = b;
                            if (keyEvent.hasNoModifiers()) {
                                final int f = F(keyCode);
                                final int repeatCount = keyEvent.getRepeatCount();
                                b2 = false;
                                while (n < repeatCount + 1 && this.G(f, null)) {
                                    ++n;
                                    b2 = true;
                                }
                                return b2;
                            }
                            return b2;
                        }
                        case 23: {
                            break;
                        }
                    }
                }
                b2 = b;
                if (keyEvent.hasNoModifiers()) {
                    b2 = b;
                    if (keyEvent.getRepeatCount() == 0) {
                        this.p();
                        b2 = true;
                    }
                }
            }
            else if (keyEvent.hasNoModifiers()) {
                b2 = this.G(2, null);
            }
            else {
                b2 = b;
                if (keyEvent.hasModifiers(1)) {
                    b2 = this.G(1, null);
                }
            }
        }
        return b2;
    }
    
    public final int x() {
        return this.k;
    }
    
    private class c extends d
    {
        final a b;
        
        c(final a b) {
            this.b = b;
        }
        
        public a.g.l.c0.c a(final int n) {
            return a.g.l.c0.c.M(this.b.H(n));
        }
        
        public a.g.l.c0.c c(int n) {
            if (n == 2) {
                n = this.b.k;
            }
            else {
                n = this.b.l;
            }
            if (n == Integer.MIN_VALUE) {
                return null;
            }
            return this.a(n);
        }
        
        public boolean e(final int n, final int n2, final Bundle bundle) {
            return this.b.P(n, n2, bundle);
        }
    }
}
