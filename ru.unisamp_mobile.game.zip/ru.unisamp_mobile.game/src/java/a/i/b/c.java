package a.i.b;

import android.util.Log;
import a.g.l.t;
import java.util.Arrays;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.content.Context;
import android.view.ViewGroup;
import android.view.View;
import android.widget.OverScroller;
import android.view.VelocityTracker;
import android.view.animation.Interpolator;

public class c
{
    private static final Interpolator w;
    private int a;
    private int b;
    private int c;
    private float[] d;
    private float[] e;
    private float[] f;
    private float[] g;
    private int[] h;
    private int[] i;
    private int[] j;
    private int k;
    private VelocityTracker l;
    private float m;
    private float n;
    private int o;
    private int p;
    private OverScroller q;
    private final c r;
    private View s;
    private boolean t;
    private final ViewGroup u;
    private final Runnable v;
    
    static {
        w = (Interpolator)new Interpolator() {
            public float getInterpolation(float n) {
                --n;
                return n * n * n * n * n + 1.0f;
            }
        };
    }
    
    private c(final Context context, final ViewGroup u, final c r) {
        this.c = -1;
        this.v = (Runnable)new Runnable() {
            final c b;
            
            public void run() {
                this.b.E(0);
            }
        };
        if (u == null) {
            throw new IllegalArgumentException("Parent view may not be null");
        }
        if (r != null) {
            this.u = u;
            this.r = r;
            final ViewConfiguration value = ViewConfiguration.get(context);
            this.o = (int)(context.getResources().getDisplayMetrics().density * 20.0f + 0.5f);
            this.b = value.getScaledTouchSlop();
            this.m = (float)value.getScaledMaximumFlingVelocity();
            this.n = (float)value.getScaledMinimumFlingVelocity();
            this.q = new OverScroller(context, a.i.b.c.w);
            return;
        }
        throw new IllegalArgumentException("Callback may not be null");
    }
    
    private void A() {
        this.l.computeCurrentVelocity(1000, this.m);
        this.n(this.e(this.l.getXVelocity(this.c), this.n, this.m), this.e(this.l.getYVelocity(this.c), this.n, this.m));
    }
    
    private void B(final float n, final float n2, final int n3) {
        boolean b = true;
        if (!this.c(n, n2, n3, 1)) {
            b = false;
        }
        int n4 = b ? 1 : 0;
        if (this.c(n2, n, n3, 4)) {
            n4 = ((b ? 1 : 0) | 0x4);
        }
        int n5 = n4;
        if (this.c(n, n2, n3, 2)) {
            n5 = (n4 | 0x2);
        }
        int n6 = n5;
        if (this.c(n2, n, n3, 8)) {
            n6 = (n5 | 0x8);
        }
        if (n6 != 0) {
            final int[] i = this.i;
            i[n3] |= n6;
            this.r.f(n6, n3);
        }
    }
    
    private void C(final float n, final float n2, final int n3) {
        this.q(n3);
        this.d[n3] = (this.f[n3] = n);
        this.e[n3] = (this.g[n3] = n2);
        this.h[n3] = this.t((int)n, (int)n2);
        this.k |= 1 << n3;
    }
    
    private void D(final MotionEvent motionEvent) {
        for (int pointerCount = motionEvent.getPointerCount(), i = 0; i < pointerCount; ++i) {
            final int pointerId = motionEvent.getPointerId(i);
            if (this.x(pointerId)) {
                final float x = motionEvent.getX(i);
                final float y = motionEvent.getY(i);
                this.f[pointerId] = x;
                this.g[pointerId] = y;
            }
        }
    }
    
    private boolean c(float abs, float abs2, final int n, final int n2) {
        abs = Math.abs(abs);
        abs2 = Math.abs(abs2);
        final int n3 = this.h[n];
        boolean b2;
        final boolean b = b2 = false;
        if ((n3 & n2) == n2) {
            b2 = b;
            if ((this.p & n2) != 0x0) {
                b2 = b;
                if ((this.j[n] & n2) != n2) {
                    b2 = b;
                    if ((this.i[n] & n2) != n2) {
                        final int b3 = this.b;
                        if (abs <= b3 && abs2 <= b3) {
                            b2 = b;
                        }
                        else {
                            if (abs < abs2 * 0.5f && this.r.g(n2)) {
                                final int[] j = this.j;
                                j[n] |= n2;
                                return false;
                            }
                            b2 = b;
                            if ((this.i[n] & n2) == 0x0) {
                                b2 = b;
                                if (abs > this.b) {
                                    b2 = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return b2;
    }
    
    private boolean d(final View view, final float n, final float n2) {
        final boolean b = false;
        final boolean b2 = false;
        boolean b3 = false;
        if (view == null) {
            return false;
        }
        final boolean b4 = this.r.d(view) > 0;
        final boolean b5 = this.r.e(view) > 0;
        if (b4 && b5) {
            final int b6 = this.b;
            if (n * n + n2 * n2 > b6 * b6) {
                b3 = true;
            }
            return b3;
        }
        if (b4) {
            boolean b7 = b;
            if (Math.abs(n) > this.b) {
                b7 = true;
            }
            return b7;
        }
        boolean b8 = b2;
        if (b5) {
            b8 = b2;
            if (Math.abs(n2) > this.b) {
                b8 = true;
            }
        }
        return b8;
    }
    
    private float e(final float n, final float n2, float n3) {
        final float abs = Math.abs(n);
        if (abs < n2) {
            return 0.0f;
        }
        if (abs > n3) {
            if (n <= 0.0f) {
                n3 = -n3;
            }
            return n3;
        }
        return n;
    }
    
    private int f(final int n, final int n2, int n3) {
        final int abs = Math.abs(n);
        if (abs < n2) {
            return 0;
        }
        if (abs > n3) {
            if (n <= 0) {
                n3 = -n3;
            }
            return n3;
        }
        return n;
    }
    
    private void g() {
        final float[] d = this.d;
        if (d == null) {
            return;
        }
        Arrays.fill(d, 0.0f);
        Arrays.fill(this.e, 0.0f);
        Arrays.fill(this.f, 0.0f);
        Arrays.fill(this.g, 0.0f);
        Arrays.fill(this.h, 0);
        Arrays.fill(this.i, 0);
        Arrays.fill(this.j, 0);
        this.k = 0;
    }
    
    private void h(final int n) {
        if (this.d != null) {
            if (this.w(n)) {
                this.d[n] = 0.0f;
                this.e[n] = 0.0f;
                this.f[n] = 0.0f;
                this.g[n] = 0.0f;
                this.h[n] = 0;
                this.i[n] = 0;
                this.j[n] = 0;
                this.k &= ~(1 << n);
            }
        }
    }
    
    private int i(int n, int abs, final int n2) {
        if (n == 0) {
            return 0;
        }
        final int width = this.u.getWidth();
        final int n3 = width / 2;
        final float min = Math.min(1.0f, Math.abs(n) / (float)width);
        final float n4 = (float)n3;
        final float o = this.o(min);
        abs = Math.abs(abs);
        if (abs > 0) {
            n = Math.round(Math.abs((n4 + o * n4) / abs) * 1000.0f) * 4;
        }
        else {
            n = (int)((Math.abs(n) / (float)n2 + 1.0f) * 256.0f);
        }
        return Math.min(n, 600);
    }
    
    private int j(final View view, int i, int j, int f, int abs) {
        final int f2 = this.f(f, (int)this.n, (int)this.m);
        f = this.f(abs, (int)this.n, (int)this.m);
        final int abs2 = Math.abs(i);
        final int abs3 = Math.abs(j);
        final int abs4 = Math.abs(f2);
        abs = Math.abs(f);
        final int n = abs4 + abs;
        final int n2 = abs2 + abs3;
        float n3;
        float n4;
        if (f2 != 0) {
            n3 = (float)abs4;
            n4 = (float)n;
        }
        else {
            n3 = (float)abs2;
            n4 = (float)n2;
        }
        final float n5 = n3 / n4;
        float n6;
        float n7;
        if (f != 0) {
            n6 = (float)abs;
            n7 = (float)n;
        }
        else {
            n6 = (float)abs3;
            n7 = (float)n2;
        }
        final float n8 = n6 / n7;
        i = this.i(i, f2, this.r.d(view));
        j = this.i(j, f, this.r.e(view));
        return (int)(i * n5 + j * n8);
    }
    
    public static c l(final ViewGroup viewGroup, final float n, final c c) {
        final c m = m(viewGroup, c);
        m.b *= (int)(1.0f / n);
        return m;
    }
    
    public static c m(final ViewGroup viewGroup, final c c) {
        return new c(viewGroup.getContext(), viewGroup, c);
    }
    
    private void n(final float n, final float n2) {
        this.t = true;
        this.r.l(this.s, n, n2);
        this.t = false;
        if (this.a == 1) {
            this.E(0);
        }
    }
    
    private float o(final float n) {
        return (float)Math.sin((double)((n - 0.5f) * 0.47123894f));
    }
    
    private void p(int b, final int n, final int n2, final int n3) {
        final int left = this.s.getLeft();
        final int top = this.s.getTop();
        int a = b;
        if (n2 != 0) {
            a = this.r.a(this.s, b, n2);
            a.g.l.t.V(this.s, a - left);
        }
        b = n;
        if (n3 != 0) {
            b = this.r.b(this.s, n, n3);
            a.g.l.t.W(this.s, b - top);
        }
        if (n2 != 0 || n3 != 0) {
            this.r.k(this.s, a, b, a - left, b - top);
        }
    }
    
    private void q(int n) {
        final float[] d = this.d;
        if (d == null || d.length <= n) {
            final float[] d2 = new float[++n];
            final float[] e = new float[n];
            final float[] f = new float[n];
            final float[] g = new float[n];
            final int[] h = new int[n];
            final int[] i = new int[n];
            final int[] j = new int[n];
            final float[] d3 = this.d;
            if (d3 != null) {
                System.arraycopy((Object)d3, 0, (Object)d2, 0, d3.length);
                final float[] e2 = this.e;
                System.arraycopy((Object)e2, 0, (Object)e, 0, e2.length);
                final float[] f2 = this.f;
                System.arraycopy((Object)f2, 0, (Object)f, 0, f2.length);
                final float[] g2 = this.g;
                System.arraycopy((Object)g2, 0, (Object)g, 0, g2.length);
                final int[] h2 = this.h;
                System.arraycopy((Object)h2, 0, (Object)h, 0, h2.length);
                final int[] k = this.i;
                System.arraycopy((Object)k, 0, (Object)i, 0, k.length);
                final int[] l = this.j;
                System.arraycopy((Object)l, 0, (Object)j, 0, l.length);
            }
            this.d = d2;
            this.e = e;
            this.f = f;
            this.g = g;
            this.h = h;
            this.i = i;
            this.j = j;
        }
    }
    
    private boolean s(int n, int n2, int j, final int n3) {
        final int left = this.s.getLeft();
        final int top = this.s.getTop();
        n -= left;
        n2 -= top;
        if (n == 0 && n2 == 0) {
            this.q.abortAnimation();
            this.E(0);
            return false;
        }
        j = this.j(this.s, n, n2, j, n3);
        this.q.startScroll(left, top, n, n2, j);
        this.E(2);
        return true;
    }
    
    private int t(int n, final int n2) {
        int n3;
        final boolean b = (n3 = ((n < this.u.getLeft() + this.o) ? 1 : 0)) != 0;
        if (n2 < this.u.getTop() + this.o) {
            n3 = ((b ? 1 : 0) | 0x4);
        }
        int n4 = n3;
        if (n > this.u.getRight() - this.o) {
            n4 = (n3 | 0x2);
        }
        n = n4;
        if (n2 > this.u.getBottom() - this.o) {
            n = (n4 | 0x8);
        }
        return n;
    }
    
    private boolean x(final int n) {
        if (!this.w(n)) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Ignoring pointerId=");
            sb.append(n);
            sb.append(" because ACTION_DOWN was not received ");
            sb.append("for this pointer before ACTION_MOVE. It likely happened because ");
            sb.append(" ViewDragHelper did not receive all the events in the event stream.");
            Log.e("ViewDragHelper", sb.toString());
            return false;
        }
        return true;
    }
    
    void E(final int a) {
        this.u.removeCallbacks(this.v);
        if (this.a != a) {
            this.a = a;
            this.r.j(a);
            if (this.a == 0) {
                this.s = null;
            }
        }
    }
    
    public boolean F(final int n, final int n2) {
        if (this.t) {
            return this.s(n, n2, (int)this.l.getXVelocity(this.c), (int)this.l.getYVelocity(this.c));
        }
        throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
    }
    
    public boolean G(final MotionEvent motionEvent) {
        final int actionMasked = motionEvent.getActionMasked();
        final int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            this.a();
        }
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(motionEvent);
        Label_0615: {
            if (actionMasked != 0) {
                Label_0513: {
                    if (actionMasked == 1) {
                        break Label_0513;
                    }
                    if (actionMasked != 2) {
                        if (actionMasked == 3) {
                            break Label_0513;
                        }
                        if (actionMasked != 5) {
                            if (actionMasked == 6) {
                                this.h(motionEvent.getPointerId(actionIndex));
                            }
                        }
                        else {
                            final int pointerId = motionEvent.getPointerId(actionIndex);
                            final float x = motionEvent.getX(actionIndex);
                            final float y = motionEvent.getY(actionIndex);
                            this.C(x, y, pointerId);
                            final int a = this.a;
                            if (a == 0) {
                                final int n = this.h[pointerId];
                                final int p = this.p;
                                if ((n & p) != 0x0) {
                                    this.r.h(n & p, pointerId);
                                }
                            }
                            else if (a == 2) {
                                final View r = this.r((int)x, (int)y);
                                if (r == this.s) {
                                    this.I(r, pointerId);
                                }
                            }
                        }
                    }
                    else if (this.d != null) {
                        if (this.e != null) {
                            for (int pointerCount = motionEvent.getPointerCount(), i = 0; i < pointerCount; ++i) {
                                final int pointerId2 = motionEvent.getPointerId(i);
                                if (this.x(pointerId2)) {
                                    final float x2 = motionEvent.getX(i);
                                    final float y2 = motionEvent.getY(i);
                                    final float n2 = x2 - this.d[pointerId2];
                                    final float n3 = y2 - this.e[pointerId2];
                                    final View r2 = this.r((int)x2, (int)y2);
                                    final boolean b = r2 != null && this.d(r2, n2, n3);
                                    if (b) {
                                        final int left = r2.getLeft();
                                        final int n4 = (int)n2;
                                        final int a2 = this.r.a(r2, left + n4, n4);
                                        final int top = r2.getTop();
                                        final int n5 = (int)n3;
                                        final int b2 = this.r.b(r2, top + n5, n5);
                                        final int d = this.r.d(r2);
                                        final int e = this.r.e(r2);
                                        if (d == 0 || (d > 0 && a2 == left)) {
                                            if (e == 0) {
                                                break;
                                            }
                                            if (e > 0 && b2 == top) {
                                                break;
                                            }
                                        }
                                    }
                                    this.B(n2, n3, pointerId2);
                                    if (this.a == 1) {
                                        break;
                                    }
                                    if (b && this.I(r2, pointerId2)) {
                                        break;
                                    }
                                }
                            }
                            this.D(motionEvent);
                        }
                    }
                    break Label_0615;
                }
                this.a();
            }
            else {
                final float x3 = motionEvent.getX();
                final float y3 = motionEvent.getY();
                final int pointerId3 = motionEvent.getPointerId(0);
                this.C(x3, y3, pointerId3);
                final View r3 = this.r((int)x3, (int)y3);
                if (r3 == this.s && this.a == 2) {
                    this.I(r3, pointerId3);
                }
                final int n6 = this.h[pointerId3];
                final int p2 = this.p;
                if ((n6 & p2) != 0x0) {
                    this.r.h(n6 & p2, pointerId3);
                }
            }
        }
        boolean b3 = false;
        if (this.a == 1) {
            b3 = true;
        }
        return b3;
    }
    
    public boolean H(final View s, final int n, final int n2) {
        this.s = s;
        this.c = -1;
        final boolean s2 = this.s(n, n2, 0, 0);
        if (!s2 && this.a == 0 && this.s != null) {
            this.s = null;
        }
        return s2;
    }
    
    boolean I(final View view, final int c) {
        if (view == this.s && this.c == c) {
            return true;
        }
        if (view != null && this.r.m(view, c)) {
            this.b(view, this.c = c);
            return true;
        }
        return false;
    }
    
    public void a() {
        this.c = -1;
        this.g();
        final VelocityTracker l = this.l;
        if (l != null) {
            l.recycle();
            this.l = null;
        }
    }
    
    public void b(final View s, final int c) {
        if (s.getParent() == this.u) {
            this.s = s;
            this.c = c;
            this.r.i(s, c);
            this.E(1);
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (");
        sb.append((Object)this.u);
        sb.append(")");
        throw new IllegalArgumentException(sb.toString());
    }
    
    public boolean k(final boolean b) {
        final int a = this.a;
        final boolean b2 = false;
        if (a == 2) {
            final boolean computeScrollOffset = this.q.computeScrollOffset();
            final int currX = this.q.getCurrX();
            final int currY = this.q.getCurrY();
            final int n = currX - this.s.getLeft();
            final int n2 = currY - this.s.getTop();
            if (n != 0) {
                a.g.l.t.V(this.s, n);
            }
            if (n2 != 0) {
                a.g.l.t.W(this.s, n2);
            }
            if (n != 0 || n2 != 0) {
                this.r.k(this.s, currX, currY, n, n2);
            }
            boolean b3 = computeScrollOffset;
            if (computeScrollOffset) {
                b3 = computeScrollOffset;
                if (currX == this.q.getFinalX()) {
                    b3 = computeScrollOffset;
                    if (currY == this.q.getFinalY()) {
                        this.q.abortAnimation();
                        b3 = false;
                    }
                }
            }
            if (!b3) {
                if (b) {
                    this.u.post(this.v);
                }
                else {
                    this.E(0);
                }
            }
        }
        boolean b4 = b2;
        if (this.a == 2) {
            b4 = true;
        }
        return b4;
    }
    
    public View r(final int n, final int n2) {
        for (int i = this.u.getChildCount() - 1; i >= 0; --i) {
            final ViewGroup u = this.u;
            this.r.c(i);
            final View child = u.getChildAt(i);
            if (n >= child.getLeft() && n < child.getRight() && n2 >= child.getTop() && n2 < child.getBottom()) {
                return child;
            }
        }
        return null;
    }
    
    public int u() {
        return this.b;
    }
    
    public boolean v(final int n, final int n2) {
        return this.y(this.s, n, n2);
    }
    
    public boolean w(final int n) {
        final int k = this.k;
        boolean b = true;
        if ((1 << n & k) == 0x0) {
            b = false;
        }
        return b;
    }
    
    public boolean y(final View view, final int n, final int n2) {
        final boolean b = false;
        if (view == null) {
            return false;
        }
        boolean b2 = b;
        if (n >= view.getLeft()) {
            b2 = b;
            if (n < view.getRight()) {
                b2 = b;
                if (n2 >= view.getTop()) {
                    b2 = b;
                    if (n2 < view.getBottom()) {
                        b2 = true;
                    }
                }
            }
        }
        return b2;
    }
    
    public void z(final MotionEvent motionEvent) {
        final int actionMasked = motionEvent.getActionMasked();
        final int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            this.a();
        }
        if (this.l == null) {
            this.l = VelocityTracker.obtain();
        }
        this.l.addMovement(motionEvent);
        final int n = 0;
        int i = 0;
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked == 2) {
                    if (this.a == 1) {
                        if (!this.x(this.c)) {
                            return;
                        }
                        final int pointerIndex = motionEvent.findPointerIndex(this.c);
                        final float x = motionEvent.getX(pointerIndex);
                        final float y = motionEvent.getY(pointerIndex);
                        final float[] f = this.f;
                        final int c = this.c;
                        final int n2 = (int)(x - f[c]);
                        final int n3 = (int)(y - this.g[c]);
                        this.p(this.s.getLeft() + n2, this.s.getTop() + n3, n2, n3);
                    }
                    else {
                        for (int pointerCount = motionEvent.getPointerCount(), j = n; j < pointerCount; ++j) {
                            final int pointerId = motionEvent.getPointerId(j);
                            if (this.x(pointerId)) {
                                final float x2 = motionEvent.getX(j);
                                final float y2 = motionEvent.getY(j);
                                final float n4 = x2 - this.d[pointerId];
                                final float n5 = y2 - this.e[pointerId];
                                this.B(n4, n5, pointerId);
                                if (this.a == 1) {
                                    break;
                                }
                                final View r = this.r((int)x2, (int)y2);
                                if (this.d(r, n4, n5) && this.I(r, pointerId)) {
                                    break;
                                }
                            }
                        }
                    }
                    this.D(motionEvent);
                    return;
                }
                if (actionMasked != 3) {
                    if (actionMasked != 5) {
                        if (actionMasked != 6) {
                            return;
                        }
                        final int pointerId2 = motionEvent.getPointerId(actionIndex);
                        Label_0222: {
                            if (this.a == 1 && pointerId2 == this.c) {
                                while (true) {
                                    while (i < motionEvent.getPointerCount()) {
                                        final int pointerId3 = motionEvent.getPointerId(i);
                                        if (pointerId3 != this.c) {
                                            final View r2 = this.r((int)motionEvent.getX(i), (int)motionEvent.getY(i));
                                            final View s = this.s;
                                            if (r2 == s && this.I(s, pointerId3)) {
                                                final int c2 = this.c;
                                                if (c2 == -1) {
                                                    this.A();
                                                }
                                                break Label_0222;
                                            }
                                        }
                                        ++i;
                                    }
                                    final int c2 = -1;
                                    continue;
                                }
                            }
                        }
                        this.h(pointerId2);
                        return;
                    }
                    else {
                        final int pointerId4 = motionEvent.getPointerId(actionIndex);
                        final float x3 = motionEvent.getX(actionIndex);
                        final float y3 = motionEvent.getY(actionIndex);
                        this.C(x3, y3, pointerId4);
                        if (this.a == 0) {
                            this.I(this.r((int)x3, (int)y3), pointerId4);
                            final int n6 = this.h[pointerId4];
                            final int p = this.p;
                            if ((n6 & p) != 0x0) {
                                this.r.h(n6 & p, pointerId4);
                            }
                            return;
                        }
                        else {
                            if (this.v((int)x3, (int)y3)) {
                                this.I(this.s, pointerId4);
                            }
                            return;
                        }
                    }
                }
                else if (this.a == 1) {
                    this.n(0.0f, 0.0f);
                }
            }
            else if (this.a == 1) {
                this.A();
            }
            this.a();
        }
        else {
            final float x4 = motionEvent.getX();
            final float y4 = motionEvent.getY();
            final int pointerId5 = motionEvent.getPointerId(0);
            final View r3 = this.r((int)x4, (int)y4);
            this.C(x4, y4, pointerId5);
            this.I(r3, pointerId5);
            final int n7 = this.h[pointerId5];
            final int p2 = this.p;
            if ((n7 & p2) != 0x0) {
                this.r.h(n7 & p2, pointerId5);
            }
        }
    }
    
    public abstract static class c
    {
        public abstract int a(final View p0, final int p1, final int p2);
        
        public abstract int b(final View p0, final int p1, final int p2);
        
        public int c(final int n) {
            return n;
        }
        
        public int d(final View view) {
            return 0;
        }
        
        public int e(final View view) {
            return 0;
        }
        
        public void f(final int n, final int n2) {
        }
        
        public boolean g(final int n) {
            return false;
        }
        
        public void h(final int n, final int n2) {
        }
        
        public void i(final View view, final int n) {
        }
        
        public abstract void j(final int p0);
        
        public abstract void k(final View p0, final int p1, final int p2, final int p3, final int p4);
        
        public abstract void l(final View p0, final float p1, final float p2);
        
        public abstract boolean m(final View p0, final int p1);
    }
}
