package a.i.b;

import java.util.Comparator;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import android.graphics.Rect;

class b
{
    private static boolean a(final int n, final Rect rect, final Rect rect2, final Rect rect3) {
        final boolean b = b(n, rect, rect2);
        final boolean b2 = b(n, rect, rect3);
        boolean b3 = false;
        if (b2 || !b) {
            return false;
        }
        if (!j(n, rect, rect3)) {
            return true;
        }
        if (n != 17 && n != 66) {
            if (k(n, rect, rect2) < m(n, rect, rect3)) {
                b3 = true;
            }
            return b3;
        }
        return true;
    }
    
    private static boolean b(final int n, final Rect rect, final Rect rect2) {
        boolean b = true;
        final boolean b2 = true;
        Label_0075: {
            if (n != 17) {
                if (n != 33) {
                    if (n == 66) {
                        break Label_0075;
                    }
                    if (n != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                }
                return rect2.right >= rect.left && rect2.left <= rect.right && b2;
            }
        }
        if (rect2.bottom < rect.top || rect2.top > rect.bottom) {
            b = false;
        }
        return b;
    }
    
    public static <L, T> T c(final L l, final b<L, T> b, final a<T> a, final T t, final Rect rect, final int n) {
        final Rect rect2 = new Rect(rect);
        final int n2 = 0;
        Label_0116: {
            int n3 = 0;
            Label_0108: {
                if (n != 17) {
                    int n4;
                    if (n != 33) {
                        if (n == 66) {
                            n3 = -(rect.width() + 1);
                            break Label_0108;
                        }
                        if (n != 130) {
                            throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                        }
                        n4 = -(rect.height() + 1);
                    }
                    else {
                        n4 = rect.height() + 1;
                    }
                    rect2.offset(0, n4);
                    break Label_0116;
                }
                n3 = rect.width() + 1;
            }
            rect2.offset(n3, 0);
        }
        T t2 = null;
        final int a2 = b.a(l);
        final Rect rect3 = new Rect();
        for (int i = n2; i < a2; ++i) {
            final T b2 = b.b(l, i);
            if (b2 != t) {
                a.a(b2, rect3);
                if (h(n, rect, rect3, rect2)) {
                    rect2.set(rect3);
                    t2 = b2;
                }
            }
        }
        return t2;
    }
    
    public static <L, T> T d(final L l, final b<L, T> b, final a<T> a, final T t, final int n, final boolean b2, final boolean b3) {
        final int a2 = b.a(l);
        final ArrayList list = new ArrayList(a2);
        for (int i = 0; i < a2; ++i) {
            list.add((Object)b.b(l, i));
        }
        Collections.sort((List)list, (Comparator)new c(b2, (a<Object>)a));
        if (n == 1) {
            return f(t, (java.util.ArrayList<T>)list, b3);
        }
        if (n == 2) {
            return e(t, (java.util.ArrayList<T>)list, b3);
        }
        throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD}.");
    }
    
    private static <T> T e(final T t, final ArrayList<T> list, final boolean b) {
        final int size = list.size();
        int lastIndex;
        if (t == null) {
            lastIndex = -1;
        }
        else {
            lastIndex = list.lastIndexOf((Object)t);
        }
        if (++lastIndex < size) {
            return (T)list.get(lastIndex);
        }
        if (b && size > 0) {
            return (T)list.get(0);
        }
        return null;
    }
    
    private static <T> T f(final T t, final ArrayList<T> list, final boolean b) {
        final int size = list.size();
        int index;
        if (t == null) {
            index = size;
        }
        else {
            index = list.indexOf((Object)t);
        }
        if (--index >= 0) {
            return (T)list.get(index);
        }
        if (b && size > 0) {
            return (T)list.get(size - 1);
        }
        return null;
    }
    
    private static int g(final int n, final int n2) {
        return n * 13 * n + n2 * n2;
    }
    
    private static boolean h(final int n, final Rect rect, final Rect rect2, final Rect rect3) {
        final boolean i = i(rect, rect2, n);
        boolean b = false;
        if (!i) {
            return false;
        }
        if (!i(rect, rect3, n)) {
            return true;
        }
        if (a(n, rect, rect2, rect3)) {
            return true;
        }
        if (a(n, rect, rect3, rect2)) {
            return false;
        }
        if (g(k(n, rect, rect2), o(n, rect, rect2)) < g(k(n, rect, rect3), o(n, rect, rect3))) {
            b = true;
        }
        return b;
    }
    
    private static boolean i(final Rect rect, final Rect rect2, int n) {
        final boolean b = true;
        final boolean b2 = true;
        boolean b3 = true;
        final boolean b4 = true;
        if (n == 17) {
            final int right = rect.right;
            n = rect2.right;
            if ((right <= n && rect.left < n) || rect.left <= rect2.left) {
                b3 = false;
            }
            return b3;
        }
        if (n == 33) {
            n = rect.bottom;
            final int bottom = rect2.bottom;
            return (n > bottom || rect.top >= bottom) && rect.top > rect2.top && b2;
        }
        if (n == 66) {
            n = rect.left;
            final int left = rect2.left;
            return (n < left || rect.right <= left) && rect.right < rect2.right && b;
        }
        if (n == 130) {
            final int top = rect.top;
            n = rect2.top;
            return (top < n || rect.bottom <= n) && rect.bottom < rect2.bottom && b4;
        }
        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
    }
    
    private static boolean j(final int n, final Rect rect, final Rect rect2) {
        final boolean b = true;
        final boolean b2 = true;
        final boolean b3 = true;
        boolean b4 = true;
        if (n == 17) {
            return rect.left >= rect2.right && b3;
        }
        if (n == 33) {
            return rect.top >= rect2.bottom && b2;
        }
        if (n == 66) {
            return rect.right <= rect2.left && b;
        }
        if (n == 130) {
            if (rect.bottom > rect2.top) {
                b4 = false;
            }
            return b4;
        }
        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
    }
    
    private static int k(final int n, final Rect rect, final Rect rect2) {
        return Math.max(0, l(n, rect, rect2));
    }
    
    private static int l(int n, final Rect rect, final Rect rect2) {
        int n2;
        if (n != 17) {
            if (n != 33) {
                if (n != 66) {
                    if (n != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                    n = rect2.top;
                    n2 = rect.bottom;
                }
                else {
                    n = rect2.left;
                    n2 = rect.right;
                }
            }
            else {
                n = rect.top;
                n2 = rect2.bottom;
            }
        }
        else {
            n = rect.left;
            n2 = rect2.right;
        }
        return n - n2;
    }
    
    private static int m(final int n, final Rect rect, final Rect rect2) {
        return Math.max(1, n(n, rect, rect2));
    }
    
    private static int n(int n, final Rect rect, final Rect rect2) {
        int n2;
        if (n != 17) {
            if (n != 33) {
                if (n != 66) {
                    if (n != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                    n = rect2.bottom;
                    n2 = rect.bottom;
                }
                else {
                    n = rect2.right;
                    n2 = rect.right;
                }
            }
            else {
                n = rect.top;
                n2 = rect2.top;
            }
        }
        else {
            n = rect.left;
            n2 = rect2.left;
        }
        return n - n2;
    }
    
    private static int o(int n, final Rect rect, final Rect rect2) {
        Label_0073: {
            if (n == 17) {
                break Label_0073;
            }
            if (n != 33) {
                if (n == 66) {
                    break Label_0073;
                }
                if (n != 130) {
                    throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                }
            }
            final int n2 = rect.left + rect.width() / 2;
            n = rect2.left;
            final int n3 = rect2.width();
            return Math.abs(n2 - (n + n3 / 2));
        }
        final int n2 = rect.top + rect.height() / 2;
        n = rect2.top;
        final int n3 = rect2.height();
        return Math.abs(n2 - (n + n3 / 2));
    }
    
    public interface a<T>
    {
        void a(final T p0, final Rect p1);
    }
    
    public interface b<T, V>
    {
        int a(final T p0);
        
        V b(final T p0, final int p1);
    }
    
    private static class c<T> implements Comparator<T>
    {
        private final Rect b;
        private final Rect c;
        private final boolean d;
        private final a<T> e;
        
        c(final boolean d, final a<T> e) {
            this.b = new Rect();
            this.c = new Rect();
            this.d = d;
            this.e = e;
        }
        
        public int compare(final T t, final T t2) {
            final Rect b = this.b;
            final Rect c = this.c;
            this.e.a(t, b);
            this.e.a(t2, c);
            final int top = b.top;
            final int top2 = c.top;
            int n = -1;
            if (top < top2) {
                return -1;
            }
            if (top > top2) {
                return 1;
            }
            final int left = b.left;
            final int left2 = c.left;
            if (left < left2) {
                if (this.d) {
                    n = 1;
                }
                return n;
            }
            if (left > left2) {
                if (!this.d) {
                    n = 1;
                }
                return n;
            }
            final int bottom = b.bottom;
            final int bottom2 = c.bottom;
            if (bottom < bottom2) {
                return -1;
            }
            if (bottom > bottom2) {
                return 1;
            }
            final int right = b.right;
            final int right2 = c.right;
            if (right < right2) {
                if (this.d) {
                    n = 1;
                }
                return n;
            }
            if (right > right2) {
                if (!this.d) {
                    n = 1;
                }
                return n;
            }
            return 0;
        }
    }
}
