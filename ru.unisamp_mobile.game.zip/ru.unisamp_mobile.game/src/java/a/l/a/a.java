package a.l.a;

import java.io.PrintWriter;
import java.io.FileDescriptor;
import androidx.lifecycle.s;
import androidx.lifecycle.g;

public abstract class a
{
    public static <T extends g & s> a b(final T t) {
        return (a)new b((g)t, t.getViewModelStore());
    }
    
    @Deprecated
    public abstract void a(final String p0, final FileDescriptor p1, final PrintWriter p2, final String[] p3);
    
    public abstract void c();
}
