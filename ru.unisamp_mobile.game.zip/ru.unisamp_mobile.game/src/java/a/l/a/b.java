package a.l.a;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.q;
import a.d.h;
import androidx.lifecycle.q$a;
import androidx.lifecycle.p;
import androidx.lifecycle.m;
import android.util.Log;
import android.os.Bundle;
import androidx.lifecycle.l;
import java.io.PrintWriter;
import java.io.FileDescriptor;
import androidx.lifecycle.r;
import androidx.lifecycle.g;

class b extends a.l.a.a
{
    static boolean c;
    private final g a;
    private final c b;
    
    b(final g a, final r r) {
        this.a = a;
        this.b = a.l.a.b.c.e(r);
    }
    
    @Deprecated
    public void a(final String s, final FileDescriptor fileDescriptor, final PrintWriter printWriter, final String[] array) {
        this.b.d(s, fileDescriptor, printWriter, array);
    }
    
    public void c() {
        this.b.f();
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode((Object)this)));
        sb.append(" in ");
        a.g.k.a.a((Object)this.a, sb);
        sb.append("}}");
        return sb.toString();
    }
    
    public static class a<D> extends l<D> implements Object<D>
    {
        private final int j;
        private final Bundle k;
        private final a.l.b.a<D> l;
        private g m;
        private b<D> n;
        private a.l.b.a<D> o;
        
        protected void e() {
            if (a.l.a.b.c) {
                final StringBuilder sb = new StringBuilder();
                sb.append("  Starting: ");
                sb.append((Object)this);
                Log.v("LoaderManager", sb.toString());
            }
            this.l.d();
            throw null;
        }
        
        protected void f() {
            if (a.l.a.b.c) {
                final StringBuilder sb = new StringBuilder();
                sb.append("  Stopping: ");
                sb.append((Object)this);
                Log.v("LoaderManager", sb.toString());
            }
            this.l.e();
            throw null;
        }
        
        public void g(final m<? super D> m) {
            super.g((m)m);
            this.m = null;
            this.n = null;
        }
        
        public void h(final D n) {
            super.h((Object)n);
            final a.l.b.a<D> o = this.o;
            if (o == null) {
                return;
            }
            o.c();
            throw null;
        }
        
        a.l.b.a<D> i(final boolean b) {
            if (b.c) {
                final StringBuilder sb = new StringBuilder();
                sb.append("  Destroying: ");
                sb.append((Object)this);
                Log.v("LoaderManager", sb.toString());
            }
            this.l.a();
            throw null;
        }
        
        public void j(final String s, final FileDescriptor fileDescriptor, final PrintWriter printWriter, final String[] array) {
            printWriter.print(s);
            printWriter.print("mId=");
            printWriter.print(this.j);
            printWriter.print(" mArgs=");
            printWriter.println((Object)this.k);
            printWriter.print(s);
            printWriter.print("mLoader=");
            printWriter.println((Object)this.l);
            final a.l.b.a<D> l = this.l;
            final StringBuilder sb = new StringBuilder();
            sb.append(s);
            sb.append("  ");
            l.b(sb.toString(), fileDescriptor, printWriter, array);
            throw null;
        }
        
        void k() {
            final g m = this.m;
            final b<D> n = this.n;
            if (m != null && n != null) {
                super.g((m)n);
                ((LiveData)this).d(m, (m)n);
            }
        }
        
        public String toString() {
            final StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode((Object)this)));
            sb.append(" #");
            sb.append(this.j);
            sb.append(" : ");
            a.g.k.a.a((Object)this.l, sb);
            sb.append("}}");
            return sb.toString();
        }
    }
    
    static class b<D> implements m<D>
    {
    }
    
    static class c extends p
    {
        private static final q$a c;
        private h<a> b;
        
        static {
            c = (q$a)new q$a() {
                public <T extends p> T a(final Class<T> clazz) {
                    return (T)new c();
                }
            };
        }
        
        c() {
            this.b = (h<a>)new h();
        }
        
        static c e(final r r) {
            return (c)new q(r, a.l.a.b.c.c).a((Class)c.class);
        }
        
        protected void c() {
            super.c();
            if (this.b.t() <= 0) {
                this.b.b();
                return;
            }
            ((a)this.b.v(0)).i(true);
            throw null;
        }
        
        public void d(final String s, final FileDescriptor fileDescriptor, final PrintWriter printWriter, final String[] array) {
            if (this.b.t() > 0) {
                printWriter.print(s);
                printWriter.println("Loaders:");
                final StringBuilder sb = new StringBuilder();
                sb.append(s);
                sb.append("    ");
                final String string = sb.toString();
                if (this.b.t() > 0) {
                    final a a = (a)this.b.v(0);
                    printWriter.print(s);
                    printWriter.print("  #");
                    printWriter.print(this.b.l(0));
                    printWriter.print(": ");
                    printWriter.println(a.toString());
                    a.j(string, fileDescriptor, printWriter, array);
                    throw null;
                }
            }
        }
        
        void f() {
            for (int t = this.b.t(), i = 0; i < t; ++i) {
                ((a)this.b.v(i)).k();
            }
        }
    }
}
