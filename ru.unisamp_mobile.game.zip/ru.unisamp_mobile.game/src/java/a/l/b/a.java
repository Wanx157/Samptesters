package a.l.b;

import java.io.PrintWriter;
import java.io.FileDescriptor;

public class a<D>
{
    public boolean a() {
        throw null;
    }
    
    @Deprecated
    public void b(final String s, final FileDescriptor fileDescriptor, final PrintWriter printWriter, final String[] array) {
        throw null;
    }
    
    public void c() {
        throw null;
    }
    
    public final void d() {
        throw null;
    }
    
    public void e() {
        throw null;
    }
}
