package a.e.b;

import java.util.Arrays;

public class j implements b$a
{
    private static float m = 0.001f;
    private int a;
    private int b;
    int[] c;
    int[] d;
    int[] e;
    float[] f;
    int[] g;
    int[] h;
    int i;
    int j;
    private final b k;
    protected final c l;
    
    j(final b k, final c l) {
        this.a = 16;
        this.b = 16;
        this.c = new int[16];
        this.d = new int[16];
        this.e = new int[16];
        this.f = new float[16];
        this.g = new int[16];
        this.h = new int[16];
        this.i = 0;
        this.j = -1;
        this.k = k;
        this.l = l;
        this.clear();
    }
    
    private void l(final i i, final int n) {
        final int n2 = i.c % this.b;
        final int[] c = this.c;
        int n3;
        if ((n3 = c[n2]) == -1) {
            c[n2] = n;
        }
        else {
            int[] d;
            while (true) {
                d = this.d;
                if (d[n3] == -1) {
                    break;
                }
                n3 = d[n3];
            }
            d[n3] = n;
        }
        this.d[n] = -1;
    }
    
    private void m(final int n, final i i, final float n2) {
        this.e[n] = i.c;
        this.f[n] = n2;
        this.g[n] = -1;
        this.h[n] = -1;
        i.a(this.k);
        ++i.m;
        ++this.i;
    }
    
    private int n() {
        for (int i = 0; i < this.a; ++i) {
            if (this.e[i] == -1) {
                return i;
            }
        }
        return -1;
    }
    
    private void o() {
        final int a = this.a * 2;
        this.e = Arrays.copyOf(this.e, a);
        this.f = Arrays.copyOf(this.f, a);
        this.g = Arrays.copyOf(this.g, a);
        this.h = Arrays.copyOf(this.h, a);
        this.d = Arrays.copyOf(this.d, a);
        for (int i = this.a; i < a; ++i) {
            this.e[i] = -1;
            this.d[i] = -1;
        }
        this.a = a;
    }
    
    private void q(final int n, final i i, final float n2) {
        final int n3 = this.n();
        this.m(n3, i, n2);
        if (n != -1) {
            this.g[n3] = n;
            final int[] h = this.h;
            h[n3] = h[n];
            h[n] = n3;
        }
        else {
            this.g[n3] = -1;
            if (this.i > 0) {
                this.h[n3] = this.j;
                this.j = n3;
            }
            else {
                this.h[n3] = -1;
            }
        }
        final int[] h2 = this.h;
        if (h2[n3] != -1) {
            this.g[h2[n3]] = n3;
        }
        this.l(i, n3);
    }
    
    private void r(final i i) {
        final int c = i.c;
        final int n = c % this.b;
        final int[] c2 = this.c;
        final int n2 = c2[n];
        if (n2 == -1) {
            return;
        }
        int n3 = n2;
        if (this.e[n2] == c) {
            final int[] d = this.d;
            c2[n] = d[n2];
            d[n2] = -1;
        }
        else {
            while (true) {
                final int[] d2 = this.d;
                if (d2[n3] == -1 || this.e[d2[n3]] == c) {
                    break;
                }
                n3 = d2[n3];
            }
            final int[] d3 = this.d;
            final int n4 = d3[n3];
            if (n4 != -1 && this.e[n4] == c) {
                d3[n3] = d3[n4];
                d3[n4] = -1;
            }
        }
    }
    
    public float a(final int n) {
        final int i = this.i;
        int j = this.j;
        for (int k = 0; k < i; ++k) {
            if (k == n) {
                return this.f[j];
            }
            j = this.h[j];
            if (j == -1) {
                break;
            }
        }
        return 0.0f;
    }
    
    public float b(final b b, final boolean b2) {
        final float g = this.g(b.a);
        this.d(b.a, b2);
        final j j = (j)b.e;
        final int k = j.k();
        final int i = j.j;
        int l = 0;
        int n = 0;
        while (l < k) {
            final int[] e = j.e;
            int n2 = l;
            if (e[n] != -1) {
                this.e(this.l.d[e[n]], j.f[n] * g, b2);
                n2 = l + 1;
            }
            ++n;
            l = n2;
        }
        return g;
    }
    
    public void c(final i i, final float n) {
        final float m = a.e.b.j.m;
        if (n > -m && n < m) {
            this.d(i, true);
            return;
        }
        final int j = this.i;
        int n2 = 0;
        if (j == 0) {
            this.m(0, i, n);
            this.l(i, 0);
            this.j = 0;
        }
        else {
            final int p2 = this.p(i);
            if (p2 != -1) {
                this.f[p2] = n;
            }
            else {
                if (this.i + 1 >= this.a) {
                    this.o();
                }
                final int k = this.i;
                int l = this.j;
                int n3 = -1;
                int n4;
                while (true) {
                    n4 = n3;
                    if (n2 >= k) {
                        break;
                    }
                    final int[] e = this.e;
                    final int n5 = e[l];
                    final int c = i.c;
                    if (n5 == c) {
                        this.f[l] = n;
                        return;
                    }
                    if (e[l] < c) {
                        n3 = l;
                    }
                    l = this.h[l];
                    if (l == -1) {
                        n4 = n3;
                        break;
                    }
                    ++n2;
                }
                this.q(n4, i, n);
            }
        }
    }
    
    public void clear() {
        for (int i = this.i, j = 0; j < i; ++j) {
            final i f = this.f(j);
            if (f != null) {
                f.c(this.k);
            }
        }
        for (int k = 0; k < this.a; ++k) {
            this.e[k] = -1;
            this.d[k] = -1;
        }
        for (int l = 0; l < this.b; ++l) {
            this.c[l] = -1;
        }
        this.i = 0;
        this.j = -1;
    }
    
    public float d(final i i, final boolean b) {
        final int p2 = this.p(i);
        if (p2 == -1) {
            return 0.0f;
        }
        this.r(i);
        final float n = this.f[p2];
        if (this.j == p2) {
            this.j = this.h[p2];
        }
        this.e[p2] = -1;
        final int[] g = this.g;
        if (g[p2] != -1) {
            final int[] h = this.h;
            h[g[p2]] = h[p2];
        }
        final int[] h2 = this.h;
        if (h2[p2] != -1) {
            final int[] g2 = this.g;
            g2[h2[p2]] = g2[p2];
        }
        --this.i;
        --i.m;
        if (b) {
            i.c(this.k);
        }
        return n;
    }
    
    public void e(final i i, float n, final boolean b) {
        final float m = a.e.b.j.m;
        if (n > -m && n < m) {
            return;
        }
        final int p3 = this.p(i);
        if (p3 == -1) {
            this.c(i, n);
        }
        else {
            final float[] f = this.f;
            f[p3] += n;
            n = f[p3];
            final float j = a.e.b.j.m;
            if (n > -j && f[p3] < j) {
                f[p3] = 0.0f;
                this.d(i, b);
            }
        }
    }
    
    public i f(final int n) {
        final int i = this.i;
        if (i == 0) {
            return null;
        }
        int j = this.j;
        for (int k = 0; k < i; ++k) {
            if (k == n && j != -1) {
                return this.l.d[this.e[j]];
            }
            j = this.h[j];
            if (j == -1) {
                break;
            }
        }
        return null;
    }
    
    public float g(final i i) {
        final int p = this.p(i);
        if (p != -1) {
            return this.f[p];
        }
        return 0.0f;
    }
    
    public boolean h(final i i) {
        return this.p(i) != -1;
    }
    
    public void i(final float n) {
        final int i = this.i;
        int j = this.j;
        for (int k = 0; k < i; ++k) {
            final float[] f = this.f;
            f[j] /= n;
            j = this.h[j];
            if (j == -1) {
                break;
            }
        }
    }
    
    public void j() {
        final int i = this.i;
        int j = this.j;
        for (int k = 0; k < i; ++k) {
            final float[] f = this.f;
            f[j] *= -1.0f;
            j = this.h[j];
            if (j == -1) {
                break;
            }
        }
    }
    
    public int k() {
        return this.i;
    }
    
    public int p(final i i) {
        if (this.i != 0) {
            if (i != null) {
                final int c = i.c;
                final int n = this.c[c % this.b];
                if (n == -1) {
                    return -1;
                }
                int n2 = n;
                if (this.e[n] == c) {
                    return n;
                }
                while (true) {
                    final int[] d = this.d;
                    if (d[n2] == -1 || this.e[d[n2]] == c) {
                        break;
                    }
                    n2 = d[n2];
                }
                final int[] d2 = this.d;
                if (d2[n2] == -1) {
                    return -1;
                }
                if (this.e[d2[n2]] == c) {
                    return d2[n2];
                }
            }
        }
        return -1;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.hashCode());
        sb.append(" { ");
        String s = sb.toString();
        for (int i = this.i, j = 0; j < i; ++j) {
            final i f = this.f(j);
            if (f != null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(s);
                sb2.append((Object)f);
                sb2.append(" = ");
                sb2.append(this.a(j));
                sb2.append(" ");
                final String string = sb2.toString();
                final int p = this.p(f);
                final StringBuilder sb3 = new StringBuilder();
                sb3.append(string);
                sb3.append("[p: ");
                final String string2 = sb3.toString();
                StringBuilder sb4;
                if (this.g[p] != -1) {
                    sb4 = new StringBuilder();
                    sb4.append(string2);
                    sb4.append((Object)this.l.d[this.e[this.g[p]]]);
                }
                else {
                    sb4 = new StringBuilder();
                    sb4.append(string2);
                    sb4.append("none");
                }
                final String string3 = sb4.toString();
                final StringBuilder sb5 = new StringBuilder();
                sb5.append(string3);
                sb5.append(", n: ");
                final String string4 = sb5.toString();
                String s2;
                if (this.h[p] != -1) {
                    final StringBuilder sb6 = new StringBuilder();
                    sb6.append(string4);
                    sb6.append((Object)this.l.d[this.e[this.h[p]]]);
                    s2 = sb6.toString();
                }
                else {
                    final StringBuilder sb7 = new StringBuilder();
                    sb7.append(string4);
                    sb7.append("none");
                    s2 = sb7.toString();
                }
                final StringBuilder sb8 = new StringBuilder();
                sb8.append(s2);
                sb8.append("]");
                s = sb8.toString();
            }
        }
        final StringBuilder sb9 = new StringBuilder();
        sb9.append(s);
        sb9.append(" }");
        return sb9.toString();
    }
}
