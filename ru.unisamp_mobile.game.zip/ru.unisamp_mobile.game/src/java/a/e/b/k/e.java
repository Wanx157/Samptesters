package a.e.b.k;

import java.util.Iterator;
import java.util.HashSet;
import a.e.b.k.m.p;
import a.e.b.b;
import a.e.b.i;
import a.e.b.k.m.n;
import a.e.b.k.m.l;
import a.e.b.k.m.c;
import java.util.ArrayList;

public class e
{
    public static float o0 = 0.5f;
    private boolean A;
    private boolean B;
    private boolean C;
    private int D;
    private int E;
    public d F;
    public d G;
    public d H;
    public d I;
    public d J;
    d K;
    d L;
    public d M;
    public d[] N;
    protected ArrayList<d> O;
    private boolean[] P;
    public b[] Q;
    public e R;
    int S;
    int T;
    public float U;
    protected int V;
    protected int W;
    protected int X;
    int Y;
    protected int Z;
    public boolean a;
    protected int a0;
    public c b;
    float b0;
    public c c;
    float c0;
    public l d;
    private Object d0;
    public n e;
    private int e0;
    public boolean[] f;
    private String f0;
    private boolean g;
    private String g0;
    private boolean h;
    int h0;
    private boolean i;
    int i0;
    private boolean j;
    public float[] j0;
    private boolean k;
    protected e[] k0;
    public int l;
    protected e[] l0;
    public int m;
    public int m0;
    public int n;
    public int n0;
    public int o;
    public int[] p;
    public int q;
    public int r;
    public float s;
    public int t;
    public int u;
    public float v;
    int w;
    float x;
    private int[] y;
    private float z;
    
    public e() {
        this.a = false;
        this.d = null;
        this.e = null;
        this.f = new boolean[] { true, true };
        this.g = true;
        this.h = false;
        this.i = true;
        this.j = false;
        this.k = false;
        this.l = -1;
        this.m = -1;
        this.n = 0;
        this.o = 0;
        this.p = new int[2];
        this.q = 0;
        this.r = 0;
        this.s = 1.0f;
        this.t = 0;
        this.u = 0;
        this.v = 1.0f;
        this.w = -1;
        this.x = 1.0f;
        this.y = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
        this.z = 0.0f;
        this.A = false;
        this.C = false;
        this.D = 0;
        this.E = 0;
        this.F = new d(this, a.e.b.k.d.b.c);
        this.G = new d(this, a.e.b.k.d.b.d);
        this.H = new d(this, a.e.b.k.d.b.e);
        this.I = new d(this, a.e.b.k.d.b.f);
        this.J = new d(this, a.e.b.k.d.b.g);
        this.K = new d(this, a.e.b.k.d.b.i);
        this.L = new d(this, a.e.b.k.d.b.j);
        final d m = new d(this, a.e.b.k.d.b.h);
        this.M = m;
        this.N = new d[] { this.F, this.H, this.G, this.I, this.J, m };
        this.O = (ArrayList<d>)new ArrayList();
        this.P = new boolean[2];
        final b b = a.e.b.k.e.b.b;
        this.Q = new b[] { b, b };
        this.R = null;
        this.S = 0;
        this.T = 0;
        this.U = 0.0f;
        this.V = -1;
        this.W = 0;
        this.X = 0;
        this.Y = 0;
        final float o0 = a.e.b.k.e.o0;
        this.b0 = o0;
        this.c0 = o0;
        this.e0 = 0;
        this.f0 = null;
        this.g0 = null;
        this.h0 = 0;
        this.i0 = 0;
        this.j0 = new float[] { -1.0f, -1.0f };
        this.k0 = new e[] { null, null };
        this.l0 = new e[] { null, null };
        this.m0 = -1;
        this.n0 = -1;
        this.d();
    }
    
    private boolean Y(int n) {
        n *= 2;
        final d[] n2 = this.N;
        final d f = n2[n].f;
        boolean b = true;
        if (f != null && n2[n].f.f != n2[n]) {
            ++n;
            if (n2[n].f != null && n2[n].f.f == n2[n]) {
                return b;
            }
        }
        b = false;
        return b;
    }
    
    private void d() {
        this.O.add((Object)this.F);
        this.O.add((Object)this.G);
        this.O.add((Object)this.H);
        this.O.add((Object)this.I);
        this.O.add((Object)this.K);
        this.O.add((Object)this.L);
        this.O.add((Object)this.M);
        this.O.add((Object)this.J);
    }
    
    private void i(final a.e.b.d d, final boolean b, boolean b2, final boolean b3, boolean b4, final i i, final i j, b b5, final boolean b6, final d d2, final d d3, int n, int min, final int n2, int n3, final float n4, final boolean b7, final boolean b8, final boolean b9, final boolean b10, final boolean b11, int n5, int n6, int n7, int n8, final float n9, final boolean b12) {
        final i q = d.q(d2);
        final i q2 = d.q(d3);
        final i q3 = d.q(d2.i());
        final i q4 = d.q(d3.i());
        if (a.e.b.d.w() != null) {
            final a.e.b.e w = a.e.b.d.w();
            ++w.w;
        }
        final boolean n10 = d2.n();
        final boolean n11 = d3.n();
        final boolean n12 = this.M.n();
        int n13;
        if (n10) {
            n13 = 1;
        }
        else {
            n13 = 0;
        }
        int n14 = n13;
        if (n11) {
            n14 = n13 + 1;
        }
        int n15 = n14;
        if (n12) {
            n15 = n14 + 1;
        }
        int n16;
        if (b7) {
            n16 = 3;
        }
        else {
            n16 = n5;
        }
        n5 = e$a.b[b5.ordinal()];
        if (n5 != 1 && n5 != 2 && n5 != 3 && n5 == 4 && n16 != 4) {
            n5 = 1;
        }
        else {
            n5 = 0;
        }
        if (this.e0 == 8) {
            n5 = 0;
            min = 0;
        }
        else {
            final int n17 = min;
            min = n5;
            n5 = n17;
        }
        if (b12) {
            if (!n10 && !n11 && !n12) {
                d.f(q, n);
            }
            else if (n10 && !n11) {
                d.e(q, q3, d2.e(), 8);
            }
        }
        int n18;
        int n19;
        if (min == 0) {
            if (b6) {
                d.e(q2, q, 0, 3);
                if (n2 > 0) {
                    d.h(q2, q, n2, 8);
                }
                if (n3 < Integer.MAX_VALUE) {
                    d.j(q2, q, n3, 8);
                }
            }
            else {
                d.e(q2, q, n5, 8);
            }
            n18 = min;
            n19 = n7;
            n = n8;
        }
        else if (n15 != 2 && !b7 && (n16 == 1 || n16 == 0)) {
            min = (n = Math.max(n7, n5));
            if (n8 > 0) {
                n = Math.min(n8, min);
            }
            d.e(q2, q, n, 8);
            n18 = 0;
            n19 = n7;
            n = n8;
        }
        else {
            if ((n = n7) == -2) {
                n = n5;
            }
            if (n8 == -2) {
                n3 = n5;
            }
            else {
                n3 = n8;
            }
            n7 = n5;
            if (n5 > 0) {
                n7 = n5;
                if (n16 != 1) {
                    n7 = 0;
                }
            }
            n5 = n7;
            if (n > 0) {
                d.h(q2, q, n, 8);
                n5 = Math.max(n7, n);
            }
            if (n3 > 0) {
                if (b2 && n16 == 1) {
                    n7 = 0;
                }
                else {
                    n7 = 1;
                }
                if (n7 != 0) {
                    d.j(q2, q, n3, 8);
                }
                n5 = Math.min(n5, n3);
            }
            if (n16 == 1) {
                if (b2) {
                    d.e(q2, q, n5, 8);
                }
                else {
                    d.e(q2, q, n5, 5);
                    d.j(q2, q, n5, 8);
                }
                n19 = n;
                n = n3;
                n18 = min;
            }
            else if (n16 == 2) {
                i k;
                e e;
                d.b b13;
                if (d2.j() != d.b.d && d2.j() != d.b.f) {
                    k = d.q(this.R.m(d.b.c));
                    e = this.R;
                    b13 = d.b.e;
                }
                else {
                    k = d.q(this.R.m(d.b.d));
                    e = this.R;
                    b13 = d.b.f;
                }
                final i q5 = d.q(e.m(b13));
                final a.e.b.b r = d.r();
                r.k(q2, q, q5, k, n9);
                d.d(r);
                n19 = n;
                n18 = 0;
                n = n3;
            }
            else {
                b4 = true;
                n18 = min;
                n19 = n;
                n = n3;
            }
        }
        if (b12 && !b9) {
            boolean b14 = false;
            Label_2140: {
                Label_2137: {
                    if (n10 || n11 || n12) {
                        if (!n10 || n11) {
                            if (!n10 && n11) {
                                d.e(q2, q4, -d3.e(), 8);
                                if (b2) {
                                    if (this.h && q.g) {
                                        final e r2 = this.R;
                                        if (r2 != null) {
                                            final f f = (f)r2;
                                            if (b) {
                                                f.i1(d2);
                                                break Label_2137;
                                            }
                                            f.n1(d2);
                                            break Label_2137;
                                        }
                                    }
                                    d.h(q, i, 0, 5);
                                }
                            }
                            else if (n10 && n11) {
                                final e d4 = d2.f.d;
                                final e d5 = d3.f.d;
                                final e l = this.I();
                                final int n20 = 6;
                                Label_1570: {
                                    Label_1563: {
                                        Label_1560: {
                                            if (n18 != 0) {
                                                if (n16 == 0) {
                                                    if (n == 0 && n19 == 0) {
                                                        if (q3.g && q4.g) {
                                                            d.e(q, q3, d2.e(), 8);
                                                            d.e(q2, q4, -d3.e(), 8);
                                                            return;
                                                        }
                                                        min = 0;
                                                        n = 1;
                                                        n5 = 0;
                                                        n3 = 8;
                                                        n6 = 8;
                                                    }
                                                    else {
                                                        min = 1;
                                                        n = 0;
                                                        n5 = 1;
                                                        n3 = 5;
                                                        n6 = 5;
                                                    }
                                                    if (!(d4 instanceof a) && !(d5 instanceof a)) {
                                                        n8 = n6;
                                                        final int n21 = 6;
                                                        n7 = min;
                                                        min = n5;
                                                        n6 = n;
                                                        n = n3;
                                                        n5 = n21;
                                                        n3 = n8;
                                                        break Label_1570;
                                                    }
                                                    final int n22 = 6;
                                                    n8 = 4;
                                                    n7 = min;
                                                    min = n5;
                                                    n6 = n;
                                                    n = n3;
                                                    n5 = n22;
                                                    n3 = n8;
                                                    break Label_1570;
                                                }
                                                else {
                                                    if (n16 == 1) {
                                                        min = 1;
                                                        n7 = 1;
                                                        n6 = 0;
                                                        n = 8;
                                                        break Label_1563;
                                                    }
                                                    if (n16 == 3) {
                                                        if (this.w == -1) {
                                                            n = 8;
                                                            if (b10) {
                                                                if (b2) {
                                                                    n5 = 5;
                                                                }
                                                                else {
                                                                    n5 = 4;
                                                                }
                                                            }
                                                            else {
                                                                n5 = 8;
                                                            }
                                                        }
                                                        else {
                                                            if (b7) {
                                                                if (n6 != 2 && n6 != 1) {
                                                                    n = 0;
                                                                }
                                                                else {
                                                                    n = 1;
                                                                }
                                                                if (n == 0) {
                                                                    min = 8;
                                                                    n = 5;
                                                                }
                                                                else {
                                                                    min = 5;
                                                                    n = 4;
                                                                }
                                                                n5 = min;
                                                                n3 = n;
                                                                min = 1;
                                                                n7 = 1;
                                                                n6 = 1;
                                                                n8 = 6;
                                                                n = n5;
                                                                n5 = n8;
                                                                break Label_1570;
                                                            }
                                                            if (n > 0) {
                                                                n = 5;
                                                                n5 = 6;
                                                            }
                                                            else {
                                                                if (n != 0 || n19 != 0) {
                                                                    min = 1;
                                                                    n7 = 1;
                                                                    n6 = 1;
                                                                    break Label_1560;
                                                                }
                                                                if (!b10) {
                                                                    min = 1;
                                                                    n7 = 1;
                                                                    n6 = 1;
                                                                    n = 5;
                                                                    n5 = 6;
                                                                    n3 = 8;
                                                                    break Label_1570;
                                                                }
                                                                if (d4 != l && d5 != l) {
                                                                    n = 4;
                                                                }
                                                                else {
                                                                    n = 5;
                                                                }
                                                                min = 1;
                                                                n7 = 1;
                                                                n6 = 1;
                                                                break Label_1563;
                                                            }
                                                        }
                                                        n6 = 1;
                                                        n7 = 1;
                                                        min = 1;
                                                        n3 = 5;
                                                        break Label_1570;
                                                    }
                                                    min = 0;
                                                    n7 = 0;
                                                }
                                            }
                                            else {
                                                if (q3.g && q4.g) {
                                                    d.c(q, q3, d2.e(), n4, q4, q2, d3.e(), 8);
                                                    if (b2 && b4) {
                                                        if (d3.f != null) {
                                                            n = d3.e();
                                                        }
                                                        else {
                                                            n = 0;
                                                        }
                                                        if (q4 != j) {
                                                            d.h(j, q2, n, 5);
                                                        }
                                                    }
                                                    return;
                                                }
                                                min = 1;
                                                n7 = 1;
                                            }
                                            n6 = 0;
                                        }
                                        n = 5;
                                    }
                                    n5 = 6;
                                    n3 = 4;
                                }
                                if (min != 0 && q3 == q4 && d4 != l) {
                                    min = 0;
                                    n8 = 0;
                                }
                                else {
                                    n8 = 1;
                                }
                                if (n7 != 0) {
                                    if (n18 == 0 && !b8 && !b10 && q3 == i && q4 == j) {
                                        b2 = false;
                                        n = 8;
                                        n5 = 8;
                                        n8 = 0;
                                    }
                                    d.c(q, q3, d2.e(), n4, q4, q2, d3.e(), n5);
                                }
                                if (this.e0 == 8 && !d3.l()) {
                                    return;
                                }
                                if (min != 0) {
                                    if (b2 && q3 != q4 && n18 == 0 && (d4 instanceof a || d5 instanceof a)) {
                                        n = 6;
                                    }
                                    d.h(q, q3, d2.e(), n);
                                    d.j(q2, q4, -d3.e(), n);
                                }
                                if (b2 && b11 && !(d4 instanceof a) && !(d5 instanceof a)) {
                                    n3 = 6;
                                    n = 6;
                                    n8 = 1;
                                }
                                else {
                                    min = n;
                                    n = n3;
                                    n3 = min;
                                }
                                if (n8 != 0) {
                                    if (n6 != 0 && (!b10 || b3)) {
                                        min = n20;
                                        if (d4 != l) {
                                            if (d5 == l) {
                                                min = n20;
                                            }
                                            else {
                                                min = n;
                                            }
                                        }
                                        if (d4 instanceof g || d5 instanceof g) {
                                            min = 5;
                                        }
                                        if (d4 instanceof a || d5 instanceof a) {
                                            min = 5;
                                        }
                                        if (b10) {
                                            min = 5;
                                        }
                                        n = Math.max(min, n);
                                    }
                                    min = n;
                                    if (b2) {
                                        min = Math.min(n3, n);
                                        if (b7 && !b10 && (d4 == l || d5 == l)) {
                                            min = 4;
                                        }
                                    }
                                    d.e(q, q3, d2.e(), min);
                                    d.e(q2, q4, -d3.e(), min);
                                }
                                if (b2) {
                                    if (i == q3) {
                                        n = d2.e();
                                    }
                                    else {
                                        n = 0;
                                    }
                                    if (q3 != i) {
                                        d.h(q, i, n, 5);
                                    }
                                }
                                if (!(b14 = b2)) {
                                    break Label_2140;
                                }
                                b14 = b2;
                                if (n18 == 0) {
                                    break Label_2140;
                                }
                                b14 = b2;
                                if (n2 != 0) {
                                    break Label_2140;
                                }
                                b14 = b2;
                                if (n19 != 0) {
                                    break Label_2140;
                                }
                                if (n18 != 0 && n16 == 3) {
                                    d.h(q2, q, 0, 8);
                                    b14 = b2;
                                    break Label_2140;
                                }
                                d.h(q2, q, 0, 5);
                                b14 = b2;
                                break Label_2140;
                            }
                        }
                    }
                }
                b14 = b2;
            }
            if (b14 && b4) {
                if (d3.f != null) {
                    n = d3.e();
                }
                else {
                    n = 0;
                }
                if (q4 != j) {
                    if (this.h && q2.g) {
                        final e r3 = this.R;
                        if (r3 != null) {
                            final f f2 = (f)r3;
                            if (b) {
                                f2.h1(d3);
                            }
                            else {
                                f2.m1(d3);
                            }
                            return;
                        }
                    }
                    d.h(j, q2, n, 5);
                }
            }
            return;
        }
        if (n15 < 2 && b2 && b4) {
            d.h(q, i, 0, 8);
            if (!b && this.J.f != null) {
                min = 0;
            }
            else {
                min = 1;
            }
            n = min;
            Label_2380: {
                if (!b) {
                    final d f3 = this.J.f;
                    n = min;
                    if (f3 != null) {
                        final e d6 = f3.d;
                        if (d6.U != 0.0f) {
                            final b[] q6 = d6.Q;
                            b5 = q6[0];
                            final b d7 = a.e.b.k.e.b.d;
                            if (b5 == d7 && q6[1] == d7) {
                                n = 1;
                                break Label_2380;
                            }
                        }
                        n = 0;
                    }
                }
            }
            if (n != 0) {
                d.h(j, q2, 0, 8);
            }
        }
    }
    
    public int A() {
        return this.D;
    }
    
    public void A0(int n, final int q, final int n2, final float s) {
        this.n = n;
        this.q = q;
        n = n2;
        if (n2 == Integer.MAX_VALUE) {
            n = 0;
        }
        this.r = n;
        this.s = s;
        if (s > 0.0f && s < 1.0f && this.n == 0) {
            this.n = 2;
        }
    }
    
    public int B() {
        return this.E;
    }
    
    public void B0(final float n) {
        this.j0[0] = n;
    }
    
    public int C(final int n) {
        if (n == 0) {
            return this.R();
        }
        if (n == 1) {
            return this.v();
        }
        return 0;
    }
    
    protected void C0(final int n, final boolean b) {
        this.P[n] = b;
    }
    
    public int D() {
        return this.y[1];
    }
    
    public void D0(final boolean b) {
        this.B = b;
    }
    
    public int E() {
        return this.y[0];
    }
    
    public void E0(final boolean c) {
        this.C = c;
    }
    
    public int F() {
        return this.a0;
    }
    
    public void F0(final int d, final int e) {
        this.D = d;
        this.E = e;
        this.I0(false);
    }
    
    public int G() {
        return this.Z;
    }
    
    public void G0(final int n) {
        this.y[1] = n;
    }
    
    public e H(final int n) {
        if (n == 0) {
            final d h = this.H;
            final d f = h.f;
            if (f != null && f.f == h) {
                return f.d;
            }
        }
        else if (n == 1) {
            final d i = this.I;
            final d f2 = i.f;
            if (f2 != null && f2.f == i) {
                return f2.d;
            }
        }
        return null;
    }
    
    public void H0(final int n) {
        this.y[0] = n;
    }
    
    public e I() {
        return this.R;
    }
    
    public void I0(final boolean g) {
        this.g = g;
    }
    
    public e J(final int n) {
        if (n == 0) {
            final d f = this.F;
            final d f2 = f.f;
            if (f2 != null && f2.f == f) {
                return f2.d;
            }
        }
        else if (n == 1) {
            final d g = this.G;
            final d f3 = g.f;
            if (f3 != null && f3.f == g) {
                return f3.d;
            }
        }
        return null;
    }
    
    public void J0(final int n) {
        int a0 = n;
        if (n < 0) {
            a0 = 0;
        }
        this.a0 = a0;
    }
    
    public int K() {
        return this.S() + this.S;
    }
    
    public void K0(final int n) {
        int z = n;
        if (n < 0) {
            z = 0;
        }
        this.Z = z;
    }
    
    public p L(final int n) {
        if (n == 0) {
            return (p)this.d;
        }
        if (n == 1) {
            return (p)this.e;
        }
        return null;
    }
    
    public void L0(final int w, final int x) {
        this.W = w;
        this.X = x;
    }
    
    public float M() {
        return this.c0;
    }
    
    public void M0(final e r) {
        this.R = r;
    }
    
    public int N() {
        return this.i0;
    }
    
    public void N0(final float c0) {
        this.c0 = c0;
    }
    
    public b O() {
        return this.Q[1];
    }
    
    public void O0(final int i0) {
        this.i0 = i0;
    }
    
    public int P() {
        final d f = this.F;
        int n = 0;
        if (f != null) {
            n = 0 + this.G.g;
        }
        int n2 = n;
        if (this.H != null) {
            n2 = n + this.I.g;
        }
        return n2;
    }
    
    public void P0(int n, int a0) {
        this.X = n;
        n = a0 - n;
        this.T = n;
        a0 = this.a0;
        if (n < a0) {
            this.T = a0;
        }
    }
    
    public int Q() {
        return this.e0;
    }
    
    public void Q0(final b b) {
        this.Q[1] = b;
    }
    
    public int R() {
        if (this.e0 == 8) {
            return 0;
        }
        return this.S;
    }
    
    public void R0(int n, final int t, final int n2, final float v) {
        this.o = n;
        this.t = t;
        n = n2;
        if (n2 == Integer.MAX_VALUE) {
            n = 0;
        }
        this.u = n;
        this.v = v;
        if (v > 0.0f && v < 1.0f && this.o == 0) {
            this.o = 2;
        }
    }
    
    public int S() {
        final e r = this.R;
        if (r != null && r instanceof f) {
            return ((f)r).w0 + this.W;
        }
        return this.W;
    }
    
    public void S0(final float n) {
        this.j0[1] = n;
    }
    
    public int T() {
        final e r = this.R;
        if (r != null && r instanceof f) {
            return ((f)r).x0 + this.X;
        }
        return this.X;
    }
    
    public void T0(final int e0) {
        this.e0 = e0;
    }
    
    public boolean U() {
        return this.A;
    }
    
    public void U0(final int s) {
        this.S = s;
        final int z = this.Z;
        if (s < z) {
            this.S = z;
        }
    }
    
    public boolean V(int n) {
        final boolean b = true;
        boolean b2 = true;
        if (n == 0) {
            if (this.F.f != null) {
                n = 1;
            }
            else {
                n = 0;
            }
            int n2;
            if (this.H.f != null) {
                n2 = 1;
            }
            else {
                n2 = 0;
            }
            if (n + n2 >= 2) {
                b2 = false;
            }
            return b2;
        }
        if (this.G.f != null) {
            n = 1;
        }
        else {
            n = 0;
        }
        int n3;
        if (this.I.f != null) {
            n3 = 1;
        }
        else {
            n3 = 0;
        }
        int n4;
        if (this.J.f != null) {
            n4 = 1;
        }
        else {
            n4 = 0;
        }
        return n + n3 + n4 < 2 && b;
    }
    
    public void V0(final int w) {
        this.W = w;
    }
    
    public boolean W() {
        for (int size = this.O.size(), i = 0; i < size; ++i) {
            if (((d)this.O.get(i)).l()) {
                return true;
            }
        }
        return false;
    }
    
    public void W0(final int x) {
        this.X = x;
    }
    
    public void X(final d.b b, final e e, final d.b b2, final int n, final int n2) {
        this.m(b).a(e.m(b2), n, n2, true);
    }
    
    public void X0(final boolean b, final boolean b2, final boolean b3, final boolean b4) {
        if (this.w == -1) {
            if (b3 && !b4) {
                this.w = 0;
            }
            else if (!b3 && b4) {
                this.w = 1;
                if (this.V == -1) {
                    this.x = 1.0f / this.x;
                }
            }
        }
        if (this.w == 0 && (!this.G.n() || !this.I.n())) {
            this.w = 1;
        }
        else if (this.w == 1 && (!this.F.n() || !this.H.n())) {
            this.w = 0;
        }
        if (this.w == -1 && (!this.G.n() || !this.I.n() || !this.F.n() || !this.H.n())) {
            if (this.G.n() && this.I.n()) {
                this.w = 0;
            }
            else if (this.F.n() && this.H.n()) {
                this.x = 1.0f / this.x;
                this.w = 1;
            }
        }
        if (this.w == -1) {
            if (this.q > 0 && this.t == 0) {
                this.w = 0;
            }
            else if (this.q == 0 && this.t > 0) {
                this.x = 1.0f / this.x;
                this.w = 1;
            }
        }
    }
    
    public void Y0(final boolean b, final boolean b2) {
        final boolean b3 = b & ((p)this.d).k();
        final boolean b4 = b2 & ((p)this.e).k();
        final l d = this.d;
        int g = ((p)d).h.g;
        final n e = this.e;
        int g2 = ((p)e).h.g;
        int g3 = ((p)d).i.g;
        final int g4 = ((p)e).i.g;
        int n;
        if (g3 - g < 0 || g4 - g2 < 0 || g == Integer.MIN_VALUE || g == Integer.MAX_VALUE || g2 == Integer.MIN_VALUE || g2 == Integer.MAX_VALUE || g3 == Integer.MIN_VALUE || g3 == Integer.MAX_VALUE || g4 == Integer.MIN_VALUE || (n = g4) == Integer.MAX_VALUE) {
            g3 = 0;
            g = 0;
            n = 0;
            g2 = 0;
        }
        final int n2 = g3 - g;
        final int n3 = n - g2;
        if (b3) {
            this.W = g;
        }
        if (b4) {
            this.X = g2;
        }
        if (this.e0 == 8) {
            this.S = 0;
            this.T = 0;
            return;
        }
        if (b3) {
            int s = n2;
            if (this.Q[0] == a.e.b.k.e.b.b) {
                final int s2 = this.S;
                if ((s = n2) < s2) {
                    s = s2;
                }
            }
            this.S = s;
            final int z = this.Z;
            if (s < z) {
                this.S = z;
            }
        }
        if (b4) {
            int t = n3;
            if (this.Q[1] == a.e.b.k.e.b.b) {
                final int t2 = this.T;
                if ((t = n3) < t2) {
                    t = t2;
                }
            }
            this.T = t;
            final int a0 = this.a0;
            if (t < a0) {
                this.T = a0;
            }
        }
    }
    
    public boolean Z() {
        final d f = this.F;
        final d f2 = f.f;
        if (f2 == null || f2.f != f) {
            final d h = this.H;
            final d f3 = h.f;
            if (f3 == null || f3.f != h) {
                return false;
            }
        }
        return true;
    }
    
    public void Z0(final a.e.b.d d, final boolean b) {
        final int x = d.x(this.F);
        final int x2 = d.x(this.G);
        final int x3 = d.x(this.H);
        final int x4 = d.x(this.I);
        int g = x;
        int g2 = x3;
        if (b) {
            final l d2 = this.d;
            g = x;
            g2 = x3;
            if (d2 != null) {
                final a.e.b.k.m.f h = ((p)d2).h;
                g = x;
                g2 = x3;
                if (h.j) {
                    final a.e.b.k.m.f i = ((p)d2).i;
                    g = x;
                    g2 = x3;
                    if (i.j) {
                        g = h.g;
                        g2 = i.g;
                    }
                }
            }
        }
        int g3 = x2;
        int g4 = x4;
        if (b) {
            final n e = this.e;
            g3 = x2;
            g4 = x4;
            if (e != null) {
                final a.e.b.k.m.f h2 = ((p)e).h;
                g3 = x2;
                g4 = x4;
                if (h2.j) {
                    final a.e.b.k.m.f j = ((p)e).i;
                    g3 = x2;
                    g4 = x4;
                    if (j.j) {
                        g3 = h2.g;
                        g4 = j.g;
                    }
                }
            }
        }
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        Label_0305: {
            if (g2 - g >= 0 && g4 - g3 >= 0 && g != Integer.MIN_VALUE && g != Integer.MAX_VALUE && g3 != Integer.MIN_VALUE && g3 != Integer.MAX_VALUE && g2 != Integer.MIN_VALUE && g2 != Integer.MAX_VALUE && g4 != Integer.MIN_VALUE) {
                n = g;
                n2 = g2;
                if ((n3 = g4) != Integer.MAX_VALUE) {
                    break Label_0305;
                }
            }
            n3 = 0;
            n = 0;
            g3 = 0;
            n2 = 0;
        }
        this.t0(n, g3, n2, n3);
    }
    
    public boolean a0() {
        return this.B;
    }
    
    public boolean b0() {
        final d g = this.G;
        final d f = g.f;
        if (f == null || f.f != g) {
            final d i = this.I;
            final d f2 = i.f;
            if (f2 == null || f2.f != i) {
                return false;
            }
        }
        return true;
    }
    
    public boolean c0() {
        return this.C;
    }
    
    public boolean d0() {
        return this.g && this.e0 != 8;
    }
    
    public void e(final f f, final a.e.b.d d, final HashSet<e> set, final int n, final boolean b) {
        if (b) {
            if (!set.contains((Object)this)) {
                return;
            }
            a.e.b.k.j.a(f, d, this);
            set.remove((Object)this);
            this.g(d, f.B1(64));
        }
        Object o;
        if (n == 0) {
            final HashSet<d> c = this.F.c();
            if (c != null) {
                final Iterator iterator = c.iterator();
                while (iterator.hasNext()) {
                    ((d)iterator.next()).d.e(f, d, set, n, true);
                }
            }
            o = this.H.c();
            if (o != null) {
                o = ((HashSet)o).iterator();
                while (((Iterator)o).hasNext()) {
                    ((d)((Iterator)o).next()).d.e(f, d, set, n, true);
                }
            }
            return;
        }
        else {
            final HashSet<d> c2 = this.G.c();
            if (c2 != null) {
                final Iterator iterator2 = c2.iterator();
                while (iterator2.hasNext()) {
                    ((d)iterator2.next()).d.e(f, d, set, n, true);
                }
            }
            final HashSet<d> c3 = this.I.c();
            if (c3 != null) {
                final Iterator iterator3 = c3.iterator();
                while (iterator3.hasNext()) {
                    ((d)iterator3.next()).d.e(f, d, set, n, true);
                }
            }
            o = this.J.c();
            if (o == null) {
                return;
            }
            o = ((HashSet)o).iterator();
        }
        while (true) {
            if (!((Iterator)o).hasNext()) {
                return;
            }
            final e d2 = ((d)((Iterator)o).next()).d;
            try {
                d2.e(f, d, set, n, true);
                continue;
            }
            finally {
                while (true) {}
            }
            break;
        }
    }
    
    public boolean e0() {
        return this.j || (this.F.m() && this.H.m());
    }
    
    boolean f() {
        return this instanceof k || this instanceof g;
    }
    
    public boolean f0() {
        return this.k || (this.G.m() && this.I.m());
    }
    
    public void g(final a.e.b.d d, final boolean b) {
        i q = d.q(this.F);
        i q2 = d.q(this.H);
        final i q3 = d.q(this.G);
        final i q4 = d.q(this.I);
        final i q5 = d.q(this.J);
        final e r = this.R;
        boolean b4;
        boolean b5;
        if (r != null) {
            final boolean b2 = r != null && r.Q[0] == a.e.b.k.e.b.c;
            final e r2 = this.R;
            final boolean b3 = r2 != null && r2.Q[1] == a.e.b.k.e.b.c;
            b4 = b2;
            b5 = b3;
        }
        else {
            b4 = false;
            b5 = false;
        }
        if (this.e0 == 8 && !this.W()) {
            final boolean[] p2 = this.P;
            if (!p2[0] && !p2[1]) {
                return;
            }
        }
        if (this.j || this.k) {
            if (this.j) {
                d.f(q, this.W);
                d.f(q2, this.W + this.S);
                if (b4) {
                    final e r3 = this.R;
                    if (r3 != null) {
                        if (this.i) {
                            final f f = (f)r3;
                            f.n1(this.F);
                            f.h1(this.H);
                        }
                        else {
                            d.h(d.q(r3.H), q2, 0, 5);
                        }
                    }
                }
            }
            if (this.k) {
                d.f(q3, this.X);
                d.f(q4, this.X + this.T);
                if (this.J.l()) {
                    d.f(q5, this.X + this.Y);
                }
                if (b5) {
                    final e r4 = this.R;
                    if (r4 != null) {
                        if (this.i) {
                            final f f2 = (f)r4;
                            f2.n1(this.G);
                            f2.m1(this.I);
                        }
                        else {
                            d.h(d.q(r4.I), q4, 0, 5);
                        }
                    }
                }
            }
            if (this.j && this.k) {
                this.j = false;
                this.k = false;
                return;
            }
        }
        final a.e.b.e x = a.e.b.d.x;
        if (x != null) {
            ++x.y;
        }
        if (b) {
            final l d2 = this.d;
            if (d2 != null) {
                final n e = this.e;
                if (e != null && ((p)d2).h.j && ((p)d2).i.j && ((p)e).h.j && ((p)e).i.j) {
                    final a.e.b.e x2 = a.e.b.d.x;
                    if (x2 != null) {
                        ++x2.r;
                    }
                    d.f(q, ((p)this.d).h.g);
                    d.f(q2, ((p)this.d).i.g);
                    d.f(q3, ((p)this.e).h.g);
                    d.f(q4, ((p)this.e).i.g);
                    d.f(q5, this.e.k.g);
                    if (this.R != null) {
                        if (b4 && this.f[0] && !this.Z()) {
                            d.h(d.q(this.R.H), q2, 0, 8);
                        }
                        if (b5 && this.f[1] && !this.b0()) {
                            d.h(d.q(this.R.I), q4, 0, 8);
                        }
                    }
                    this.j = false;
                    this.k = false;
                    return;
                }
            }
        }
        final a.e.b.e x3 = a.e.b.d.x;
        if (x3 != null) {
            ++x3.s;
        }
        boolean z;
        boolean b6;
        if (this.R != null) {
            if (this.Y(0)) {
                ((f)this.R).e1(this, 0);
                z = true;
            }
            else {
                z = this.Z();
            }
            if (this.Y(1)) {
                ((f)this.R).e1(this, 1);
                b6 = true;
            }
            else {
                b6 = this.b0();
            }
            if (!z && b4 && this.e0 != 8 && this.F.f == null && this.H.f == null) {
                d.h(d.q(this.R.H), q2, 0, 1);
            }
            if (!b6 && b5 && this.e0 != 8 && this.G.f == null && this.I.f == null && this.J == null) {
                d.h(d.q(this.R.I), q4, 0, 1);
            }
        }
        else {
            b6 = false;
            z = false;
        }
        final int s = this.S;
        final int z2 = this.Z;
        int n = s;
        if (s < z2) {
            n = z2;
        }
        final int t = this.T;
        final int a0 = this.a0;
        int n2;
        if ((n2 = t) < a0) {
            n2 = a0;
        }
        final boolean b7 = this.Q[0] != a.e.b.k.e.b.d;
        final boolean b8 = this.Q[1] != a.e.b.k.e.b.d;
        this.w = this.V;
        final float u = this.U;
        this.x = u;
        final int n3 = this.n;
        final int o = this.o;
        int n5 = 0;
        int n11 = 0;
        int n12 = 0;
        int n13 = 0;
        int n14 = 0;
        Label_1475: {
            if (u > 0.0f && this.e0 != 8) {
                int n4 = n3;
                if (this.Q[0] == a.e.b.k.e.b.d && (n4 = n3) == 0) {
                    n4 = 3;
                }
                n5 = o;
                if (this.Q[1] == a.e.b.k.e.b.d && (n5 = o) == 0) {
                    n5 = 3;
                }
                final b[] q6 = this.Q;
                final b b9 = q6[0];
                final b d3 = a.e.b.k.e.b.d;
                Label_1442: {
                    int n15 = 0;
                    Label_1434: {
                        if (b9 == d3 && q6[1] == d3 && n4 == 3 && n5 == 3) {
                            this.X0(b4, b5, b7, b8);
                        }
                        else {
                            final b[] q7 = this.Q;
                            final b b10 = q7[0];
                            final b d4 = a.e.b.k.e.b.d;
                            if (b10 == d4 && n4 == 3) {
                                this.w = 0;
                                final int n6 = (int)(this.x * this.T);
                                final b b11 = q7[1];
                                final int n7 = n5;
                                if (b11 != d4) {
                                    final int n8 = n2;
                                    final int n9 = 0;
                                    final int n10 = 4;
                                    n11 = n6;
                                    n12 = n8;
                                    n13 = n9;
                                    n5 = n7;
                                    n14 = n10;
                                    break Label_1475;
                                }
                                n15 = n6;
                                break Label_1434;
                            }
                            else if (this.Q[1] == a.e.b.k.e.b.d && n5 == 3) {
                                this.w = 1;
                                if (this.V == -1) {
                                    this.x = 1.0f / this.x;
                                }
                                final int n16 = (int)(this.x * this.S);
                                if (this.Q[0] != a.e.b.k.e.b.d) {
                                    final int n17 = n4;
                                    n13 = 0;
                                    n5 = 4;
                                    n11 = n;
                                    n12 = n16;
                                    n14 = n17;
                                    break Label_1475;
                                }
                                n11 = n;
                                n12 = n16;
                                break Label_1442;
                            }
                        }
                        n15 = n;
                    }
                    n12 = n2;
                    n11 = n15;
                }
                n14 = n4;
                n13 = 1;
            }
            else {
                n5 = o;
                n14 = n3;
                final int n18 = n;
                n12 = n2;
                n13 = 0;
                n11 = n18;
            }
        }
        final int[] p3 = this.p;
        p3[0] = n14;
        p3[1] = n5;
        boolean b12 = false;
        Label_1524: {
            if (n13 != 0) {
                final int w = this.w;
                if (w == 0 || w == -1) {
                    b12 = true;
                    break Label_1524;
                }
            }
            b12 = false;
        }
        boolean b13 = false;
        Label_1556: {
            if (n13 != 0) {
                final int w2 = this.w;
                if (w2 == 1 || w2 == -1) {
                    b13 = true;
                    break Label_1556;
                }
            }
            b13 = false;
        }
        final boolean b14 = this.Q[0] == a.e.b.k.e.b.c && this instanceof f;
        if (b14) {
            n11 = 0;
        }
        final boolean b15 = this.M.n() ^ true;
        final boolean[] p4 = this.P;
        final boolean b16 = p4[0];
        final boolean b17 = p4[1];
        Label_1961: {
            if (this.l != 2 && !this.j) {
                if (b) {
                    final l d5 = this.d;
                    if (d5 != null) {
                        final a.e.b.k.m.f h = ((p)d5).h;
                        if (h.j) {
                            if (((p)d5).i.j) {
                                if (!b) {
                                    break Label_1961;
                                }
                                d.f(q, h.g);
                                d.f(q2, ((p)this.d).i.g);
                                if (this.R != null && b4 && this.f[0] && !this.Z()) {
                                    d.h(d.q(this.R.H), q2, 0, 8);
                                }
                                break Label_1961;
                            }
                        }
                    }
                }
                final e r5 = this.R;
                i q8;
                if (r5 != null) {
                    q8 = d.q(r5.H);
                }
                else {
                    q8 = null;
                }
                final e r6 = this.R;
                i q9;
                if (r6 != null) {
                    q9 = d.q(r6.F);
                }
                else {
                    q9 = null;
                }
                final boolean b18 = this.f[0];
                final b[] q10 = this.Q;
                this.i(d, true, b4, b5, b18, q9, q8, q10[0], b14, this.F, this.H, this.W, n11, this.Z, this.y[0], this.b0, b12, q10[1] == a.e.b.k.e.b.d, z, b6, b16, n14, n5, this.q, this.r, this.s, b15);
            }
        }
        boolean b19 = false;
        Label_2119: {
            if (b) {
                final n e2 = this.e;
                if (e2 != null) {
                    final a.e.b.k.m.f h2 = ((p)e2).h;
                    if (h2.j && ((p)e2).i.j) {
                        d.f(q3, h2.g);
                        d.f(q4, ((p)this.e).i.g);
                        d.f(q5, this.e.k.g);
                        final e r7 = this.R;
                        if (r7 != null && !b6 && b5) {
                            if (this.f[1]) {
                                d.h(d.q(r7.I), q4, 0, 8);
                            }
                        }
                        b19 = false;
                        break Label_2119;
                    }
                }
            }
            b19 = true;
        }
        if (this.m == 2) {
            b19 = false;
        }
        if (b19 && !this.k) {
            final boolean b20 = this.Q[1] == a.e.b.k.e.b.c && this instanceof f;
            if (b20) {
                n12 = 0;
            }
            final e r8 = this.R;
            i q11;
            if (r8 != null) {
                q11 = d.q(r8.I);
            }
            else {
                q11 = null;
            }
            final e r9 = this.R;
            i q12;
            if (r9 != null) {
                q12 = d.q(r9.G);
            }
            else {
                q12 = null;
            }
            boolean b21 = false;
            Label_2366: {
                if (this.Y > 0 || this.e0 == 8) {
                    if (this.J.f != null) {
                        d.e(q5, q3, this.n(), 8);
                        d.e(q5, d.q(this.J.f), 0, 8);
                        if (b5) {
                            d.h(q11, d.q(this.I), 0, 5);
                        }
                        b21 = false;
                        break Label_2366;
                    }
                    if (this.e0 == 8) {
                        d.e(q5, q3, 0, 8);
                    }
                    else {
                        d.e(q5, q3, this.n(), 8);
                    }
                }
                b21 = b15;
            }
            final boolean b22 = this.f[1];
            final b[] q13 = this.Q;
            this.i(d, false, b5, b4, b22, q12, q11, q13[1], b20, this.G, this.I, this.X, n12, this.a0, this.y[1], this.c0, b13, q13[0] == a.e.b.k.e.b.d, b6, z, b17, n5, n14, this.t, this.u, this.v, b21);
        }
        if (n13 != 0) {
            final int w3 = this.w;
            final float x4 = this.x;
            i k;
            i m;
            if (w3 == 1) {
                final i i = q4;
                final i j = q3;
                k = q2;
                final i l = q;
                q2 = i;
                q = j;
                m = l;
            }
            else {
                final i i2 = q4;
                m = q3;
                k = i2;
            }
            d.k(q2, q, k, m, x4, 8);
        }
        if (this.M.n()) {
            d.b(this, this.M.i().g(), (float)Math.toRadians((double)(this.z + 90.0f)), this.M.e());
        }
        this.j = false;
        this.k = false;
    }
    
    public boolean g0() {
        final b[] q = this.Q;
        final boolean b = false;
        final b b2 = q[0];
        final b d = a.e.b.k.e.b.d;
        boolean b3 = b;
        if (b2 == d) {
            b3 = b;
            if (q[1] == d) {
                b3 = true;
            }
        }
        return b3;
    }
    
    public boolean h() {
        return this.e0 != 8;
    }
    
    public void h0() {
        this.F.p();
        this.G.p();
        this.H.p();
        this.I.p();
        this.J.p();
        this.K.p();
        this.L.p();
        this.M.p();
        this.R = null;
        this.z = 0.0f;
        this.S = 0;
        this.T = 0;
        this.U = 0.0f;
        this.V = -1;
        this.W = 0;
        this.X = 0;
        this.Y = 0;
        this.Z = 0;
        this.a0 = 0;
        final float o0 = a.e.b.k.e.o0;
        this.b0 = o0;
        this.c0 = o0;
        final b[] q = this.Q;
        q[1] = (q[0] = a.e.b.k.e.b.b);
        this.d0 = null;
        this.e0 = 0;
        this.g0 = null;
        this.h0 = 0;
        this.i0 = 0;
        final float[] j0 = this.j0;
        j0[1] = (j0[0] = -1.0f);
        this.l = -1;
        this.m = -1;
        final int[] y = this.y;
        y[1] = (y[0] = Integer.MAX_VALUE);
        this.n = 0;
        this.o = 0;
        this.s = 1.0f;
        this.v = 1.0f;
        this.r = Integer.MAX_VALUE;
        this.u = Integer.MAX_VALUE;
        this.q = 0;
        this.t = 0;
        this.w = -1;
        this.x = 1.0f;
        final boolean[] f = this.f;
        f[1] = (f[0] = true);
        this.C = false;
        final boolean[] p = this.P;
        p[1] = (p[0] = false);
        this.g = true;
    }
    
    public void i0() {
        int i = 0;
        this.j = false;
        this.k = false;
        while (i < this.O.size()) {
            ((d)this.O.get(i)).q();
            ++i;
        }
    }
    
    public void j(final e e, final float z, final int n) {
        final d.b h = a.e.b.k.d.b.h;
        this.X(h, e, h, n, 0);
        this.z = z;
    }
    
    public void j0(final a.e.b.c c) {
        this.F.r(c);
        this.G.r(c);
        this.H.r(c);
        this.I.r(c);
        this.J.r(c);
        this.M.r(c);
        this.K.r(c);
        this.L.r(c);
    }
    
    public void k(final a.e.b.d d) {
        d.q(this.F);
        d.q(this.G);
        d.q(this.H);
        d.q(this.I);
        if (this.Y > 0) {
            d.q(this.J);
        }
    }
    
    public void k0(final int y) {
        this.Y = y;
        this.A = (y > 0);
    }
    
    public void l() {
        if (this.d == null) {
            this.d = new l(this);
        }
        if (this.e == null) {
            this.e = new n(this);
        }
    }
    
    public void l0(final Object d0) {
        this.d0 = d0;
    }
    
    public d m(final d.b b) {
        switch (e$a.a[b.ordinal()]) {
            default: {
                throw new AssertionError((Object)b.name());
            }
            case 9: {
                return null;
            }
            case 8: {
                return this.L;
            }
            case 7: {
                return this.K;
            }
            case 6: {
                return this.M;
            }
            case 5: {
                return this.J;
            }
            case 4: {
                return this.I;
            }
            case 3: {
                return this.H;
            }
            case 2: {
                return this.G;
            }
            case 1: {
                return this.F;
            }
        }
    }
    
    public void m0(final String f0) {
        this.f0 = f0;
    }
    
    public int n() {
        return this.Y;
    }
    
    public void n0(String s) {
        Label_0261: {
            if (s == null || s.length() == 0) {
                break Label_0261;
            }
            final int n = -1;
            final int length = s.length();
            final int index = s.indexOf(44);
            final int n2 = 0;
            int v = n;
            int n3 = n2;
            if (index > 0) {
                v = n;
                n3 = n2;
                if (index < length - 1) {
                    final String substring = s.substring(0, index);
                    if (substring.equalsIgnoreCase("W")) {
                        v = 0;
                    }
                    else {
                        v = n;
                        if (substring.equalsIgnoreCase("H")) {
                            v = 1;
                        }
                    }
                    n3 = index + 1;
                }
            }
            final int index2 = s.indexOf(58);
            Label_0219: {
                if (index2 < 0 || index2 >= length - 1) {
                    break Label_0219;
                }
                final String substring2 = s.substring(n3, index2);
                s = s.substring(index2 + 1);
                while (true) {
                    if (substring2.length() <= 0 || s.length() <= 0) {
                        break Label_0241;
                    }
                    try {
                        final float float1 = Float.parseFloat(substring2);
                        final float float2 = Float.parseFloat(s);
                        while (true) {
                            if (float1 > 0.0f && float2 > 0.0f) {
                                if (v == 1) {
                                    final float u = Math.abs(float2 / float1);
                                    break Label_0243;
                                }
                                final float u = Math.abs(float1 / float2);
                                break Label_0243;
                            }
                            float u = 0.0f;
                            if (u > 0.0f) {
                                this.U = u;
                                this.V = v;
                            }
                            return;
                            s = s.substring(n3);
                            iftrue(Label_0241:)(s.length() <= 0);
                            Block_15: {
                                break Block_15;
                                this.U = 0.0f;
                                return;
                            }
                            u = Float.parseFloat(s);
                            continue;
                        }
                    }
                    catch (final NumberFormatException ex) {
                        continue;
                    }
                    break;
                }
            }
        }
    }
    
    public float o(final int n) {
        if (n == 0) {
            return this.b0;
        }
        if (n == 1) {
            return this.c0;
        }
        return -1.0f;
    }
    
    public void o0(final int n) {
        if (!this.A) {
            return;
        }
        final int x = n - this.Y;
        final int t = this.T;
        this.X = x;
        this.G.s(x);
        this.I.s(t + x);
        this.J.s(n);
        this.k = true;
    }
    
    public int p() {
        return this.T() + this.T;
    }
    
    public void p0(final int w, final int n) {
        this.F.s(w);
        this.H.s(n);
        this.W = w;
        this.S = n - w;
        this.j = true;
    }
    
    public Object q() {
        return this.d0;
    }
    
    public void q0(final int w) {
        this.F.s(w);
        this.W = w;
    }
    
    public String r() {
        return this.f0;
    }
    
    public void r0(final int x) {
        this.G.s(x);
        this.X = x;
    }
    
    public b s(final int n) {
        if (n == 0) {
            return this.y();
        }
        if (n == 1) {
            return this.O();
        }
        return null;
    }
    
    public void s0(final int x, final int n) {
        this.G.s(x);
        this.I.s(n);
        this.X = x;
        this.T = n - x;
        if (this.A) {
            this.J.s(x + this.Y);
        }
        this.k = true;
    }
    
    public float t() {
        return this.U;
    }
    
    public void t0(int t, int s, int n, int t2) {
        final int n2 = n - t;
        n = t2 - s;
        this.W = t;
        this.X = s;
        if (this.e0 == 8) {
            this.S = 0;
            this.T = 0;
            return;
        }
        t = n2;
        if (this.Q[0] == a.e.b.k.e.b.b) {
            s = this.S;
            if ((t = n2) < s) {
                t = s;
            }
        }
        s = n;
        if (this.Q[1] == a.e.b.k.e.b.b) {
            t2 = this.T;
            if ((s = n) < t2) {
                s = t2;
            }
        }
        this.S = t;
        this.T = s;
        t = this.a0;
        if (s < t) {
            this.T = t;
        }
        t = this.S;
        s = this.Z;
        if (t < s) {
            this.S = s;
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        final String g0 = this.g0;
        final String s = "";
        String string;
        if (g0 != null) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("type: ");
            sb2.append(this.g0);
            sb2.append(" ");
            string = sb2.toString();
        }
        else {
            string = "";
        }
        sb.append(string);
        String string2 = s;
        if (this.f0 != null) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("id: ");
            sb3.append(this.f0);
            sb3.append(" ");
            string2 = sb3.toString();
        }
        sb.append(string2);
        sb.append("(");
        sb.append(this.W);
        sb.append(", ");
        sb.append(this.X);
        sb.append(") - (");
        sb.append(this.S);
        sb.append(" x ");
        sb.append(this.T);
        sb.append(")");
        return sb.toString();
    }
    
    public int u() {
        return this.V;
    }
    
    public void u0(final boolean a) {
        this.A = a;
    }
    
    public int v() {
        if (this.e0 == 8) {
            return 0;
        }
        return this.T;
    }
    
    public void v0(final int t) {
        this.T = t;
        final int a0 = this.a0;
        if (t < a0) {
            this.T = a0;
        }
    }
    
    public float w() {
        return this.b0;
    }
    
    public void w0(final float b0) {
        this.b0 = b0;
    }
    
    public int x() {
        return this.h0;
    }
    
    public void x0(final int h0) {
        this.h0 = h0;
    }
    
    public b y() {
        return this.Q[0];
    }
    
    public void y0(int z, int s) {
        this.W = z;
        s -= z;
        this.S = s;
        z = this.Z;
        if (s < z) {
            this.S = z;
        }
    }
    
    public int z() {
        final d f = this.F;
        int n = 0;
        if (f != null) {
            n = 0 + f.g;
        }
        final d h = this.H;
        int n2 = n;
        if (h != null) {
            n2 = n + h.g;
        }
        return n2;
    }
    
    public void z0(final b b) {
        this.Q[0] = b;
    }
    
    public enum b
    {
        b, 
        c, 
        d, 
        e;
        
        private static final b[] f;
    }
}
