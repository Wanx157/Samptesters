package a.e.b.k;

import a.e.b.c;
import java.util.ArrayList;

public class l extends e
{
    public ArrayList<e> p0;
    
    public l() {
        this.p0 = (ArrayList<e>)new ArrayList();
    }
    
    public void a(final e e) {
        this.p0.add((Object)e);
        if (e.I() != null) {
            ((l)e.I()).c1(e);
        }
        e.M0((e)this);
    }
    
    public ArrayList<e> a1() {
        return this.p0;
    }
    
    public void b1() {
        final ArrayList<e> p0 = this.p0;
        if (p0 == null) {
            return;
        }
        for (int size = p0.size(), i = 0; i < size; ++i) {
            final e e = (e)this.p0.get(i);
            if (e instanceof l) {
                ((l)e).b1();
            }
        }
    }
    
    public void c1(final e e) {
        this.p0.remove((Object)e);
        e.h0();
    }
    
    public void d1() {
        this.p0.clear();
    }
    
    public void h0() {
        this.p0.clear();
        super.h0();
    }
    
    public void j0(final c c) {
        super.j0(c);
        for (int size = this.p0.size(), i = 0; i < size; ++i) {
            ((e)this.p0.get(i)).j0(c);
        }
    }
}
