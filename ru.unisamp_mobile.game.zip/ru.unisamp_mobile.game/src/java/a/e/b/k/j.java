package a.e.b.k;

import a.e.b.d;

public class j
{
    static boolean[] a;
    
    static {
        j.a = new boolean[3];
    }
    
    static void a(final f f, final d d, final e e) {
        e.l = -1;
        e.m = -1;
        if (((e)f).Q[0] != e.b.c && e.Q[0] == e.b.e) {
            final int g = e.F.g;
            final int n = ((e)f).R() - e.H.g;
            final a.e.b.k.d f2 = e.F;
            f2.i = d.q(f2);
            final a.e.b.k.d h = e.H;
            h.i = d.q(h);
            d.f(e.F.i, g);
            d.f(e.H.i, n);
            e.l = 2;
            e.y0(g, n);
        }
        if (((e)f).Q[1] != e.b.c && e.Q[1] == e.b.e) {
            final int g2 = e.G.g;
            final int n2 = ((e)f).v() - e.I.g;
            final a.e.b.k.d g3 = e.G;
            g3.i = d.q(g3);
            final a.e.b.k.d i = e.I;
            i.i = d.q(i);
            d.f(e.G.i, g2);
            d.f(e.I.i, n2);
            if (e.Y > 0 || e.Q() == 8) {
                final a.e.b.k.d j = e.J;
                j.i = d.q(j);
                d.f(e.J.i, e.Y + g2);
            }
            e.m = 2;
            e.P0(g2, n2);
        }
    }
    
    public static final boolean b(final int n, final int n2) {
        return (n & n2) == n2;
    }
}
