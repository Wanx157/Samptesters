package a.e.b.k;

import java.util.ArrayList;

public class c
{
    protected e a;
    protected e b;
    protected e c;
    protected e d;
    protected e e;
    protected e f;
    protected e g;
    protected ArrayList<e> h;
    protected int i;
    protected int j;
    protected float k;
    int l;
    int m;
    int n;
    private int o;
    private boolean p;
    protected boolean q;
    protected boolean r;
    protected boolean s;
    private boolean t;
    
    public c(final e a, final int o, final boolean p3) {
        this.k = 0.0f;
        this.p = false;
        this.a = a;
        this.o = o;
        this.p = p3;
    }
    
    private void b() {
        final int n = this.o * 2;
        e a = this.a;
        final boolean b = false;
        e e = a;
        int i = 0;
        while (i == 0) {
            ++this.i;
            final e[] l0 = a.l0;
            final int o = this.o;
            final e e2 = null;
            l0[o] = null;
            a.k0[o] = null;
            if (a.Q() != 8) {
                ++this.l;
                if (a.s(this.o) != a.e.b.k.e.b.d) {
                    this.m += a.C(this.o);
                }
                final int m = this.m + a.N[n].e();
                this.m = m;
                final d[] n2 = a.N;
                final int n3 = n + 1;
                this.m = m + n2[n3].e();
                final int n4 = this.n + a.N[n].e();
                this.n = n4;
                this.n = n4 + a.N[n3].e();
                if (this.b == null) {
                    this.b = a;
                }
                this.d = a;
                final e.b[] q = a.Q;
                final int o2 = this.o;
                if (q[o2] == a.e.b.k.e.b.d) {
                    final int[] p = a.p;
                    if (p[o2] == 0 || p[o2] == 3 || p[o2] == 2) {
                        ++this.j;
                        final float[] j0 = a.j0;
                        final int o3 = this.o;
                        final float n5 = j0[o3];
                        if (n5 > 0.0f) {
                            this.k += j0[o3];
                        }
                        if (c(a, this.o)) {
                            if (n5 < 0.0f) {
                                this.q = true;
                            }
                            else {
                                this.r = true;
                            }
                            if (this.h == null) {
                                this.h = (ArrayList<e>)new ArrayList();
                            }
                            this.h.add((Object)a);
                        }
                        if (this.f == null) {
                            this.f = a;
                        }
                        final e g = this.g;
                        if (g != null) {
                            g.k0[this.o] = a;
                        }
                        this.g = a;
                    }
                    if (this.o == 0) {
                        if (a.n == 0) {
                            if (a.q == 0) {
                                final int r = a.r;
                            }
                        }
                    }
                    else if (a.o == 0) {
                        if (a.t == 0) {
                            final int u = a.u;
                        }
                    }
                    final float u2 = a.U;
                }
            }
            if (e != a) {
                e.l0[this.o] = a;
            }
            final d f = a.N[n + 1].f;
            e e3 = e2;
            if (f != null) {
                final e d = f.d;
                final d[] n6 = d.N;
                e3 = e2;
                if (n6[n].f != null) {
                    if (n6[n].f.d != a) {
                        e3 = e2;
                    }
                    else {
                        e3 = d;
                    }
                }
            }
            if (e3 == null) {
                e3 = a;
                i = 1;
            }
            final e e4 = a;
            a = e3;
            e = e4;
        }
        final e b2 = this.b;
        if (b2 != null) {
            this.m -= b2.N[n].e();
        }
        final e d2 = this.d;
        if (d2 != null) {
            this.m -= d2.N[n + 1].e();
        }
        this.c = a;
        if (this.o == 0 && this.p) {
            this.e = a;
        }
        else {
            this.e = this.a;
        }
        boolean s = b;
        if (this.r) {
            s = b;
            if (this.q) {
                s = true;
            }
        }
        this.s = s;
    }
    
    private static boolean c(final e e, final int n) {
        if (e.Q() != 8 && e.Q[n] == e.b.d) {
            final int[] p2 = e.p;
            if (p2[n] == 0 || p2[n] == 3) {
                return true;
            }
        }
        return false;
    }
    
    public void a() {
        if (!this.t) {
            this.b();
        }
        this.t = true;
    }
}
