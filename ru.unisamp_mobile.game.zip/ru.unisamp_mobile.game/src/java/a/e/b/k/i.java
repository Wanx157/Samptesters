package a.e.b.k;

import a.e.b.k.m.o;
import java.util.ArrayList;
import java.util.Arrays;

public class i extends e implements h
{
    public e[] p0;
    public int q0;
    
    public i() {
        this.p0 = new e[4];
        this.q0 = 0;
    }
    
    public void a(final e e) {
        if (e != this) {
            if (e != null) {
                final int q0 = this.q0;
                final e[] p = this.p0;
                if (q0 + 1 > p.length) {
                    this.p0 = (e[])Arrays.copyOf((Object[])p, p.length * 2);
                }
                final e[] p2 = this.p0;
                final int q2 = this.q0;
                p2[q2] = e;
                this.q0 = q2 + 1;
            }
        }
    }
    
    public void a1(final ArrayList<o> list, final int n, final o o) {
        final int n2 = 0;
        int n3 = 0;
        int i;
        while (true) {
            i = n2;
            if (n3 >= this.q0) {
                break;
            }
            o.a(this.p0[n3]);
            ++n3;
        }
        while (i < this.q0) {
            a.e.b.k.m.i.a(this.p0[i], n, (ArrayList)list, o);
            ++i;
        }
    }
    
    public void b(final f f) {
    }
    
    public int b1(final int n) {
        for (int i = 0; i < this.q0; ++i) {
            final e e = this.p0[i];
            if (n == 0) {
                final int m0 = e.m0;
                if (m0 != -1) {
                    return m0;
                }
            }
            if (n == 1) {
                final int n2 = e.n0;
                if (n2 != -1) {
                    return n2;
                }
            }
        }
        return -1;
    }
    
    public void c() {
        this.q0 = 0;
        Arrays.fill((Object[])this.p0, (Object)null);
    }
}
