package a.e.b.k.m;

import a.e.b.k.g;
import a.e.b.k.e;

class j extends p
{
    public j(final e e) {
        super(e);
        e.d.f();
        e.e.f();
        super.f = ((g)e).b1();
    }
    
    private void q(final f f) {
        super.h.k.add((Object)f);
        f.l.add((Object)super.h);
    }
    
    @Override
    public void a(final d d) {
        final f h = super.h;
        if (!h.c) {
            return;
        }
        if (h.j) {
            return;
        }
        super.h.d((int)(((f)h.l.get(0)).g * ((g)super.b).e1() + 0.5f));
    }
    
    @Override
    void d() {
        final g g = (g)super.b;
        int c1 = g.c1();
        final int d1 = g.d1();
        g.e1();
        p p;
        if (g.b1() == 1) {
            final f h = super.h;
            Label_0222: {
                f f;
                if (c1 != -1) {
                    h.l.add((Object)super.b.R.d.h);
                    super.b.R.d.h.k.add((Object)super.h);
                    f = super.h;
                }
                else {
                    if (d1 == -1) {
                        h.b = true;
                        h.l.add((Object)super.b.R.d.i);
                        super.b.R.d.i.k.add((Object)super.h);
                        break Label_0222;
                    }
                    h.l.add((Object)super.b.R.d.i);
                    super.b.R.d.i.k.add((Object)super.h);
                    f = super.h;
                    c1 = -d1;
                }
                f.f = c1;
            }
            this.q(super.b.d.h);
            p = super.b.d;
        }
        else {
            final f h2 = super.h;
            Label_0438: {
                f f2;
                if (c1 != -1) {
                    h2.l.add((Object)super.b.R.e.h);
                    super.b.R.e.h.k.add((Object)super.h);
                    f2 = super.h;
                }
                else {
                    if (d1 == -1) {
                        h2.b = true;
                        h2.l.add((Object)super.b.R.e.i);
                        super.b.R.e.i.k.add((Object)super.h);
                        break Label_0438;
                    }
                    h2.l.add((Object)super.b.R.e.i);
                    super.b.R.e.i.k.add((Object)super.h);
                    f2 = super.h;
                    c1 = -d1;
                }
                f2.f = c1;
            }
            this.q(super.b.e.h);
            p = super.b.e;
        }
        this.q(p.i);
    }
    
    public void e() {
        if (((g)super.b).b1() == 1) {
            super.b.V0(super.h.g);
        }
        else {
            super.b.W0(super.h.g);
        }
    }
    
    @Override
    void f() {
        super.h.c();
    }
    
    @Override
    boolean m() {
        return false;
    }
}
