package a.e.b.k;

public interface h
{
    void a(final e p0);
    
    void b(final f p0);
    
    void c();
}
