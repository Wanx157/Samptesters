package a.e.b.k;

import a.e.b.k.m.b$a;

public class k extends i
{
    private boolean r0;
    
    public k() {
        this.r0 = false;
        new(a.e.b.k.m.b$a.class)();
    }
    
    @Override
    public void b(final f f) {
        this.c1();
    }
    
    public void c1() {
        for (int i = 0; i < super.q0; ++i) {
            final e e = super.p0[i];
            if (e != null) {
                e.E0(true);
            }
        }
    }
    
    public boolean d1() {
        return this.r0;
    }
}
