package a.e.b.k;

import java.util.Iterator;
import java.util.HashSet;
import java.io.PrintStream;
import java.util.ArrayList;
import a.e.b.k.m.h;
import a.e.b.i;
import java.util.Arrays;
import a.e.b.k.m.b$b;
import a.e.b.k.m.e;
import a.e.b.k.m.b;
import a.e.b.k.m.b$a;
import java.lang.ref.WeakReference;

public class f extends l
{
    c[] A0;
    c[] B0;
    private int C0;
    private boolean D0;
    private boolean E0;
    private WeakReference<d> F0;
    private WeakReference<d> G0;
    private WeakReference<d> H0;
    private WeakReference<d> I0;
    public b$a J0;
    b q0;
    public e r0;
    protected b$b s0;
    private boolean t0;
    public a.e.b.e u0;
    protected a.e.b.d v0;
    int w0;
    int x0;
    public int y0;
    public int z0;
    
    public f() {
        this.q0 = new b(this);
        this.r0 = new e(this);
        this.s0 = null;
        this.t0 = false;
        this.v0 = new a.e.b.d();
        this.y0 = 0;
        this.z0 = 0;
        this.A0 = new c[4];
        this.B0 = new c[4];
        this.C0 = 257;
        this.D0 = false;
        this.E0 = false;
        this.F0 = null;
        this.G0 = null;
        this.H0 = null;
        this.I0 = null;
        this.J0 = new b$a();
    }
    
    public static boolean A1(final a.e.b.k.e e, final b$b b$b, final b$a b$a, int j) {
        if (b$b == null) {
            return false;
        }
        b$a.a = e.y();
        b$a.b = e.O();
        b$a.c = e.R();
        b$a.d = e.v();
        b$a.i = false;
        b$a.j = j;
        final boolean b = b$a.a == e$b.d;
        if (b$a.b == e$b.d) {
            j = 1;
        }
        else {
            j = 0;
        }
        final boolean b2 = b && e.U > 0.0f;
        final boolean b3 = j != 0 && e.U > 0.0f;
        int n = b ? 1 : 0;
        if (b) {
            n = (b ? 1 : 0);
            if (e.V(0)) {
                n = (b ? 1 : 0);
                if (e.n == 0) {
                    n = (b ? 1 : 0);
                    if (!b2) {
                        b$a.a = e$b.c;
                        if (j != 0 && e.o == 0) {
                            b$a.a = e$b.b;
                        }
                        n = 0;
                    }
                }
            }
        }
        int n2;
        if ((n2 = j) != 0) {
            n2 = j;
            if (e.V(1)) {
                n2 = j;
                if (e.o == 0) {
                    n2 = j;
                    if (!b3) {
                        b$a.b = e$b.c;
                        if (n != 0 && e.n == 0) {
                            b$a.b = e$b.b;
                        }
                        n2 = 0;
                    }
                }
            }
        }
        if (e.e0()) {
            b$a.a = e$b.b;
            n = 0;
        }
        if (e.f0()) {
            b$a.b = e$b.b;
            n2 = 0;
        }
        if (b2) {
            if (e.p[0] == 4) {
                b$a.a = e$b.b;
            }
            else if (n2 == 0) {
                if (b$a.b == e$b.b) {
                    j = b$a.d;
                }
                else {
                    b$a.a = e$b.c;
                    b$b.a(e, b$a);
                    j = b$a.f;
                }
                b$a.a = e$b.b;
                final int v = e.V;
                float n3;
                if (v != 0 && v != -1) {
                    n3 = e.t() / j;
                }
                else {
                    n3 = e.t() * j;
                }
                b$a.c = (int)n3;
            }
        }
        if (b3) {
            if (e.p[1] == 4) {
                b$a.b = e$b.b;
            }
            else if (n == 0) {
                if (b$a.a == e$b.b) {
                    j = b$a.c;
                }
                else {
                    b$a.b = e$b.c;
                    b$b.a(e, b$a);
                    j = b$a.e;
                }
                b$a.b = e$b.b;
                final int v2 = e.V;
                float n4;
                if (v2 != 0 && v2 != -1) {
                    n4 = j * e.t();
                }
                else {
                    n4 = j / e.t();
                }
                b$a.d = (int)n4;
            }
        }
        b$b.a(e, b$a);
        e.U0(b$a.e);
        e.v0(b$a.f);
        e.u0(b$a.h);
        e.k0(b$a.g);
        b$a.j = b$a.k;
        return b$a.i;
    }
    
    private void C1() {
        this.y0 = 0;
        this.z0 = 0;
    }
    
    private void g1(final a.e.b.k.e e) {
        final int y0 = this.y0;
        final c[] b0 = this.B0;
        if (y0 + 1 >= b0.length) {
            this.B0 = (c[])Arrays.copyOf((Object[])b0, b0.length * 2);
        }
        this.B0[this.y0] = new c(e, 0, this.x1());
        ++this.y0;
    }
    
    private void j1(final d d, final i i) {
        this.v0.h(i, this.v0.q((Object)d), 0, 5);
    }
    
    private void k1(final d d, final i i) {
        this.v0.h(this.v0.q((Object)d), i, 0, 5);
    }
    
    private void l1(final a.e.b.k.e e) {
        final int z0 = this.z0;
        final c[] a0 = this.A0;
        if (z0 + 1 >= a0.length) {
            this.A0 = (c[])Arrays.copyOf((Object[])a0, a0.length * 2);
        }
        this.A0[this.z0] = new c(e, 1, this.x1());
        ++this.z0;
    }
    
    public boolean B1(final int n) {
        return (this.C0 & n) == n;
    }
    
    public void D1(final b$b s0) {
        this.s0 = s0;
        this.r0.n(s0);
    }
    
    public void E1(final int c0) {
        this.C0 = c0;
        a.e.b.d.r = this.B1(512);
    }
    
    public void F1(final boolean t0) {
        this.t0 = t0;
    }
    
    public void G1(final a.e.b.d d, final boolean[] array) {
        int i = 0;
        array[2] = false;
        final boolean b1 = this.B1(64);
        this.Z0(d, b1);
        while (i < super.p0.size()) {
            ((a.e.b.k.e)super.p0.get(i)).Z0(d, b1);
            ++i;
        }
    }
    
    public void H1() {
        this.q0.e(this);
    }
    
    public void Y0(final boolean b, final boolean b2) {
        super.Y0(b, b2);
        for (int size = super.p0.size(), i = 0; i < size; ++i) {
            ((a.e.b.k.e)super.p0.get(i)).Y0(b, b2);
        }
    }
    
    @Override
    public void b1() {
        super.W = 0;
        super.X = 0;
        this.D0 = false;
        this.E0 = false;
        final int size = super.p0.size();
        final int max = Math.max(0, this.R());
        final int max2 = Math.max(0, this.v());
        final e$b[] q = super.Q;
        final e$b e$b = q[1];
        final e$b e$b2 = q[0];
        final a.e.b.e u0 = this.u0;
        if (u0 != null) {
            ++u0.z;
        }
        if (j.b(this.C0, 1)) {
            h.h(this, this.r1());
            for (int i = 0; i < size; ++i) {
                final a.e.b.k.e e = (a.e.b.k.e)super.p0.get(i);
                if (e.d0() && !(e instanceof g) && !(e instanceof a) && !(e instanceof k) && !e.c0()) {
                    final e$b s = e.s(0);
                    final e$b s2 = e.s(1);
                    final e$b d = a.e.b.k.e$b.d;
                    if (s != d || e.n == 1 || s2 != d || e.o == 1) {
                        A1(e, this.s0, new b$a(), b$a.k);
                    }
                }
            }
        }
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        Label_0417: {
            if (size > 2) {
                final e$b c = a.e.b.k.e$b.c;
                if ((e$b2 == c || e$b == c) && j.b(this.C0, 1024) && a.e.b.k.m.i.c(this, this.r1())) {
                    int r = max;
                    if (e$b2 == a.e.b.k.e$b.c) {
                        if (max < this.R() && max > 0) {
                            this.U0(max);
                            this.D0 = true;
                            r = max;
                        }
                        else {
                            r = this.R();
                        }
                    }
                    int v = max2;
                    if (e$b == a.e.b.k.e$b.c) {
                        if (max2 < this.v() && max2 > 0) {
                            this.v0(max2);
                            this.E0 = true;
                            v = max2;
                        }
                        else {
                            v = this.v();
                        }
                    }
                    n = r;
                    n2 = 1;
                    n3 = v;
                    break Label_0417;
                }
            }
            n2 = 0;
            n3 = max2;
            n = max;
        }
        final boolean b = this.B1(64) || this.B1(128);
        final a.e.b.d v2 = this.v0;
        v2.h = false;
        v2.i = false;
        if (this.C0 != 0 && b) {
            v2.i = true;
        }
        final ArrayList<a.e.b.k.e> p0 = (ArrayList<a.e.b.k.e>)super.p0;
        final boolean b2 = this.y() == a.e.b.k.e$b.c || this.O() == a.e.b.k.e$b.c;
        this.C1();
        for (int j = 0; j < size; ++j) {
            final a.e.b.k.e e2 = (a.e.b.k.e)super.p0.get(j);
            if (e2 instanceof l) {
                ((l)e2).b1();
            }
        }
        final boolean b3 = this.B1(64);
        int n4 = 0;
        int k = 1;
        while (k != 0) {
            final int n5 = n4 + 1;
            int f1 = k;
            try {
                this.v0.D();
                f1 = k;
                this.C1();
                f1 = k;
                this.k(this.v0);
                for (int l = 0; l < size; ++l) {
                    f1 = k;
                    ((a.e.b.k.e)super.p0.get(l)).k(this.v0);
                }
                f1 = k;
                final boolean b4 = (f1 = (this.f1(this.v0) ? 1 : 0)) != 0;
                if (this.F0 != null) {
                    f1 = (b4 ? 1 : 0);
                    if (this.F0.get() != null) {
                        f1 = (b4 ? 1 : 0);
                        this.k1((d)this.F0.get(), this.v0.q((Object)super.G));
                        f1 = (b4 ? 1 : 0);
                        this.F0 = null;
                    }
                }
                f1 = (b4 ? 1 : 0);
                if (this.H0 != null) {
                    f1 = (b4 ? 1 : 0);
                    if (this.H0.get() != null) {
                        f1 = (b4 ? 1 : 0);
                        this.j1((d)this.H0.get(), this.v0.q((Object)super.I));
                        f1 = (b4 ? 1 : 0);
                        this.H0 = null;
                    }
                }
                f1 = (b4 ? 1 : 0);
                if (this.G0 != null) {
                    f1 = (b4 ? 1 : 0);
                    if (this.G0.get() != null) {
                        f1 = (b4 ? 1 : 0);
                        this.k1((d)this.G0.get(), this.v0.q((Object)super.F));
                        f1 = (b4 ? 1 : 0);
                        this.G0 = null;
                    }
                }
                f1 = (b4 ? 1 : 0);
                if (this.I0 != null) {
                    f1 = (b4 ? 1 : 0);
                    if (this.I0.get() != null) {
                        f1 = (b4 ? 1 : 0);
                        this.j1((d)this.I0.get(), this.v0.q((Object)super.H));
                        f1 = (b4 ? 1 : 0);
                        this.I0 = null;
                    }
                }
                if ((f1 = (b4 ? 1 : 0)) != 0) {
                    f1 = (b4 ? 1 : 0);
                    this.v0.z();
                    f1 = (b4 ? 1 : 0);
                }
            }
            catch (final Exception ex) {
                ex.printStackTrace();
                final PrintStream out = System.out;
                final StringBuilder sb = new StringBuilder();
                sb.append("EXCEPTION : ");
                sb.append((Object)ex);
                out.println(sb.toString());
            }
            final a.e.b.d v3 = this.v0;
            if (f1 != 0) {
                this.G1(v3, j.a);
            }
            else {
                this.Z0(v3, b3);
                for (int n6 = 0; n6 < size; ++n6) {
                    ((a.e.b.k.e)super.p0.get(n6)).Z0(this.v0, b3);
                }
            }
            boolean b6;
            if (b2 && n5 < 8 && j.a[2]) {
                int n7 = 0;
                int max3 = 0;
                int max4 = 0;
                while (n7 < size) {
                    final a.e.b.k.e e3 = (a.e.b.k.e)super.p0.get(n7);
                    max3 = Math.max(max3, e3.W + e3.R());
                    max4 = Math.max(max4, e3.X + e3.v());
                    ++n7;
                }
                final int max5 = Math.max(super.Z, max3);
                final int max6 = Math.max(super.a0, max4);
                boolean b5;
                int n8;
                if (e$b2 == a.e.b.k.e$b.c && this.R() < max5) {
                    this.U0(max5);
                    super.Q[0] = a.e.b.k.e$b.c;
                    b5 = true;
                    n8 = 1;
                }
                else {
                    b5 = false;
                    n8 = n2;
                }
                b6 = b5;
                n2 = n8;
                if (e$b == a.e.b.k.e$b.c) {
                    b6 = b5;
                    n2 = n8;
                    if (this.v() < max6) {
                        this.v0(max6);
                        super.Q[1] = a.e.b.k.e$b.c;
                        b6 = true;
                        n2 = 1;
                    }
                }
            }
            else {
                b6 = false;
            }
            final int max7 = Math.max(super.Z, this.R());
            if (max7 > this.R()) {
                this.U0(max7);
                super.Q[0] = a.e.b.k.e$b.b;
                b6 = true;
                n2 = 1;
            }
            final int max8 = Math.max(super.a0, this.v());
            if (max8 > this.v()) {
                this.v0(max8);
                super.Q[1] = a.e.b.k.e$b.b;
                b6 = true;
                n2 = 1;
            }
            boolean b7 = b6;
            Label_1504: {
                int n9;
                if ((n9 = n2) == 0) {
                    boolean b8 = b6;
                    int n10 = n2;
                    if (super.Q[0] == a.e.b.k.e$b.c) {
                        b8 = b6;
                        n10 = n2;
                        if (n > 0) {
                            b8 = b6;
                            n10 = n2;
                            if (this.R() > n) {
                                this.D0 = true;
                                super.Q[0] = a.e.b.k.e$b.b;
                                this.U0(n);
                                b8 = true;
                                n10 = 1;
                            }
                        }
                    }
                    b7 = b8;
                    n9 = n10;
                    if (super.Q[1] == a.e.b.k.e$b.c) {
                        b7 = b8;
                        n9 = n10;
                        if (n3 > 0) {
                            b7 = b8;
                            n9 = n10;
                            if (this.v() > n3) {
                                this.E0 = true;
                                super.Q[1] = a.e.b.k.e$b.b;
                                this.v0(n3);
                                n2 = 1;
                                k = 1;
                                break Label_1504;
                            }
                        }
                    }
                }
                k = (b7 ? 1 : 0);
                n2 = n9;
            }
            n4 = n5;
        }
        super.p0 = p0;
        if (n2 != 0) {
            final e$b[] q2 = super.Q;
            q2[0] = e$b2;
            q2[1] = e$b;
        }
        this.j0(this.v0.v());
    }
    
    void e1(final a.e.b.k.e e, final int n) {
        if (n == 0) {
            this.g1(e);
        }
        else if (n == 1) {
            this.l1(e);
        }
    }
    
    public boolean f1(final a.e.b.d d) {
        final boolean b1 = this.B1(64);
        this.g(d, b1);
        final int size = super.p0.size();
        int i = 0;
        boolean b2 = false;
        while (i < size) {
            final a.e.b.k.e e = (a.e.b.k.e)super.p0.get(i);
            e.C0(0, false);
            e.C0(1, false);
            if (e instanceof a) {
                b2 = true;
            }
            ++i;
        }
        if (b2) {
            for (int j = 0; j < size; ++j) {
                final a.e.b.k.e e2 = (a.e.b.k.e)super.p0.get(j);
                if (e2 instanceof a) {
                    ((a)e2).h1();
                }
            }
        }
        for (int k = 0; k < size; ++k) {
            final a.e.b.k.e e3 = (a.e.b.k.e)super.p0.get(k);
            if (e3.f()) {
                e3.g(d, b1);
            }
        }
        if (a.e.b.d.r) {
            final HashSet set = new HashSet();
            for (int l = 0; l < size; ++l) {
                final a.e.b.k.e e4 = (a.e.b.k.e)super.p0.get(l);
                if (!e4.f()) {
                    set.add((Object)e4);
                }
            }
            int n;
            if (this.y() == e$b.c) {
                n = 0;
            }
            else {
                n = 1;
            }
            this.e(this, d, set, n, false);
            for (final a.e.b.k.e e5 : set) {
                j.a(this, d, e5);
                e5.g(d, b1);
            }
        }
        else {
            for (int n2 = 0; n2 < size; ++n2) {
                final a.e.b.k.e e6 = (a.e.b.k.e)super.p0.get(n2);
                if (e6 instanceof f) {
                    final e$b[] q = e6.Q;
                    final e$b e$b = q[0];
                    final e$b e$b2 = q[1];
                    if (e$b == a.e.b.k.e$b.c) {
                        e6.z0(a.e.b.k.e$b.b);
                    }
                    if (e$b2 == a.e.b.k.e$b.c) {
                        e6.Q0(a.e.b.k.e$b.b);
                    }
                    e6.g(d, b1);
                    if (e$b == a.e.b.k.e$b.c) {
                        e6.z0(e$b);
                    }
                    if (e$b2 == a.e.b.k.e$b.c) {
                        e6.Q0(e$b2);
                    }
                }
                else {
                    j.a(this, d, e6);
                    if (!e6.f()) {
                        e6.g(d, b1);
                    }
                }
            }
        }
        if (this.y0 > 0) {
            a.e.b.k.b.b(this, d, (ArrayList)null, 0);
        }
        if (this.z0 > 0) {
            a.e.b.k.b.b(this, d, (ArrayList)null, 1);
        }
        return true;
    }
    
    @Override
    public void h0() {
        this.v0.D();
        this.w0 = 0;
        this.x0 = 0;
        super.h0();
    }
    
    public void h1(final d d) {
        final WeakReference<d> i0 = this.I0;
        if (i0 == null || i0.get() == null || d.d() > ((d)this.I0.get()).d()) {
            this.I0 = (WeakReference<d>)new WeakReference((Object)d);
        }
    }
    
    public void i1(final d d) {
        final WeakReference<d> g0 = this.G0;
        if (g0 == null || g0.get() == null || d.d() > ((d)this.G0.get()).d()) {
            this.G0 = (WeakReference<d>)new WeakReference((Object)d);
        }
    }
    
    void m1(final d d) {
        final WeakReference<d> h0 = this.H0;
        if (h0 == null || h0.get() == null || d.d() > ((d)this.H0.get()).d()) {
            this.H0 = (WeakReference<d>)new WeakReference((Object)d);
        }
    }
    
    void n1(final d d) {
        final WeakReference<d> f0 = this.F0;
        if (f0 == null || f0.get() == null || d.d() > ((d)this.F0.get()).d()) {
            this.F0 = (WeakReference<d>)new WeakReference((Object)d);
        }
    }
    
    public boolean o1(final boolean b) {
        return this.r0.f(b);
    }
    
    public boolean p1(final boolean b) {
        return this.r0.g(b);
    }
    
    public boolean q1(final boolean b, final int n) {
        return this.r0.h(b, n);
    }
    
    public b$b r1() {
        return this.s0;
    }
    
    public int s1() {
        return this.C0;
    }
    
    public a.e.b.d t1() {
        return this.v0;
    }
    
    public void u1() {
        this.r0.j();
    }
    
    public void v1() {
        this.r0.k();
    }
    
    public boolean w1() {
        return this.E0;
    }
    
    public boolean x1() {
        return this.t0;
    }
    
    public boolean y1() {
        return this.D0;
    }
    
    public long z1(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int n7, final int w0, final int x0) {
        this.w0 = w0;
        this.x0 = x0;
        return this.q0.d(this, n, w0, x0, n2, n3, n4, n5, n6, n7);
    }
}
