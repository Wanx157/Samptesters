package a.e.b.k.m;

import a.e.b.k.d$b;
import a.e.b.k.h;
import a.e.b.k.e$b;
import a.e.b.k.e;

public class n extends p
{
    public f k;
    g l;
    
    public n(final e e) {
        super(e);
        final f k = new f(this);
        this.k = k;
        this.l = null;
        super.h.e = f$a.g;
        super.i.e = f$a.h;
        k.e = f$a.i;
        super.f = 1;
    }
    
    @Override
    public void a(final d d) {
        final int n = n$a.a[((Enum)super.j).ordinal()];
        if (n != 1) {
            if (n != 2) {
                if (n == 3) {
                    final e b = super.b;
                    this.n(d, b.G, b.I, 1);
                    return;
                }
            }
            else {
                this.o(d);
            }
        }
        else {
            this.p(d);
        }
        final g e = super.e;
        Label_0263: {
            if (e.c && !e.j && super.d == e$b.d) {
                final e b2 = super.b;
                final int o = b2.o;
                int n3 = 0;
                Label_0255: {
                    if (o != 2) {
                        if (o != 3) {
                            break Label_0263;
                        }
                        if (!b2.d.e.j) {
                            break Label_0263;
                        }
                        final int u = b2.u();
                        float n2 = 0.0f;
                        Label_0202: {
                            if (u != -1) {
                                if (u == 0) {
                                    final e b3 = super.b;
                                    n2 = b3.d.e.g * b3.t();
                                    break Label_0202;
                                }
                                if (u != 1) {
                                    n3 = 0;
                                    break Label_0255;
                                }
                            }
                            final e b4 = super.b;
                            n2 = b4.d.e.g / b4.t();
                        }
                        n3 = (int)(n2 + 0.5f);
                    }
                    else {
                        final e i = b2.I();
                        if (i == null) {
                            break Label_0263;
                        }
                        final g e2 = i.e.e;
                        if (!e2.j) {
                            break Label_0263;
                        }
                        n3 = (int)(e2.g * super.b.v + 0.5f);
                    }
                }
                super.e.d(n3);
            }
        }
        final f h = super.h;
        if (h.c) {
            final f j = super.i;
            if (j.c) {
                if (h.j && j.j && super.e.j) {
                    return;
                }
                if (!super.e.j && super.d == e$b.d) {
                    final e b5 = super.b;
                    if (b5.n == 0 && !b5.b0()) {
                        final f f = (f)super.h.l.get(0);
                        final f f2 = (f)super.i.l.get(0);
                        final int g = f.g;
                        final f h2 = super.h;
                        final int n4 = g + h2.f;
                        final int n5 = f2.g + super.i.f;
                        h2.d(n4);
                        super.i.d(n5);
                        super.e.d(n5 - n4);
                        return;
                    }
                }
                if (!super.e.j && super.d == e$b.d && super.a == 1 && super.h.l.size() > 0 && super.i.l.size() > 0) {
                    final int n6 = ((f)super.i.l.get(0)).g + super.i.f - (((f)super.h.l.get(0)).g + super.h.f);
                    final g e3 = super.e;
                    final int m = e3.m;
                    if (n6 < m) {
                        e3.d(n6);
                    }
                    else {
                        e3.d(m);
                    }
                }
                if (!super.e.j) {
                    return;
                }
                if (super.h.l.size() > 0 && super.i.l.size() > 0) {
                    final f f3 = (f)super.h.l.get(0);
                    final f f4 = (f)super.i.l.get(0);
                    int g2 = f3.g + super.h.f;
                    int g3 = f4.g + super.i.f;
                    float k = super.b.M();
                    if (f3 == f4) {
                        g2 = f3.g;
                        g3 = f4.g;
                        k = 0.5f;
                    }
                    super.h.d((int)(g2 + 0.5f + (g3 - g2 - super.e.g) * k));
                    super.i.d(super.h.g + super.e.g);
                }
            }
        }
    }
    
    @Override
    void d() {
        final e b = super.b;
        if (b.a) {
            super.e.d(b.v());
        }
        if (!super.e.j) {
            super.d = super.b.O();
            if (super.b.U()) {
                this.l = (g)new a((p)this);
            }
            final e$b d = super.d;
            if (d != e$b.d) {
                if (d == e$b.e) {
                    final e i = super.b.I();
                    if (i != null && i.O() == e$b.b) {
                        final int v = i.v();
                        final int e = super.b.G.e();
                        final int e2 = super.b.I.e();
                        this.b(super.h, i.e.h, super.b.G.e());
                        this.b(super.i, i.e.i, -super.b.I.e());
                        super.e.d(v - e - e2);
                        return;
                    }
                }
                if (super.d == e$b.b) {
                    super.e.d(super.b.v());
                }
            }
        }
        else if (super.d == e$b.e) {
            final e j = super.b.I();
            if (j != null && j.O() == e$b.b) {
                this.b(super.h, j.e.h, super.b.G.e());
                this.b(super.i, j.e.i, -super.b.I.e());
                return;
            }
        }
        if (super.e.j) {
            final e b2 = super.b;
            if (b2.a) {
                final a.e.b.k.d[] n = b2.N;
                f f = null;
                f f2 = null;
                int n3 = 0;
                Label_0558: {
                    if (n[2].f != null && n[3].f != null) {
                        if (b2.b0()) {
                            super.h.f = super.b.N[2].e();
                            super.i.f = -super.b.N[3].e();
                        }
                        else {
                            final f h = this.h(super.b.N[2]);
                            if (h != null) {
                                this.b(super.h, h, super.b.N[2].e());
                            }
                            final f h2 = this.h(super.b.N[3]);
                            if (h2 != null) {
                                this.b(super.i, h2, -super.b.N[3].e());
                            }
                            super.h.b = true;
                            super.i.b = true;
                        }
                        if (!super.b.U()) {
                            return;
                        }
                    }
                    else {
                        final e b3 = super.b;
                        final a.e.b.k.d[] n2 = b3.N;
                        if (n2[2].f != null) {
                            final f h3 = this.h(n2[2]);
                            if (h3 == null) {
                                return;
                            }
                            this.b(super.h, h3, super.b.N[2].e());
                            this.b(super.i, super.h, super.e.g);
                            if (!super.b.U()) {
                                return;
                            }
                        }
                        else if (n2[3].f != null) {
                            final f h4 = this.h(n2[3]);
                            if (h4 != null) {
                                this.b(super.i, h4, -super.b.N[3].e());
                                this.b(super.h, super.i, -super.e.g);
                            }
                            if (!super.b.U()) {
                                return;
                            }
                        }
                        else if (n2[4].f != null) {
                            final f h5 = this.h(n2[4]);
                            if (h5 != null) {
                                this.b(this.k, h5, 0);
                                this.b(super.h, this.k, -super.b.n());
                                f = super.i;
                                f2 = super.h;
                                n3 = super.e.g;
                                break Label_0558;
                            }
                            return;
                        }
                        else {
                            if (b3 instanceof h || b3.I() == null || super.b.m(d$b.h).f != null) {
                                return;
                            }
                            this.b(super.h, super.b.I().e.h, super.b.T());
                            this.b(super.i, super.h, super.e.g);
                            if (!super.b.U()) {
                                return;
                            }
                        }
                    }
                    f = this.k;
                    f2 = super.h;
                    n3 = super.b.n();
                }
                this.b(f, f2, n3);
                return;
            }
        }
        Label_1113: {
            if (!super.e.j && super.d == e$b.d) {
                final e b4 = super.b;
                final int o = b4.o;
                p p;
                if (o != 2) {
                    if (o != 3) {
                        break Label_1113;
                    }
                    if (b4.b0()) {
                        break Label_1113;
                    }
                    final e b5 = super.b;
                    if (b5.n == 3) {
                        break Label_1113;
                    }
                    p = b5.d;
                }
                else {
                    final e k = b4.I();
                    if (k == null) {
                        break Label_1113;
                    }
                    p = k.e;
                }
                final g e3 = p.e;
                super.e.l.add((Object)e3);
                e3.k.add((Object)super.e);
                final g e4 = super.e;
                e4.b = true;
                e4.k.add((Object)super.h);
                super.e.k.add((Object)super.i);
            }
            else {
                super.e.b((d)this);
            }
        }
        final e b6 = super.b;
        final a.e.b.k.d[] n4 = b6.N;
        Label_1771: {
            f f3 = null;
            f f4 = null;
            g g = null;
            Label_1273: {
                Label_1255: {
                    if (n4[2].f == null || n4[3].f == null) {
                        final e b7 = super.b;
                        final a.e.b.k.d[] n5 = b7.N;
                        l l;
                        if (n5[2].f != null) {
                            final f h6 = this.h(n5[2]);
                            if (h6 == null) {
                                break Label_1771;
                            }
                            this.b(super.h, h6, super.b.N[2].e());
                            this.c(super.i, super.h, 1, super.e);
                            if (super.b.U()) {
                                this.c(this.k, super.h, 1, this.l);
                            }
                            if (super.d != e$b.d || super.b.t() <= 0.0f) {
                                break Label_1771;
                            }
                            l = super.b.d;
                            if (l.d != e$b.d) {
                                break Label_1771;
                            }
                        }
                        else if (n5[3].f != null) {
                            final f h7 = this.h(n5[3]);
                            if (h7 == null) {
                                break Label_1771;
                            }
                            this.b(super.i, h7, -super.b.N[3].e());
                            this.c(super.h, super.i, -1, super.e);
                            if (super.b.U()) {
                                break Label_1255;
                            }
                            break Label_1771;
                        }
                        else if (n5[4].f != null) {
                            final f h8 = this.h(n5[4]);
                            if (h8 != null) {
                                this.b(this.k, h8, 0);
                                this.c(super.h, this.k, -1, this.l);
                                f3 = super.i;
                                f4 = super.h;
                                g = super.e;
                                break Label_1273;
                            }
                            break Label_1771;
                        }
                        else {
                            if (b7 instanceof h || b7.I() == null) {
                                break Label_1771;
                            }
                            this.b(super.h, super.b.I().e.h, super.b.T());
                            this.c(super.i, super.h, 1, super.e);
                            if (super.b.U()) {
                                this.c(this.k, super.h, 1, this.l);
                            }
                            if (super.d != e$b.d || super.b.t() <= 0.0f) {
                                break Label_1771;
                            }
                            l = super.b.d;
                            if (l.d != e$b.d) {
                                break Label_1771;
                            }
                        }
                        l.e.k.add((Object)super.e);
                        super.e.l.add((Object)super.b.d.e);
                        super.e.a = (d)this;
                        break Label_1771;
                    }
                    if (b6.b0()) {
                        super.h.f = super.b.N[2].e();
                        super.i.f = -super.b.N[3].e();
                    }
                    else {
                        final f h9 = this.h(super.b.N[2]);
                        final f h10 = this.h(super.b.N[3]);
                        h9.b((d)this);
                        h10.b((d)this);
                        super.j = p$b.e;
                    }
                    if (!super.b.U()) {
                        break Label_1771;
                    }
                }
                f3 = this.k;
                f4 = super.h;
                g = this.l;
            }
            this.c(f3, f4, 1, g);
        }
        if (super.e.l.size() == 0) {
            super.e.c = true;
        }
    }
    
    public void e() {
        final f h = super.h;
        if (h.j) {
            super.b.W0(h.g);
        }
    }
    
    @Override
    void f() {
        super.c = null;
        super.h.c();
        super.i.c();
        this.k.c();
        super.e.c();
        super.g = false;
    }
    
    @Override
    boolean m() {
        return super.d != e$b.d || super.b.o == 0;
    }
    
    void q() {
        super.g = false;
        super.h.c();
        super.h.j = false;
        super.i.c();
        super.i.j = false;
        this.k.c();
        this.k.j = false;
        super.e.j = false;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("VerticalRun ");
        sb.append(super.b.r());
        return sb.toString();
    }
}
