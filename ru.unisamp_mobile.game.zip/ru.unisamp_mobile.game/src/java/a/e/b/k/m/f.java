package a.e.b.k.m;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

public class f implements d
{
    public d a;
    public boolean b;
    public boolean c;
    p d;
    f.f$a e;
    int f;
    public int g;
    int h;
    g i;
    public boolean j;
    List<d> k;
    List<f> l;
    
    public f(final p d) {
        this.a = null;
        this.b = false;
        this.c = false;
        this.e = a.e.b.k.m.f.f$a.b;
        this.h = 1;
        this.i = null;
        this.j = false;
        this.k = (List<d>)new ArrayList();
        this.l = (List<f>)new ArrayList();
        this.d = d;
    }
    
    public void a(d d) {
        final Iterator iterator = this.l.iterator();
        while (iterator.hasNext()) {
            if (!((f)iterator.next()).j) {
                return;
            }
        }
        this.c = true;
        d = this.a;
        if (d != null) {
            d.a((d)this);
        }
        if (this.b) {
            this.d.a((d)this);
            return;
        }
        f f = null;
        int n = 0;
        for (final f f2 : this.l) {
            if (f2 instanceof g) {
                continue;
            }
            ++n;
            f = f2;
        }
        if (f != null && n == 1 && f.j) {
            final g i = this.i;
            if (i != null) {
                if (!i.j) {
                    return;
                }
                this.f = this.h * i.g;
            }
            this.d(f.g + this.f);
        }
        d = this.a;
        if (d != null) {
            d.a((d)this);
        }
    }
    
    public void b(final d d) {
        this.k.add((Object)d);
        if (this.j) {
            d.a(d);
        }
    }
    
    public void c() {
        this.l.clear();
        this.k.clear();
        this.j = false;
        this.g = 0;
        this.c = false;
        this.b = false;
    }
    
    public void d(final int g) {
        if (this.j) {
            return;
        }
        this.j = true;
        this.g = g;
        for (final d d : this.k) {
            d.a(d);
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.d.b.r());
        sb.append(":");
        sb.append((Object)this.e);
        sb.append("(");
        Object value;
        if (this.j) {
            value = this.g;
        }
        else {
            value = "unresolved";
        }
        sb.append(value);
        sb.append(") <t=");
        sb.append(this.l.size());
        sb.append(":d=");
        sb.append(this.k.size());
        sb.append(">");
        return sb.toString();
    }
}
