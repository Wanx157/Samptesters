package a.e.b.k.m;

import a.e.b.k.e$b;
import java.util.Iterator;
import a.e.b.k.f;
import a.e.b.k.e;
import java.util.ArrayList;

public class c extends p
{
    ArrayList<p> k;
    private int l;
    
    public c(final e e, final int f) {
        super(e);
        this.k = (ArrayList<p>)new ArrayList();
        super.f = f;
        this.q();
    }
    
    private void q() {
        e b = super.b;
        while (true) {
            final e j = b.J(super.f);
            if (j == null) {
                break;
            }
            b = j;
        }
        super.b = b;
        this.k.add((Object)b.L(super.f));
        for (e e = b.H(super.f); e != null; e = e.H(super.f)) {
            this.k.add((Object)e.L(super.f));
        }
        for (final p p : this.k) {
            final int f = super.f;
            if (f == 0) {
                p.b.b = this;
            }
            else {
                if (f != 1) {
                    continue;
                }
                p.b.c = this;
            }
        }
        if (super.f == 0 && ((f)super.b.I()).x1() && this.k.size() > 1) {
            final ArrayList<p> k = this.k;
            super.b = ((p)k.get(k.size() - 1)).b;
        }
        int l;
        if (super.f == 0) {
            l = super.b.x();
        }
        else {
            l = super.b.N();
        }
        this.l = l;
    }
    
    private e r() {
        for (int i = 0; i < this.k.size(); ++i) {
            final p p = (p)this.k.get(i);
            if (p.b.Q() != 8) {
                return p.b;
            }
        }
        return null;
    }
    
    private e s() {
        for (int i = this.k.size() - 1; i >= 0; --i) {
            final p p = (p)this.k.get(i);
            if (p.b.Q() != 8) {
                return p.b;
            }
        }
        return null;
    }
    
    @Override
    public void a(final d d) {
        if (super.h.j) {
            if (super.i.j) {
                final e i = super.b.I();
                final boolean b = i != null && i instanceof f && ((f)i).x1();
                final int n = super.i.g - super.h.g;
                final int size = this.k.size();
                int n2 = 0;
                int n3;
                int n4;
                while (true) {
                    n3 = -1;
                    if (n2 >= size) {
                        n4 = -1;
                        break;
                    }
                    n4 = n2;
                    if (((p)this.k.get(n2)).b.Q() != 8) {
                        break;
                    }
                    ++n2;
                }
                int n6;
                final int n5 = n6 = size - 1;
                int n7;
                while (true) {
                    n7 = n3;
                    if (n6 < 0) {
                        break;
                    }
                    if (((p)this.k.get(n6)).b.Q() != 8) {
                        n7 = n6;
                        break;
                    }
                    --n6;
                }
                int j = 0;
                while (true) {
                    while (j < 2) {
                        int k = 0;
                        int n8 = 0;
                        int n9 = 0;
                        int n10 = 0;
                        float n11 = 0.0f;
                        while (k < size) {
                            final p p = (p)this.k.get(k);
                            int n12;
                            int n13;
                            if (p.b.Q() == 8) {
                                n12 = n8;
                                n13 = n9;
                            }
                            else {
                                final int n14 = n10 + 1;
                                int n15 = n8;
                                if (k > 0) {
                                    n15 = n8;
                                    if (k >= n4) {
                                        n15 = n8 + p.h.f;
                                    }
                                }
                                final int g = p.e.g;
                                final boolean b2 = p.d != e$b.d;
                                boolean b3 = false;
                                int n16 = 0;
                                int n17 = 0;
                                Label_0466: {
                                    if (b2) {
                                        if (super.f == 0 && !p.b.d.e.j) {
                                            return;
                                        }
                                        b3 = b2;
                                        n16 = g;
                                        n17 = n9;
                                        if (super.f == 1) {
                                            b3 = b2;
                                            n16 = g;
                                            n17 = n9;
                                            if (!p.b.e.e.j) {
                                                return;
                                            }
                                        }
                                    }
                                    else {
                                        int n18;
                                        if (p.a == 1 && j == 0) {
                                            final int m = p.e.m;
                                            n17 = n9 + 1;
                                            n18 = m;
                                        }
                                        else {
                                            b3 = b2;
                                            n16 = g;
                                            n17 = n9;
                                            if (!p.e.j) {
                                                break Label_0466;
                                            }
                                            n17 = n9;
                                            n18 = g;
                                        }
                                        b3 = true;
                                        n16 = n18;
                                    }
                                }
                                int n21;
                                float n22;
                                if (!b3) {
                                    final int n19 = n17 + 1;
                                    final float n20 = p.b.j0[super.f];
                                    n21 = n15;
                                    n17 = n19;
                                    n22 = n11;
                                    if (n20 >= 0.0f) {
                                        n22 = n11 + n20;
                                        n21 = n15;
                                        n17 = n19;
                                    }
                                }
                                else {
                                    n21 = n15 + n16;
                                    n22 = n11;
                                }
                                n12 = n21;
                                n13 = n17;
                                n10 = n14;
                                n11 = n22;
                                if (k < n5) {
                                    n12 = n21;
                                    n13 = n17;
                                    n10 = n14;
                                    n11 = n22;
                                    if (k < n7) {
                                        n12 = n21 + -p.i.f;
                                        n11 = n22;
                                        n10 = n14;
                                        n13 = n17;
                                    }
                                }
                            }
                            ++k;
                            n8 = n12;
                            n9 = n13;
                        }
                        if (n8 >= n && n9 != 0) {
                            ++j;
                        }
                        else {
                            final int n23 = n10;
                            int n24 = n9;
                            int n25 = super.h.g;
                            if (b) {
                                n25 = super.i.g;
                            }
                            int n26 = n25;
                            if (n8 > n) {
                                final int n27 = (int)((n8 - n) / 2.0f + 0.5f);
                                if (b) {
                                    n26 = n25 + n27;
                                }
                                else {
                                    n26 = n25 - n27;
                                }
                            }
                            int n43;
                            if (n24 > 0) {
                                final float n28 = (float)(n - n8);
                                final int n29 = (int)(n28 / n24 + 0.5f);
                                int l = 0;
                                int n30 = 0;
                                final int n31 = n26;
                                while (l < size) {
                                    final p p2 = (p)this.k.get(l);
                                    if (p2.b.Q() != 8) {
                                        if (p2.d == e$b.d && !p2.e.j) {
                                            int n32;
                                            if (n11 > 0.0f) {
                                                n32 = (int)(p2.b.j0[super.f] * n28 / n11 + 0.5f);
                                            }
                                            else {
                                                n32 = n29;
                                            }
                                            int n35 = 0;
                                            int n36 = 0;
                                            Label_1050: {
                                                int n34;
                                                if (super.f == 0) {
                                                    final e b4 = p2.b;
                                                    final int r = b4.r;
                                                    final int q = b4.q;
                                                    int min;
                                                    if (p2.a == 1) {
                                                        min = Math.min(n32, p2.e.m);
                                                    }
                                                    else {
                                                        min = n32;
                                                    }
                                                    final int n33 = n34 = Math.max(q, min);
                                                    if (r > 0) {
                                                        n34 = Math.min(r, n33);
                                                    }
                                                    n35 = n32;
                                                    n36 = n30;
                                                    if (n34 == n32) {
                                                        break Label_1050;
                                                    }
                                                }
                                                else {
                                                    final e b5 = p2.b;
                                                    final int u = b5.u;
                                                    final int t = b5.t;
                                                    int min2;
                                                    if (p2.a == 1) {
                                                        min2 = Math.min(n32, p2.e.m);
                                                    }
                                                    else {
                                                        min2 = n32;
                                                    }
                                                    final int n37 = n34 = Math.max(t, min2);
                                                    if (u > 0) {
                                                        n34 = Math.min(u, n37);
                                                    }
                                                    n35 = n32;
                                                    n36 = n30;
                                                    if (n34 == n32) {
                                                        break Label_1050;
                                                    }
                                                }
                                                n36 = n30 + 1;
                                                n35 = n34;
                                            }
                                            p2.e.d(n35);
                                            n30 = n36;
                                        }
                                    }
                                    ++l;
                                }
                                int n40;
                                if (n30 > 0) {
                                    final int n38 = n24 - n30;
                                    int n39 = 0;
                                    n40 = 0;
                                    while (n39 < size) {
                                        final p p3 = (p)this.k.get(n39);
                                        if (p3.b.Q() != 8) {
                                            int n41 = n40;
                                            if (n39 > 0) {
                                                n41 = n40;
                                                if (n39 >= n4) {
                                                    n41 = n40 + p3.h.f;
                                                }
                                            }
                                            final int n42 = n40 = n41 + p3.e.g;
                                            if (n39 < n5) {
                                                n40 = n42;
                                                if (n39 < n7) {
                                                    n40 = n42 + -p3.i.f;
                                                }
                                            }
                                        }
                                        ++n39;
                                    }
                                    n24 = n38;
                                }
                                else {
                                    n40 = n8;
                                }
                                if (this.l == 2 && n30 == 0) {
                                    this.l = 0;
                                    n8 = n40;
                                    n43 = n24;
                                    n26 = n31;
                                }
                                else {
                                    n8 = n40;
                                    n43 = n24;
                                    n26 = n31;
                                }
                            }
                            else {
                                n43 = n24;
                            }
                            if (n8 > n) {
                                this.l = 2;
                            }
                            if (n23 > 0 && n43 == 0 && n4 == n7) {
                                this.l = 2;
                            }
                            final int l2 = this.l;
                            if (l2 == 1) {
                                int n44;
                                if (n23 > 1) {
                                    n44 = (n - n8) / (n23 - 1);
                                }
                                else if (n23 == 1) {
                                    n44 = (n - n8) / 2;
                                }
                                else {
                                    n44 = 0;
                                }
                                int n45 = n44;
                                if (n43 > 0) {
                                    n45 = 0;
                                }
                                int n46 = 0;
                                int n47 = n26;
                                while (n46 < size) {
                                    int n48;
                                    if (b) {
                                        n48 = size - (n46 + 1);
                                    }
                                    else {
                                        n48 = n46;
                                    }
                                    final p p4 = (p)this.k.get(n48);
                                    int n49;
                                    if (p4.b.Q() == 8) {
                                        p4.h.d(n47);
                                        p4.i.d(n47);
                                        n49 = n47;
                                    }
                                    else {
                                        int n50 = n47;
                                        if (n46 > 0) {
                                            if (b) {
                                                n50 = n47 - n45;
                                            }
                                            else {
                                                n50 = n47 + n45;
                                            }
                                        }
                                        int n51 = n50;
                                        if (n46 > 0) {
                                            n51 = n50;
                                            if (n46 >= n4) {
                                                final int f = p4.h.f;
                                                if (b) {
                                                    n51 = n50 - f;
                                                }
                                                else {
                                                    n51 = n50 + f;
                                                }
                                            }
                                        }
                                        a.e.b.k.m.f f2;
                                        if (b) {
                                            f2 = p4.i;
                                        }
                                        else {
                                            f2 = p4.h;
                                        }
                                        f2.d(n51);
                                        final g e = p4.e;
                                        int n53;
                                        final int n52 = n53 = e.g;
                                        if (p4.d == e$b.d) {
                                            n53 = n52;
                                            if (p4.a == 1) {
                                                n53 = e.m;
                                            }
                                        }
                                        int n54;
                                        if (b) {
                                            n54 = n51 - n53;
                                        }
                                        else {
                                            n54 = n51 + n53;
                                        }
                                        a.e.b.k.m.f f3;
                                        if (b) {
                                            f3 = p4.h;
                                        }
                                        else {
                                            f3 = p4.i;
                                        }
                                        f3.d(n54);
                                        p4.g = true;
                                        n49 = n54;
                                        if (n46 < n5) {
                                            n49 = n54;
                                            if (n46 < n7) {
                                                final int n55 = -p4.i.f;
                                                if (b) {
                                                    n49 = n54 - n55;
                                                }
                                                else {
                                                    n49 = n54 + n55;
                                                }
                                            }
                                        }
                                    }
                                    ++n46;
                                    n47 = n49;
                                }
                                return;
                            }
                            if (l2 == 0) {
                                int n56 = (n - n8) / (n23 + 1);
                                if (n43 > 0) {
                                    n56 = 0;
                                }
                                for (int n57 = 0; n57 < size; ++n57) {
                                    int n58;
                                    if (b) {
                                        n58 = size - (n57 + 1);
                                    }
                                    else {
                                        n58 = n57;
                                    }
                                    final p p5 = (p)this.k.get(n58);
                                    if (p5.b.Q() == 8) {
                                        p5.h.d(n26);
                                        p5.i.d(n26);
                                    }
                                    else {
                                        int n59;
                                        if (b) {
                                            n59 = n26 - n56;
                                        }
                                        else {
                                            n59 = n26 + n56;
                                        }
                                        int n60 = n59;
                                        if (n57 > 0) {
                                            n60 = n59;
                                            if (n57 >= n4) {
                                                final int f4 = p5.h.f;
                                                if (b) {
                                                    n60 = n59 - f4;
                                                }
                                                else {
                                                    n60 = n59 + f4;
                                                }
                                            }
                                        }
                                        a.e.b.k.m.f f5;
                                        if (b) {
                                            f5 = p5.i;
                                        }
                                        else {
                                            f5 = p5.h;
                                        }
                                        f5.d(n60);
                                        final g e2 = p5.e;
                                        int n62;
                                        final int n61 = n62 = e2.g;
                                        if (p5.d == e$b.d) {
                                            n62 = n61;
                                            if (p5.a == 1) {
                                                n62 = Math.min(n61, e2.m);
                                            }
                                        }
                                        int n63;
                                        if (b) {
                                            n63 = n60 - n62;
                                        }
                                        else {
                                            n63 = n60 + n62;
                                        }
                                        a.e.b.k.m.f f6;
                                        if (b) {
                                            f6 = p5.h;
                                        }
                                        else {
                                            f6 = p5.i;
                                        }
                                        f6.d(n63);
                                        n26 = n63;
                                        if (n57 < n5) {
                                            n26 = n63;
                                            if (n57 < n7) {
                                                final int n64 = -p5.i.f;
                                                if (b) {
                                                    n26 = n63 - n64;
                                                }
                                                else {
                                                    n26 = n63 + n64;
                                                }
                                            }
                                        }
                                    }
                                }
                                return;
                            }
                            if (l2 == 2) {
                                float n65;
                                if (super.f == 0) {
                                    n65 = super.b.w();
                                }
                                else {
                                    n65 = super.b.M();
                                }
                                float n66 = n65;
                                if (b) {
                                    n66 = 1.0f - n65;
                                }
                                int n67 = (int)((n - n8) * n66 + 0.5f);
                                if (n67 < 0 || n43 > 0) {
                                    n67 = 0;
                                }
                                int n68;
                                if (b) {
                                    n68 = n26 - n67;
                                }
                                else {
                                    n68 = n26 + n67;
                                }
                                for (int n69 = 0; n69 < size; ++n69) {
                                    int n70;
                                    if (b) {
                                        n70 = size - (n69 + 1);
                                    }
                                    else {
                                        n70 = n69;
                                    }
                                    final p p6 = (p)this.k.get(n70);
                                    if (p6.b.Q() == 8) {
                                        p6.h.d(n68);
                                        p6.i.d(n68);
                                    }
                                    else {
                                        int n71 = n68;
                                        if (n69 > 0) {
                                            n71 = n68;
                                            if (n69 >= n4) {
                                                final int f7 = p6.h.f;
                                                if (b) {
                                                    n71 = n68 - f7;
                                                }
                                                else {
                                                    n71 = n68 + f7;
                                                }
                                            }
                                        }
                                        a.e.b.k.m.f f8;
                                        if (b) {
                                            f8 = p6.i;
                                        }
                                        else {
                                            f8 = p6.h;
                                        }
                                        f8.d(n71);
                                        final g e3 = p6.e;
                                        int n72 = e3.g;
                                        if (p6.d == e$b.d && p6.a == 1) {
                                            n72 = e3.m;
                                        }
                                        int n73;
                                        if (b) {
                                            n73 = n71 - n72;
                                        }
                                        else {
                                            n73 = n71 + n72;
                                        }
                                        a.e.b.k.m.f f9;
                                        if (b) {
                                            f9 = p6.h;
                                        }
                                        else {
                                            f9 = p6.i;
                                        }
                                        f9.d(n73);
                                        n68 = n73;
                                        if (n69 < n5) {
                                            n68 = n73;
                                            if (n69 < n7) {
                                                final int n74 = -p6.i.f;
                                                if (b) {
                                                    n68 = n73 - n74;
                                                }
                                                else {
                                                    n68 = n73 + n74;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            return;
                        }
                    }
                    final int n23 = 0;
                    int n8 = 0;
                    int n24 = 0;
                    float n11 = 0.0f;
                    continue;
                }
            }
        }
    }
    
    @Override
    void d() {
        final Iterator iterator = this.k.iterator();
        while (iterator.hasNext()) {
            ((p)iterator.next()).d();
        }
        final int size = this.k.size();
        if (size < 1) {
            return;
        }
        final e b = ((p)this.k.get(0)).b;
        final e b2 = ((p)this.k.get(size - 1)).b;
        Label_0280: {
            a.e.b.k.m.f f2;
            int n2;
            if (super.f == 0) {
                final a.e.b.k.d f = b.F;
                final a.e.b.k.d h = b2.H;
                final a.e.b.k.m.f i = this.i(f, 0);
                int n = f.e();
                final e r = this.r();
                if (r != null) {
                    n = r.F.e();
                }
                if (i != null) {
                    this.b(super.h, i, n);
                }
                f2 = this.i(h, 0);
                n2 = h.e();
                final e s = this.s();
                if (s != null) {
                    n2 = s.H.e();
                }
                if (f2 == null) {
                    break Label_0280;
                }
            }
            else {
                final a.e.b.k.d g = b.G;
                final a.e.b.k.d j = b2.I;
                final a.e.b.k.m.f k = this.i(g, 1);
                int n3 = g.e();
                final e r2 = this.r();
                if (r2 != null) {
                    n3 = r2.G.e();
                }
                if (k != null) {
                    this.b(super.h, k, n3);
                }
                f2 = this.i(j, 1);
                n2 = j.e();
                final e s2 = this.s();
                if (s2 != null) {
                    n2 = s2.I.e();
                }
                if (f2 == null) {
                    break Label_0280;
                }
            }
            this.b(super.i, f2, -n2);
        }
        super.h.a = (d)this;
        super.i.a = (d)this;
    }
    
    public void e() {
        for (int i = 0; i < this.k.size(); ++i) {
            ((p)this.k.get(i)).e();
        }
    }
    
    @Override
    void f() {
        super.c = null;
        final Iterator iterator = this.k.iterator();
        while (iterator.hasNext()) {
            ((p)iterator.next()).f();
        }
    }
    
    @Override
    public long j() {
        final int size = this.k.size();
        long n = 0L;
        for (int i = 0; i < size; ++i) {
            final p p = (p)this.k.get(i);
            n = n + p.h.f + p.j() + p.i.f;
        }
        return n;
    }
    
    @Override
    boolean m() {
        for (int size = this.k.size(), i = 0; i < size; ++i) {
            if (!((p)this.k.get(i)).m()) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("ChainRun ");
        String s;
        if (super.f == 0) {
            s = "horizontal : ";
        }
        else {
            s = "vertical : ";
        }
        sb.append(s);
        String s2 = sb.toString();
        for (final p p : this.k) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(s2);
            sb2.append("<");
            final String string = sb2.toString();
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(string);
            sb3.append((Object)p);
            final String string2 = sb3.toString();
            final StringBuilder sb4 = new StringBuilder();
            sb4.append(string2);
            sb4.append("> ");
            s2 = sb4.toString();
        }
        return s2;
    }
}
