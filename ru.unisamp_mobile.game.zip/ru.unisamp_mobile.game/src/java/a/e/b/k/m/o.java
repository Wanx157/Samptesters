package a.e.b.k.m;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import a.e.b.k.b;
import a.e.b.k.f;
import a.e.b.d;
import a.e.b.k.e;
import java.util.ArrayList;

public class o
{
    static int f;
    ArrayList<e> a;
    int b;
    int c;
    ArrayList<a> d;
    private int e;
    
    public o(final int c) {
        this.a = (ArrayList<e>)new ArrayList();
        this.b = -1;
        this.c = 0;
        this.d = null;
        this.e = -1;
        final int f = o.f;
        o.f = f + 1;
        this.b = f;
        this.c = c;
    }
    
    private String e() {
        final int c = this.c;
        if (c == 0) {
            return "Horizontal";
        }
        if (c == 1) {
            return "Vertical";
        }
        if (c == 2) {
            return "Both";
        }
        return "Unknown";
    }
    
    private int j(final d d, final ArrayList<e> list, int n) {
        final int n2 = 0;
        final f f = (f)((e)list.get(0)).I();
        d.D();
        ((e)f).g(d, false);
        for (int i = 0; i < list.size(); ++i) {
            ((e)list.get(i)).g(d, false);
        }
        if (n == 0 && f.y0 > 0) {
            a.e.b.k.b.b(f, d, list, 0);
        }
        if (n == 1 && f.z0 > 0) {
            a.e.b.k.b.b(f, d, list, 1);
        }
        try {
            d.z();
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
        this.d = (ArrayList<a>)new ArrayList();
        for (int j = n2; j < list.size(); ++j) {
            this.d.add((Object)new a((e)list.get(j), d, n));
        }
        a.e.b.k.d d2;
        if (n == 0) {
            n = d.x(((e)f).F);
            d2 = ((e)f).H;
        }
        else {
            n = d.x(((e)f).G);
            d2 = ((e)f).I;
        }
        final int x = d.x(d2);
        d.D();
        return x - n;
    }
    
    public boolean a(final e e) {
        if (this.a.contains((Object)e)) {
            return false;
        }
        this.a.add((Object)e);
        return true;
    }
    
    public void b(final ArrayList<o> list) {
        final int size = this.a.size();
        if (this.e != -1 && size > 0) {
            for (int i = 0; i < list.size(); ++i) {
                final o o = (o)list.get(i);
                if (this.e == o.b) {
                    this.g(this.c, o);
                }
            }
        }
        if (size == 0) {
            list.remove((Object)this);
        }
    }
    
    public int c() {
        return this.b;
    }
    
    public int d() {
        return this.c;
    }
    
    public int f(final d d, final int n) {
        if (this.a.size() == 0) {
            return 0;
        }
        return this.j(d, this.a, n);
    }
    
    public void g(final int n, final o o) {
        for (final e e : this.a) {
            o.a(e);
            final int c = o.c();
            if (n == 0) {
                e.m0 = c;
            }
            else {
                e.n0 = c;
            }
        }
        this.e = o.b;
    }
    
    public void h(final boolean b) {
    }
    
    public void i(final int c) {
        this.c = c;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.e());
        sb.append(" [");
        sb.append(this.b);
        sb.append("] <");
        String s = sb.toString();
        for (final e e : this.a) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(s);
            sb2.append(" ");
            sb2.append(e.r());
            s = sb2.toString();
        }
        final StringBuilder sb3 = new StringBuilder();
        sb3.append(s);
        sb3.append(" >");
        return sb3.toString();
    }
    
    class a
    {
        public a(final o o, final e e, final d d, final int n) {
            new WeakReference((Object)e);
            d.x(e.F);
            d.x(e.G);
            d.x(e.H);
            d.x(e.I);
            d.x(e.J);
        }
    }
}
