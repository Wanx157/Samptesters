package a.e.b.k.m;

import java.util.Iterator;
import a.e.b.k.a;
import a.e.b.k.e;

class k extends p
{
    public k(final e e) {
        super(e);
    }
    
    private void q(final f f) {
        super.h.k.add((Object)f);
        f.l.add((Object)super.h);
    }
    
    @Override
    public void a(final d d) {
        final a a = (a)super.b;
        final int e1 = a.e1();
        final Iterator iterator = super.h.l.iterator();
        int n = 0;
        int n2 = -1;
        while (iterator.hasNext()) {
            final int g = ((f)iterator.next()).g;
            int n3;
            if (n2 == -1 || g < (n3 = n2)) {
                n3 = g;
            }
            n2 = n3;
            if (n < g) {
                n = g;
                n2 = n3;
            }
        }
        if (e1 != 0 && e1 != 2) {
            super.h.d(n + a.f1());
        }
        else {
            super.h.d(n2 + a.f1());
        }
    }
    
    @Override
    void d() {
        final e b = super.b;
        if (b instanceof a) {
            super.h.b = true;
            final a a = (a)b;
            final int e1 = a.e1();
            final boolean d1 = a.d1();
            final int n = 0;
            int i = 0;
            final int n2 = 0;
            final int n3 = 0;
            p p = null;
            Label_0502: {
                if (e1 != 0) {
                    if (e1 != 1) {
                        if (e1 != 2) {
                            if (e1 != 3) {
                                return;
                            }
                            super.h.e = f$a.h;
                            for (int j = n3; j < a.q0; ++j) {
                                final e e2 = a.p0[j];
                                if (d1 || e2.Q() != 8) {
                                    final f k = e2.e.i;
                                    k.k.add((Object)super.h);
                                    super.h.l.add((Object)k);
                                }
                            }
                        }
                        else {
                            super.h.e = f$a.g;
                            for (int l = n; l < a.q0; ++l) {
                                final e e3 = a.p0[l];
                                if (d1 || e3.Q() != 8) {
                                    final f h = e3.e.h;
                                    h.k.add((Object)super.h);
                                    super.h.l.add((Object)h);
                                }
                            }
                        }
                        this.q(super.b.e.h);
                        p = super.b.e;
                        break Label_0502;
                    }
                    super.h.e = f$a.f;
                    while (i < a.q0) {
                        final e e4 = a.p0[i];
                        if (d1 || e4.Q() != 8) {
                            final f m = e4.d.i;
                            m.k.add((Object)super.h);
                            super.h.l.add((Object)m);
                        }
                        ++i;
                    }
                }
                else {
                    super.h.e = f$a.e;
                    for (int n4 = n2; n4 < a.q0; ++n4) {
                        final e e5 = a.p0[n4];
                        if (d1 || e5.Q() != 8) {
                            final f h2 = e5.d.h;
                            h2.k.add((Object)super.h);
                            super.h.l.add((Object)h2);
                        }
                    }
                }
                this.q(super.b.d.h);
                p = super.b.d;
            }
            this.q(p.i);
        }
    }
    
    public void e() {
        final e b = super.b;
        if (b instanceof a) {
            final int e1 = ((a)b).e1();
            if (e1 != 0 && e1 != 1) {
                super.b.W0(super.h.g);
            }
            else {
                super.b.V0(super.h.g);
            }
        }
    }
    
    @Override
    void f() {
        super.c = null;
        super.h.c();
    }
    
    @Override
    boolean m() {
        return false;
    }
}
