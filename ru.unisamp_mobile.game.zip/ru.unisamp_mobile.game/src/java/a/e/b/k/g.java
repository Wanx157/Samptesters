package a.e.b.k;

import a.e.b.i;

public class g extends e
{
    protected float p0;
    protected int q0;
    protected int r0;
    private d s0;
    private int t0;
    private boolean u0;
    
    public g() {
        this.p0 = -1.0f;
        this.q0 = -1;
        this.r0 = -1;
        this.s0 = super.G;
        int i = 0;
        this.t0 = 0;
        super.O.clear();
        super.O.add((Object)this.s0);
        while (i < super.N.length) {
            super.N[i] = this.s0;
            ++i;
        }
    }
    
    public void Z0(final a.e.b.d d, final boolean b) {
        if (this.I() == null) {
            return;
        }
        final int x = d.x((Object)this.s0);
        if (this.t0 == 1) {
            this.V0(x);
            this.W0(0);
            this.v0(this.I().v());
            this.U0(0);
        }
        else {
            this.V0(0);
            this.W0(x);
            this.U0(this.I().R());
            this.v0(0);
        }
    }
    
    public d a1() {
        return this.s0;
    }
    
    public int b1() {
        return this.t0;
    }
    
    public int c1() {
        return this.q0;
    }
    
    public int d1() {
        return this.r0;
    }
    
    public boolean e0() {
        return this.u0;
    }
    
    public float e1() {
        return this.p0;
    }
    
    public boolean f0() {
        return this.u0;
    }
    
    public void f1(final int n) {
        this.s0.s(n);
        this.u0 = true;
    }
    
    public void g(final a.e.b.d d, final boolean b) {
        final f f = (f)this.I();
        if (f == null) {
            return;
        }
        d d2 = ((e)f).m(d$b.c);
        d d3 = ((e)f).m(d$b.e);
        final e r = super.R;
        final int n = 1;
        int n2;
        if (r != null && r.Q[0] == e$b.c) {
            n2 = 1;
        }
        else {
            n2 = 0;
        }
        if (this.t0 == 0) {
            d2 = ((e)f).m(d$b.d);
            d3 = ((e)f).m(d$b.f);
            final e r2 = super.R;
            if (r2 != null && r2.Q[1] == e$b.c) {
                n2 = n;
            }
            else {
                n2 = 0;
            }
        }
        if (this.u0 && this.s0.m()) {
            final i q = d.q((Object)this.s0);
            d.f(q, this.s0.d());
            if (this.q0 != -1) {
                if (n2 != 0) {
                    d.h(d.q((Object)d3), q, 0, 5);
                }
            }
            else if (this.r0 != -1 && n2 != 0) {
                final i q2 = d.q((Object)d3);
                d.h(q, d.q((Object)d2), 0, 5);
                d.h(q2, q, 0, 5);
            }
            this.u0 = false;
            return;
        }
        if (this.q0 != -1) {
            final i q3 = d.q((Object)this.s0);
            d.e(q3, d.q((Object)d2), this.q0, 8);
            if (n2 != 0) {
                d.h(d.q((Object)d3), q3, 0, 5);
            }
        }
        else if (this.r0 != -1) {
            final i q4 = d.q((Object)this.s0);
            final i q5 = d.q((Object)d3);
            d.e(q4, q5, -this.r0, 8);
            if (n2 != 0) {
                d.h(q4, d.q((Object)d2), 0, 5);
                d.h(q5, q4, 0, 5);
            }
        }
        else if (this.p0 != -1.0f) {
            d.d(a.e.b.d.s(d, d.q((Object)this.s0), d.q((Object)d3), this.p0));
        }
    }
    
    public void g1(final int q0) {
        if (q0 > -1) {
            this.p0 = -1.0f;
            this.q0 = q0;
            this.r0 = -1;
        }
    }
    
    public boolean h() {
        return true;
    }
    
    public void h1(final int r0) {
        if (r0 > -1) {
            this.p0 = -1.0f;
            this.q0 = -1;
            this.r0 = r0;
        }
    }
    
    public void i1(final float p) {
        if (p > -1.0f) {
            this.p0 = p;
            this.q0 = -1;
            this.r0 = -1;
        }
    }
    
    public void j1(int i) {
        if (this.t0 == i) {
            return;
        }
        this.t0 = i;
        super.O.clear();
        d s0;
        if (this.t0 == 1) {
            s0 = super.F;
        }
        else {
            s0 = super.G;
        }
        this.s0 = s0;
        super.O.add((Object)this.s0);
        int length;
        for (length = super.N.length, i = 0; i < length; ++i) {
            super.N[i] = this.s0;
        }
    }
    
    public d m(final d$b d$b) {
        switch (g$a.a[((Enum)d$b).ordinal()]) {
            case 5:
            case 6:
            case 7:
            case 8:
            case 9: {
                return null;
            }
            case 3:
            case 4: {
                if (this.t0 == 0) {
                    return this.s0;
                }
                break;
            }
            case 1:
            case 2: {
                if (this.t0 == 1) {
                    return this.s0;
                }
                break;
            }
        }
        throw new AssertionError((Object)((Enum)d$b).name());
    }
}
