package a.e.b.k.m;

import a.e.b.k.l;
import java.util.Iterator;
import a.e.b.k.a;
import a.e.b.k.f;
import a.e.b.k.d;
import a.e.b.k.g;
import java.util.ArrayList;
import a.e.b.k.e;

public class i
{
    public static o a(final e e, final int n, final ArrayList<o> list, o o) {
        int n2;
        if (n == 0) {
            n2 = e.m0;
        }
        else {
            n2 = e.n0;
        }
        final int n3 = 0;
        Object o2;
        if (n2 != -1 && (o == null || n2 != o.b)) {
            int n4 = 0;
            while (true) {
                o2 = o;
                if (n4 >= list.size()) {
                    break;
                }
                o2 = list.get(n4);
                if (((o)o2).c() == n2) {
                    if (o != null) {
                        o.g(n, (o)o2);
                        list.remove((Object)o);
                    }
                    break;
                }
                ++n4;
            }
        }
        else {
            o2 = o;
            if (n2 != -1) {
                return o;
            }
        }
        if ((o = (o)o2) == null) {
            o = (o)o2;
            if (e instanceof a.e.b.k.i) {
                final int b1 = ((a.e.b.k.i)e).b1(n);
                o = (o)o2;
                if (b1 != -1) {
                    int n5 = 0;
                    while (true) {
                        o = (o)o2;
                        if (n5 >= list.size()) {
                            break;
                        }
                        o = (o)list.get(n5);
                        if (o.c() == b1) {
                            break;
                        }
                        ++n5;
                    }
                }
            }
            o o3;
            if ((o3 = o) == null) {
                o3 = new o(n);
            }
            list.add((Object)o3);
            o = o3;
        }
        if (o.a(e)) {
            if (e instanceof g) {
                final g g = (g)e;
                final d a1 = g.a1();
                int n6 = n3;
                if (g.b1() == 0) {
                    n6 = 1;
                }
                a1.b(n6, list, o);
            }
            final int c = o.c();
            d d;
            if (n == 0) {
                e.m0 = c;
                e.F.b(n, list, o);
                d = e.H;
            }
            else {
                e.n0 = c;
                e.G.b(n, list, o);
                e.J.b(n, list, o);
                d = e.I;
            }
            d.b(n, list, o);
            e.M.b(n, list, o);
        }
        return o;
    }
    
    private static o b(final ArrayList<o> list, final int n) {
        for (int size = list.size(), i = 0; i < size; ++i) {
            final o o = (o)list.get(i);
            if (n == o.b) {
                return o;
            }
        }
        return null;
    }
    
    public static boolean c(final f f, final b.b b) {
        final ArrayList a1 = ((l)f).a1();
        final int size = a1.size();
        for (int i = 0; i < size; ++i) {
            final e e = (e)a1.get(i);
            if (!d(((e)f).y(), ((e)f).O(), e.y(), e.O())) {
                return false;
            }
        }
        final a.e.b.e u0 = f.u0;
        if (u0 != null) {
            ++u0.A;
        }
        int j = 0;
        ArrayList list = null;
        ArrayList list2 = null;
        ArrayList list3 = null;
        ArrayList list4 = null;
        ArrayList list5 = null;
        ArrayList list6 = null;
        while (j < size) {
            final e e2 = (e)a1.get(j);
            if (!d(((e)f).y(), ((e)f).O(), e2.y(), e2.O())) {
                f.A1(e2, b, f.J0, a.e.b.k.m.b.a.k);
            }
            final boolean b2 = e2 instanceof g;
            ArrayList list7 = list;
            ArrayList list8 = list3;
            if (b2) {
                final g g = (g)e2;
                ArrayList list9 = list3;
                if (g.b1() == 0) {
                    if ((list9 = list3) == null) {
                        list9 = new ArrayList();
                    }
                    list9.add((Object)g);
                }
                list7 = list;
                list8 = list9;
                if (g.b1() == 1) {
                    ArrayList list10;
                    if ((list10 = list) == null) {
                        list10 = new ArrayList();
                    }
                    list10.add((Object)g);
                    list8 = list9;
                    list7 = list10;
                }
            }
            ArrayList list11 = list2;
            ArrayList list12 = list4;
            Label_0480: {
                if (e2 instanceof a.e.b.k.i) {
                    Object o;
                    ArrayList list14;
                    if (e2 instanceof a) {
                        final a a2 = (a)e2;
                        ArrayList list13 = list2;
                        if (a2.g1() == 0) {
                            if ((list13 = list2) == null) {
                                list13 = new ArrayList();
                            }
                            list13.add((Object)a2);
                        }
                        list11 = list13;
                        list12 = list4;
                        if (a2.g1() != 1) {
                            break Label_0480;
                        }
                        o = a2;
                        list11 = list13;
                        if ((list14 = list4) == null) {
                            list14 = new ArrayList();
                            o = a2;
                            list11 = list13;
                        }
                    }
                    else {
                        final a.e.b.k.i k = (a.e.b.k.i)e2;
                        ArrayList list15;
                        if ((list15 = list2) == null) {
                            list15 = new ArrayList();
                        }
                        list15.add((Object)k);
                        o = k;
                        list11 = list15;
                        if ((list14 = list4) == null) {
                            list14 = new ArrayList();
                            list11 = list15;
                            o = k;
                        }
                    }
                    list14.add(o);
                    list12 = list14;
                }
            }
            ArrayList list16 = list5;
            if (e2.F.f == null) {
                list16 = list5;
                if (e2.H.f == null) {
                    list16 = list5;
                    if (!b2) {
                        list16 = list5;
                        if (!(e2 instanceof a)) {
                            ArrayList list17;
                            if ((list17 = list5) == null) {
                                list17 = new ArrayList();
                            }
                            list17.add((Object)e2);
                            list16 = list17;
                        }
                    }
                }
            }
            ArrayList list18 = list6;
            if (e2.G.f == null) {
                list18 = list6;
                if (e2.I.f == null) {
                    list18 = list6;
                    if (e2.J.f == null) {
                        list18 = list6;
                        if (!b2) {
                            list18 = list6;
                            if (!(e2 instanceof a)) {
                                ArrayList list19;
                                if ((list19 = list6) == null) {
                                    list19 = new ArrayList();
                                }
                                list19.add((Object)e2);
                                list18 = list19;
                            }
                        }
                    }
                }
            }
            ++j;
            list = list7;
            list2 = list11;
            list3 = list8;
            list4 = list12;
            list5 = list16;
            list6 = list18;
        }
        final ArrayList list20 = new ArrayList();
        if (list != null) {
            final Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                a((e)iterator.next(), 0, (ArrayList<o>)list20, null);
            }
        }
        if (list2 != null) {
            for (final a.e.b.k.i l : list2) {
                final o a3 = a((e)l, 0, (ArrayList<o>)list20, null);
                l.a1(list20, 0, a3);
                a3.b((ArrayList<o>)list20);
            }
        }
        final d m = ((e)f).m(d.b.c);
        if (m.c() != null) {
            final Iterator iterator3 = m.c().iterator();
            while (iterator3.hasNext()) {
                a(((d)iterator3.next()).d, 0, (ArrayList<o>)list20, null);
            }
        }
        final d m2 = ((e)f).m(d.b.e);
        if (m2.c() != null) {
            final Iterator iterator4 = m2.c().iterator();
            while (iterator4.hasNext()) {
                a(((d)iterator4.next()).d, 0, (ArrayList<o>)list20, null);
            }
        }
        final d m3 = ((e)f).m(d.b.h);
        if (m3.c() != null) {
            final Iterator iterator5 = m3.c().iterator();
            while (iterator5.hasNext()) {
                a(((d)iterator5.next()).d, 0, (ArrayList<o>)list20, null);
            }
        }
        if (list5 != null) {
            final Iterator iterator6 = list5.iterator();
            while (iterator6.hasNext()) {
                a((e)iterator6.next(), 0, (ArrayList<o>)list20, null);
            }
        }
        if (list3 != null) {
            final Iterator iterator7 = list3.iterator();
            while (iterator7.hasNext()) {
                a((e)iterator7.next(), 1, (ArrayList<o>)list20, null);
            }
        }
        if (list4 != null) {
            for (final a.e.b.k.i i2 : list4) {
                final o a4 = a((e)i2, 1, (ArrayList<o>)list20, null);
                i2.a1(list20, 1, a4);
                a4.b((ArrayList<o>)list20);
            }
        }
        final d m4 = ((e)f).m(d.b.d);
        if (m4.c() != null) {
            final Iterator iterator9 = m4.c().iterator();
            while (iterator9.hasNext()) {
                a(((d)iterator9.next()).d, 1, (ArrayList<o>)list20, null);
            }
        }
        final d m5 = ((e)f).m(d.b.g);
        if (m5.c() != null) {
            final Iterator iterator10 = m5.c().iterator();
            while (iterator10.hasNext()) {
                a(((d)iterator10.next()).d, 1, (ArrayList<o>)list20, null);
            }
        }
        final d m6 = ((e)f).m(d.b.f);
        if (m6.c() != null) {
            final Iterator iterator11 = m6.c().iterator();
            while (iterator11.hasNext()) {
                a(((d)iterator11.next()).d, 1, (ArrayList<o>)list20, null);
            }
        }
        final d m7 = ((e)f).m(d.b.h);
        if (m7.c() != null) {
            final Iterator iterator12 = m7.c().iterator();
            while (iterator12.hasNext()) {
                a(((d)iterator12.next()).d, 1, (ArrayList<o>)list20, null);
            }
        }
        if (list6 != null) {
            final Iterator iterator13 = list6.iterator();
            while (iterator13.hasNext()) {
                a((e)iterator13.next(), 1, (ArrayList<o>)list20, null);
            }
        }
        for (int n = 0; n < size; ++n) {
            final e e3 = (e)a1.get(n);
            if (e3.g0()) {
                final o b3 = b((ArrayList<o>)list20, e3.m0);
                final o b4 = b((ArrayList<o>)list20, e3.n0);
                if (b3 != null && b4 != null) {
                    b3.g(0, b4);
                    b4.i(2);
                    list20.remove((Object)b3);
                }
            }
        }
        if (list20.size() <= 1) {
            return false;
        }
        o o4 = null;
        Label_1575: {
            if (((e)f).y() == e.b.c) {
                final Iterator iterator14 = list20.iterator();
                o o2 = null;
                int n2 = 0;
                while (iterator14.hasNext()) {
                    final o o3 = (o)iterator14.next();
                    if (o3.d() == 1) {
                        continue;
                    }
                    o3.h(false);
                    final int f2 = o3.f(f.t1(), 0);
                    if (f2 <= n2) {
                        continue;
                    }
                    o2 = o3;
                    n2 = f2;
                }
                if (o2 != null) {
                    ((e)f).z0(e.b.b);
                    ((e)f).U0(n2);
                    o2.h(true);
                    o4 = o2;
                    break Label_1575;
                }
            }
            o4 = null;
        }
        if (((e)f).O() == e.b.c) {
            final Iterator iterator15 = list20.iterator();
            o o5 = null;
            int n3 = 0;
            while (iterator15.hasNext()) {
                final o o6 = (o)iterator15.next();
                if (o6.d() == 0) {
                    continue;
                }
                o6.h(false);
                final int f3 = o6.f(f.t1(), 1);
                if (f3 <= n3) {
                    continue;
                }
                o5 = o6;
                n3 = f3;
            }
            if (o5 != null) {
                ((e)f).Q0(e.b.b);
                ((e)f).v0(n3);
                o5.h(true);
                final o o7 = o5;
                return o4 != null || o7 != null;
            }
        }
        final o o7 = null;
        return o4 != null || o7 != null;
    }
    
    public static boolean d(final e.b b, final e.b b2, final e.b b3, final e.b b4) {
        final boolean b5 = b3 == e.b.b || b3 == e.b.c || (b3 == e.b.e && b != e.b.c);
        final boolean b6 = b4 == e.b.b || b4 == e.b.c || (b4 == e.b.e && b2 != e.b.c);
        return b5 || b6;
    }
}
