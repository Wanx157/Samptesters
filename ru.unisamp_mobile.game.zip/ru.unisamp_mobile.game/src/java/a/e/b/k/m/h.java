package a.e.b.k.m;

import a.e.b.k.l;
import java.util.ArrayList;
import a.e.b.k.a;
import java.util.Iterator;
import a.e.b.k.g;
import a.e.b.k.d;
import a.e.b.k.f;
import a.e.b.k.e;

public class h
{
    private static b.a a;
    
    static {
        h.a = new b.a();
    }
    
    private static boolean a(final e e) {
        final e.b y = e.y();
        final e.b o = e.O();
        Object o2;
        if (e.I() != null) {
            o2 = e.I();
        }
        else {
            o2 = null;
        }
        if (o2 != null) {
            ((e)o2).y();
            final e.b b = a.e.b.k.e.b.b;
        }
        if (o2 != null) {
            ((e)o2).O();
            final e.b b2 = a.e.b.k.e.b.b;
        }
        final e.b b3 = a.e.b.k.e.b.b;
        final boolean b4 = false;
        final boolean b5 = y == b3 || y == a.e.b.k.e.b.c || (y == a.e.b.k.e.b.d && e.n == 0 && e.U == 0.0f && e.V(0)) || e.e0();
        final boolean b6 = o == a.e.b.k.e.b.b || o == a.e.b.k.e.b.c || (o == a.e.b.k.e.b.d && e.o == 0 && e.U == 0.0f && e.V(1)) || e.f0();
        if (e.U > 0.0f && (b5 || b6)) {
            return true;
        }
        boolean b7 = b4;
        if (b5) {
            b7 = b4;
            if (b6) {
                b7 = true;
            }
        }
        return b7;
    }
    
    private static void b(final e e, final b.b b, final boolean b2) {
        if (!(e instanceof f) && e.d0() && a(e)) {
            f.A1(e, b, new b.a(), a.e.b.k.m.b.a.k);
        }
        final d m = e.m(d.b.c);
        final d i = e.m(d.b.e);
        final int d = m.d();
        final int d2 = i.d();
        if (m.c() != null && m.m()) {
            for (final d d3 : m.c()) {
                final e d4 = d3.d;
                final boolean a = a(d4);
                if (d4.d0() && a) {
                    f.A1(d4, b, new b.a(), a.e.b.k.m.b.a.k);
                }
                if (d4.y() == e.b.d && !a) {
                    if (d4.y() != e.b.d || d4.r < 0 || d4.q < 0 || (d4.Q() != 8 && (d4.n != 0 || d4.t() != 0.0f)) || d4.Z() || d4.c0()) {
                        continue;
                    }
                    boolean b3 = false;
                    Label_0324: {
                        Label_0317: {
                            if (d3 == d4.F) {
                                final d f = d4.H.f;
                                if (f != null && f.m()) {
                                    break Label_0317;
                                }
                            }
                            if (d3 == d4.H) {
                                final d f2 = d4.F.f;
                                if (f2 != null && f2.m()) {
                                    break Label_0317;
                                }
                            }
                            b3 = false;
                            break Label_0324;
                        }
                        b3 = true;
                    }
                    if (!b3 || d4.Z()) {
                        continue;
                    }
                    e(e, b, d4, b2);
                }
                else {
                    if (d4.d0()) {
                        continue;
                    }
                    final d f3 = d4.F;
                    if (d3 == f3 && d4.H.f == null) {
                        final int n = f3.e() + d;
                        d4.p0(n, d4.R() + n);
                    }
                    else {
                        final d h = d4.H;
                        if (d3 == h && d4.F.f == null) {
                            final int n2 = d - h.e();
                            d4.p0(n2 - d4.R(), n2);
                        }
                        else {
                            if (d3 != d4.F) {
                                continue;
                            }
                            final d f4 = d4.H.f;
                            if (f4 != null && f4.m() && !d4.Z()) {
                                d(b, d4, b2);
                                continue;
                            }
                            continue;
                        }
                    }
                    b(d4, b, b2);
                }
            }
        }
        if (e instanceof g) {
            return;
        }
        if (i.c() != null && i.m()) {
            for (final d d5 : i.c()) {
                final e d6 = d5.d;
                final boolean a2 = a(d6);
                if (d6.d0() && a2) {
                    f.A1(d6, b, new b.a(), a.e.b.k.m.b.a.k);
                }
                boolean b4 = false;
                Label_0689: {
                    Label_0682: {
                        if (d5 == d6.F) {
                            final d f5 = d6.H.f;
                            if (f5 != null && f5.m()) {
                                break Label_0682;
                            }
                        }
                        if (d5 == d6.H) {
                            final d f6 = d6.F.f;
                            if (f6 != null && f6.m()) {
                                break Label_0682;
                            }
                        }
                        b4 = false;
                        break Label_0689;
                    }
                    b4 = true;
                }
                if (d6.y() == e.b.d && !a2) {
                    if (d6.y() != e.b.d || d6.r < 0 || d6.q < 0 || (d6.Q() != 8 && (d6.n != 0 || d6.t() != 0.0f)) || d6.Z() || d6.c0() || !b4 || d6.Z()) {
                        continue;
                    }
                    e(e, b, d6, b2);
                }
                else {
                    if (d6.d0()) {
                        continue;
                    }
                    final d f7 = d6.F;
                    if (d5 == f7 && d6.H.f == null) {
                        final int n3 = f7.e() + d2;
                        d6.p0(n3, d6.R() + n3);
                    }
                    else {
                        final d h2 = d6.H;
                        if (d5 == h2 && d6.F.f == null) {
                            final int n4 = d2 - h2.e();
                            d6.p0(n4 - d6.R(), n4);
                        }
                        else {
                            if (b4 && !d6.Z()) {
                                d(b, d6, b2);
                                continue;
                            }
                            continue;
                        }
                    }
                    b(d6, b, b2);
                }
            }
        }
    }
    
    private static void c(final a a, final b.b b, final int n, final boolean b2) {
        if (a.c1()) {
            if (n == 0) {
                b((e)a, b, b2);
            }
            else {
                i((e)a, b);
            }
        }
    }
    
    private static void d(final b.b b, final e e, final boolean b2) {
        float w = e.w();
        int d = e.F.f.d();
        int d2 = e.H.f.d();
        final int e2 = e.F.e();
        final int e3 = e.H.e();
        if (d == d2) {
            w = 0.5f;
        }
        else {
            d += e2;
            d2 -= e3;
        }
        final int r = e.R();
        int n = d2 - d - r;
        if (d > d2) {
            n = d - d2 - r;
        }
        final int n2 = (int)(w * n + 0.5f) + d;
        int n3 = n2 + r;
        if (d > d2) {
            n3 = n2 - r;
        }
        e.p0(n2, n3);
        b(e, b, b2);
    }
    
    private static void e(e i, final b.b b, final e e, final boolean b2) {
        final float w = e.w();
        final int n = e.F.f.d() + e.F.e();
        final int n2 = e.H.f.d() - e.H.e();
        if (n2 >= n) {
            int n4;
            final int n3 = n4 = e.R();
            if (e.Q() != 8) {
                final int n5 = e.n;
                int n6;
                if (n5 == 2) {
                    if (!(i instanceof f)) {
                        i = i.I();
                    }
                    n6 = (int)(e.w() * 0.5f * i.R());
                }
                else {
                    n6 = n3;
                    if (n5 == 0) {
                        n6 = n2 - n;
                    }
                }
                final int max = Math.max(e.q, n6);
                final int r = e.r;
                n4 = max;
                if (r > 0) {
                    n4 = Math.min(r, max);
                }
            }
            final int n7 = n + (int)(w * (n2 - n - n4) + 0.5f);
            e.p0(n7, n4 + n7);
            b(e, b, b2);
        }
    }
    
    private static void f(final b.b b, final e e) {
        float m = e.M();
        int d = e.G.f.d();
        int d2 = e.I.f.d();
        final int e2 = e.G.e();
        final int e3 = e.I.e();
        if (d == d2) {
            m = 0.5f;
        }
        else {
            d += e2;
            d2 -= e3;
        }
        final int v = e.v();
        int n = d2 - d - v;
        if (d > d2) {
            n = d - d2 - v;
        }
        final int n2 = (int)(m * n + 0.5f);
        int n3 = d + n2;
        int n4 = n3 + v;
        if (d > d2) {
            n3 = d - n2;
            n4 = n3 - v;
        }
        e.s0(n3, n4);
        i(e, b);
    }
    
    private static void g(e i, final b.b b, final e e) {
        final float m = e.M();
        final int n = e.G.f.d() + e.G.e();
        final int n2 = e.I.f.d() - e.I.e();
        if (n2 >= n) {
            int n4;
            final int n3 = n4 = e.v();
            if (e.Q() != 8) {
                final int o = e.o;
                int n5;
                if (o == 2) {
                    if (!(i instanceof f)) {
                        i = i.I();
                    }
                    n5 = (int)(m * 0.5f * i.v());
                }
                else {
                    n5 = n3;
                    if (o == 0) {
                        n5 = n2 - n;
                    }
                }
                final int max = Math.max(e.t, n5);
                final int u = e.u;
                n4 = max;
                if (u > 0) {
                    n4 = Math.min(u, max);
                }
            }
            final int n6 = n + (int)(m * (n2 - n - n4) + 0.5f);
            e.s0(n6, n4 + n6);
            i(e, b);
        }
    }
    
    public static void h(final f f, final b.b b) {
        final e.b y = ((e)f).y();
        final e.b o = ((e)f).O();
        ((e)f).i0();
        final ArrayList a1 = ((l)f).a1();
        final int size = a1.size();
        final int n = 0;
        for (int i = 0; i < size; ++i) {
            ((e)a1.get(i)).i0();
        }
        final boolean x1 = f.x1();
        if (y == e.b.b) {
            ((e)f).p0(0, ((e)f).R());
        }
        else {
            ((e)f).q0(0);
        }
        int j = 0;
        int n2 = 0;
        int n3 = 0;
        while (j < size) {
            final e e = (e)a1.get(j);
            int n4;
            int n5;
            if (e instanceof g) {
                final g g = (g)e;
                n4 = n2;
                n5 = n3;
                if (g.b1() == 1) {
                    Label_0225: {
                        int c1;
                        if (g.c1() != -1) {
                            c1 = g.c1();
                        }
                        else if (g.d1() != -1 && ((e)f).e0()) {
                            c1 = ((e)f).R() - g.d1();
                        }
                        else {
                            if (!((e)f).e0()) {
                                break Label_0225;
                            }
                            c1 = (int)(g.e1() * ((e)f).R() + 0.5f);
                        }
                        g.f1(c1);
                    }
                    n4 = 1;
                    n5 = n3;
                }
            }
            else {
                n4 = n2;
                n5 = n3;
                if (e instanceof a) {
                    n4 = n2;
                    n5 = n3;
                    if (((a)e).g1() == 0) {
                        n5 = 1;
                        n4 = n2;
                    }
                }
            }
            ++j;
            n2 = n4;
            n3 = n5;
        }
        if (n2 != 0) {
            for (int k = 0; k < size; ++k) {
                final e e2 = (e)a1.get(k);
                if (e2 instanceof g) {
                    final g g2 = (g)e2;
                    if (g2.b1() == 1) {
                        b((e)g2, b, x1);
                    }
                }
            }
        }
        b((e)f, b, x1);
        if (n3 != 0) {
            for (int l = 0; l < size; ++l) {
                final e e3 = (e)a1.get(l);
                if (e3 instanceof a) {
                    final a a2 = (a)e3;
                    if (a2.g1() == 0) {
                        c(a2, b, 0, x1);
                    }
                }
            }
        }
        if (o == e.b.b) {
            ((e)f).s0(0, ((e)f).v());
        }
        else {
            ((e)f).r0(0);
        }
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        while (n6 < size) {
            final e e4 = (e)a1.get(n6);
            int n9;
            int n10;
            if (e4 instanceof g) {
                final g g3 = (g)e4;
                n9 = n7;
                n10 = n8;
                if (g3.b1() == 0) {
                    Label_0572: {
                        int c2;
                        if (g3.c1() != -1) {
                            c2 = g3.c1();
                        }
                        else if (g3.d1() != -1 && ((e)f).f0()) {
                            c2 = ((e)f).v() - g3.d1();
                        }
                        else {
                            if (!((e)f).f0()) {
                                break Label_0572;
                            }
                            c2 = (int)(g3.e1() * ((e)f).v() + 0.5f);
                        }
                        g3.f1(c2);
                    }
                    n9 = 1;
                    n10 = n8;
                }
            }
            else {
                n9 = n7;
                n10 = n8;
                if (e4 instanceof a) {
                    n9 = n7;
                    n10 = n8;
                    if (((a)e4).g1() == 1) {
                        n10 = 1;
                        n9 = n7;
                    }
                }
            }
            ++n6;
            n7 = n9;
            n8 = n10;
        }
        if (n7 != 0) {
            for (int n11 = 0; n11 < size; ++n11) {
                final e e5 = (e)a1.get(n11);
                if (e5 instanceof g) {
                    final g g4 = (g)e5;
                    if (g4.b1() == 0) {
                        i((e)g4, b);
                    }
                }
            }
        }
        i((e)f, b);
        int n12 = n;
        if (n8 != 0) {
            int n13 = 0;
            while (true) {
                n12 = n;
                if (n13 >= size) {
                    break;
                }
                final e e6 = (e)a1.get(n13);
                if (e6 instanceof a) {
                    final a a3 = (a)e6;
                    if (a3.g1() == 1) {
                        c(a3, b, 1, x1);
                    }
                }
                ++n13;
            }
        }
        while (n12 < size) {
            final e e7 = (e)a1.get(n12);
            if (e7.d0() && a(e7)) {
                f.A1(e7, b, h.a, a.e.b.k.m.b.a.k);
                b(e7, b, x1);
                i(e7, b);
            }
            ++n12;
        }
    }
    
    private static void i(e d, final b.b b) {
        if (!(d instanceof f) && d.d0() && a(d)) {
            f.A1(d, b, new b.a(), a.e.b.k.m.b.a.k);
        }
        final d m = d.m(d.b.d);
        Object o = d.m(d.b.f);
        final int d2 = m.d();
        final int d3 = ((d)o).d();
        int d6 = 0;
        if (m.c() != null && m.m()) {
            for (final d d4 : m.c()) {
                final e d5 = d4.d;
                final boolean a = a(d5);
                if (d5.d0() && a) {
                    f.A1(d5, b, new b.a(), a.e.b.k.m.b.a.k);
                }
                if (d5.O() == e.b.d && !a) {
                    if (d5.O() != e.b.d || d5.u < 0 || d5.t < 0 || (d5.Q() != 8 && (d5.o != 0 || d5.t() != 0.0f)) || d5.b0() || d5.c0()) {
                        continue;
                    }
                    Label_0323: {
                        Label_0316: {
                            if (d4 == d5.G) {
                                final d f = d5.I.f;
                                if (f != null && f.m()) {
                                    break Label_0316;
                                }
                            }
                            if (d4 == d5.I) {
                                final d f2 = d5.G.f;
                                if (f2 != null && f2.m()) {
                                    break Label_0316;
                                }
                            }
                            d6 = 0;
                            break Label_0323;
                        }
                        d6 = 1;
                    }
                    if (d6 == 0 || d5.b0()) {
                        continue;
                    }
                    g(d, b, d5);
                }
                else {
                    if (d5.d0()) {
                        continue;
                    }
                    final d g = d5.G;
                    if (d4 == g && d5.I.f == null) {
                        d6 = g.e() + d2;
                        d5.s0(d6, d5.v() + d6);
                    }
                    else {
                        final d i = d5.I;
                        if (d4 == i && i.f == null) {
                            d6 = d2 - i.e();
                            d5.s0(d6 - d5.v(), d6);
                        }
                        else {
                            if (d4 != d5.G) {
                                continue;
                            }
                            final d f3 = d5.I.f;
                            if (f3 != null && f3.m()) {
                                f(b, d5);
                                continue;
                            }
                            continue;
                        }
                    }
                    i(d5, b);
                }
            }
        }
        if (d instanceof g) {
            return;
        }
        if (((d)o).c() != null && ((d)o).m()) {
            for (final d d7 : ((d)o).c()) {
                o = d7.d;
                final boolean a2 = a((e)o);
                if (((e)o).d0() && a2) {
                    f.A1((e)o, b, new b.a(), a.e.b.k.m.b.a.k);
                }
                Label_0674: {
                    Label_0667: {
                        if (d7 == ((e)o).G) {
                            final d f4 = ((e)o).I.f;
                            if (f4 != null && f4.m()) {
                                break Label_0667;
                            }
                        }
                        if (d7 == ((e)o).I) {
                            final d f5 = ((e)o).G.f;
                            if (f5 != null && f5.m()) {
                                break Label_0667;
                            }
                        }
                        d6 = 0;
                        break Label_0674;
                    }
                    d6 = 1;
                }
                if (((e)o).O() == e.b.d && !a2) {
                    if (((e)o).O() != e.b.d || ((e)o).u < 0 || ((e)o).t < 0 || (((e)o).Q() != 8 && (((e)o).o != 0 || ((e)o).t() != 0.0f)) || ((e)o).b0() || ((e)o).c0() || d6 == 0 || ((e)o).b0()) {
                        continue;
                    }
                    g(d, b, (e)o);
                }
                else {
                    if (((e)o).d0()) {
                        continue;
                    }
                    final d g2 = ((e)o).G;
                    if (d7 == g2 && ((e)o).I.f == null) {
                        d6 = g2.e() + d3;
                        ((e)o).s0(d6, ((e)o).v() + d6);
                    }
                    else {
                        final d j = ((e)o).I;
                        if (d7 == j && ((e)o).G.f == null) {
                            d6 = d3 - j.e();
                            ((e)o).s0(d6 - ((e)o).v(), d6);
                        }
                        else {
                            if (d6 != 0 && !((e)o).b0()) {
                                f(b, (e)o);
                                continue;
                            }
                            continue;
                        }
                    }
                    i((e)o, b);
                }
            }
        }
        final d k = d.m(d.b.g);
        if (k.c() == null || !k.m()) {
            return;
        }
        d6 = k.d();
        while (true) {
            o = k.c().iterator();
            Block_67: {
                while (((Iterator)o).hasNext()) {
                    final d d8 = (d)((Iterator)o).next();
                    d = d8.d;
                    final boolean a3 = a(d);
                    if (d.d0() && a3) {
                        f.A1(d, b, new b.a(), a.e.b.k.m.b.a.k);
                    }
                    if (d.O() != e.b.d || a3) {
                        if (d.d0()) {
                            continue;
                        }
                        if (d8 == d.J) {
                            break Block_67;
                        }
                        continue;
                    }
                }
                return;
            }
            d.o0(d6);
            try {
                i(d, b);
                continue;
            }
            finally {
                while (true) {}
            }
            break;
        }
    }
}
