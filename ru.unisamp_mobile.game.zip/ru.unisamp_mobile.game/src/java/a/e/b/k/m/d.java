package a.e.b.k.m;

public interface d
{
    void a(final d p0);
}
