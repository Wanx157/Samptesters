package a.e.b.k;

import a.e.b.d;

public class a extends i
{
    private int r0;
    private boolean s0;
    private int t0;
    boolean u0;
    
    public a() {
        this.r0 = 0;
        this.s0 = true;
        this.t0 = 0;
        this.u0 = false;
    }
    
    public boolean c1() {
        int i = 0;
        int n = 0;
        int n2 = 1;
        int q0;
        while (true) {
            q0 = super.q0;
            if (n >= q0) {
                break;
            }
            final e e = super.p0[n];
            int n3 = 0;
            Label_0105: {
                if (!this.s0 && !e.h()) {
                    n3 = n2;
                }
                else {
                    final int r0 = this.r0;
                    if ((r0 != 0 && r0 != 1) || e.e0()) {
                        final int r2 = this.r0;
                        if (r2 != 2) {
                            n3 = n2;
                            if (r2 != 3) {
                                break Label_0105;
                            }
                        }
                        n3 = n2;
                        if (e.f0()) {
                            break Label_0105;
                        }
                    }
                    n3 = 0;
                }
            }
            ++n;
            n2 = n3;
        }
        if (n2 != 0 && q0 > 0) {
            int n4 = 0;
            int n5 = 0;
            while (i < super.q0) {
                final e e2 = super.p0[i];
                Label_0344: {
                    if (this.s0 || e2.h()) {
                        int n6 = n4;
                        int n7;
                        if ((n7 = n5) == 0) {
                            final int r3 = this.r0;
                            Label_0237: {
                                d$b d$b;
                                if (r3 == 0) {
                                    d$b = a.e.b.k.d$b.c;
                                }
                                else if (r3 == 1) {
                                    d$b = a.e.b.k.d$b.e;
                                }
                                else if (r3 == 2) {
                                    d$b = a.e.b.k.d$b.d;
                                }
                                else {
                                    if (r3 != 3) {
                                        break Label_0237;
                                    }
                                    d$b = a.e.b.k.d$b.f;
                                }
                                n4 = e2.m(d$b).d();
                            }
                            n7 = 1;
                            n6 = n4;
                        }
                        final int r4 = this.r0;
                        d$b d$b3 = null;
                        Label_0258: {
                            if (r4 != 0) {
                                d$b d$b2;
                                if (r4 == 1) {
                                    d$b2 = d$b.e;
                                }
                                else {
                                    if (r4 == 2) {
                                        d$b3 = d$b.d;
                                        break Label_0258;
                                    }
                                    n4 = n6;
                                    n5 = n7;
                                    if (r4 != 3) {
                                        break Label_0344;
                                    }
                                    d$b2 = d$b.f;
                                }
                                n4 = Math.max(n6, e2.m(d$b2).d());
                                n5 = n7;
                                break Label_0344;
                            }
                            d$b3 = d$b.c;
                        }
                        n4 = Math.min(n6, e2.m(d$b3).d());
                        n5 = n7;
                    }
                }
                ++i;
            }
            final int n8 = n4 + this.t0;
            final int r5 = this.r0;
            if (r5 != 0 && r5 != 1) {
                this.s0(n8, n8);
            }
            else {
                this.p0(n8, n8);
            }
            return this.u0 = true;
        }
        return false;
    }
    
    public boolean d1() {
        return this.s0;
    }
    
    public boolean e0() {
        return this.u0;
    }
    
    public int e1() {
        return this.r0;
    }
    
    public boolean f0() {
        return this.u0;
    }
    
    public int f1() {
        return this.t0;
    }
    
    public void g(final d d, final boolean b) {
        final a.e.b.k.d[] n = super.N;
        n[0] = super.F;
        n[2] = super.G;
        n[1] = super.H;
        n[3] = super.I;
        int n2 = 0;
        a.e.b.k.d[] n3;
        while (true) {
            n3 = super.N;
            if (n2 >= n3.length) {
                break;
            }
            n3[n2].i = d.q((Object)n3[n2]);
            ++n2;
        }
        final int r0 = this.r0;
        if (r0 >= 0 && r0 < 4) {
            final a.e.b.k.d d2 = n3[r0];
            if (!this.u0) {
                this.c1();
            }
            if (this.u0) {
                this.u0 = false;
                final int r2 = this.r0;
                a.e.b.i i;
                int n4;
                if (r2 != 0 && r2 != 1) {
                    if (r2 != 2 && r2 != 3) {
                        return;
                    }
                    d.f(super.G.i, super.X);
                    i = super.I.i;
                    n4 = super.X;
                }
                else {
                    d.f(super.F.i, super.W);
                    i = super.H.i;
                    n4 = super.W;
                }
                d.f(i, n4);
                return;
            }
            while (true) {
                for (int j = 0; j < super.q0; ++j) {
                    final e e = super.p0[j];
                    if (this.s0 || e.h()) {
                        final int r3 = this.r0;
                        if ((r3 != 0 && r3 != 1) || e.y() != e$b.d || e.F.f == null || e.H.f == null) {
                            final int r4 = this.r0;
                            if ((r4 != 2 && r4 != 3) || e.O() != e$b.d || e.G.f == null || e.I.f == null) {
                                continue;
                            }
                        }
                        final boolean b2 = true;
                        final boolean b3 = super.F.k() || super.H.k();
                        final boolean b4 = super.G.k() || super.I.k();
                        final boolean b5 = !b2 && ((this.r0 == 0 && b3) || (this.r0 == 2 && b4) || (this.r0 == 1 && b3) || (this.r0 == 3 && b4));
                        int n5 = 5;
                        if (!b5) {
                            n5 = 4;
                        }
                        for (int k = 0; k < super.q0; ++k) {
                            final e e2 = super.p0[k];
                            if (this.s0 || e2.h()) {
                                final a.e.b.i q = d.q((Object)e2.N[this.r0]);
                                final a.e.b.k.d[] n6 = e2.N;
                                final int r5 = this.r0;
                                n6[r5].i = q;
                                int n7;
                                if (n6[r5].f != null && n6[r5].f.d == this) {
                                    n7 = n6[r5].g + 0;
                                }
                                else {
                                    n7 = 0;
                                }
                                final int r6 = this.r0;
                                if (r6 != 0 && r6 != 2) {
                                    d.g(d2.i, q, this.t0 + n7, b2);
                                }
                                else {
                                    d.i(d2.i, q, this.t0 - n7, b2);
                                }
                                d.e(d2.i, q, this.t0 + n7, n5);
                            }
                        }
                        final int r7 = this.r0;
                        a.e.b.i l;
                        a.e.b.k.d d3;
                        if (r7 == 0) {
                            d.e(super.H.i, super.F.i, 0, 8);
                            d.e(super.F.i, super.R.H.i, 0, 4);
                            l = super.F.i;
                            d3 = super.R.F;
                        }
                        else if (r7 == 1) {
                            d.e(super.F.i, super.H.i, 0, 8);
                            d.e(super.F.i, super.R.F.i, 0, 4);
                            l = super.F.i;
                            d3 = super.R.H;
                        }
                        else if (r7 == 2) {
                            d.e(super.I.i, super.G.i, 0, 8);
                            d.e(super.G.i, super.R.I.i, 0, 4);
                            l = super.G.i;
                            d3 = super.R.G;
                        }
                        else {
                            if (r7 != 3) {
                                return;
                            }
                            d.e(super.G.i, super.I.i, 0, 8);
                            d.e(super.G.i, super.R.G.i, 0, 4);
                            l = super.G.i;
                            d3 = super.R.I;
                        }
                        d.e(l, d3.i, 0, 0);
                        return;
                    }
                }
                final boolean b2 = false;
                continue;
            }
        }
    }
    
    public int g1() {
        final int r0 = this.r0;
        if (r0 == 0 || r0 == 1) {
            return 0;
        }
        if (r0 != 2 && r0 != 3) {
            return -1;
        }
        return 1;
    }
    
    public boolean h() {
        return true;
    }
    
    protected void h1() {
        for (int i = 0; i < super.q0; ++i) {
            final e e = super.p0[i];
            final int r0 = this.r0;
            if (r0 != 0 && r0 != 1) {
                if (r0 == 2 || r0 == 3) {
                    e.C0(1, true);
                }
            }
            else {
                e.C0(0, true);
            }
        }
    }
    
    public void i1(final boolean s0) {
        this.s0 = s0;
    }
    
    public void j1(final int r0) {
        this.r0 = r0;
    }
    
    public void k1(final int t0) {
        this.t0 = t0;
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("[Barrier] ");
        sb.append(this.r());
        sb.append(" {");
        String s = sb.toString();
        for (int i = 0; i < super.q0; ++i) {
            final e e = super.p0[i];
            String string = s;
            if (i > 0) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(s);
                sb2.append(", ");
                string = sb2.toString();
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(string);
            sb3.append(e.r());
            s = sb3.toString();
        }
        final StringBuilder sb4 = new StringBuilder();
        sb4.append(s);
        sb4.append("}");
        return sb4.toString();
    }
}
