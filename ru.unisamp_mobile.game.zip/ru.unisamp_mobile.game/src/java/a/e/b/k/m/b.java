package a.e.b.k.m;

import a.e.b.k.h;
import a.e.b.d;
import a.e.b.k.j;
import a.e.b.k.k;
import a.e.b.k.a;
import a.e.b.k.g;
import a.e.b.k.f;
import a.e.b.k.e;
import java.util.ArrayList;

public class b
{
    private final ArrayList<e> a;
    private a b;
    private f c;
    
    public b(final f c) {
        this.a = (ArrayList<e>)new ArrayList();
        this.b = new a();
        this.c = c;
    }
    
    private boolean a(final b b, final e e, int j) {
        this.b.a = e.y();
        this.b.b = e.O();
        this.b.c = e.R();
        this.b.d = e.v();
        final a b2 = this.b;
        b2.i = false;
        b2.j = j;
        if (b2.a == e.b.d) {
            j = 1;
        }
        else {
            j = 0;
        }
        final boolean b3 = this.b.b == e.b.d;
        if (j != 0 && e.U > 0.0f) {
            j = 1;
        }
        else {
            j = 0;
        }
        final boolean b4 = b3 && e.U > 0.0f;
        if (j != 0 && e.p[0] == 4) {
            this.b.a = e.b.b;
        }
        if (b4 && e.p[1] == 4) {
            this.b.b = e.b.b;
        }
        b.a(e, this.b);
        e.U0(this.b.e);
        e.v0(this.b.f);
        e.u0(this.b.h);
        e.k0(this.b.g);
        final a b5 = this.b;
        b5.j = a.e.b.k.m.b.a.k;
        return b5.i;
    }
    
    private void b(final f f) {
        final int size = ((a.e.b.k.l)f).p0.size();
        final boolean b1 = f.B1(64);
        final b r1 = f.r1();
        for (int i = 0; i < size; ++i) {
            final e e = (e)((a.e.b.k.l)f).p0.get(i);
            if (!(e instanceof g)) {
                if (!(e instanceof a.e.b.k.a)) {
                    if (!e.c0()) {
                        if (b1) {
                            final l d = e.d;
                            if (d != null) {
                                final n e2 = e.e;
                                if (e2 != null && ((a.e.b.k.m.f)((p)d).e).j && ((a.e.b.k.m.f)((p)e2).e).j) {
                                    continue;
                                }
                            }
                        }
                        final e.b s = e.s(0);
                        final int n = 1;
                        final e.b s2 = e.s(1);
                        final e.b d2 = a.e.b.k.e.b.d;
                        final boolean b2 = s == d2 && e.n != 1 && s2 == d2 && e.o != 1;
                        int n5 = 0;
                        Label_0354: {
                            int n2 = 0;
                            Label_0352: {
                                if ((n2 = (b2 ? 1 : 0)) == 0) {
                                    n2 = (b2 ? 1 : 0);
                                    if (f.B1(1)) {
                                        n2 = (b2 ? 1 : 0);
                                        if (!(e instanceof k)) {
                                            final e.b d3 = a.e.b.k.e.b.d;
                                            int n3 = b2 ? 1 : 0;
                                            if (s == d3) {
                                                n3 = (b2 ? 1 : 0);
                                                if (e.n == 0) {
                                                    n3 = (b2 ? 1 : 0);
                                                    if (s2 != d3) {
                                                        n3 = (b2 ? 1 : 0);
                                                        if (!e.Z()) {
                                                            n3 = 1;
                                                        }
                                                    }
                                                }
                                            }
                                            final e.b d4 = a.e.b.k.e.b.d;
                                            int n4 = n3;
                                            if (s2 == d4) {
                                                n4 = n3;
                                                if (e.o == 0) {
                                                    n4 = n3;
                                                    if (s != d4) {
                                                        n4 = n3;
                                                        if (!e.Z()) {
                                                            n4 = 1;
                                                        }
                                                    }
                                                }
                                            }
                                            final e.b d5 = a.e.b.k.e.b.d;
                                            if (s != d5) {
                                                n2 = n4;
                                                if (s2 != d5) {
                                                    break Label_0352;
                                                }
                                            }
                                            n2 = n4;
                                            if (e.U > 0.0f) {
                                                n5 = n;
                                                break Label_0354;
                                            }
                                        }
                                    }
                                }
                            }
                            n5 = n2;
                        }
                        if (n5 == 0) {
                            this.a(r1, e, a.e.b.k.m.b.a.k);
                            final a.e.b.e u0 = f.u0;
                            if (u0 != null) {
                                ++u0.a;
                            }
                        }
                    }
                }
            }
        }
        r1.b();
    }
    
    private void c(final f f, final String s, final int n, final int n2) {
        final int g = ((e)f).G();
        final int f2 = ((e)f).F();
        ((e)f).K0(0);
        ((e)f).J0(0);
        ((e)f).U0(n);
        ((e)f).v0(n2);
        ((e)f).K0(g);
        ((e)f).J0(f2);
        this.c.b1();
    }
    
    public long d(final f f, int n, int n2, int n3, int s1, int r, int i, int n4, int n5, int v) {
        final b r2 = f.r1();
        final int size = ((a.e.b.k.l)f).p0.size();
        final int r3 = ((e)f).R();
        v = ((e)f).v();
        final boolean b = j.b(n, 128);
        if (!b && !j.b(n, 64)) {
            n = 0;
        }
        else {
            n = 1;
        }
        n3 = n;
        Label_0231: {
            if (n != 0) {
                n2 = 0;
                while (true) {
                    n3 = n;
                    if (n2 >= size) {
                        break Label_0231;
                    }
                    final e e = (e)((a.e.b.k.l)f).p0.get(n2);
                    if (e.y() == a.e.b.k.e.b.d) {
                        n3 = 1;
                    }
                    else {
                        n3 = 0;
                    }
                    if (e.O() == a.e.b.k.e.b.d) {
                        n5 = 1;
                    }
                    else {
                        n5 = 0;
                    }
                    if (n3 != 0 && n5 != 0 && e.t() > 0.0f) {
                        n3 = 1;
                    }
                    else {
                        n3 = 0;
                    }
                    if (e.Z() && n3 != 0) {
                        break;
                    }
                    if (e.b0() && n3 != 0) {
                        break;
                    }
                    if (e instanceof k) {
                        break;
                    }
                    if (e.Z()) {
                        break;
                    }
                    if (e.b0()) {
                        break;
                    }
                    ++n2;
                }
                n3 = 0;
            }
        }
        if (n3 != 0) {
            final a.e.b.e x = d.x;
            if (x != null) {
                ++x.c;
            }
        }
        if ((s1 == 1073741824 && i == 1073741824) || b) {
            n = 1;
        }
        else {
            n = 0;
        }
        final int n6 = n3 & n;
        boolean b3;
        if (n6 != 0) {
            n = Math.min(((e)f).E(), r);
            n2 = Math.min(((e)f).D(), n4);
            if (s1 == 1073741824 && ((e)f).R() != n) {
                ((e)f).U0(n);
                f.u1();
            }
            if (i == 1073741824 && ((e)f).v() != n2) {
                ((e)f).v0(n2);
                f.u1();
            }
            boolean b2;
            if (s1 == 1073741824 && i == 1073741824) {
                b2 = f.o1(b);
                n = 2;
            }
            else {
                b2 = f.p1(b);
                if (s1 == 1073741824) {
                    b2 &= f.q1(b, 0);
                    n = 1;
                }
                else {
                    n = 0;
                }
                if (i == 1073741824) {
                    b2 &= f.q1(b, 1);
                    ++n;
                }
            }
            b3 = b2;
            n2 = n;
            if (b2) {
                f.Y0(s1 == 1073741824, i == 1073741824);
                b3 = b2;
                n2 = n;
            }
        }
        else {
            b3 = false;
            n2 = 0;
        }
        if (!b3 || n2 != 2) {
            s1 = f.s1();
            if (size > 0) {
                this.b(f);
            }
            this.e(f);
            n4 = this.a.size();
            if (size > 0) {
                this.c(f, "First pass", r3, v);
            }
            if (n4 > 0) {
                if (((e)f).y() == e.b.c) {
                    n5 = 1;
                }
                else {
                    n5 = 0;
                }
                final boolean b4 = ((e)f).O() == e.b.c;
                n2 = Math.max(((e)f).R(), ((e)this.c).G());
                n = Math.max(((e)f).v(), ((e)this.c).F());
                i = 0;
                n3 = 0;
                while (i < n4) {
                    final e e2 = (e)this.a.get(i);
                    if (!(e2 instanceof k)) {
                        r = n3;
                    }
                    else {
                        r = e2.R();
                        final int v2 = e2.v();
                        final boolean a = this.a(r2, e2, a.e.b.k.m.b.a.l);
                        final a.e.b.e u0 = f.u0;
                        if (u0 != null) {
                            ++u0.b;
                        }
                        final int r4 = e2.R();
                        final int v3 = e2.v();
                        if (r4 != r) {
                            e2.U0(r4);
                            n3 = n2;
                            if (n5 != 0 && e2.K() > (n3 = n2)) {
                                n3 = Math.max(n2, e2.K() + e2.m(a.e.b.k.d.b.e).e());
                            }
                            r = 1;
                            n2 = n3;
                        }
                        else {
                            r = ((a ? 1 : 0) | n3);
                        }
                        n3 = n;
                        if (v3 != v2) {
                            e2.v0(v3);
                            n3 = n;
                            if (b4 && e2.p() > (n3 = n)) {
                                n3 = Math.max(n, e2.p() + e2.m(a.e.b.k.d.b.f).e());
                            }
                            r = 1;
                        }
                        r |= (((k)e2).d1() ? 1 : 0);
                        n = n3;
                    }
                    ++i;
                    n3 = r;
                }
                int n7 = 0;
                r = n6;
                int n8;
                int n9;
                int n10;
                while (true) {
                    n8 = n2;
                    n9 = n;
                    n10 = n3;
                    if (n7 >= 2) {
                        break;
                    }
                    int j = 0;
                    i = n3;
                    e e3;
                    int r5;
                    int v4;
                    int n11;
                    a.e.b.e u2;
                    int r6;
                    int v5;
                    int n12;
                    for (n3 = n4; j < n3; ++j, n2 = n12, i = n4) {
                        e3 = (e)this.a.get(j);
                        if (!(e3 instanceof h) || e3 instanceof k) {
                            if (!(e3 instanceof g)) {
                                if (e3.Q() != 8) {
                                    if (r == 0 || !((a.e.b.k.m.f)((p)e3.d).e).j || !((a.e.b.k.m.f)((p)e3.e).e).j) {
                                        if (!(e3 instanceof k)) {
                                            r5 = e3.R();
                                            v4 = e3.v();
                                            n11 = e3.n();
                                            n4 = a.e.b.k.m.b.a.l;
                                            if (n7 == 1) {
                                                n4 = a.e.b.k.m.b.a.m;
                                            }
                                            n4 = ((this.a(r2, e3, n4) ? 1 : 0) | i);
                                            u2 = f.u0;
                                            if (u2 != null) {
                                                ++u2.b;
                                            }
                                            r6 = e3.R();
                                            v5 = e3.v();
                                            i = n2;
                                            if (r6 != r5) {
                                                e3.U0(r6);
                                                i = n2;
                                                if (n5 != 0 && e3.K() > (i = n2)) {
                                                    i = Math.max(n2, e3.K() + e3.m(a.e.b.k.d.b.e).e());
                                                }
                                                n4 = 1;
                                            }
                                            n2 = n;
                                            if (v5 != v4) {
                                                e3.v0(v5);
                                                n2 = n;
                                                if (b4 && e3.p() > (n2 = n)) {
                                                    n2 = Math.max(n, e3.p() + e3.m(a.e.b.k.d.b.f).e());
                                                }
                                                n4 = 1;
                                            }
                                            if (e3.U() && n11 != e3.n()) {
                                                n4 = 1;
                                                n12 = i;
                                                n = n2;
                                                continue;
                                            }
                                            n = n2;
                                            n12 = i;
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                        n12 = n2;
                        n4 = i;
                    }
                    n8 = n2;
                    n9 = n;
                    if ((n10 = i) == 0) {
                        break;
                    }
                    this.c(f, "intermediate pass", r3, v);
                    ++n7;
                    i = 0;
                    n4 = n3;
                    n3 = i;
                }
                if (n10 != 0) {
                    this.c(f, "2nd pass", r3, v);
                    if (((e)f).R() < n8) {
                        ((e)f).U0(n8);
                        n = 1;
                    }
                    else {
                        n = 0;
                    }
                    if (((e)f).v() < n9) {
                        ((e)f).v0(n9);
                        n = 1;
                    }
                    if (n != 0) {
                        this.c(f, "3rd pass", r3, v);
                    }
                }
            }
            f.E1(s1);
        }
        return 0L;
    }
    
    public void e(final f f) {
        this.a.clear();
        for (int size = ((a.e.b.k.l)f).p0.size(), i = 0; i < size; ++i) {
            final e e = (e)((a.e.b.k.l)f).p0.get(i);
            if (e.y() == a.e.b.k.e.b.d || e.O() == a.e.b.k.e.b.d) {
                this.a.add((Object)e);
            }
        }
        f.u1();
    }
    
    public static class a
    {
        public static int k = 0;
        public static int l = 1;
        public static int m = 2;
        public e.b a;
        public e.b b;
        public int c;
        public int d;
        public int e;
        public int f;
        public int g;
        public boolean h;
        public boolean i;
        public int j;
    }
    
    public interface b
    {
        void a(final e p0, final a p1);
        
        void b();
    }
}
