package a.e.b.k;

import java.util.ArrayList;
import a.e.b.i;
import a.e.b.d;

public class b
{
    static void a(final f f, final d d, int n, int e, final c c) {
        final e a = c.a;
        final e c2 = c.c;
        final e b = c.b;
        final e d2 = c.d;
        final e e2 = c.e;
        final float k = c.k;
        final e f2 = c.f;
        final e g = c.g;
        final boolean b2 = ((e)f).Q[n] == a.e.b.k.e.b.c;
        int n3 = 0;
        int n4 = 0;
        boolean b3 = false;
        Label_0205: {
            int n5 = 0;
            Label_0198: {
                int n2;
                if (n == 0) {
                    if (e2.h0 == 0) {
                        n2 = 1;
                    }
                    else {
                        n2 = 0;
                    }
                    if (e2.h0 == 1) {
                        n3 = 1;
                    }
                    else {
                        n3 = 0;
                    }
                    n4 = n2;
                    n5 = n3;
                    if (e2.h0 != 2) {
                        break Label_0198;
                    }
                }
                else {
                    if (e2.i0 == 0) {
                        n2 = 1;
                    }
                    else {
                        n2 = 0;
                    }
                    if (e2.i0 == 1) {
                        n3 = 1;
                    }
                    else {
                        n3 = 0;
                    }
                    n4 = n2;
                    n5 = n3;
                    if (e2.i0 != 2) {
                        break Label_0198;
                    }
                }
                b3 = true;
                n4 = n2;
                break Label_0205;
            }
            b3 = false;
            n3 = n5;
        }
        e e3 = a;
        int n6 = 0;
        final int n7 = n3;
        i i;
        while (true) {
            i = null;
            final e e4 = null;
            if (n6 != 0) {
                break;
            }
            final a.e.b.k.d d3 = e3.N[e];
            int n8;
            if (b3) {
                n8 = 1;
            }
            else {
                n8 = 4;
            }
            final int e5 = d3.e();
            final boolean b4 = e3.Q[n] == a.e.b.k.e.b.d && e3.p[n] == 0;
            final a.e.b.k.d f3 = d3.f;
            int n9 = e5;
            if (f3 != null) {
                n9 = e5;
                if (e3 != a) {
                    n9 = e5 + f3.e();
                }
            }
            if (b3 && e3 != a && e3 != b) {
                n8 = 8;
            }
            final a.e.b.k.d f4 = d3.f;
            if (f4 != null) {
                if (e3 == b) {
                    d.h(d3.i, f4.i, n9, 6);
                }
                else {
                    d.h(d3.i, f4.i, n9, 8);
                }
                if (b4 && !b3) {
                    n8 = 5;
                }
                d.e(d3.i, d3.f.i, n9, n8);
            }
            if (b2) {
                if (e3.Q() != 8 && e3.Q[n] == a.e.b.k.e.b.d) {
                    final a.e.b.k.d[] n10 = e3.N;
                    d.h(n10[e + 1].i, n10[e].i, 0, 5);
                }
                d.h(e3.N[e].i, ((e)f).N[e].i, 0, 8);
            }
            final a.e.b.k.d f5 = e3.N[e + 1].f;
            e e6 = e4;
            if (f5 != null) {
                final e d4 = f5.d;
                final a.e.b.k.d[] n11 = d4.N;
                e6 = e4;
                if (n11[e].f != null) {
                    if (n11[e].f.d != e3) {
                        e6 = e4;
                    }
                    else {
                        e6 = d4;
                    }
                }
            }
            if (e6 != null) {
                e3 = e6;
            }
            else {
                n6 = 1;
            }
        }
        if (d2 != null) {
            final a.e.b.k.d[] n12 = c2.N;
            final int n13 = e + 1;
            if (n12[n13].f != null) {
                final a.e.b.k.d d5 = d2.N[n13];
                Label_0796: {
                    if (d2.Q[n] == a.e.b.k.e.b.d && d2.p[n] == 0 && !b3) {
                        final a.e.b.k.d f6 = d5.f;
                        if (f6.d == f) {
                            d.e(d5.i, f6.i, -d5.e(), 5);
                            break Label_0796;
                        }
                    }
                    if (b3) {
                        final a.e.b.k.d f7 = d5.f;
                        if (f7.d == f) {
                            d.e(d5.i, f7.i, -d5.e(), 4);
                        }
                    }
                }
                d.j(d5.i, c2.N[n13].f.i, -d5.e(), 6);
            }
        }
        if (b2) {
            final a.e.b.k.d[] n14 = ((e)f).N;
            final int n15 = e + 1;
            final i j = n14[n15].i;
            final a.e.b.k.d[] n16 = c2.N;
            d.h(j, n16[n15].i, n16[n15].e(), 8);
        }
        final ArrayList<e> h = c.h;
        if (h != null) {
            final int size = h.size();
            if (size > 1) {
                float n17;
                if (c.q && !c.s) {
                    n17 = (float)c.j;
                }
                else {
                    n17 = k;
                }
                e e7 = null;
                int l = 0;
                float n18 = 0.0f;
                while (l < size) {
                    final e e8 = (e)h.get(l);
                    float n19 = e8.j0[n];
                    Label_1172: {
                        Label_1064: {
                            if (n19 < 0.0f) {
                                if (c.s) {
                                    final a.e.b.k.d[] n20 = e8.N;
                                    d.e(n20[e + 1].i, n20[e].i, 0, 4);
                                    break Label_1064;
                                }
                                n19 = 1.0f;
                            }
                            if (n19 != 0.0f) {
                                if (e7 != null) {
                                    final a.e.b.k.d[] n21 = e7.N;
                                    final i m = n21[e].i;
                                    final int n22 = e + 1;
                                    final i i2 = n21[n22].i;
                                    final a.e.b.k.d[] n23 = e8.N;
                                    final i i3 = n23[e].i;
                                    final i i4 = n23[n22].i;
                                    final a.e.b.b r = d.r();
                                    r.l(n18, n17, n19, m, i2, i3, i4);
                                    d.d(r);
                                }
                                e7 = e8;
                                break Label_1172;
                            }
                            final a.e.b.k.d[] n24 = e8.N;
                            d.e(n24[e + 1].i, n24[e].i, 0, 8);
                        }
                        n19 = n18;
                    }
                    ++l;
                    n18 = n19;
                }
            }
        }
        if (b != null && (b == d2 || b3)) {
            final a.e.b.k.d d6 = a.N[e];
            final a.e.b.k.d[] n25 = c2.N;
            final int n26 = e + 1;
            final a.e.b.k.d d7 = n25[n26];
            final a.e.b.k.d f8 = d6.f;
            i i5;
            if (f8 != null) {
                i5 = f8.i;
            }
            else {
                i5 = null;
            }
            final a.e.b.k.d f9 = d7.f;
            i i6;
            if (f9 != null) {
                i6 = f9.i;
            }
            else {
                i6 = null;
            }
            final a.e.b.k.d d8 = b.N[e];
            final a.e.b.k.d d9 = d2.N[n26];
            if (i5 != null && i6 != null) {
                float n27;
                if (n == 0) {
                    n27 = e2.b0;
                }
                else {
                    n27 = e2.c0;
                }
                final int e9 = d8.e();
                n = d9.e();
                d.c(d8.i, i5, e9, n27, i6, d9.i, n, 7);
            }
        }
        else if (n4 != 0 && b != null) {
            final int j2 = c.j;
            final boolean b5 = j2 > 0 && c.i == j2;
            e e11;
            e e12;
            for (e e10 = e11 = b; e10 != null; e10 = e12) {
                for (e12 = e10.l0[n]; e12 != null && e12.Q() == 8; e12 = e12.l0[n]) {}
                if (e12 != null || e10 == d2) {
                    final a.e.b.k.d d10 = e10.N[e];
                    final i i7 = d10.i;
                    final a.e.b.k.d f10 = d10.f;
                    i i8;
                    if (f10 != null) {
                        i8 = f10.i;
                    }
                    else {
                        i8 = null;
                    }
                    i i9 = null;
                    Label_1581: {
                        a.e.b.k.d f11;
                        if (e11 != e10) {
                            f11 = e11.N[e + 1];
                        }
                        else {
                            i9 = i8;
                            if (e10 != b) {
                                break Label_1581;
                            }
                            i9 = i8;
                            if (e11 != e10) {
                                break Label_1581;
                            }
                            final a.e.b.k.d[] n28 = a.N;
                            if (n28[e].f == null) {
                                i9 = null;
                                break Label_1581;
                            }
                            f11 = n28[e].f;
                        }
                        i9 = f11.i;
                    }
                    final int e13 = d10.e();
                    final a.e.b.k.d[] n29 = e10.N;
                    final int n30 = e + 1;
                    final int e14 = n29[n30].e();
                    a.e.b.k.d f12;
                    i i10;
                    i i11;
                    if (e12 != null) {
                        f12 = e12.N[e];
                        i10 = f12.i;
                        i11 = e10.N[n30].i;
                    }
                    else {
                        f12 = c2.N[n30].f;
                        if (f12 != null) {
                            i10 = f12.i;
                        }
                        else {
                            i10 = null;
                        }
                        i11 = e10.N[n30].i;
                    }
                    int e15 = e14;
                    if (f12 != null) {
                        e15 = e14 + f12.e();
                    }
                    int e16 = e13;
                    if (e11 != null) {
                        e16 = e13 + e11.N[n30].e();
                    }
                    if (i7 != null && i9 != null && i10 != null && i11 != null) {
                        if (e10 == b) {
                            e16 = b.N[e].e();
                        }
                        if (e10 == d2) {
                            e15 = d2.N[n30].e();
                        }
                        int n31;
                        if (b5) {
                            n31 = 8;
                        }
                        else {
                            n31 = 5;
                        }
                        d.c(i7, i9, e16, 0.5f, i10, i11, e15, n31);
                    }
                }
                if (e10.Q() != 8) {
                    e11 = e10;
                }
            }
        }
        else if (n7 != 0 && b != null) {
            final int j3 = c.j;
            final boolean b6 = j3 > 0 && c.i == j3;
            e e18;
            e e19;
            for (e e17 = e18 = b; e17 != null; e17 = e19) {
                for (e19 = e17.l0[n]; e19 != null && e19.Q() == 8; e19 = e19.l0[n]) {}
                if (e17 != b && e17 != d2 && e19 != null) {
                    if (e19 == d2) {
                        e19 = null;
                    }
                    final a.e.b.k.d d11 = e17.N[e];
                    final i i12 = d11.i;
                    final a.e.b.k.d f13 = d11.f;
                    if (f13 != null) {
                        final i i13 = f13.i;
                    }
                    final a.e.b.k.d[] n32 = e18.N;
                    final int n33 = e + 1;
                    final i i14 = n32[n33].i;
                    final int e20 = d11.e();
                    final int e21 = e17.N[n33].e();
                    a.e.b.k.d d12 = null;
                    i i15 = null;
                    i i16 = null;
                    Label_2120: {
                        a.e.b.k.d f14;
                        if (e19 != null) {
                            d12 = e19.N[e];
                            i15 = d12.i;
                            f14 = d12.f;
                            if (f14 == null) {
                                i16 = null;
                                break Label_2120;
                            }
                        }
                        else {
                            d12 = d2.N[e];
                            if (d12 != null) {
                                i15 = d12.i;
                            }
                            else {
                                i15 = null;
                            }
                            f14 = e17.N[n33];
                        }
                        i16 = f14.i;
                    }
                    int n34 = e21;
                    if (d12 != null) {
                        n34 = e21 + d12.e();
                    }
                    int n35 = e20;
                    if (e18 != null) {
                        n35 = e20 + e18.N[n33].e();
                    }
                    int n36;
                    if (b6) {
                        n36 = 8;
                    }
                    else {
                        n36 = 4;
                    }
                    if (i12 != null && i14 != null && i15 != null && i16 != null) {
                        d.c(i12, i14, n35, 0.5f, i15, i16, n34, n36);
                    }
                }
                if (e17.Q() == 8) {
                    e17 = e18;
                }
                e18 = e17;
            }
            final a.e.b.k.d d13 = b.N[e];
            final a.e.b.k.d f15 = a.N[e].f;
            final a.e.b.k.d[] n37 = d2.N;
            n = e + 1;
            final a.e.b.k.d d14 = n37[n];
            final a.e.b.k.d f16 = c2.N[n].f;
            if (f15 != null) {
                if (b != d2) {
                    d.e(d13.i, f15.i, d13.e(), 5);
                }
                else if (f16 != null) {
                    d.c(d13.i, f15.i, d13.e(), 0.5f, d14.i, f16.i, d14.e(), 5);
                }
            }
            if (f16 != null && b != d2) {
                d.e(d14.i, f16.i, -d14.e(), 5);
            }
        }
        if ((n4 != 0 || n7 != 0) && b != null && b != d2) {
            a.e.b.k.d d15 = b.N[e];
            final a.e.b.k.d[] n38 = d2.N;
            final int n39 = e + 1;
            a.e.b.k.d d16 = n38[n39];
            final a.e.b.k.d f17 = d15.f;
            i i17;
            if (f17 != null) {
                i17 = f17.i;
            }
            else {
                i17 = null;
            }
            final a.e.b.k.d f18 = d16.f;
            i i18;
            if (f18 != null) {
                i18 = f18.i;
            }
            else {
                i18 = null;
            }
            if (c2 != d2) {
                final a.e.b.k.d f19 = c2.N[n39].f;
                i18 = i;
                if (f19 != null) {
                    i18 = f19.i;
                }
            }
            if (b == d2) {
                final a.e.b.k.d[] n40 = b.N;
                d15 = n40[e];
                d16 = n40[n39];
            }
            if (i17 != null && i18 != null) {
                n = d15.e();
                e e22;
                if (d2 == null) {
                    e22 = c2;
                }
                else {
                    e22 = d2;
                }
                e = e22.N[n39].e();
                d.c(d15.i, i17, n, 0.5f, i18, d16.i, e, 5);
            }
        }
    }
    
    public static void b(final f f, final d d, final ArrayList<e> list, final int n) {
        int i = 0;
        int n2;
        c[] array;
        int n3;
        if (n == 0) {
            n2 = f.y0;
            array = f.B0;
            n3 = 0;
        }
        else {
            n2 = f.z0;
            array = f.A0;
            n3 = 2;
        }
        while (i < n2) {
            final c c = array[i];
            c.a();
            if (list == null || (list != null && list.contains((Object)c.a))) {
                a(f, d, n, n3, c);
            }
            ++i;
        }
    }
}
