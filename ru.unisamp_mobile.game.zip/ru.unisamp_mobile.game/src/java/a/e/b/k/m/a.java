package a.e.b.k.m;

class a extends g
{
    public a(final p p) {
        super(p);
    }
}
