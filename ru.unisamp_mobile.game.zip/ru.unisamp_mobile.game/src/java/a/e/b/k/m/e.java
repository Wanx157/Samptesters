package a.e.b.k.m;

import java.util.Collection;
import a.e.b.k.i;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ArrayList;
import a.e.b.k.f;

public class e
{
    private f a;
    private boolean b;
    private boolean c;
    private f d;
    private ArrayList<p> e;
    private b.b f;
    private b.a g;
    ArrayList<m> h;
    
    public e(final f f) {
        this.b = true;
        this.c = true;
        this.e = (ArrayList<p>)new ArrayList();
        new ArrayList();
        this.f = null;
        this.g = new b.a();
        this.h = (ArrayList<m>)new ArrayList();
        this.a = f;
        this.d = f;
    }
    
    private void a(final a.e.b.k.m.f f, final int n, final int n2, final a.e.b.k.m.f f2, final ArrayList<m> list, m m) {
        final p d = f.d;
        if (d.c != null) {
            return;
        }
        final f a = this.a;
        if (d == ((a.e.b.k.e)a).d) {
            return;
        }
        if (d == ((a.e.b.k.e)a).e) {
            return;
        }
        m c;
        if ((c = m) == null) {
            c = new m(d, n2);
            list.add((Object)c);
        }
        (d.c = c).a(d);
        for (final d d2 : d.h.k) {
            if (d2 instanceof a.e.b.k.m.f) {
                this.a((a.e.b.k.m.f)d2, n, 0, f2, list, c);
            }
        }
        for (final d d3 : d.i.k) {
            if (d3 instanceof a.e.b.k.m.f) {
                this.a((a.e.b.k.m.f)d3, n, 1, f2, list, c);
            }
        }
        if (n == 1 && d instanceof n) {
            for (final d d4 : ((n)d).k.k) {
                if (d4 instanceof a.e.b.k.m.f) {
                    this.a((a.e.b.k.m.f)d4, n, 2, f2, list, c);
                }
            }
        }
        for (final a.e.b.k.m.f f3 : d.h.l) {
            if (f3 == f2) {
                c.a = true;
            }
            this.a(f3, n, 0, f2, list, c);
        }
        m = (m)d.i.l.iterator();
        while (((Iterator)m).hasNext()) {
            final a.e.b.k.m.f f4 = (a.e.b.k.m.f)((Iterator)m).next();
            if (f4 == f2) {
                c.a = true;
            }
            this.a(f4, n, 1, f2, list, c);
        }
        if (n != 1 || !(d instanceof n)) {
            return;
        }
        m = (m)((n)d).k.l.iterator();
        while (true) {
            if (!((Iterator)m).hasNext()) {
                return;
            }
            final a.e.b.k.m.f f5 = (a.e.b.k.m.f)((Iterator)m).next();
            try {
                this.a(f5, n, 2, f2, list, c);
                continue;
            }
            finally {
                while (true) {}
            }
            break;
        }
    }
    
    private boolean b(final f f) {
    Label_0583_Outer:
        for (final a.e.b.k.e e : ((a.e.b.k.l)f).p0) {
            final a.e.b.k.e.b[] q = e.Q;
            final a.e.b.k.e.b b = q[0];
            final a.e.b.k.e.b b2 = q[1];
            if (e.Q() != 8) {
                if (e.s < 1.0f && b == a.e.b.k.e.b.d) {
                    e.n = 2;
                }
                if (e.v < 1.0f && b2 == a.e.b.k.e.b.d) {
                    e.o = 2;
                }
                Label_0237: {
                    if (e.t() > 0.0f) {
                        if (b == a.e.b.k.e.b.d && (b2 == a.e.b.k.e.b.c || b2 == a.e.b.k.e.b.b)) {
                            e.n = 3;
                        }
                        else {
                            if (b2 != a.e.b.k.e.b.d || (b != a.e.b.k.e.b.c && b != a.e.b.k.e.b.b)) {
                                final a.e.b.k.e.b d = a.e.b.k.e.b.d;
                                if (b != d || b2 != d) {
                                    break Label_0237;
                                }
                                if (e.n == 0) {
                                    e.n = 3;
                                }
                                if (e.o != 0) {
                                    break Label_0237;
                                }
                            }
                            e.o = 3;
                        }
                    }
                }
                Enum<a.e.b.k.e.b> d2 = null;
                Label_0293: {
                    if ((d2 = b) == a.e.b.k.e.b.d) {
                        d2 = b;
                        if (e.n == 1) {
                            if (e.F.f != null) {
                                d2 = b;
                                if (e.H.f != null) {
                                    break Label_0293;
                                }
                            }
                            d2 = a.e.b.k.e.b.c;
                        }
                    }
                }
                Enum<a.e.b.k.e.b> d3 = null;
                Label_0349: {
                    if ((d3 = b2) == a.e.b.k.e.b.d) {
                        d3 = b2;
                        if (e.o == 1) {
                            if (e.G.f != null) {
                                d3 = b2;
                                if (e.I.f != null) {
                                    break Label_0349;
                                }
                            }
                            d3 = a.e.b.k.e.b.c;
                        }
                    }
                }
                final l d4 = e.d;
                ((p)d4).d = (a.e.b.k.e.b)d2;
                ((p)d4).a = e.n;
                final n e2 = e.e;
                ((p)e2).d = (a.e.b.k.e.b)d3;
                ((p)e2).a = e.o;
                int n2 = 0;
                int n3 = 0;
                Enum<a.e.b.k.e.b> enum1 = null;
                Label_1256: {
                    Label_1252: {
                        if ((d2 != a.e.b.k.e.b.e && d2 != a.e.b.k.e.b.b && d2 != a.e.b.k.e.b.c) || (d3 != a.e.b.k.e.b.e && d3 != a.e.b.k.e.b.b && d3 != a.e.b.k.e.b.c)) {
                            int n;
                            a.e.b.k.e.b c;
                            g g;
                            int m;
                            a.e.b.k.e.b[] q2;
                            a.e.b.k.d[] n4;
                            int o;
                            a.e.b.k.e.b c2;
                            float u;
                            float v;
                            a.e.b.k.e.b[] q3;
                            float v2;
                            a.e.b.k.d[] n5;
                            a.e.b.k.e.b d5;
                            int n6;
                            int o2;
                            a.e.b.k.e.b[] q4;
                            a.e.b.k.e.b b3;
                            a.e.b.k.e.b b4;
                            a.e.b.k.e.b[] q5;
                            a.e.b.k.e.b b5;
                            a.e.b.k.e.b b6;
                            float s;
                            a.e.b.k.e.b c3;
                            Label_0684_Outer:Label_0531_Outer:Label_0791_Outer:
                            while (true) {
                                Label_1114: {
                                    while (true) {
                                    Label_0921:
                                        while (true) {
                                            while (true) {
                                                Label_0698: {
                                                    if (d2 != a.e.b.k.e.b.d || (d3 != a.e.b.k.e.b.c && d3 != a.e.b.k.e.b.b)) {
                                                        break Label_0698;
                                                    }
                                                    n = e.n;
                                                    if (n == 3) {
                                                        c = a.e.b.k.e.b.c;
                                                        if (d3 == c) {
                                                            this.l(e, c, 0, c, 0);
                                                        }
                                                        n2 = e.v();
                                                        n3 = (int)(n2 * e.U + 0.5f);
                                                    }
                                                    else {
                                                        if (n == 1) {
                                                            this.l(e, a.e.b.k.e.b.c, 0, (a.e.b.k.e.b)d3, 0);
                                                            g = ((p)e.d).e;
                                                            m = e.R();
                                                            break Label_0583;
                                                        }
                                                        if (n == 2) {
                                                            q2 = ((a.e.b.k.e)f).Q;
                                                            if (q2[0] == a.e.b.k.e.b.b || q2[0] == a.e.b.k.e.b.e) {
                                                                n3 = (int)(e.s * ((a.e.b.k.e)f).R() + 0.5f);
                                                                n2 = e.v();
                                                                d2 = a.e.b.k.e.b.b;
                                                                break Label_1252;
                                                            }
                                                            break Label_0698;
                                                        }
                                                        else {
                                                            n4 = e.N;
                                                            if (n4[0].f == null || n4[1].f == null) {
                                                                break Label_0684;
                                                            }
                                                            break Label_0698;
                                                        }
                                                    }
                                                    enum1 = (d3 = a.e.b.k.e.b.b);
                                                    break Label_1256;
                                                    g.m = m;
                                                    continue Label_0583_Outer;
                                                    d2 = a.e.b.k.e.b.c;
                                                    n3 = 0;
                                                    n2 = 0;
                                                    break Label_1252;
                                                }
                                                if (d3 != a.e.b.k.e.b.d || (d2 != a.e.b.k.e.b.c && d2 != a.e.b.k.e.b.b)) {
                                                    break Label_0921;
                                                }
                                                o = e.o;
                                                if (o == 3) {
                                                    c2 = a.e.b.k.e.b.c;
                                                    if (d2 == c2) {
                                                        this.l(e, c2, 0, c2, 0);
                                                    }
                                                    n3 = e.R();
                                                    u = e.U;
                                                    if (e.u() == -1) {
                                                        u = 1.0f / u;
                                                    }
                                                    v = (float)n3;
                                                }
                                                else {
                                                    if (o == 1) {
                                                        this.l(e, (a.e.b.k.e.b)d2, 0, a.e.b.k.e.b.c, 0);
                                                        break Label_1114;
                                                    }
                                                    if (o == 2) {
                                                        q3 = ((a.e.b.k.e)f).Q;
                                                        if (q3[1] == a.e.b.k.e.b.b || q3[1] == a.e.b.k.e.b.e) {
                                                            v2 = e.v;
                                                            n3 = e.R();
                                                            n2 = (int)(v2 * ((a.e.b.k.e)f).v() + 0.5f);
                                                            d3 = a.e.b.k.e.b.b;
                                                            break Label_1252;
                                                        }
                                                        break Label_0921;
                                                    }
                                                    else {
                                                        n5 = e.N;
                                                        if (n5[2].f == null) {
                                                            continue Label_0531_Outer;
                                                        }
                                                        if (n5[3].f == null) {
                                                            continue Label_0531_Outer;
                                                        }
                                                        break Label_0921;
                                                    }
                                                }
                                                break;
                                            }
                                            n2 = (int)(v * u + 0.5f);
                                            continue Label_0791_Outer;
                                        }
                                        d5 = a.e.b.k.e.b.d;
                                        if (d2 != d5 || d3 != d5) {
                                            continue Label_0583_Outer;
                                        }
                                        n6 = e.n;
                                        if (n6 != 1) {
                                            o2 = e.o;
                                            if (o2 != 1) {
                                                if (o2 != 2 || n6 != 2) {
                                                    continue Label_0583_Outer;
                                                }
                                                q4 = ((a.e.b.k.e)f).Q;
                                                b3 = q4[0];
                                                b4 = a.e.b.k.e.b.b;
                                                if (b3 != b4 && q4[0] != b4) {
                                                    continue Label_0583_Outer;
                                                }
                                                q5 = ((a.e.b.k.e)f).Q;
                                                b5 = q5[1];
                                                b6 = a.e.b.k.e.b.b;
                                                if (b5 == b6 || q5[1] == b6) {
                                                    s = e.s;
                                                    v = e.v;
                                                    n3 = (int)(s * ((a.e.b.k.e)f).R() + 0.5f);
                                                    u = (float)((a.e.b.k.e)f).v();
                                                    continue;
                                                }
                                                continue Label_0583_Outer;
                                            }
                                        }
                                        break;
                                    }
                                    c3 = a.e.b.k.e.b.c;
                                    this.l(e, c3, 0, c3, 0);
                                    ((p)e.d).e.m = e.R();
                                }
                                g = ((p)e.e).e;
                                m = e.v();
                                continue Label_0684_Outer;
                            }
                        }
                        n3 = e.R();
                        if (d2 == a.e.b.k.e.b.e) {
                            final int r = ((a.e.b.k.e)f).R();
                            final int g2 = e.F.g;
                            final int g3 = e.H.g;
                            d2 = a.e.b.k.e.b.b;
                            n3 = r - g2 - g3;
                        }
                        n2 = e.v();
                        if (d3 == a.e.b.k.e.b.e) {
                            final int v3 = ((a.e.b.k.e)f).v();
                            final int g4 = e.G.g;
                            final int g5 = e.I.g;
                            d3 = a.e.b.k.e.b.b;
                            n2 = v3 - g4 - g5;
                        }
                    }
                    enum1 = d2;
                }
                this.l(e, (a.e.b.k.e.b)enum1, n3, (a.e.b.k.e.b)d3, n2);
                ((p)e.d).e.d(e.R());
                ((p)e.e).e.d(e.v());
            }
            e.a = true;
        }
        return false;
    }
    
    private int e(final f f, final int n) {
        final int size = this.h.size();
        long max = 0L;
        for (int i = 0; i < size; ++i) {
            max = Math.max(max, ((m)this.h.get(i)).b(f, n));
        }
        return (int)max;
    }
    
    private void i(final p p3, final int n, final ArrayList<m> list) {
        for (final d d : p3.h.k) {
            if (d instanceof a.e.b.k.m.f) {
                this.a((a.e.b.k.m.f)d, n, 0, p3.i, list, null);
            }
            else {
                if (!(d instanceof p)) {
                    continue;
                }
                this.a(((p)d).h, n, 0, p3.i, list, null);
            }
        }
        for (final d d2 : p3.i.k) {
            if (d2 instanceof a.e.b.k.m.f) {
                this.a((a.e.b.k.m.f)d2, n, 1, p3.h, list, null);
            }
            else {
                if (!(d2 instanceof p)) {
                    continue;
                }
                this.a(((p)d2).i, n, 1, p3.h, list, null);
            }
        }
        if (n == 1) {
            for (final d d3 : ((n)p3).k.k) {
                if (d3 instanceof a.e.b.k.m.f) {
                    this.a((a.e.b.k.m.f)d3, n, 2, null, list, null);
                }
            }
        }
    }
    
    private void l(final a.e.b.k.e e, final a.e.b.k.e.b a, final int c, final a.e.b.k.e.b b, final int d) {
        final b.a g = this.g;
        g.a = a;
        g.b = b;
        g.c = c;
        g.d = d;
        this.f.a(e, g);
        e.U0(this.g.e);
        e.v0(this.g.f);
        e.u0(this.g.h);
        e.k0(this.g.g);
    }
    
    public void c() {
        this.d(this.e);
        this.h.clear();
        m.d = 0;
        this.i((p)((a.e.b.k.e)this.a).d, 0, this.h);
        this.i((p)((a.e.b.k.e)this.a).e, 1, this.h);
        this.b = false;
    }
    
    public void d(final ArrayList<p> list) {
        list.clear();
        ((a.e.b.k.e)this.d).d.f();
        ((a.e.b.k.e)this.d).e.f();
        list.add((Object)((a.e.b.k.e)this.d).d);
        list.add((Object)((a.e.b.k.e)this.d).e);
        final Iterator iterator = ((a.e.b.k.l)this.d).p0.iterator();
        Object o = null;
        while (iterator.hasNext()) {
            final a.e.b.k.e e = (a.e.b.k.e)iterator.next();
            Object o2;
            if (e instanceof a.e.b.k.g) {
                o2 = new j(e);
            }
            else {
                if (e.Z()) {
                    if (e.b == null) {
                        e.b = new c(e, 0);
                    }
                    HashSet set;
                    if ((set = (HashSet)o) == null) {
                        set = new HashSet();
                    }
                    set.add((Object)e.b);
                    o = set;
                }
                else {
                    list.add((Object)e.d);
                }
                HashSet set2;
                if (e.b0()) {
                    if (e.c == null) {
                        e.c = new c(e, 1);
                    }
                    if ((set2 = (HashSet)o) == null) {
                        set2 = new HashSet();
                    }
                    set2.add((Object)e.c);
                }
                else {
                    list.add((Object)e.e);
                    set2 = (HashSet)o;
                }
                o = set2;
                if (!(e instanceof i)) {
                    continue;
                }
                final k k = new k(e);
                o = set2;
                o2 = k;
            }
            list.add(o2);
        }
        if (o != null) {
            list.addAll((Collection)o);
        }
        final Iterator iterator2 = list.iterator();
        while (iterator2.hasNext()) {
            ((p)iterator2.next()).f();
        }
        for (final p p : list) {
            if (p.b == this.d) {
                continue;
            }
            p.d();
        }
    }
    
    public boolean f(final boolean b) {
        final boolean b2 = true;
        final boolean b3 = b & true;
        if (this.b || this.c) {
            for (final a.e.b.k.e e : ((a.e.b.k.l)this.a).p0) {
                e.l();
                e.a = false;
                e.d.r();
                e.e.q();
            }
            ((a.e.b.k.e)this.a).l();
            final f a = this.a;
            ((a.e.b.k.e)a).a = false;
            ((a.e.b.k.e)a).d.r();
            ((a.e.b.k.e)this.a).e.q();
            this.c = false;
        }
        if (this.b(this.d)) {
            return false;
        }
        ((a.e.b.k.e)this.a).V0(0);
        ((a.e.b.k.e)this.a).W0(0);
        final a.e.b.k.e.b s = ((a.e.b.k.e)this.a).s(0);
        final a.e.b.k.e.b s2 = ((a.e.b.k.e)this.a).s(1);
        if (this.b) {
            this.c();
        }
        final int s3 = ((a.e.b.k.e)this.a).S();
        final int t = ((a.e.b.k.e)this.a).T();
        ((p)((a.e.b.k.e)this.a).d).h.d(s3);
        ((p)((a.e.b.k.e)this.a).e).h.d(t);
        this.m();
        final a.e.b.k.e.b c = a.e.b.k.e.b.c;
        if (s == c || s2 == c) {
            boolean b4 = false;
            Label_0303: {
                if (b4 = b3) {
                    final Iterator iterator2 = this.e.iterator();
                    do {
                        b4 = b3;
                        if (iterator2.hasNext()) {
                            continue;
                        }
                        break Label_0303;
                    } while (((p)iterator2.next()).m());
                    b4 = false;
                }
            }
            if (b4 && s == a.e.b.k.e.b.c) {
                ((a.e.b.k.e)this.a).z0(a.e.b.k.e.b.b);
                final f a2 = this.a;
                ((a.e.b.k.e)a2).U0(this.e(a2, 0));
                final f a3 = this.a;
                ((p)((a.e.b.k.e)a3).d).e.d(((a.e.b.k.e)a3).R());
            }
            if (b4 && s2 == a.e.b.k.e.b.c) {
                ((a.e.b.k.e)this.a).Q0(a.e.b.k.e.b.b);
                final f a4 = this.a;
                ((a.e.b.k.e)a4).v0(this.e(a4, 1));
                final f a5 = this.a;
                ((p)((a.e.b.k.e)a5).e).e.d(((a.e.b.k.e)a5).v());
            }
        }
        final a.e.b.k.e.b[] q = ((a.e.b.k.e)this.a).Q;
        boolean b5;
        if (q[0] != a.e.b.k.e.b.b && q[0] != a.e.b.k.e.b.e) {
            b5 = false;
        }
        else {
            final int n = ((a.e.b.k.e)this.a).R() + s3;
            ((p)((a.e.b.k.e)this.a).d).i.d(n);
            ((p)((a.e.b.k.e)this.a).d).e.d(n - s3);
            this.m();
            final a.e.b.k.e.b[] q2 = ((a.e.b.k.e)this.a).Q;
            if (q2[1] == a.e.b.k.e.b.b || q2[1] == a.e.b.k.e.b.e) {
                final int n2 = ((a.e.b.k.e)this.a).v() + t;
                ((p)((a.e.b.k.e)this.a).e).i.d(n2);
                ((p)((a.e.b.k.e)this.a).e).e.d(n2 - t);
            }
            this.m();
            b5 = true;
        }
        for (final p p : this.e) {
            if (p.b == this.a && !p.g) {
                continue;
            }
            p.e();
        }
        final Iterator iterator4 = this.e.iterator();
        boolean b6 = false;
        Label_0770: {
            while (true) {
                b6 = b2;
                if (!iterator4.hasNext()) {
                    break Label_0770;
                }
                final p p2 = (p)iterator4.next();
                if (!b5 && p2.b == this.a) {
                    continue;
                }
                if (!p2.h.j) {
                    break;
                }
                if (!p2.i.j && !(p2 instanceof j)) {
                    break;
                }
                if (!((a.e.b.k.m.f)p2.e).j && !(p2 instanceof c) && !(p2 instanceof j)) {
                    break;
                }
            }
            b6 = false;
        }
        ((a.e.b.k.e)this.a).z0(s);
        ((a.e.b.k.e)this.a).Q0(s2);
        return b6;
    }
    
    public boolean g(final boolean b) {
        if (this.b) {
            for (final a.e.b.k.e e : ((a.e.b.k.l)this.a).p0) {
                e.l();
                e.a = false;
                final l d = e.d;
                ((a.e.b.k.m.f)((p)d).e).j = false;
                ((p)d).g = false;
                d.r();
                final n e2 = e.e;
                ((a.e.b.k.m.f)((p)e2).e).j = false;
                ((p)e2).g = false;
                e2.q();
            }
            ((a.e.b.k.e)this.a).l();
            final f a = this.a;
            ((a.e.b.k.e)a).a = false;
            final l d2 = ((a.e.b.k.e)a).d;
            ((a.e.b.k.m.f)((p)d2).e).j = false;
            ((p)d2).g = false;
            d2.r();
            final n e3 = ((a.e.b.k.e)this.a).e;
            ((a.e.b.k.m.f)((p)e3).e).j = false;
            ((p)e3).g = false;
            e3.q();
            this.c();
        }
        if (this.b(this.d)) {
            return false;
        }
        ((a.e.b.k.e)this.a).V0(0);
        ((a.e.b.k.e)this.a).W0(0);
        ((p)((a.e.b.k.e)this.a).d).h.d(0);
        ((p)((a.e.b.k.e)this.a).e).h.d(0);
        return true;
    }
    
    public boolean h(final boolean b, final int n) {
        final boolean b2 = true;
        final boolean b3 = b & true;
        final a.e.b.k.e.b s = ((a.e.b.k.e)this.a).s(0);
        final a.e.b.k.e.b s2 = ((a.e.b.k.e)this.a).s(1);
        final int s3 = ((a.e.b.k.e)this.a).S();
        final int t = ((a.e.b.k.e)this.a).T();
        Label_0260: {
            if (b3) {
                final a.e.b.k.e.b c = a.e.b.k.e.b.c;
                if (s == c || s2 == c) {
                    final Iterator iterator = this.e.iterator();
                    while (true) {
                        p p2;
                        do {
                            final boolean b4 = b3;
                            if (!iterator.hasNext()) {
                                g g;
                                int n2;
                                if (n == 0) {
                                    if (!b4 || s != a.e.b.k.e.b.c) {
                                        break Label_0260;
                                    }
                                    ((a.e.b.k.e)this.a).z0(a.e.b.k.e.b.b);
                                    final f a = this.a;
                                    ((a.e.b.k.e)a).U0(this.e(a, 0));
                                    final f a2 = this.a;
                                    g = ((p)((a.e.b.k.e)a2).d).e;
                                    n2 = ((a.e.b.k.e)a2).R();
                                }
                                else {
                                    if (!b4 || s2 != a.e.b.k.e.b.c) {
                                        break Label_0260;
                                    }
                                    ((a.e.b.k.e)this.a).Q0(a.e.b.k.e.b.b);
                                    final f a3 = this.a;
                                    ((a.e.b.k.e)a3).v0(this.e(a3, 1));
                                    final f a4 = this.a;
                                    g = ((p)((a.e.b.k.e)a4).e).e;
                                    n2 = ((a.e.b.k.e)a4).v();
                                }
                                g.d(n2);
                                break Label_0260;
                            }
                            p2 = (p)iterator.next();
                        } while (p2.f != n || p2.m());
                        final boolean b4 = false;
                        continue;
                    }
                }
            }
        }
        final a.e.b.k.e.b[] q = ((a.e.b.k.e)this.a).Q;
        boolean b5 = false;
        Label_0410: {
            Label_0408: {
                if (n == 0) {
                    if (q[0] == a.e.b.k.e.b.b || q[0] == a.e.b.k.e.b.e) {
                        final int n3 = ((a.e.b.k.e)this.a).R() + s3;
                        ((p)((a.e.b.k.e)this.a).d).i.d(n3);
                        ((p)((a.e.b.k.e)this.a).d).e.d(n3 - s3);
                        break Label_0408;
                    }
                }
                else if (q[1] == a.e.b.k.e.b.b || q[1] == a.e.b.k.e.b.e) {
                    final int n4 = ((a.e.b.k.e)this.a).v() + t;
                    ((p)((a.e.b.k.e)this.a).e).i.d(n4);
                    ((p)((a.e.b.k.e)this.a).e).e.d(n4 - t);
                    break Label_0408;
                }
                b5 = false;
                break Label_0410;
            }
            b5 = true;
        }
        this.m();
        for (final p p3 : this.e) {
            if (p3.f != n) {
                continue;
            }
            if (p3.b == this.a && !p3.g) {
                continue;
            }
            p3.e();
        }
        final Iterator iterator3 = this.e.iterator();
        boolean b6 = false;
        Label_0605: {
            while (true) {
                b6 = b2;
                if (!iterator3.hasNext()) {
                    break Label_0605;
                }
                final p p4 = (p)iterator3.next();
                if (p4.f != n) {
                    continue;
                }
                if (!b5 && p4.b == this.a) {
                    continue;
                }
                if (!p4.h.j) {
                    break;
                }
                if (!p4.i.j) {
                    break;
                }
                if (!(p4 instanceof c) && !((a.e.b.k.m.f)p4.e).j) {
                    break;
                }
            }
            b6 = false;
        }
        ((a.e.b.k.e)this.a).z0(s);
        ((a.e.b.k.e)this.a).Q0(s2);
        return b6;
    }
    
    public void j() {
        this.b = true;
    }
    
    public void k() {
        this.c = true;
    }
    
    public void m() {
        for (final a.e.b.k.e e : ((a.e.b.k.l)this.a).p0) {
            if (e.a) {
                continue;
            }
            final a.e.b.k.e.b[] q = e.Q;
            final int n = 0;
            final a.e.b.k.e.b b = q[0];
            final a.e.b.k.e.b b2 = q[1];
            final int n2 = e.n;
            final int o = e.o;
            final boolean b3 = b == a.e.b.k.e.b.c || (b == a.e.b.k.e.b.d && n2 == 1);
            int n3 = 0;
            Label_0138: {
                if (b2 != a.e.b.k.e.b.c) {
                    n3 = n;
                    if (b2 != a.e.b.k.e.b.d) {
                        break Label_0138;
                    }
                    n3 = n;
                    if (o != 1) {
                        break Label_0138;
                    }
                }
                n3 = 1;
            }
            final g e2 = ((p)e.d).e;
            final boolean j = ((a.e.b.k.m.f)e2).j;
            final g e3 = ((p)e.e).e;
            final boolean i = ((a.e.b.k.m.f)e3).j;
            Label_0406: {
                if (j && i) {
                    final a.e.b.k.e.b b4 = a.e.b.k.e.b.b;
                    this.l(e, b4, ((a.e.b.k.m.f)e2).g, b4, ((a.e.b.k.m.f)e3).g);
                }
                else {
                    g g = null;
                    int n4 = 0;
                    Label_0308: {
                        g g2;
                        int m;
                        if (j && n3 != 0) {
                            this.l(e, a.e.b.k.e.b.b, ((a.e.b.k.m.f)((p)e.d).e).g, a.e.b.k.e.b.c, ((a.e.b.k.m.f)((p)e.e).e).g);
                            if (b2 != a.e.b.k.e.b.d) {
                                g = ((p)e.e).e;
                                n4 = e.v();
                                break Label_0308;
                            }
                            g2 = ((p)e.e).e;
                            m = e.v();
                        }
                        else {
                            if (!i || !b3) {
                                break Label_0406;
                            }
                            this.l(e, a.e.b.k.e.b.c, ((a.e.b.k.m.f)((p)e.d).e).g, a.e.b.k.e.b.b, ((a.e.b.k.m.f)((p)e.e).e).g);
                            if (b != a.e.b.k.e.b.d) {
                                g = ((p)e.d).e;
                                n4 = e.R();
                                break Label_0308;
                            }
                            g2 = ((p)e.d).e;
                            m = e.R();
                        }
                        g2.m = m;
                        break Label_0406;
                    }
                    g.d(n4);
                }
                e.a = true;
            }
            if (!e.a) {
                continue;
            }
            final g l = e.e.l;
            if (l == null) {
                continue;
            }
            l.d(e.n());
        }
    }
    
    public void n(final b.b f) {
        this.f = f;
    }
}
