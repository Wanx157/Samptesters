package a.e.b.k.m;

import java.util.List;
import a.e.b.k.d$b;
import a.e.b.k.h;
import a.e.b.k.e$b;
import a.e.b.k.e;

public class l extends p
{
    private static int[] k;
    
    static {
        l.k = new int[2];
    }
    
    public l(final e e) {
        super(e);
        super.h.e = f$a.e;
        super.i.e = f$a.f;
        super.f = 0;
    }
    
    private void q(final int[] array, int n, int n2, int n3, int n4, final float n5, final int n6) {
        n = n2 - n;
        n2 = n4 - n3;
        if (n6 != -1) {
            if (n6 != 0) {
                if (n6 == 1) {
                    n2 = (int)(n * n5 + 0.5f);
                    array[0] = n;
                    array[1] = n2;
                }
            }
            else {
                array[0] = (int)(n2 * n5 + 0.5f);
                array[1] = n2;
            }
        }
        else {
            n4 = (int)(n2 * n5 + 0.5f);
            n3 = (int)(n / n5 + 0.5f);
            if (n4 <= n) {
                array[0] = n4;
                array[1] = n2;
            }
            else if (n3 <= n2) {
                array[0] = n;
                array[1] = n3;
            }
        }
    }
    
    @Override
    public void a(final d d) {
        final int n = l$a.a[((Enum)super.j).ordinal()];
        if (n != 1) {
            if (n != 2) {
                if (n == 3) {
                    final e b = super.b;
                    this.n(d, b.F, b.H, 0);
                    return;
                }
            }
            else {
                this.o(d);
            }
        }
        else {
            this.p(d);
        }
        Label_1481: {
            if (!super.e.j && super.d == e$b.d) {
                final e b2 = super.b;
                final int n2 = b2.n;
                int n18 = 0;
                Label_1473: {
                    if (n2 != 2) {
                        if (n2 != 3) {
                            break Label_1481;
                        }
                        final int o = b2.o;
                        if (o == 0 || o == 3) {
                            final e b3 = super.b;
                            final n e = b3.e;
                            final f h = e.h;
                            final f i = e.i;
                            final boolean b4 = b3.F.f != null;
                            final boolean b5 = super.b.G.f != null;
                            final boolean b6 = super.b.H.f != null;
                            final boolean b7 = super.b.I.f != null;
                            final int u = super.b.u();
                            g g;
                            int n3 = 0;
                            if (b4 && b5 && b6 && b7) {
                                final float t = super.b.t();
                                if (h.j && i.j) {
                                    final f h2 = super.h;
                                    if (h2.c) {
                                        if (super.i.c) {
                                            this.q(l.k, ((f)h2.l.get(0)).g + super.h.f, ((f)super.i.l.get(0)).g - super.i.f, h.g + h.f, i.g - i.f, t, u);
                                            super.e.d(l.k[0]);
                                            super.b.e.e.d(l.k[1]);
                                        }
                                    }
                                    return;
                                }
                                final f h3 = super.h;
                                if (h3.j) {
                                    final f j = super.i;
                                    if (j.j) {
                                        if (!h.c || !i.c) {
                                            return;
                                        }
                                        this.q(l.k, h3.g + h3.f, j.g - j.f, ((f)h.l.get(0)).g + h.f, ((f)i.l.get(0)).g - i.f, t, u);
                                        super.e.d(l.k[0]);
                                        super.b.e.e.d(l.k[1]);
                                    }
                                }
                                final f h4 = super.h;
                                if (!h4.c || !super.i.c || !h.c || !i.c) {
                                    return;
                                }
                                this.q(l.k, ((f)h4.l.get(0)).g + super.h.f, ((f)super.i.l.get(0)).g - super.i.f, ((f)h.l.get(0)).g + h.f, ((f)i.l.get(0)).g - i.f, t, u);
                                super.e.d(l.k[0]);
                                g = super.b.e.e;
                                n3 = l.k[1];
                            }
                            else if (b4 && b6) {
                                if (super.h.c && super.i.c) {
                                    final float t2 = super.b.t();
                                    final int n4 = ((f)super.h.l.get(0)).g + super.h.f;
                                    final int n5 = ((f)super.i.l.get(0)).g - super.i.f;
                                    int n6 = 0;
                                    int n8 = 0;
                                    Label_1161: {
                                        float n9;
                                        if (u != -1 && u != 0) {
                                            if (u != 1) {
                                                break Label_1481;
                                            }
                                            n6 = this.g(n5 - n4, 0);
                                            final int n7 = (int)(n6 / t2 + 0.5f);
                                            final int g2 = this.g(n7, 1);
                                            if (n7 == (n8 = g2)) {
                                                break Label_1161;
                                            }
                                            n9 = g2 * t2;
                                            n8 = g2;
                                        }
                                        else {
                                            n6 = this.g(n5 - n4, 0);
                                            final int n10 = (int)(n6 * t2 + 0.5f);
                                            final int g3 = this.g(n10, 1);
                                            if (n10 == (n8 = g3)) {
                                                break Label_1161;
                                            }
                                            n9 = g3 / t2;
                                            n8 = g3;
                                        }
                                        n6 = (int)(n9 + 0.5f);
                                    }
                                    super.e.d(n6);
                                    super.b.e.e.d(n8);
                                    break Label_1481;
                                }
                                return;
                            }
                            else {
                                if (!b5 || !b7) {
                                    break Label_1481;
                                }
                                if (!h.c || !i.c) {
                                    return;
                                }
                                final float t3 = super.b.t();
                                final int n11 = ((f)h.l.get(0)).g + h.f;
                                final int n12 = ((f)i.l.get(0)).g - i.f;
                                int n14 = 0;
                                Label_1400: {
                                    float n15 = 0.0f;
                                    Label_1394: {
                                        if (u != -1) {
                                            if (u != 0) {
                                                if (u != 1) {
                                                    break Label_1481;
                                                }
                                            }
                                            else {
                                                n3 = this.g(n12 - n11, 1);
                                                final int n13 = (int)(n3 * t3 + 0.5f);
                                                final int g4 = this.g(n13, 0);
                                                if (n13 != (n14 = g4)) {
                                                    n15 = g4 / t3;
                                                    n14 = g4;
                                                    break Label_1394;
                                                }
                                                break Label_1400;
                                            }
                                        }
                                        n3 = this.g(n12 - n11, 1);
                                        final int n16 = (int)(n3 / t3 + 0.5f);
                                        final int g5 = this.g(n16, 0);
                                        if (n16 == (n14 = g5)) {
                                            break Label_1400;
                                        }
                                        n15 = g5 * t3;
                                        n14 = g5;
                                    }
                                    n3 = (int)(n15 + 0.5f);
                                }
                                super.e.d(n14);
                                g = super.b.e.e;
                            }
                            g.d(n3);
                            break Label_1481;
                        }
                        final int u2 = b2.u();
                        float n17 = 0.0f;
                        Label_0197: {
                            if (u2 != -1) {
                                if (u2 == 0) {
                                    final e b8 = super.b;
                                    n17 = b8.e.e.g / b8.t();
                                    break Label_0197;
                                }
                                if (u2 != 1) {
                                    n18 = 0;
                                    break Label_1473;
                                }
                            }
                            final e b9 = super.b;
                            n17 = b9.e.e.g * b9.t();
                        }
                        n18 = (int)(n17 + 0.5f);
                    }
                    else {
                        final e k = b2.I();
                        if (k == null) {
                            break Label_1481;
                        }
                        final g e2 = k.d.e;
                        if (!e2.j) {
                            break Label_1481;
                        }
                        n18 = (int)(e2.g * super.b.s + 0.5f);
                    }
                }
                super.e.d(n18);
            }
        }
        final f h5 = super.h;
        if (h5.c) {
            final f l = super.i;
            if (l.c) {
                if (h5.j && l.j && super.e.j) {
                    return;
                }
                if (!super.e.j && super.d == e$b.d) {
                    final e b10 = super.b;
                    if (b10.n == 0 && !b10.Z()) {
                        final f f = (f)super.h.l.get(0);
                        final f f2 = (f)super.i.l.get(0);
                        final int g6 = f.g;
                        final f h6 = super.h;
                        final int n19 = g6 + h6.f;
                        final int n20 = f2.g + super.i.f;
                        h6.d(n19);
                        super.i.d(n20);
                        super.e.d(n20 - n19);
                        return;
                    }
                }
                if (!super.e.j && super.d == e$b.d && super.a == 1 && super.h.l.size() > 0 && super.i.l.size() > 0) {
                    final int min = Math.min(((f)super.i.l.get(0)).g + super.i.f - (((f)super.h.l.get(0)).g + super.h.f), super.e.m);
                    final e b11 = super.b;
                    final int r = b11.r;
                    int n21 = Math.max(b11.q, min);
                    if (r > 0) {
                        n21 = Math.min(r, n21);
                    }
                    super.e.d(n21);
                }
                if (!super.e.j) {
                    return;
                }
                final f f3 = (f)super.h.l.get(0);
                final f f4 = (f)super.i.l.get(0);
                int g7 = f3.g + super.h.f;
                int g8 = f4.g + super.i.f;
                float w = super.b.w();
                if (f3 == f4) {
                    g7 = f3.g;
                    g8 = f4.g;
                    w = 0.5f;
                }
                super.h.d((int)(g7 + 0.5f + (g8 - g7 - super.e.g) * w));
                super.i.d(super.h.g + super.e.g);
            }
        }
    }
    
    @Override
    void d() {
        final e b = super.b;
        if (b.a) {
            super.e.d(b.R());
        }
        if (!super.e.j) {
            final e$b y = super.b.y();
            if ((super.d = y) != e$b.d) {
                if (y == e$b.e) {
                    final e i = super.b.I();
                    if ((i != null && i.y() == e$b.b) || i.y() == e$b.e) {
                        final int r = i.R();
                        final int e = super.b.F.e();
                        final int e2 = super.b.H.e();
                        this.b(super.h, i.d.h, super.b.F.e());
                        this.b(super.i, i.d.i, -super.b.H.e());
                        super.e.d(r - e - e2);
                        return;
                    }
                }
                if (super.d == e$b.b) {
                    super.e.d(super.b.R());
                }
            }
        }
        else if (super.d == e$b.e) {
            final e j = super.b.I();
            if ((j != null && j.y() == e$b.b) || j.y() == e$b.e) {
                this.b(super.h, j.d.h, super.b.F.e());
                this.b(super.i, j.d.i, -super.b.H.e());
                return;
            }
        }
        final boolean k = super.e.j;
        int n = 1;
        f f3 = null;
        a.e.b.k.d d = null;
        Label_1435: {
            if (k) {
                final e b2 = super.b;
                if (b2.a) {
                    final a.e.b.k.d[] n2 = b2.N;
                    if (n2[0].f == null || n2[1].f == null) {
                        final e b3 = super.b;
                        final a.e.b.k.d[] n3 = b3.N;
                        f f = null;
                        f f2 = null;
                        int g = 0;
                        Label_0751: {
                            if (n3[0].f != null) {
                                final f h = this.h(n3[0]);
                                if (h == null) {
                                    return;
                                }
                                this.b(super.h, h, super.b.N[0].e());
                            }
                            else if (n3[1].f != null) {
                                final f h2 = this.h(n3[1]);
                                if (h2 != null) {
                                    this.b(super.i, h2, -super.b.N[1].e());
                                    f = super.h;
                                    f2 = super.i;
                                    g = -super.e.g;
                                    break Label_0751;
                                }
                                return;
                            }
                            else {
                                if (b3 instanceof h || b3.I() == null || super.b.m(d$b.h).f != null) {
                                    return;
                                }
                                this.b(super.h, super.b.I().d.h, super.b.S());
                            }
                            f = super.i;
                            f2 = super.h;
                            g = super.e.g;
                        }
                        this.b(f, f2, g);
                        return;
                    }
                    if (b2.Z()) {
                        super.h.f = super.b.N[0].e();
                        f3 = super.i;
                        d = super.b.N[1];
                        break Label_1435;
                    }
                    final f h3 = this.h(super.b.N[0]);
                    if (h3 != null) {
                        this.b(super.h, h3, super.b.N[0].e());
                    }
                    final f h4 = this.h(super.b.N[1]);
                    if (h4 != null) {
                        this.b(super.i, h4, -super.b.N[1].e());
                    }
                    super.h.b = true;
                    super.i.b = true;
                    return;
                }
            }
            Label_1358: {
                if (super.d == e$b.d) {
                    final e b4 = super.b;
                    final int n4 = b4.n;
                    Object o = null;
                    f f4 = null;
                    Label_1348: {
                        if (n4 != 2) {
                            if (n4 != 3) {
                                break Label_1358;
                            }
                            Label_1242: {
                                f f5;
                                if (b4.o == 3) {
                                    super.h.a = (d)this;
                                    super.i.a = (d)this;
                                    final n e3 = b4.e;
                                    e3.h.a = (d)this;
                                    e3.i.a = (d)this;
                                    super.e.a = (d)this;
                                    if (b4.b0()) {
                                        super.e.l.add((Object)super.b.e.e);
                                        super.b.e.e.k.add((Object)super.e);
                                        final n e4 = super.b.e;
                                        e4.e.a = (d)this;
                                        super.e.l.add((Object)e4.h);
                                        super.e.l.add((Object)super.b.e.i);
                                        super.b.e.h.k.add((Object)super.e);
                                        o = super.b.e.i.k;
                                        break Label_1242;
                                    }
                                    if (super.b.Z()) {
                                        super.b.e.e.l.add((Object)super.e);
                                        o = super.e.k;
                                        f4 = super.b.e.e;
                                        break Label_1348;
                                    }
                                    f5 = super.b.e.e;
                                }
                                else {
                                    final g e5 = b4.e.e;
                                    super.e.l.add((Object)e5);
                                    e5.k.add((Object)super.e);
                                    super.b.e.h.k.add((Object)super.e);
                                    super.b.e.i.k.add((Object)super.e);
                                    final g e6 = super.e;
                                    e6.b = true;
                                    e6.k.add((Object)super.h);
                                    super.e.k.add((Object)super.i);
                                    super.h.l.add((Object)super.e);
                                    f5 = super.i;
                                }
                                o = f5.l;
                            }
                            f4 = super.e;
                        }
                        else {
                            final e l = b4.I();
                            if (l == null) {
                                break Label_1358;
                            }
                            final g e7 = l.e.e;
                            super.e.l.add((Object)e7);
                            e7.k.add((Object)super.e);
                            final g e8 = super.e;
                            e8.b = true;
                            e8.k.add((Object)super.h);
                            o = super.e.k;
                            f4 = super.i;
                        }
                    }
                    ((List)o).add((Object)f4);
                }
            }
            final e b5 = super.b;
            final a.e.b.k.d[] n5 = b5.N;
            if (n5[0].f == null || n5[1].f == null) {
                final e b6 = super.b;
                final a.e.b.k.d[] n6 = b6.N;
                f f6 = null;
                f f7 = null;
                Label_1689: {
                    if (n6[0].f != null) {
                        final f h5 = this.h(n6[0]);
                        if (h5 == null) {
                            return;
                        }
                        this.b(super.h, h5, super.b.N[0].e());
                    }
                    else if (n6[1].f != null) {
                        final f h6 = this.h(n6[1]);
                        if (h6 != null) {
                            this.b(super.i, h6, -super.b.N[1].e());
                            f6 = super.h;
                            f7 = super.i;
                            n = -1;
                            break Label_1689;
                        }
                        return;
                    }
                    else {
                        if (b6 instanceof h || b6.I() == null) {
                            return;
                        }
                        this.b(super.h, super.b.I().d.h, super.b.S());
                    }
                    f6 = super.i;
                    f7 = super.h;
                }
                this.c(f6, f7, n, super.e);
                return;
            }
            if (!b5.Z()) {
                final f h7 = this.h(super.b.N[0]);
                final f h8 = this.h(super.b.N[1]);
                h7.b((d)this);
                h8.b((d)this);
                super.j = p$b.e;
                return;
            }
            super.h.f = super.b.N[0].e();
            f3 = super.i;
            d = super.b.N[1];
        }
        f3.f = -d.e();
    }
    
    public void e() {
        final f h = super.h;
        if (h.j) {
            super.b.V0(h.g);
        }
    }
    
    @Override
    void f() {
        super.c = null;
        super.h.c();
        super.i.c();
        super.e.c();
        super.g = false;
    }
    
    @Override
    boolean m() {
        return super.d != e$b.d || super.b.n == 0;
    }
    
    void r() {
        super.g = false;
        super.h.c();
        super.h.j = false;
        super.i.c();
        super.i.j = false;
        super.e.j = false;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("HorizontalRun ");
        sb.append(super.b.r());
        return sb.toString();
    }
}
