package a.e.b.k;

import a.e.b.c;
import java.util.Iterator;
import a.e.b.k.m.o;
import java.util.ArrayList;
import a.e.b.i;
import java.util.HashSet;

public class d
{
    private HashSet<d> a;
    private int b;
    private boolean c;
    public final e d;
    public final b e;
    public d f;
    public int g;
    int h;
    i i;
    
    public d(final e d, final b e) {
        this.a = null;
        this.g = 0;
        this.h = -1;
        this.d = d;
        this.e = e;
    }
    
    public boolean a(final d f, final int g, final int h, final boolean b) {
        if (f == null) {
            this.p();
            return true;
        }
        if (!b && !this.o(f)) {
            return false;
        }
        this.f = f;
        if (f.a == null) {
            f.a = (HashSet<d>)new HashSet();
        }
        final HashSet<d> a = this.f.a;
        if (a != null) {
            a.add((Object)this);
        }
        if (g > 0) {
            this.g = g;
        }
        else {
            this.g = 0;
        }
        this.h = h;
        return true;
    }
    
    public void b(final int n, final ArrayList<o> list, final o o) {
        final HashSet<d> a = this.a;
        if (a != null) {
            final Iterator iterator = a.iterator();
            while (iterator.hasNext()) {
                a.e.b.k.m.i.a(((d)iterator.next()).d, n, list, o);
            }
        }
    }
    
    public HashSet<d> c() {
        return this.a;
    }
    
    public int d() {
        if (!this.c) {
            return 0;
        }
        return this.b;
    }
    
    public int e() {
        if (this.d.Q() == 8) {
            return 0;
        }
        if (this.h > -1) {
            final d f = this.f;
            if (f != null && f.d.Q() == 8) {
                return this.h;
            }
        }
        return this.g;
    }
    
    public final d f() {
        switch (d$a.a[this.e.ordinal()]) {
            default: {
                throw new AssertionError((Object)this.e.name());
            }
            case 5: {
                return this.d.G;
            }
            case 4: {
                return this.d.I;
            }
            case 3: {
                return this.d.F;
            }
            case 2: {
                return this.d.H;
            }
            case 1:
            case 6:
            case 7:
            case 8:
            case 9: {
                return null;
            }
        }
    }
    
    public e g() {
        return this.d;
    }
    
    public i h() {
        return this.i;
    }
    
    public d i() {
        return this.f;
    }
    
    public b j() {
        return this.e;
    }
    
    public boolean k() {
        final HashSet<d> a = this.a;
        if (a == null) {
            return false;
        }
        final Iterator iterator = a.iterator();
        while (iterator.hasNext()) {
            if (((d)iterator.next()).f().n()) {
                return true;
            }
        }
        return false;
    }
    
    public boolean l() {
        final HashSet<d> a = this.a;
        boolean b = false;
        if (a == null) {
            return false;
        }
        if (a.size() > 0) {
            b = true;
        }
        return b;
    }
    
    public boolean m() {
        return this.c;
    }
    
    public boolean n() {
        return this.f != null;
    }
    
    public boolean o(final d d) {
        final boolean b = false;
        final boolean b2 = false;
        final boolean b3 = false;
        if (d == null) {
            return false;
        }
        final b j = d.j();
        final b e = this.e;
        if (j == e) {
            return e != a.e.b.k.d.b.g || (d.g().U() && this.g().U());
        }
        switch (d$a.a[e.ordinal()]) {
            default: {
                throw new AssertionError((Object)this.e.name());
            }
            case 6:
            case 7:
            case 8:
            case 9: {
                return false;
            }
            case 4:
            case 5: {
                boolean b4 = j == a.e.b.k.d.b.d || j == a.e.b.k.d.b.f;
                if (d.g() instanceof g) {
                    boolean b5 = false;
                    Label_0196: {
                        if (!b4) {
                            b5 = b3;
                            if (j != a.e.b.k.d.b.j) {
                                break Label_0196;
                            }
                        }
                        b5 = true;
                    }
                    b4 = b5;
                }
                return b4;
            }
            case 2:
            case 3: {
                boolean b6 = j == a.e.b.k.d.b.c || j == a.e.b.k.d.b.e;
                if (d.g() instanceof g) {
                    boolean b7 = false;
                    Label_0255: {
                        if (!b6) {
                            b7 = b;
                            if (j != a.e.b.k.d.b.i) {
                                break Label_0255;
                            }
                        }
                        b7 = true;
                    }
                    b6 = b7;
                }
                return b6;
            }
            case 1: {
                boolean b8 = b2;
                if (j != a.e.b.k.d.b.g) {
                    b8 = b2;
                    if (j != a.e.b.k.d.b.i) {
                        b8 = b2;
                        if (j != a.e.b.k.d.b.j) {
                            b8 = true;
                        }
                    }
                }
                return b8;
            }
        }
    }
    
    public void p() {
        final d f = this.f;
        if (f != null) {
            final HashSet<d> a = f.a;
            if (a != null) {
                a.remove((Object)this);
                if (this.f.a.size() == 0) {
                    this.f.a = null;
                }
            }
        }
        this.a = null;
        this.f = null;
        this.g = 0;
        this.h = -1;
        this.c = false;
        this.b = 0;
    }
    
    public void q() {
        this.c = false;
        this.b = 0;
    }
    
    public void r(final c c) {
        final i i = this.i;
        if (i == null) {
            this.i = new i(a.e.b.i.a.b, null);
        }
        else {
            i.d();
        }
    }
    
    public void s(final int b) {
        this.b = b;
        this.c = true;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.d.r());
        sb.append(":");
        sb.append(this.e.toString());
        return sb.toString();
    }
    
    public enum b
    {
        b, 
        c, 
        d, 
        e, 
        f, 
        g, 
        h, 
        i, 
        j;
        
        private static final b[] k;
    }
}
