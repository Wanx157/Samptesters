package a.e.b.k.m;

import a.e.b.k.e$b;
import a.e.b.k.e;

public abstract class p implements d
{
    public int a;
    e b;
    m c;
    protected e$b d;
    g e;
    public int f;
    boolean g;
    public f h;
    public f i;
    protected p.p$b j;
    
    public p(final e b) {
        this.e = new g(this);
        this.f = 0;
        this.g = false;
        this.h = new f(this);
        this.i = new f(this);
        this.j = p.p$b.b;
        this.b = b;
    }
    
    private void l(int n, final int n2) {
        final int a = this.a;
        int n3 = n2;
        g g = null;
        Label_0335: {
            if (a != 0) {
                if (a == 1) {
                    n = this.g(this.e.m, n);
                    g = this.e;
                    n = Math.min(n, n2);
                    break Label_0335;
                }
                if (a != 2) {
                    if (a != 3) {
                        return;
                    }
                    final e b = this.b;
                    final l d = b.d;
                    final e$b d2 = d.d;
                    final e$b d3 = e$b.d;
                    if (d2 == d3 && d.a == 3) {
                        final n e = b.e;
                        if (e.d == d3 && e.a == 3) {
                            return;
                        }
                    }
                    final e b2 = this.b;
                    p p2;
                    if (n == 0) {
                        p2 = b2.e;
                    }
                    else {
                        p2 = b2.d;
                    }
                    if (p2.e.j) {
                        final float t = this.b.t();
                        if (n == 1) {
                            n = (int)(p2.e.g / t + 0.5f);
                        }
                        else {
                            n = (int)(t * p2.e.g + 0.5f);
                        }
                        this.e.d(n);
                    }
                    return;
                }
                else {
                    final e i = this.b.I();
                    if (i == null) {
                        return;
                    }
                    p p3;
                    if (n == 0) {
                        p3 = i.d;
                    }
                    else {
                        p3 = i.e;
                    }
                    if (!p3.e.j) {
                        return;
                    }
                    final e b3 = this.b;
                    float n4;
                    if (n == 0) {
                        n4 = b3.s;
                    }
                    else {
                        n4 = b3.v;
                    }
                    n3 = (int)(p3.e.g * n4 + 0.5f);
                }
            }
            g = this.e;
            n = this.g(n3, n);
        }
        g.d(n);
    }
    
    public void a(final d d) {
    }
    
    protected final void b(final f f, final f f2, final int f3) {
        f.l.add((Object)f2);
        f.f = f3;
        f2.k.add((Object)f);
    }
    
    protected final void c(final f f, final f f2, final int h, final g i) {
        f.l.add((Object)f2);
        f.l.add((Object)this.e);
        f.h = h;
        f.i = i;
        f2.k.add((Object)f);
        i.k.add((Object)f);
    }
    
    abstract void d();
    
    abstract void e();
    
    abstract void f();
    
    protected final int g(final int n, int n2) {
        if (n2 == 0) {
            final e b = this.b;
            final int r = b.r;
            n2 = Math.max(b.q, n);
            if (r > 0) {
                n2 = Math.min(r, n);
            }
            final int n3;
            if (n2 == (n3 = n)) {
                return n3;
            }
        }
        else {
            final e b2 = this.b;
            final int u = b2.u;
            n2 = Math.max(b2.t, n);
            if (u > 0) {
                n2 = Math.min(u, n);
            }
            final int n3;
            if (n2 == (n3 = n)) {
                return n3;
            }
        }
        return n2;
    }
    
    protected final f h(final a.e.b.k.d d) {
        final a.e.b.k.d f = d.f;
        f f2 = null;
        if (f == null) {
            return null;
        }
        final e d2 = f.d;
        final int n = p$a.a[((Enum)f.e).ordinal()];
        if (n != 1) {
            p p2;
            if (n != 2) {
                if (n == 3) {
                    final p p = d2.e;
                    return p.h;
                }
                if (n == 4) {
                    f2 = d2.e.k;
                    return f2;
                }
                if (n != 5) {
                    return f2;
                }
                p2 = d2.e;
            }
            else {
                p2 = d2.d;
            }
            f2 = p2.i;
            return f2;
        }
        final p p = d2.d;
        f2 = p.h;
        return f2;
    }
    
    protected final f i(final a.e.b.k.d d, int n) {
        final a.e.b.k.d f = d.f;
        final f f2 = null;
        if (f == null) {
            return null;
        }
        final e d2 = f.d;
        p p2;
        if (n == 0) {
            p2 = d2.d;
        }
        else {
            p2 = d2.e;
        }
        n = p$a.a[((Enum)d.f.e).ordinal()];
        if (n != 1) {
            if (n != 2) {
                if (n == 3) {
                    return p2.h;
                }
                if (n != 5) {
                    return f2;
                }
            }
            return p2.i;
        }
        return p2.h;
    }
    
    public long j() {
        final g e = this.e;
        if (e.j) {
            return e.g;
        }
        return 0L;
    }
    
    public boolean k() {
        return this.g;
    }
    
    abstract boolean m();
    
    protected void n(final d d, final a.e.b.k.d d2, final a.e.b.k.d d3, int g) {
        final f h = this.h(d2);
        final f h2 = this.h(d3);
        if (!h.j || !h2.j) {
            return;
        }
        final int n = h.g + d2.e();
        int g2 = h2.g - d3.e();
        final int n2 = g2 - n;
        if (!this.e.j && this.d == e$b.d) {
            this.l(g, n2);
        }
        final g e = this.e;
        if (!e.j) {
            return;
        }
        f f;
        if (e.g == n2) {
            this.h.d(n);
            f = this.i;
        }
        else {
            final e b = this.b;
            float n3;
            if (g == 0) {
                n3 = b.w();
            }
            else {
                n3 = b.M();
            }
            g = n;
            if (h == h2) {
                g = h.g;
                g2 = h2.g;
                n3 = 0.5f;
            }
            this.h.d((int)(g + 0.5f + (g2 - g - this.e.g) * n3));
            f = this.i;
            g2 = this.h.g + this.e.g;
        }
        f.d(g2);
    }
    
    protected void o(final d d) {
    }
    
    protected void p(final d d) {
    }
}
