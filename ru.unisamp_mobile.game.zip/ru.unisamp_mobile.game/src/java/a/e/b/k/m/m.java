package a.e.b.k.m;

import a.e.b.k.e;
import java.util.ArrayList;

class m
{
    public static int d;
    public boolean a;
    p b;
    ArrayList<p> c;
    
    public m(final p b, final int n) {
        this.b = null;
        this.c = (ArrayList<p>)new ArrayList();
        ++m.d;
        this.b = b;
    }
    
    private long c(f h, long n) {
        final p d = h.d;
        if (d instanceof k) {
            return n;
        }
        final int size = h.k.size();
        int i = 0;
        long n2 = n;
        while (i < size) {
            final d d2 = (d)h.k.get(i);
            long min = n2;
            if (d2 instanceof f) {
                final f f = (f)d2;
                if (f.d == d) {
                    min = n2;
                }
                else {
                    min = Math.min(n2, this.c(f, f.f + n));
                }
            }
            ++i;
            n2 = min;
        }
        long min2 = n2;
        if (h == d.i) {
            final long j = d.j();
            h = d.h;
            n -= j;
            min2 = Math.min(Math.min(n2, this.c(h, n)), n - d.h.f);
        }
        return min2;
    }
    
    private long d(f i, long n) {
        final p d = i.d;
        if (d instanceof k) {
            return n;
        }
        final int size = i.k.size();
        int j = 0;
        long n2 = n;
        while (j < size) {
            final d d2 = (d)i.k.get(j);
            long max = n2;
            if (d2 instanceof f) {
                final f f = (f)d2;
                if (f.d == d) {
                    max = n2;
                }
                else {
                    max = Math.max(n2, this.d(f, f.f + n));
                }
            }
            ++j;
            n2 = max;
        }
        long max2 = n2;
        if (i == d.h) {
            final long k = d.j();
            i = d.i;
            n += k;
            max2 = Math.max(Math.max(n2, this.d(i, n)), n - d.i.f);
        }
        return max2;
    }
    
    public void a(final p p) {
        this.c.add((Object)p);
    }
    
    public long b(final a.e.b.k.f f, final int n) {
        final p b = this.b;
        final boolean b2 = b instanceof c;
        long n2 = 0L;
        if (b2) {
            if (((p)b).f != n) {
                return 0L;
            }
        }
        else if (n == 0) {
            if (!(b instanceof l)) {
                return 0L;
            }
        }
        else if (!(b instanceof n)) {
            return 0L;
        }
        Object o;
        if (n == 0) {
            o = ((e)f).d;
        }
        else {
            o = ((e)f).e;
        }
        final f h = ((p)o).h;
        Object o2;
        if (n == 0) {
            o2 = ((e)f).d;
        }
        else {
            o2 = ((e)f).e;
        }
        final f i = ((p)o2).i;
        final boolean contains = this.b.h.l.contains((Object)h);
        final boolean contains2 = this.b.i.l.contains((Object)i);
        final long j = this.b.j();
        if (!contains || !contains2) {
            long d;
            long n3;
            if (contains) {
                final f h2 = this.b.h;
                d = this.d(h2, h2.f);
                n3 = this.b.h.f + j;
            }
            else {
                if (!contains2) {
                    final p b3 = this.b;
                    final long n4 = b3.h.f + b3.j();
                    final p p2 = this.b;
                    return n4 - p2.i.f;
                }
                final f k = this.b.i;
                final long c = this.c(k, k.f);
                n3 = -this.b.i.f + j;
                d = -c;
            }
            return Math.max(d, n3);
        }
        final long d2 = this.d(this.b.h, 0L);
        final long c2 = this.c(this.b.i, 0L);
        final long n5 = d2 - j;
        final int f2 = this.b.i.f;
        long n6 = n5;
        if (n5 >= -f2) {
            n6 = n5 + f2;
        }
        final long n7 = -c2;
        final int f3 = this.b.h.f;
        long n9;
        final long n8 = n9 = n7 - j - f3;
        if (n8 >= f3) {
            n9 = n8 - f3;
        }
        final float o3 = this.b.b.o(n);
        if (o3 > 0.0f) {
            n2 = (long)(n9 / o3 + n6 / (1.0f - o3));
        }
        final float n10 = (float)n2;
        final long n11 = (long)(n10 * o3 + 0.5f);
        final long n12 = (long)(n10 * (1.0f - o3) + 0.5f);
        final p p2 = this.b;
        final long n4 = p2.h.f + (n11 + j + n12);
        return n4 - p2.i.f;
    }
}
