package a.e.b.k.m;

import java.util.Iterator;

class g extends f
{
    public int m;
    
    public g(final p p) {
        super(p);
        f$a e;
        if (p instanceof l) {
            e = f$a.c;
        }
        else {
            e = f$a.d;
        }
        super.e = e;
    }
    
    @Override
    public void d(final int g) {
        if (super.j) {
            return;
        }
        super.j = true;
        super.g = g;
        for (final d d : super.k) {
            d.a(d);
        }
    }
}
