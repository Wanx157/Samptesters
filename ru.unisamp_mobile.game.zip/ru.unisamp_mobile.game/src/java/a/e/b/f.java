package a.e.b;

interface f<T>
{
    boolean a(final T p0);
    
    T b();
    
    void c(final T[] p0, final int p1);
}
