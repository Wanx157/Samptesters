package a.e.b;

import java.util.Arrays;

public class a implements b$a
{
    private static float l = 0.001f;
    int a;
    private final b b;
    protected final c c;
    private int d;
    private i e;
    private int[] f;
    private int[] g;
    private float[] h;
    private int i;
    private int j;
    private boolean k;
    
    a(final b b, final c c) {
        this.a = 0;
        this.d = 8;
        this.e = null;
        this.f = new int[8];
        this.g = new int[8];
        this.h = new float[8];
        this.i = -1;
        this.j = -1;
        this.k = false;
        this.b = b;
        this.c = c;
    }
    
    public float a(final int n) {
        for (int i = this.i, n2 = 0; i != -1 && n2 < this.a; i = this.g[i], ++n2) {
            if (n2 == n) {
                return this.h[i];
            }
        }
        return 0.0f;
    }
    
    public float b(final b b, final boolean b2) {
        final float g = this.g(b.a);
        this.d(b.a, b2);
        final b.b$a e = b.e;
        for (int k = e.k(), i = 0; i < k; ++i) {
            final i f = e.f(i);
            this.e(f, e.g(f) * g, b2);
        }
        return g;
    }
    
    public final void c(final i i, final float n) {
        if (n == 0.0f) {
            this.d(i, true);
            return;
        }
        int j = this.i;
        if (j == -1) {
            this.i = 0;
            this.h[0] = n;
            this.f[0] = i.c;
            this.g[0] = -1;
            ++i.m;
            i.a(this.b);
            ++this.a;
            if (!this.k) {
                final int k = this.j + 1;
                this.j = k;
                final int[] f = this.f;
                if (k >= f.length) {
                    this.k = true;
                    this.j = f.length - 1;
                }
            }
            return;
        }
        int n2 = 0;
        int n3 = -1;
        while (j != -1 && n2 < this.a) {
            final int[] f2 = this.f;
            final int n4 = f2[j];
            final int c = i.c;
            if (n4 == c) {
                this.h[j] = n;
                return;
            }
            if (f2[j] < c) {
                n3 = j;
            }
            j = this.g[j];
            ++n2;
        }
        int n5 = this.j;
        if (this.k) {
            final int[] f3 = this.f;
            if (f3[n5] != -1) {
                n5 = f3.length;
            }
        }
        else {
            ++n5;
        }
        final int[] f4 = this.f;
        int n6 = n5;
        if (n5 >= f4.length) {
            n6 = n5;
            if (this.a < f4.length) {
                int n7 = 0;
                while (true) {
                    final int[] f5 = this.f;
                    n6 = n5;
                    if (n7 >= f5.length) {
                        break;
                    }
                    if (f5[n7] == -1) {
                        n6 = n7;
                        break;
                    }
                    ++n7;
                }
            }
        }
        final int[] f6 = this.f;
        int length;
        if ((length = n6) >= f6.length) {
            length = f6.length;
            final int d = this.d * 2;
            this.d = d;
            this.k = false;
            this.j = length - 1;
            this.h = Arrays.copyOf(this.h, d);
            this.f = Arrays.copyOf(this.f, this.d);
            this.g = Arrays.copyOf(this.g, this.d);
        }
        this.f[length] = i.c;
        this.h[length] = n;
        final int[] g = this.g;
        if (n3 != -1) {
            g[length] = g[n3];
            g[n3] = length;
        }
        else {
            g[length] = this.i;
            this.i = length;
        }
        ++i.m;
        i.a(this.b);
        ++this.a;
        if (!this.k) {
            ++this.j;
        }
        if (this.a >= this.f.length) {
            this.k = true;
        }
        final int l = this.j;
        final int[] f7 = this.f;
        if (l >= f7.length) {
            this.k = true;
            this.j = f7.length - 1;
        }
    }
    
    public final void clear() {
        for (int i = this.i, n = 0; i != -1 && n < this.a; i = this.g[i], ++n) {
            final i j = this.c.d[this.f[i]];
            if (j != null) {
                j.c(this.b);
            }
        }
        this.i = -1;
        this.j = -1;
        this.k = false;
        this.a = 0;
    }
    
    public final float d(final i i, final boolean b) {
        if (this.e == i) {
            this.e = null;
        }
        int j = this.i;
        if (j == -1) {
            return 0.0f;
        }
        int n = 0;
        int n2 = -1;
        while (j != -1 && n < this.a) {
            if (this.f[j] == i.c) {
                if (j == this.i) {
                    this.i = this.g[j];
                }
                else {
                    final int[] g = this.g;
                    g[n2] = g[j];
                }
                if (b) {
                    i.c(this.b);
                }
                --i.m;
                --this.a;
                this.f[j] = -1;
                if (this.k) {
                    this.j = j;
                }
                return this.h[j];
            }
            final int n3 = this.g[j];
            ++n;
            n2 = j;
            j = n3;
        }
        return 0.0f;
    }
    
    public void e(final i i, float n, final boolean b) {
        final float l = a.e.b.a.l;
        if (n > -l && n < l) {
            return;
        }
        int j = this.i;
        if (j == -1) {
            this.i = 0;
            this.h[0] = n;
            this.f[0] = i.c;
            this.g[0] = -1;
            ++i.m;
            i.a(this.b);
            ++this.a;
            if (!this.k) {
                final int k = this.j + 1;
                this.j = k;
                final int[] f = this.f;
                if (k >= f.length) {
                    this.k = true;
                    this.j = f.length - 1;
                }
            }
            return;
        }
        int n2 = 0;
        int n3 = -1;
        while (j != -1 && n2 < this.a) {
            final int[] f2 = this.f;
            final int n4 = f2[j];
            final int c = i.c;
            if (n4 == c) {
                final float n5 = this.h[j] + n;
                final float m = a.e.b.a.l;
                n = n5;
                if (n5 > -m) {
                    n = n5;
                    if (n5 < m) {
                        n = 0.0f;
                    }
                }
                this.h[j] = n;
                if (n == 0.0f) {
                    if (j == this.i) {
                        this.i = this.g[j];
                    }
                    else {
                        final int[] g = this.g;
                        g[n3] = g[j];
                    }
                    if (b) {
                        i.c(this.b);
                    }
                    if (this.k) {
                        this.j = j;
                    }
                    --i.m;
                    --this.a;
                }
                return;
            }
            if (f2[j] < c) {
                n3 = j;
            }
            j = this.g[j];
            ++n2;
        }
        int n6 = this.j;
        if (this.k) {
            final int[] f3 = this.f;
            if (f3[n6] != -1) {
                n6 = f3.length;
            }
        }
        else {
            ++n6;
        }
        final int[] f4 = this.f;
        int n7 = n6;
        if (n6 >= f4.length) {
            n7 = n6;
            if (this.a < f4.length) {
                int n8 = 0;
                while (true) {
                    final int[] f5 = this.f;
                    n7 = n6;
                    if (n8 >= f5.length) {
                        break;
                    }
                    if (f5[n8] == -1) {
                        n7 = n8;
                        break;
                    }
                    ++n8;
                }
            }
        }
        final int[] f6 = this.f;
        int length;
        if ((length = n7) >= f6.length) {
            length = f6.length;
            final int d = this.d * 2;
            this.d = d;
            this.k = false;
            this.j = length - 1;
            this.h = Arrays.copyOf(this.h, d);
            this.f = Arrays.copyOf(this.f, this.d);
            this.g = Arrays.copyOf(this.g, this.d);
        }
        this.f[length] = i.c;
        this.h[length] = n;
        final int[] g2 = this.g;
        if (n3 != -1) {
            g2[length] = g2[n3];
            g2[n3] = length;
        }
        else {
            g2[length] = this.i;
            this.i = length;
        }
        ++i.m;
        i.a(this.b);
        ++this.a;
        if (!this.k) {
            ++this.j;
        }
        final int j2 = this.j;
        final int[] f7 = this.f;
        if (j2 >= f7.length) {
            this.k = true;
            this.j = f7.length - 1;
        }
    }
    
    public i f(final int n) {
        for (int i = this.i, n2 = 0; i != -1 && n2 < this.a; i = this.g[i], ++n2) {
            if (n2 == n) {
                return this.c.d[this.f[i]];
            }
        }
        return null;
    }
    
    public final float g(final i i) {
        for (int j = this.i, n = 0; j != -1 && n < this.a; j = this.g[j], ++n) {
            if (this.f[j] == i.c) {
                return this.h[j];
            }
        }
        return 0.0f;
    }
    
    public boolean h(final i i) {
        int j = this.i;
        if (j == -1) {
            return false;
        }
        for (int n = 0; j != -1 && n < this.a; j = this.g[j], ++n) {
            if (this.f[j] == i.c) {
                return true;
            }
        }
        return false;
    }
    
    public void i(final float n) {
        for (int i = this.i, n2 = 0; i != -1 && n2 < this.a; i = this.g[i], ++n2) {
            final float[] h = this.h;
            h[i] /= n;
        }
    }
    
    public void j() {
        for (int i = this.i, n = 0; i != -1 && n < this.a; i = this.g[i], ++n) {
            final float[] h = this.h;
            h[i] *= -1.0f;
        }
    }
    
    public int k() {
        return this.a;
    }
    
    @Override
    public String toString() {
        int i = this.i;
        String string = "";
        for (int n = 0; i != -1 && n < this.a; i = this.g[i], ++n) {
            final StringBuilder sb = new StringBuilder();
            sb.append(string);
            sb.append(" -> ");
            final String string2 = sb.toString();
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(string2);
            sb2.append(this.h[i]);
            sb2.append(" : ");
            final String string3 = sb2.toString();
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(string3);
            sb3.append((Object)this.c.d[this.f[i]]);
            string = sb3.toString();
        }
        return string;
    }
}
