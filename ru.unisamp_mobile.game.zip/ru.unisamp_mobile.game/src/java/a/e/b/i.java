package a.e.b;

import java.util.Arrays;

public class i
{
    private static int q = 1;
    public boolean a;
    private String b;
    public int c;
    int d;
    public int e;
    public float f;
    public boolean g;
    float[] h;
    float[] i;
    a j;
    b[] k;
    int l;
    public int m;
    boolean n;
    int o;
    float p;
    
    public i(final a j, final String s) {
        this.c = -1;
        this.d = -1;
        this.e = 0;
        this.g = false;
        this.h = new float[9];
        this.i = new float[9];
        this.k = new b[16];
        this.l = 0;
        this.m = 0;
        this.n = false;
        this.o = -1;
        this.p = 0.0f;
        this.j = j;
    }
    
    static void b() {
        ++i.q;
    }
    
    public final void a(final b b) {
        int n = 0;
        while (true) {
            final int l = this.l;
            if (n >= l) {
                final b[] k = this.k;
                if (l >= k.length) {
                    this.k = (b[])Arrays.copyOf((Object[])k, k.length * 2);
                }
                final b[] i = this.k;
                final int j = this.l;
                i[j] = b;
                this.l = j + 1;
                return;
            }
            if (this.k[n] == b) {
                return;
            }
            ++n;
        }
    }
    
    public final void c(final b b) {
        for (int l = this.l, i = 0; i < l; ++i) {
            if (this.k[i] == b) {
                while (i < l - 1) {
                    final b[] k = this.k;
                    final int n = i + 1;
                    k[i] = k[n];
                    i = n;
                }
                --this.l;
                return;
            }
        }
    }
    
    public void d() {
        this.b = null;
        this.j = a.e.b.i.a.f;
        this.e = 0;
        this.c = -1;
        this.d = -1;
        this.f = 0.0f;
        this.g = false;
        this.n = false;
        this.o = -1;
        this.p = 0.0f;
        for (int l = this.l, i = 0; i < l; ++i) {
            this.k[i] = null;
        }
        this.l = 0;
        this.m = 0;
        this.a = false;
        Arrays.fill(this.i, 0.0f);
    }
    
    public void e(final d d, final float f) {
        this.f = f;
        this.g = true;
        this.n = false;
        this.o = -1;
        this.p = 0.0f;
        final int l = this.l;
        this.d = -1;
        for (int i = 0; i < l; ++i) {
            this.k[i].A(d, this, false);
        }
        this.l = 0;
    }
    
    public void f(final a j, final String s) {
        this.j = j;
    }
    
    public final void g(final d d, final b b) {
        for (int l = this.l, i = 0; i < l; ++i) {
            this.k[i].B(d, b, false);
        }
        this.l = 0;
    }
    
    @Override
    public String toString() {
        StringBuilder sb;
        if (this.b != null) {
            sb = new StringBuilder();
            sb.append("");
            sb.append(this.b);
        }
        else {
            sb = new StringBuilder();
            sb.append("");
            sb.append(this.c);
        }
        return sb.toString();
    }
    
    public enum a
    {
        b, 
        c, 
        d, 
        e, 
        f;
        
        private static final a[] g;
    }
}
