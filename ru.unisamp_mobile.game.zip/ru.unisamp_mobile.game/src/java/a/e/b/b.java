package a.e.b;

import java.util.ArrayList;

public class b implements d$a
{
    i a;
    float b;
    boolean c;
    ArrayList<i> d;
    public b.b$a e;
    boolean f;
    
    public b() {
        this.a = null;
        this.b = 0.0f;
        this.d = (ArrayList<i>)new ArrayList();
        this.f = false;
    }
    
    public b(final c c) {
        this.a = null;
        this.b = 0.0f;
        this.d = (ArrayList<i>)new ArrayList();
        this.f = false;
        this.e = (b.b$a)new a(this, c);
    }
    
    private boolean u(final i i, final d d) {
        final int m = i.m;
        boolean b = true;
        if (m > 1) {
            b = false;
        }
        return b;
    }
    
    private i w(final boolean[] array, final i i) {
        final int k = this.e.k();
        i j = null;
        int l = 0;
        float n = 0.0f;
        while (l < k) {
            final float a = this.e.a(l);
            i m = j;
            float n2 = n;
            Label_0152: {
                if (a < 0.0f) {
                    final i f = this.e.f(l);
                    if (array != null) {
                        m = j;
                        n2 = n;
                        if (array[f.c]) {
                            break Label_0152;
                        }
                    }
                    m = j;
                    n2 = n;
                    if (f != i) {
                        final i$a j2 = f.j;
                        if (j2 != i$a.d) {
                            m = j;
                            n2 = n;
                            if (j2 != i$a.e) {
                                break Label_0152;
                            }
                        }
                        m = j;
                        n2 = n;
                        if (a < n) {
                            n2 = a;
                            m = f;
                        }
                    }
                }
            }
            ++l;
            j = m;
            n = n2;
        }
        return j;
    }
    
    public void A(final d d, final i i, final boolean b) {
        if (!i.g) {
            return;
        }
        this.b += i.f * this.e.g(i);
        this.e.d(i, b);
        if (b) {
            i.c(this);
        }
        if (d.t && i != null && this.e.k() == 0) {
            this.f = true;
            d.a = true;
        }
    }
    
    public void B(final d d, final b b, final boolean b2) {
        this.b += b.b * this.e.b(b, b2);
        if (b2) {
            b.a.c(this);
        }
        if (d.t && this.a != null && this.e.k() == 0) {
            this.f = true;
            d.a = true;
        }
    }
    
    public void C(final d d, final i i, final boolean b) {
        if (!i.n) {
            return;
        }
        final float g = this.e.g(i);
        this.b += i.p * g;
        this.e.d(i, b);
        if (b) {
            i.c(this);
        }
        this.e.e(d.n.d[i.o], g, b);
        if (d.t && i != null && this.e.k() == 0) {
            this.f = true;
            d.a = true;
        }
    }
    
    public void D(final d d) {
        if (d.g.length == 0) {
            return;
        }
        int i = 0;
        while (i == 0) {
            for (int k = this.e.k(), j = 0; j < k; ++j) {
                final i f = this.e.f(j);
                if (f.d != -1 || f.g || f.n) {
                    this.d.add((Object)f);
                }
            }
            final int size = this.d.size();
            if (size > 0) {
                for (int l = 0; l < size; ++l) {
                    final i m = (i)this.d.get(l);
                    if (m.g) {
                        this.A(d, m, true);
                    }
                    else if (m.n) {
                        this.C(d, m, true);
                    }
                    else {
                        this.B(d, d.g[m.d], true);
                    }
                }
                this.d.clear();
            }
            else {
                i = 1;
            }
        }
        if (d.t && this.a != null && this.e.k() == 0) {
            this.f = true;
            d.a = true;
        }
    }
    
    public void a(final d$a d$a) {
        if (d$a instanceof b) {
            final b b = (b)d$a;
            this.a = null;
            this.e.clear();
            for (int i = 0; i < b.e.k(); ++i) {
                this.e.e(b.e.f(i), b.e.a(i), true);
            }
        }
    }
    
    public void b(final i i) {
        final int e = i.e;
        float n = 1.0f;
        if (e != 1) {
            if (e == 2) {
                n = 1000.0f;
            }
            else if (e == 3) {
                n = 1000000.0f;
            }
            else if (e == 4) {
                n = 1.0E9f;
            }
            else if (e == 5) {
                n = 1.0E12f;
            }
        }
        this.e.c(i, n);
    }
    
    public i c(final d d, final boolean[] array) {
        return this.w(array, null);
    }
    
    public void clear() {
        this.e.clear();
        this.a = null;
        this.b = 0.0f;
    }
    
    public b d(final d d, final int n) {
        this.e.c(d.o(n, "ep"), 1.0f);
        this.e.c(d.o(n, "em"), -1.0f);
        return this;
    }
    
    b e(final i i, final int n) {
        this.e.c(i, (float)n);
        return this;
    }
    
    boolean f(final d d) {
        final i g = this.g(d);
        boolean b;
        if (g == null) {
            b = true;
        }
        else {
            this.x(g);
            b = false;
        }
        if (this.e.k() == 0) {
            this.f = true;
        }
        return b;
    }
    
    i g(final d d) {
        final int k = this.e.k();
        i i = null;
        i j = null;
        int l = 0;
        int n = 0;
        int n2 = 0;
        float n3 = 0.0f;
        float n4 = 0.0f;
        while (l < k) {
            final float a = this.e.a(l);
            final i f = this.e.f(l);
            i m;
            i i2;
            int u;
            int u2;
            float n5;
            float n6;
            if (f.j == i$a.b) {
                if (i != null && n3 <= a) {
                    m = i;
                    i2 = j;
                    u = n;
                    u2 = n2;
                    n5 = n3;
                    n6 = n4;
                    if (n == 0) {
                        m = i;
                        i2 = j;
                        u = n;
                        u2 = n2;
                        n5 = n3;
                        n6 = n4;
                        if (this.u(f, d)) {
                            u = 1;
                            m = f;
                            i2 = j;
                            u2 = n2;
                            n5 = a;
                            n6 = n4;
                        }
                    }
                }
                else {
                    u = (this.u(f, d) ? 1 : 0);
                    m = f;
                    i2 = j;
                    u2 = n2;
                    n5 = a;
                    n6 = n4;
                }
            }
            else {
                m = i;
                i2 = j;
                u = n;
                u2 = n2;
                n5 = n3;
                n6 = n4;
                if (i == null) {
                    m = i;
                    i2 = j;
                    u = n;
                    u2 = n2;
                    n5 = n3;
                    n6 = n4;
                    if (a < 0.0f) {
                        if (j != null && n4 <= a) {
                            m = i;
                            i2 = j;
                            u = n;
                            u2 = n2;
                            n5 = n3;
                            n6 = n4;
                            if (n2 == 0) {
                                m = i;
                                i2 = j;
                                u = n;
                                u2 = n2;
                                n5 = n3;
                                n6 = n4;
                                if (this.u(f, d)) {
                                    u2 = 1;
                                    n6 = a;
                                    n5 = n3;
                                    u = n;
                                    i2 = f;
                                    m = i;
                                }
                            }
                        }
                        else {
                            u2 = (this.u(f, d) ? 1 : 0);
                            m = i;
                            i2 = f;
                            u = n;
                            n5 = n3;
                            n6 = a;
                        }
                    }
                }
            }
            ++l;
            i = m;
            j = i2;
            n = u;
            n2 = u2;
            n3 = n5;
            n4 = n6;
        }
        if (i != null) {
            return i;
        }
        return j;
    }
    
    public i getKey() {
        return this.a;
    }
    
    b h(final i i, final i j, int n, float b, final i k, final i l, final int n2) {
        if (j == k) {
            this.e.c(i, 1.0f);
            this.e.c(l, 1.0f);
            this.e.c(j, -2.0f);
            return this;
        }
        Label_0155: {
            if (b == 0.5f) {
                this.e.c(i, 1.0f);
                this.e.c(j, -1.0f);
                this.e.c(k, -1.0f);
                this.e.c(l, 1.0f);
                if (n <= 0 && n2 <= 0) {
                    return this;
                }
                n = -n + n2;
            }
            else {
                if (b <= 0.0f) {
                    this.e.c(i, -1.0f);
                    this.e.c(j, 1.0f);
                    b = (float)n;
                    break Label_0155;
                }
                if (b >= 1.0f) {
                    this.e.c(l, -1.0f);
                    this.e.c(k, 1.0f);
                    n = -n2;
                }
                else {
                    final b.b$a e = this.e;
                    final float n3 = 1.0f - b;
                    e.c(i, n3 * 1.0f);
                    this.e.c(j, n3 * -1.0f);
                    this.e.c(k, -1.0f * b);
                    this.e.c(l, 1.0f * b);
                    if (n > 0 || n2 > 0) {
                        b = -n * n3 + n2 * b;
                        break Label_0155;
                    }
                    return this;
                }
            }
            b = (float)n;
        }
        this.b = b;
        return this;
    }
    
    b i(final i a, final int n) {
        this.a = a;
        final float n2 = (float)n;
        a.f = n2;
        this.b = n2;
        this.f = true;
        return this;
    }
    
    public boolean isEmpty() {
        return this.a == null && this.b == 0.0f && this.e.k() == 0;
    }
    
    b j(final i i, final i j, final float n) {
        this.e.c(i, -1.0f);
        this.e.c(j, n);
        return this;
    }
    
    public b k(final i i, final i j, final i k, final i l, final float n) {
        this.e.c(i, -1.0f);
        this.e.c(j, 1.0f);
        this.e.c(k, n);
        this.e.c(l, -n);
        return this;
    }
    
    public b l(float n, final float n2, final float n3, final i i, final i j, final i k, final i l) {
        this.b = 0.0f;
        if (n2 != 0.0f && n != n3) {
            if (n == 0.0f) {
                this.e.c(i, 1.0f);
                this.e.c(j, -1.0f);
            }
            else if (n3 == 0.0f) {
                this.e.c(k, 1.0f);
                this.e.c(l, -1.0f);
            }
            else {
                n = n / n2 / (n3 / n2);
                this.e.c(i, 1.0f);
                this.e.c(j, -1.0f);
                this.e.c(l, n);
                this.e.c(k, -n);
            }
        }
        else {
            this.e.c(i, 1.0f);
            this.e.c(j, -1.0f);
            this.e.c(l, 1.0f);
            this.e.c(k, -1.0f);
        }
        return this;
    }
    
    public b m(final i i, final int n) {
        b.b$a b$a;
        float n2;
        if (n < 0) {
            this.b = (float)(n * -1);
            b$a = this.e;
            n2 = 1.0f;
        }
        else {
            this.b = (float)n;
            b$a = this.e;
            n2 = -1.0f;
        }
        b$a.c(i, n2);
        return this;
    }
    
    public b n(final i i, final i j, final int n) {
        int n2 = 0;
        final int n3 = 0;
        if (n != 0) {
            n2 = n3;
            int n4;
            if ((n4 = n) < 0) {
                n4 = n * -1;
                n2 = 1;
            }
            this.b = (float)n4;
        }
        if (n2 == 0) {
            this.e.c(i, -1.0f);
            this.e.c(j, 1.0f);
        }
        else {
            this.e.c(i, 1.0f);
            this.e.c(j, -1.0f);
        }
        return this;
    }
    
    public b o(final i i, final i j, final i k, final int n) {
        int n2 = 0;
        final int n3 = 0;
        if (n != 0) {
            n2 = n3;
            int n4;
            if ((n4 = n) < 0) {
                n4 = n * -1;
                n2 = 1;
            }
            this.b = (float)n4;
        }
        if (n2 == 0) {
            this.e.c(i, -1.0f);
            this.e.c(j, 1.0f);
            this.e.c(k, 1.0f);
        }
        else {
            this.e.c(i, 1.0f);
            this.e.c(j, -1.0f);
            this.e.c(k, -1.0f);
        }
        return this;
    }
    
    public b p(final i i, final i j, final i k, final int n) {
        int n2 = 0;
        final int n3 = 0;
        if (n != 0) {
            n2 = n3;
            int n4;
            if ((n4 = n) < 0) {
                n4 = n * -1;
                n2 = 1;
            }
            this.b = (float)n4;
        }
        if (n2 == 0) {
            this.e.c(i, -1.0f);
            this.e.c(j, 1.0f);
            this.e.c(k, -1.0f);
        }
        else {
            this.e.c(i, 1.0f);
            this.e.c(j, -1.0f);
            this.e.c(k, 1.0f);
        }
        return this;
    }
    
    public b q(final i i, final i j, final i k, final i l, final float n) {
        this.e.c(k, 0.5f);
        this.e.c(l, 0.5f);
        this.e.c(i, -0.5f);
        this.e.c(j, -0.5f);
        this.b = -n;
        return this;
    }
    
    void r() {
        final float b = this.b;
        if (b < 0.0f) {
            this.b = b * -1.0f;
            this.e.j();
        }
    }
    
    boolean s() {
        final i a = this.a;
        return a != null && (a.j == i$a.b || this.b >= 0.0f);
    }
    
    boolean t(final i i) {
        return this.e.h(i);
    }
    
    @Override
    public String toString() {
        return this.z();
    }
    
    public i v(final i i) {
        return this.w(null, i);
    }
    
    void x(final i a) {
        final i a2 = this.a;
        if (a2 != null) {
            this.e.c(a2, -1.0f);
            this.a.d = -1;
            this.a = null;
        }
        final float n = this.e.d(a, true) * -1.0f;
        this.a = a;
        if (n == 1.0f) {
            return;
        }
        this.b /= n;
        this.e.i(n);
    }
    
    public void y() {
        this.a = null;
        this.e.clear();
        this.b = 0.0f;
        this.f = false;
    }
    
    String z() {
        StringBuilder sb;
        if (this.a == null) {
            sb = new StringBuilder();
            sb.append("");
            sb.append("0");
        }
        else {
            sb = new StringBuilder();
            sb.append("");
            sb.append((Object)this.a);
        }
        final String string = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(string);
        sb2.append(" = ");
        String s = sb2.toString();
        final float b = this.b;
        int i = 0;
        int n;
        if (b != 0.0f) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(s);
            sb3.append(this.b);
            s = sb3.toString();
            n = 1;
        }
        else {
            n = 0;
        }
        while (i < this.e.k()) {
            final i f = this.e.f(i);
            if (f != null) {
                final float a = this.e.a(i);
                if (a != 0.0f) {
                    final String string2 = f.toString();
                    String s2 = null;
                    float n2 = 0.0f;
                    Label_0355: {
                        String s3;
                        StringBuilder sb5;
                        if (n == 0) {
                            s2 = s;
                            n2 = a;
                            if (a >= 0.0f) {
                                break Label_0355;
                            }
                            final StringBuilder sb4 = new StringBuilder();
                            sb4.append(s);
                            s3 = "- ";
                            sb5 = sb4;
                        }
                        else {
                            if (a > 0.0f) {
                                final StringBuilder sb6 = new StringBuilder();
                                sb6.append(s);
                                sb6.append(" + ");
                                s2 = sb6.toString();
                                n2 = a;
                                break Label_0355;
                            }
                            final StringBuilder sb7 = new StringBuilder();
                            sb7.append(s);
                            s3 = " - ";
                            sb5 = sb7;
                        }
                        sb5.append(s3);
                        s2 = sb5.toString();
                        n2 = a * -1.0f;
                    }
                    StringBuilder sb8;
                    if (n2 == 1.0f) {
                        sb8 = new StringBuilder();
                    }
                    else {
                        sb8 = new StringBuilder();
                        sb8.append(s2);
                        sb8.append(n2);
                        s2 = " ";
                    }
                    sb8.append(s2);
                    sb8.append(string2);
                    s = sb8.toString();
                    n = 1;
                }
            }
            ++i;
        }
        String string3 = s;
        if (n == 0) {
            final StringBuilder sb9 = new StringBuilder();
            sb9.append(s);
            sb9.append("0.0");
            string3 = sb9.toString();
        }
        return string3;
    }
}
