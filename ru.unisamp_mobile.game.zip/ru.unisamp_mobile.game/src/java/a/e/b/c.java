package a.e.b;

public class c
{
    f<b> a;
    f<b> b;
    f<i> c;
    i[] d;
    
    public c() {
        this.a = (f<b>)new g(256);
        this.b = (f<b>)new g(256);
        this.c = (f<i>)new g(256);
        this.d = new i[32];
    }
}
