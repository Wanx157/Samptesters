package a.e.b;

import java.util.Arrays;
import java.util.HashMap;

public class d
{
    public static boolean r = false;
    public static boolean s = true;
    public static boolean t = true;
    public static boolean u = true;
    public static boolean v = false;
    private static int w = 1000;
    public static e x;
    public static long y;
    public static long z;
    public boolean a;
    int b;
    private HashMap<String, i> c;
    private a d;
    private int e;
    private int f;
    b[] g;
    public boolean h;
    public boolean i;
    private boolean[] j;
    int k;
    int l;
    private int m;
    final c n;
    private i[] o;
    private int p;
    private a q;
    
    public d() {
        this.a = false;
        this.b = 0;
        this.c = null;
        this.e = 32;
        this.f = 32;
        this.g = null;
        this.h = false;
        this.i = false;
        this.j = new boolean[32];
        this.k = 1;
        this.l = 0;
        this.m = 32;
        this.o = new i[a.e.b.d.w];
        this.p = 0;
        this.g = new b[32];
        this.C();
        final c n = new c();
        this.n = n;
        this.d = (a)new h(n);
        Object q;
        if (a.e.b.d.v) {
            q = new d.d$b(this, this.n);
        }
        else {
            q = new b(this.n);
        }
        this.q = (a)q;
    }
    
    private final int B(final a a, final boolean b) {
        final e x = a.e.b.d.x;
        if (x != null) {
            ++x.h;
        }
        for (int i = 0; i < this.k; ++i) {
            this.j[i] = false;
        }
        int j = 0;
        int n = 0;
        while (j == 0) {
            final e x2 = a.e.b.d.x;
            if (x2 != null) {
                ++x2.i;
            }
            final int n2 = n + 1;
            if (n2 >= this.k * 2) {
                return n2;
            }
            if (a.getKey() != null) {
                this.j[a.getKey().c] = true;
            }
            final i c = a.c(this, this.j);
            if (c != null) {
                final boolean[] k = this.j;
                final int c2 = c.c;
                if (k[c2]) {
                    return n2;
                }
                k[c2] = true;
            }
            if (c != null) {
                float n3 = Float.MAX_VALUE;
                int l = 0;
                int d = -1;
                while (l < this.l) {
                    final b b2 = this.g[l];
                    float n4;
                    int n5;
                    if (b2.a.j == a.e.b.i.a.b) {
                        n4 = n3;
                        n5 = d;
                    }
                    else if (b2.f) {
                        n4 = n3;
                        n5 = d;
                    }
                    else {
                        n4 = n3;
                        n5 = d;
                        if (b2.t(c)) {
                            final float g = b2.e.g(c);
                            n4 = n3;
                            n5 = d;
                            if (g < 0.0f) {
                                final float n6 = -b2.b / g;
                                n4 = n3;
                                n5 = d;
                                if (n6 < n3) {
                                    n5 = l;
                                    n4 = n6;
                                }
                            }
                        }
                    }
                    ++l;
                    n3 = n4;
                    d = n5;
                }
                n = n2;
                if (d <= -1) {
                    continue;
                }
                final b b3 = this.g[d];
                b3.a.d = -1;
                final e x3 = a.e.b.d.x;
                if (x3 != null) {
                    ++x3.j;
                }
                b3.x(c);
                final i a2 = b3.a;
                a2.d = d;
                a2.g(this, b3);
                n = n2;
            }
            else {
                j = 1;
                n = n2;
            }
        }
        return n;
    }
    
    private void C() {
        final boolean v = a.e.b.d.v;
        int i = 0;
        final int n = 0;
        if (v) {
            for (int j = n; j < this.l; ++j) {
                final b b = this.g[j];
                if (b != null) {
                    this.n.a.a(b);
                }
                this.g[j] = null;
            }
        }
        else {
            while (i < this.l) {
                final b b2 = this.g[i];
                if (b2 != null) {
                    this.n.b.a(b2);
                }
                this.g[i] = null;
                ++i;
            }
        }
    }
    
    private i a(final i.a a, final String s) {
        i i = this.n.c.b();
        if (i == null) {
            i = new i(a, s);
        }
        else {
            i.d();
        }
        i.f(a, s);
        final int p2 = this.p;
        final int w = a.e.b.d.w;
        if (p2 >= w) {
            this.o = (i[])Arrays.copyOf((Object[])this.o, a.e.b.d.w = w * 2);
        }
        return this.o[this.p++] = i;
    }
    
    private final void l(final b b) {
        if (a.e.b.d.t && b.f) {
            b.a.e(this, b.b);
        }
        else {
            final b[] g = this.g;
            final int l = this.l;
            g[l] = b;
            final i a = b.a;
            a.d = l;
            this.l = l + 1;
            a.g(this, b);
        }
        if (a.e.b.d.t && this.a) {
            int n;
            for (int i = 0; i < this.l; i = n + 1) {
                if (this.g[i] == null) {
                    System.out.println("WTF");
                }
                final b[] g2 = this.g;
                n = i;
                if (g2[i] != null) {
                    n = i;
                    if (g2[i].f) {
                        final b b2 = g2[i];
                        b2.a.e(this, b2.b);
                        f<b> f;
                        if (a.e.b.d.v) {
                            f = this.n.a;
                        }
                        else {
                            f = this.n.b;
                        }
                        f.a(b2);
                        this.g[i] = null;
                        int n3;
                        int n2 = n3 = i + 1;
                        int j;
                        while (true) {
                            j = this.l;
                            if (n2 >= j) {
                                break;
                            }
                            final b[] g3 = this.g;
                            final int d = n2 - 1;
                            g3[d] = g3[n2];
                            if (g3[d].a.d == n2) {
                                g3[d].a.d = d;
                            }
                            n3 = n2;
                            ++n2;
                        }
                        if (n3 < j) {
                            this.g[n3] = null;
                        }
                        --this.l;
                        n = i - 1;
                    }
                }
            }
            this.a = false;
        }
    }
    
    private void n() {
        for (int i = 0; i < this.l; ++i) {
            final b b = this.g[i];
            b.a.f = b.b;
        }
    }
    
    public static b s(final d d, final i i, final i j, final float n) {
        final b r = d.r();
        r.j(i, j, n);
        return r;
    }
    
    private int u(final a a) {
        while (true) {
            for (int i = 0; i < this.l; ++i) {
                final b[] g = this.g;
                if (g[i].a.j != a.e.b.i.a.b) {
                    if (g[i].b < 0.0f) {
                        final boolean b = true;
                        int n;
                        if (b) {
                            int j = 0;
                            n = 0;
                            while (j == 0) {
                                final e x = a.e.b.d.x;
                                if (x != null) {
                                    ++x.k;
                                }
                                final int n2 = n + 1;
                                float n3 = Float.MAX_VALUE;
                                int k = 0;
                                int d = -1;
                                int n4 = -1;
                                int n5 = 0;
                                while (k < this.l) {
                                    final b b2 = this.g[k];
                                    float n6;
                                    int n7;
                                    int n8;
                                    int n9;
                                    if (b2.a.j == a.e.b.i.a.b) {
                                        n6 = n3;
                                        n7 = d;
                                        n8 = n4;
                                        n9 = n5;
                                    }
                                    else if (b2.f) {
                                        n6 = n3;
                                        n7 = d;
                                        n8 = n4;
                                        n9 = n5;
                                    }
                                    else {
                                        n6 = n3;
                                        n7 = d;
                                        n8 = n4;
                                        n9 = n5;
                                        if (b2.b < 0.0f) {
                                            if (a.e.b.d.u) {
                                                final int l = b2.e.k();
                                                int n10 = 0;
                                                while (true) {
                                                    n6 = n3;
                                                    n7 = d;
                                                    n8 = n4;
                                                    n9 = n5;
                                                    if (n10 >= l) {
                                                        break;
                                                    }
                                                    final i f = b2.e.f(n10);
                                                    final float g2 = b2.e.g(f);
                                                    float n11;
                                                    int n12;
                                                    int n13;
                                                    int n14;
                                                    if (g2 <= 0.0f) {
                                                        n11 = n3;
                                                        n12 = d;
                                                        n13 = n4;
                                                        n14 = n5;
                                                    }
                                                    else {
                                                        final int n15 = 0;
                                                        int c = n4;
                                                        int n16 = n15;
                                                        while (true) {
                                                            n11 = n3;
                                                            n12 = d;
                                                            n13 = c;
                                                            n14 = n5;
                                                            if (n16 >= 9) {
                                                                break;
                                                            }
                                                            final float n17 = f.h[n16] / g2;
                                                            int n18;
                                                            if ((n17 < n3 && n16 == n5) || n16 > (n18 = n5)) {
                                                                c = f.c;
                                                                n18 = n16;
                                                                d = k;
                                                                n3 = n17;
                                                            }
                                                            ++n16;
                                                            n5 = n18;
                                                        }
                                                    }
                                                    ++n10;
                                                    n3 = n11;
                                                    d = n12;
                                                    n4 = n13;
                                                    n5 = n14;
                                                }
                                            }
                                            else {
                                                int n19 = 1;
                                                while (true) {
                                                    n6 = n3;
                                                    n7 = d;
                                                    n8 = n4;
                                                    n9 = n5;
                                                    if (n19 >= this.k) {
                                                        break;
                                                    }
                                                    final i m = this.n.d[n19];
                                                    final float g3 = b2.e.g(m);
                                                    float n20;
                                                    int n21;
                                                    int n22;
                                                    int n23;
                                                    if (g3 <= 0.0f) {
                                                        n20 = n3;
                                                        n21 = d;
                                                        n22 = n4;
                                                        n23 = n5;
                                                    }
                                                    else {
                                                        final int n24 = 0;
                                                        int n25 = n4;
                                                        int n26 = n24;
                                                        while (true) {
                                                            n20 = n3;
                                                            n21 = d;
                                                            n22 = n25;
                                                            n23 = n5;
                                                            if (n26 >= 9) {
                                                                break;
                                                            }
                                                            final float n27 = m.h[n26] / g3;
                                                            int n28;
                                                            if ((n27 < n3 && n26 == n5) || n26 > (n28 = n5)) {
                                                                n25 = n19;
                                                                n28 = n26;
                                                                d = k;
                                                                n3 = n27;
                                                            }
                                                            ++n26;
                                                            n5 = n28;
                                                        }
                                                    }
                                                    ++n19;
                                                    n3 = n20;
                                                    d = n21;
                                                    n4 = n22;
                                                    n5 = n23;
                                                }
                                            }
                                        }
                                    }
                                    ++k;
                                    n3 = n6;
                                    d = n7;
                                    n4 = n8;
                                    n5 = n9;
                                }
                                if (d != -1) {
                                    final b b3 = this.g[d];
                                    b3.a.d = -1;
                                    final e x2 = a.e.b.d.x;
                                    if (x2 != null) {
                                        ++x2.j;
                                    }
                                    b3.x(this.n.d[n4]);
                                    final i a2 = b3.a;
                                    a2.d = d;
                                    a2.g(this, b3);
                                }
                                else {
                                    j = 1;
                                }
                                n = n2;
                                if (n2 > this.k / 2) {
                                    j = 1;
                                    n = n2;
                                }
                            }
                        }
                        else {
                            n = 0;
                        }
                        return n;
                    }
                }
            }
            final boolean b = false;
            continue;
        }
    }
    
    public static e w() {
        return d.x;
    }
    
    private void y() {
        final int e = this.e * 2;
        this.e = e;
        this.g = (b[])Arrays.copyOf((Object[])this.g, e);
        final c n = this.n;
        n.d = (i[])Arrays.copyOf((Object[])n.d, this.e);
        final int e2 = this.e;
        this.j = new boolean[e2];
        this.f = e2;
        this.m = e2;
        final e x = a.e.b.d.x;
        if (x != null) {
            ++x.d;
            x.o = Math.max(x.o, (long)e2);
            final e x2 = a.e.b.d.x;
            x2.x = x2.o;
        }
    }
    
    void A(final a a) {
        final e x = a.e.b.d.x;
        if (x != null) {
            ++x.t;
            x.u = Math.max(x.u, (long)this.k);
            final e x2 = a.e.b.d.x;
            x2.v = Math.max(x2.v, (long)this.l);
        }
        this.u(a);
        this.B(a, false);
        this.n();
    }
    
    public void D() {
        int n = 0;
        c n2;
        while (true) {
            n2 = this.n;
            final i[] d = n2.d;
            if (n >= d.length) {
                break;
            }
            final i i = d[n];
            if (i != null) {
                i.d();
            }
            ++n;
        }
        n2.c.c(this.o, this.p);
        this.p = 0;
        Arrays.fill((Object[])this.n.d, (Object)null);
        final HashMap<String, i> c = this.c;
        if (c != null) {
            c.clear();
        }
        this.b = 0;
        this.d.clear();
        this.k = 1;
        for (int j = 0; j < this.l; ++j) {
            final b[] g = this.g;
            if (g[j] != null) {
                g[j].c = false;
            }
        }
        this.C();
        this.l = 0;
        Object q;
        if (a.e.b.d.v) {
            q = new d.d$b(this, this.n);
        }
        else {
            q = new b(this.n);
        }
        this.q = (a)q;
    }
    
    public void b(final a.e.b.k.e e, final a.e.b.k.e e2, final float n, final int n2) {
        final i q = this.q(e.m(a.e.b.k.d.b.c));
        final i q2 = this.q(e.m(a.e.b.k.d.b.d));
        final i q3 = this.q(e.m(a.e.b.k.d.b.e));
        final i q4 = this.q(e.m(a.e.b.k.d.b.f));
        final i q5 = this.q(e2.m(a.e.b.k.d.b.c));
        final i q6 = this.q(e2.m(a.e.b.k.d.b.d));
        final i q7 = this.q(e2.m(a.e.b.k.d.b.e));
        final i q8 = this.q(e2.m(a.e.b.k.d.b.f));
        final b r = this.r();
        final double n3 = n;
        final double sin = Math.sin(n3);
        final double n4 = n2;
        Double.isNaN(n4);
        r.q(q2, q4, q6, q8, (float)(sin * n4));
        this.d(r);
        final b r2 = this.r();
        final double cos = Math.cos(n3);
        Double.isNaN(n4);
        r2.q(q, q3, q5, q7, (float)(cos * n4));
        this.d(r2);
    }
    
    public void c(final i i, final i j, final int n, final float n2, final i k, final i l, final int n3, final int n4) {
        final b r = this.r();
        r.h(i, j, n, n2, k, l, n3);
        if (n4 != 8) {
            r.d(this, n4);
        }
        this.d(r);
    }
    
    public void d(final b b) {
        if (b == null) {
            return;
        }
        final e x = a.e.b.d.x;
        if (x != null) {
            ++x.f;
            if (b.f) {
                ++x.g;
            }
        }
        final int l = this.l;
        final boolean b2 = true;
        if (l + 1 >= this.m || this.k + 1 >= this.f) {
            this.y();
        }
        int n = 0;
        if (!b.f) {
            b.D(this);
            if (b.isEmpty()) {
                return;
            }
            b.r();
            Label_0296: {
                if (b.f(this)) {
                    final i p = this.p();
                    b.a = p;
                    final int i = this.l;
                    this.l(b);
                    if (this.l == i + 1) {
                        this.q.a((a)b);
                        this.B(this.q, true);
                        n = (b2 ? 1 : 0);
                        if (p.d == -1) {
                            if (b.a == p) {
                                final i v = b.v(p);
                                if (v != null) {
                                    final e x2 = a.e.b.d.x;
                                    if (x2 != null) {
                                        ++x2.j;
                                    }
                                    b.x(v);
                                }
                            }
                            if (!b.f) {
                                b.a.g(this, b);
                            }
                            f<b> f;
                            if (a.e.b.d.v) {
                                f = this.n.a;
                            }
                            else {
                                f = this.n.b;
                            }
                            f.a(b);
                            --this.l;
                            n = (b2 ? 1 : 0);
                        }
                        break Label_0296;
                    }
                }
                n = 0;
            }
            if (!b.s()) {
                return;
            }
        }
        if (n == 0) {
            this.l(b);
        }
    }
    
    public b e(final i i, final i j, final int n, final int n2) {
        if (a.e.b.d.s && n2 == 8 && j.g && i.d == -1) {
            i.e(this, j.f + n);
            return null;
        }
        final b r = this.r();
        r.n(i, j, n);
        if (n2 != 8) {
            r.d(this, n2);
        }
        this.d(r);
        return r;
    }
    
    public void f(final i i, int j) {
        if (a.e.b.d.s && i.d == -1) {
            final float n = (float)j;
            i.e(this, n);
            i k;
            for (j = 0; j < this.b + 1; ++j) {
                k = this.n.d[j];
                if (k != null && k.n && k.o == i.c) {
                    k.e(this, k.p + n);
                }
            }
            return;
        }
        final int d = i.d;
        b b2 = null;
        Label_0189: {
            if (d != -1) {
                final b b = this.g[d];
                if (!b.f) {
                    if (b.e.k() != 0) {
                        final b r = this.r();
                        r.m(i, j);
                        b2 = r;
                        break Label_0189;
                    }
                    b.f = true;
                }
                b.b = (float)j;
                return;
            }
            final b r2 = this.r();
            r2.i(i, j);
            b2 = r2;
        }
        this.d(b2);
    }
    
    public void g(final i i, final i j, final int n, final boolean b) {
        final b r = this.r();
        final i t = this.t();
        t.e = 0;
        r.o(i, j, t, n);
        this.d(r);
    }
    
    public void h(final i i, final i j, final int n, final int n2) {
        final b r = this.r();
        final i t = this.t();
        t.e = 0;
        r.o(i, j, t, n);
        if (n2 != 8) {
            this.m(r, (int)(r.e.g(t) * -1.0f), n2);
        }
        this.d(r);
    }
    
    public void i(final i i, final i j, final int n, final boolean b) {
        final b r = this.r();
        final i t = this.t();
        t.e = 0;
        r.p(i, j, t, n);
        this.d(r);
    }
    
    public void j(final i i, final i j, final int n, final int n2) {
        final b r = this.r();
        final i t = this.t();
        t.e = 0;
        r.p(i, j, t, n);
        if (n2 != 8) {
            this.m(r, (int)(r.e.g(t) * -1.0f), n2);
        }
        this.d(r);
    }
    
    public void k(final i i, final i j, final i k, final i l, final float n, final int n2) {
        final b r = this.r();
        r.k(i, j, k, l, n);
        if (n2 != 8) {
            r.d(this, n2);
        }
        this.d(r);
    }
    
    void m(final b b, final int n, final int n2) {
        b.e(this.o(n2, null), n);
    }
    
    public i o(final int e, final String s) {
        final e x = a.e.b.d.x;
        if (x != null) {
            ++x.l;
        }
        if (this.k + 1 >= this.f) {
            this.y();
        }
        final i a = this.a(a.e.b.i.a.e, s);
        final int n = this.b + 1;
        this.b = n;
        ++this.k;
        a.c = n;
        a.e = e;
        this.n.d[n] = a;
        this.d.b(a);
        return a;
    }
    
    public i p() {
        final e x = a.e.b.d.x;
        if (x != null) {
            ++x.n;
        }
        if (this.k + 1 >= this.f) {
            this.y();
        }
        final i a = this.a(a.e.b.i.a.d, null);
        final int n = this.b + 1;
        this.b = n;
        ++this.k;
        a.c = n;
        return this.n.d[n] = a;
    }
    
    public i q(final Object o) {
        i i = null;
        if (o == null) {
            return null;
        }
        if (this.k + 1 >= this.f) {
            this.y();
        }
        if (o instanceof a.e.b.k.d) {
            final a.e.b.k.d d = (a.e.b.k.d)o;
            i j;
            if ((j = d.h()) == null) {
                d.r(this.n);
                j = d.h();
            }
            final int c = j.c;
            if (c != -1 && c <= this.b) {
                i = j;
                if (this.n.d[c] != null) {
                    return i;
                }
            }
            if (j.c != -1) {
                j.d();
            }
            final int n = this.b + 1;
            this.b = n;
            ++this.k;
            j.c = n;
            j.j = a.e.b.i.a.b;
            this.n.d[n] = j;
            i = j;
        }
        return i;
    }
    
    public b r() {
        Object o = null;
        Label_0101: {
            if (a.e.b.d.v) {
                if ((o = this.n.a.b()) == null) {
                    o = new d.d$b(this, this.n);
                    ++a.e.b.d.z;
                    break Label_0101;
                }
            }
            else if ((o = this.n.b.b()) == null) {
                o = new b(this.n);
                ++a.e.b.d.y;
                break Label_0101;
            }
            ((b)o).y();
        }
        a.e.b.i.b();
        return (b)o;
    }
    
    public i t() {
        final e x = a.e.b.d.x;
        if (x != null) {
            ++x.m;
        }
        if (this.k + 1 >= this.f) {
            this.y();
        }
        final i a = this.a(a.e.b.i.a.d, null);
        final int n = this.b + 1;
        this.b = n;
        ++this.k;
        a.c = n;
        return this.n.d[n] = a;
    }
    
    public c v() {
        return this.n;
    }
    
    public int x(final Object o) {
        final i h = ((a.e.b.k.d)o).h();
        if (h != null) {
            return (int)(h.f + 0.5f);
        }
        return 0;
    }
    
    public void z() {
        final e x = a.e.b.d.x;
        if (x != null) {
            ++x.e;
        }
        if (this.d.isEmpty()) {
            this.n();
            return;
        }
        Label_0052: {
            if (this.h || this.i) {
                final e x2 = a.e.b.d.x;
                if (x2 != null) {
                    ++x2.q;
                }
                final int n = 0;
                int i = 0;
                while (true) {
                    while (i < this.l) {
                        if (!this.g[i].f) {
                            final int n2 = n;
                            if (n2 == 0) {
                                break Label_0052;
                            }
                            final e x3 = a.e.b.d.x;
                            if (x3 != null) {
                                ++x3.p;
                            }
                            this.n();
                            return;
                        }
                        else {
                            ++i;
                        }
                    }
                    final int n2 = 1;
                    continue;
                }
            }
        }
        this.A(this.d);
    }
    
    interface a
    {
        void a(final a p0);
        
        void b(final i p0);
        
        i c(final d p0, final boolean[] p1);
        
        void clear();
        
        i getKey();
        
        boolean isEmpty();
    }
}
