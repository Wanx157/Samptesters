package a.e.b;

import java.util.Comparator;
import java.util.Arrays;

public class h extends b
{
    private int g;
    private i[] h;
    private i[] i;
    private int j;
    h.h$b k;
    
    public h(final c c) {
        super(c);
        this.g = 128;
        this.h = new i[128];
        this.i = new i[128];
        this.j = 0;
        this.k = new h.h$b(this, this);
    }
    
    private final void F(final i i) {
        final int j = this.j;
        final i[] h = this.h;
        if (j + 1 > h.length) {
            final i[] h2 = (i[])Arrays.copyOf((Object[])h, h.length * 2);
            this.h = h2;
            this.i = (i[])Arrays.copyOf((Object[])h2, h2.length * 2);
        }
        final i[] h3 = this.h;
        int k = this.j;
        h3[k] = i;
        ++k;
        this.j = k;
        if (k > 1 && h3[k - 1].c > i.c) {
            final int n = 0;
            int n2 = 0;
            int l;
            while (true) {
                l = this.j;
                if (n2 >= l) {
                    break;
                }
                this.i[n2] = this.h[n2];
                ++n2;
            }
            Arrays.sort((Object[])this.i, 0, l, (Comparator)new h$a(this));
            for (int n3 = n; n3 < this.j; ++n3) {
                this.h[n3] = this.i[n3];
            }
        }
        i.a = true;
        i.a((b)this);
    }
    
    private final void G(final i i) {
        for (int j = 0; j < this.j; ++j) {
            if (this.h[j] == i) {
                int k;
                while (true) {
                    k = this.j;
                    if (j >= k - 1) {
                        break;
                    }
                    final i[] h = this.h;
                    final int n = j + 1;
                    h[j] = h[n];
                    j = n;
                }
                this.j = k - 1;
                i.a = false;
                return;
            }
        }
    }
    
    public void B(final d d, final b b, final boolean b2) {
        final i a = b.a;
        if (a == null) {
            return;
        }
        final b$a e = b.e;
        for (int k = e.k(), i = 0; i < k; ++i) {
            final i f = e.f(i);
            final float a2 = e.a(i);
            this.k.e(f);
            if (this.k.d(a, a2)) {
                this.F(f);
            }
            super.b += b.b * a2;
        }
        this.G(a);
    }
    
    public void b(final i i) {
        this.k.e(i);
        this.k.i();
        i.i[i.e] = 1.0f;
        this.F(i);
    }
    
    public i c(final d d, final boolean[] array) {
        int i = 0;
        int n = -1;
        while (i < this.j) {
            final i j = this.h[i];
            int n2 = 0;
            Label_0090: {
                if (array[j.c]) {
                    n2 = n;
                }
                else {
                    this.k.e(j);
                    final h.h$b k = this.k;
                    if (n == -1) {
                        n2 = n;
                        if (!k.f()) {
                            break Label_0090;
                        }
                    }
                    else {
                        n2 = n;
                        if (!k.g(this.h[n])) {
                            break Label_0090;
                        }
                    }
                    n2 = i;
                }
            }
            ++i;
            n = n2;
        }
        if (n == -1) {
            return null;
        }
        return this.h[n];
    }
    
    public void clear() {
        this.j = 0;
        super.b = 0.0f;
    }
    
    public boolean isEmpty() {
        return this.j == 0;
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(" goal -> (");
        sb.append(super.b);
        sb.append(") : ");
        String s = sb.toString();
        for (int i = 0; i < this.j; ++i) {
            this.k.e(this.h[i]);
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(s);
            sb2.append((Object)this.k);
            sb2.append(" ");
            s = sb2.toString();
        }
        return s;
    }
}
