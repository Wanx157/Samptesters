package a.e.a.b;

import android.view.View;

public class a
{
    public static String a(final View view) {
        try {
            return view.getContext().getResources().getResourceEntryName(view.getId());
        }
        catch (final Exception ex) {
            return "UNKNOWN";
        }
    }
}
