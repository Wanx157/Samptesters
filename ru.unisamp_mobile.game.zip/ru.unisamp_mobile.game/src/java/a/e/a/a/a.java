package a.e.a.a;

public class a
{
    public static String[] a;
    
    static {
        a.e.a.a.a.a = new String[] { "standard", "accelerate", "decelerate", "linear" };
    }
}
