package a.n;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;

class z implements b0
{
    protected z.z$a a;
    
    z(final Context context, final ViewGroup viewGroup, final View view) {
        this.a = new z.z$a(context, viewGroup, view, this);
    }
    
    static z e(final View view) {
        final ViewGroup f = f(view);
        if (f != null) {
            for (int childCount = f.getChildCount(), i = 0; i < childCount; ++i) {
                final View child = f.getChildAt(i);
                if (child instanceof z.z$a) {
                    return ((z.z$a)child).e;
                }
            }
            return new u(f.getContext(), f, view);
        }
        return null;
    }
    
    static ViewGroup f(View view) {
        while (view != null) {
            if (view.getId() == 16908290 && view instanceof ViewGroup) {
                return (ViewGroup)view;
            }
            if (!(view.getParent() instanceof ViewGroup)) {
                continue;
            }
            view = (View)view.getParent();
        }
        return null;
    }
    
    public void b(final Drawable drawable) {
        this.a.a(drawable);
    }
    
    public void d(final Drawable drawable) {
        this.a.f(drawable);
    }
}
