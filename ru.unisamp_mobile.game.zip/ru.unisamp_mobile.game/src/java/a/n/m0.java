package a.n;

interface m0
{
}
