package a.n;

import android.os.IBinder;

class k0 implements m0
{
    private final IBinder a;
    
    k0(final IBinder a) {
        this.a = a;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof k0 && ((k0)o).a.equals(this.a);
    }
    
    @Override
    public int hashCode() {
        return this.a.hashCode();
    }
}
