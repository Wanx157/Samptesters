package a.n;

import android.annotation.SuppressLint;
import android.os.Build$VERSION;
import android.view.ViewGroup;

class x
{
    private static boolean a = true;
    
    static w a(final ViewGroup viewGroup) {
        if (Build$VERSION.SDK_INT >= 18) {
            return (w)new v(viewGroup);
        }
        return (w)u.g(viewGroup);
    }
    
    @SuppressLint({ "NewApi" })
    private static void b(final ViewGroup viewGroup, final boolean b) {
        if (x.a) {
            try {
                viewGroup.suppressLayout(b);
            }
            catch (final NoSuchMethodError noSuchMethodError) {
                x.a = false;
            }
        }
    }
    
    static void c(final ViewGroup viewGroup, final boolean b) {
        final int sdk_INT = Build$VERSION.SDK_INT;
        if (sdk_INT >= 29) {
            viewGroup.suppressLayout(b);
        }
        else if (sdk_INT >= 18) {
            b(viewGroup, b);
        }
        else {
            y.b(viewGroup, b);
        }
    }
}
