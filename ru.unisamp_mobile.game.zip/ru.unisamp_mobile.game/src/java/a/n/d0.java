package a.n;

import android.annotation.SuppressLint;
import android.view.View;

class d0 extends i0
{
    private static boolean e = true;
    
    public void a(final View view) {
    }
    
    @SuppressLint({ "NewApi" })
    public float c(final View view) {
        if (d0.e) {
            try {
                return view.getTransitionAlpha();
            }
            catch (final NoSuchMethodError noSuchMethodError) {
                d0.e = false;
            }
        }
        return view.getAlpha();
    }
    
    public void d(final View view) {
    }
    
    @SuppressLint({ "NewApi" })
    public void f(final View view, final float n) {
        if (d0.e) {
            try {
                view.setTransitionAlpha(n);
                return;
            }
            catch (final NoSuchMethodError noSuchMethodError) {
                d0.e = false;
            }
        }
        view.setAlpha(n);
    }
}
