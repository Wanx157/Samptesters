package a.n;

public class n implements m$f
{
    public void a(final m m) {
    }
    
    public void b(final m m) {
    }
    
    public void c(final m m) {
    }
    
    public void d(final m m) {
    }
}
