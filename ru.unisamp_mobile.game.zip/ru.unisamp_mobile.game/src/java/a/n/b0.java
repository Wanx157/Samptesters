package a.n;

import android.graphics.drawable.Drawable;

interface b0
{
    void b(final Drawable p0);
    
    void d(final Drawable p0);
}
