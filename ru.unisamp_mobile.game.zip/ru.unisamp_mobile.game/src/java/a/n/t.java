package a.n;

import a.d.d;
import android.util.SparseArray;
import android.view.View;
import a.d.a;

class t
{
    final a<View, s> a;
    final SparseArray<View> b;
    final d<View> c;
    final a<String, View> d;
    
    t() {
        this.a = (a<View, s>)new a();
        this.b = (SparseArray<View>)new SparseArray();
        this.c = new d<View>();
        this.d = (a<String, View>)new a();
    }
}
