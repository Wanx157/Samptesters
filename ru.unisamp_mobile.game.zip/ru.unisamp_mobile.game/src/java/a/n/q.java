package a.n;

import android.view.ViewGroup;
import android.util.AndroidRuntimeException;
import android.animation.TimeInterpolator;
import android.view.View;
import java.util.Iterator;
import java.util.ArrayList;

public class q extends m
{
    private ArrayList<m> K;
    private boolean L;
    int M;
    boolean N;
    private int O;
    
    public q() {
        this.K = (ArrayList<m>)new ArrayList();
        this.L = true;
        this.N = false;
        this.O = 0;
    }
    
    private void F0() {
        final b b = new b(this);
        final Iterator iterator = this.K.iterator();
        while (iterator.hasNext()) {
            ((m)iterator.next()).a((m$f)b);
        }
        this.M = this.K.size();
    }
    
    private void w0(final m m) {
        this.K.add((Object)m);
        m.s = this;
    }
    
    public q A0(final View view) {
        for (int i = 0; i < this.K.size(); ++i) {
            ((m)this.K.get(i)).h0(view);
        }
        super.h0(view);
        return this;
    }
    
    public q B0(final long n) {
        super.l0(n);
        if (super.d >= 0L) {
            final ArrayList<m> k = this.K;
            if (k != null) {
                for (int size = k.size(), i = 0; i < size; ++i) {
                    ((m)this.K.get(i)).l0(n);
                }
            }
        }
        return this;
    }
    
    public q C0(final TimeInterpolator timeInterpolator) {
        this.O |= 0x1;
        final ArrayList<m> k = this.K;
        if (k != null) {
            for (int size = k.size(), i = 0; i < size; ++i) {
                ((m)this.K.get(i)).n0(timeInterpolator);
            }
        }
        super.n0(timeInterpolator);
        return this;
    }
    
    public q D0(final int n) {
        if (n != 0) {
            if (n != 1) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Invalid parameter for TransitionSet ordering: ");
                sb.append(n);
                throw new AndroidRuntimeException(sb.toString());
            }
            this.L = false;
        }
        else {
            this.L = true;
        }
        return this;
    }
    
    public q E0(final long n) {
        super.q0(n);
        return this;
    }
    
    public void e0(final View view) {
        super.e0(view);
        for (int size = this.K.size(), i = 0; i < size; ++i) {
            ((m)this.K.get(i)).e0(view);
        }
    }
    
    protected void g() {
        super.g();
        for (int size = this.K.size(), i = 0; i < size; ++i) {
            ((m)this.K.get(i)).g();
        }
    }
    
    public void h(final s s) {
        if (this.X(s.b)) {
            for (final m m : this.K) {
                if (m.X(s.b)) {
                    m.h(s);
                    s.c.add((Object)m);
                }
            }
        }
    }
    
    public void i0(final View view) {
        super.i0(view);
        for (int size = this.K.size(), i = 0; i < size; ++i) {
            ((m)this.K.get(i)).i0(view);
        }
    }
    
    protected void k0() {
        if (this.K.isEmpty()) {
            this.r0();
            this.y();
            return;
        }
        this.F0();
        if (!this.L) {
            for (int i = 1; i < this.K.size(); ++i) {
                ((m)this.K.get(i - 1)).a((m$f)new n(this, (m)this.K.get(i)) {
                    final m a;
                    
                    public void e(final m m) {
                        this.a.k0();
                        m.g0((m$f)this);
                    }
                });
            }
            final m m = (m)this.K.get(0);
            if (m != null) {
                m.k0();
            }
        }
        else {
            final Iterator iterator = this.K.iterator();
            while (iterator.hasNext()) {
                ((m)iterator.next()).k0();
            }
        }
    }
    
    void l(final s s) {
        super.l(s);
        for (int size = this.K.size(), i = 0; i < size; ++i) {
            ((m)this.K.get(i)).l(s);
        }
    }
    
    public void m0(final m$e m$e) {
        super.m0(m$e);
        this.O |= 0x8;
        for (int size = this.K.size(), i = 0; i < size; ++i) {
            ((m)this.K.get(i)).m0(m$e);
        }
    }
    
    public void o0(final g g) {
        super.o0(g);
        this.O |= 0x4;
        if (this.K != null) {
            for (int i = 0; i < this.K.size(); ++i) {
                ((m)this.K.get(i)).o0(g);
            }
        }
    }
    
    public void p(final s s) {
        if (this.X(s.b)) {
            for (final m m : this.K) {
                if (m.X(s.b)) {
                    m.p(s);
                    s.c.add((Object)m);
                }
            }
        }
    }
    
    public void p0(final p p) {
        super.p0(p);
        this.O |= 0x2;
        for (int size = this.K.size(), i = 0; i < size; ++i) {
            ((m)this.K.get(i)).p0(p);
        }
    }
    
    String s0(final String s) {
        String s2 = super.s0(s);
        for (int i = 0; i < this.K.size(); ++i) {
            final StringBuilder sb = new StringBuilder();
            sb.append(s2);
            sb.append("\n");
            final m m = (m)this.K.get(i);
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(s);
            sb2.append("  ");
            sb.append(m.s0(sb2.toString()));
            s2 = sb.toString();
        }
        return s2;
    }
    
    public q t0(final m$f m$f) {
        super.a(m$f);
        return this;
    }
    
    public q u0(final View view) {
        for (int i = 0; i < this.K.size(); ++i) {
            ((m)this.K.get(i)).b(view);
        }
        super.b(view);
        return this;
    }
    
    public m v() {
        final q q = (q)super.v();
        q.K = (ArrayList<m>)new ArrayList();
        for (int size = this.K.size(), i = 0; i < size; ++i) {
            q.w0(((m)this.K.get(i)).v());
        }
        return q;
    }
    
    public q v0(final m m) {
        this.w0(m);
        final long d = super.d;
        if (d >= 0L) {
            m.l0(d);
        }
        if ((this.O & 0x1) != 0x0) {
            m.n0(this.B());
        }
        if ((this.O & 0x2) != 0x0) {
            m.p0(this.H());
        }
        if ((this.O & 0x4) != 0x0) {
            m.o0(this.G());
        }
        if ((this.O & 0x8) != 0x0) {
            m.m0(this.A());
        }
        return this;
    }
    
    protected void x(final ViewGroup viewGroup, final t t, final t t2, final ArrayList<s> list, final ArrayList<s> list2) {
        final long m = this.M();
        for (int size = this.K.size(), i = 0; i < size; ++i) {
            final m j = (m)this.K.get(i);
            if (m > 0L && (this.L || i == 0)) {
                final long k = j.M();
                if (k > 0L) {
                    j.q0(k + m);
                }
                else {
                    j.q0(m);
                }
            }
            j.x(viewGroup, t, t2, (ArrayList)list, (ArrayList)list2);
        }
    }
    
    public m x0(final int n) {
        if (n >= 0 && n < this.K.size()) {
            return (m)this.K.get(n);
        }
        return null;
    }
    
    public int y0() {
        return this.K.size();
    }
    
    public q z0(final m$f m$f) {
        super.g0(m$f);
        return this;
    }
    
    static class b extends n
    {
        q a;
        
        b(final q a) {
            this.a = a;
        }
        
        @Override
        public void c(final m m) {
            final q a = this.a;
            if (!a.N) {
                a.r0();
                this.a.N = true;
            }
        }
        
        public void e(final m m) {
            final q a = this.a;
            final int i = a.M - 1;
            a.M = i;
            if (i == 0) {
                a.N = false;
                a.y();
            }
            m.g0((m$f)this);
        }
    }
}
