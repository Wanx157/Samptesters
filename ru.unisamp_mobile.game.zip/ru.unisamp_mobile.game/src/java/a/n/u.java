package a.n;

import android.view.View;
import android.view.ViewGroup;
import android.content.Context;

class u extends z implements w
{
    u(final Context context, final ViewGroup viewGroup, final View view) {
        super(context, viewGroup, view);
    }
    
    static u g(final ViewGroup viewGroup) {
        return (u)z.e((View)viewGroup);
    }
    
    @Override
    public void a(final View view) {
        super.a.b(view);
    }
    
    @Override
    public void c(final View view) {
        super.a.g(view);
    }
}
