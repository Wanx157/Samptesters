package a.n;

import android.util.SparseIntArray;
import java.util.Iterator;
import java.util.List;
import android.view.ViewGroup;
import android.animation.Animator$AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.widget.ListView;
import a.d.d;
import android.util.SparseArray;
import android.view.View;
import android.animation.TimeInterpolator;
import java.util.ArrayList;
import android.animation.Animator;
import a.d.a;

public abstract class m implements Cloneable
{
    private static final int[] H;
    private static final g I;
    private static ThreadLocal<a<Animator, d>> J;
    private boolean A;
    private ArrayList<f> B;
    private ArrayList<Animator> C;
    p D;
    private e E;
    private a<String, String> F;
    private g G;
    private String b;
    private long c;
    long d;
    private TimeInterpolator e;
    ArrayList<Integer> f;
    ArrayList<View> g;
    private ArrayList<String> h;
    private ArrayList<Class<?>> i;
    private ArrayList<Integer> j;
    private ArrayList<View> k;
    private ArrayList<Class<?>> l;
    private ArrayList<String> m;
    private ArrayList<Integer> n;
    private ArrayList<View> o;
    private ArrayList<Class<?>> p;
    private t q;
    private t r;
    q s;
    private int[] t;
    private ArrayList<s> u;
    private ArrayList<s> v;
    boolean w;
    ArrayList<Animator> x;
    private int y;
    private boolean z;
    
    static {
        H = new int[] { 2, 1, 3, 4 };
        I = (g)new m$a();
        m.J = (ThreadLocal<a<Animator, d>>)new ThreadLocal();
    }
    
    public m() {
        this.b = this.getClass().getName();
        this.c = -1L;
        this.d = -1L;
        this.e = null;
        this.f = (ArrayList<Integer>)new ArrayList();
        this.g = (ArrayList<View>)new ArrayList();
        this.h = null;
        this.i = null;
        this.j = null;
        this.k = null;
        this.l = null;
        this.m = null;
        this.n = null;
        this.o = null;
        this.p = null;
        this.q = new t();
        this.r = new t();
        this.s = null;
        this.t = a.n.m.H;
        this.w = false;
        this.x = (ArrayList<Animator>)new ArrayList();
        this.y = 0;
        this.z = false;
        this.A = false;
        this.B = null;
        this.C = (ArrayList<Animator>)new ArrayList();
        this.G = a.n.m.I;
    }
    
    private static a<Animator, d> I() {
        a a;
        if ((a = (a)m.J.get()) == null) {
            a = new a();
            m.J.set((Object)a);
        }
        return (a<Animator, d>)a;
    }
    
    private static boolean Y(final s s, final s s2, final String s3) {
        final Object value = s.a.get((Object)s3);
        final Object value2 = s2.a.get((Object)s3);
        final boolean b = true;
        boolean b2;
        if (value == null && value2 == null) {
            b2 = false;
        }
        else {
            b2 = b;
            if (value != null) {
                if (value2 == null) {
                    b2 = b;
                }
                else {
                    b2 = (true ^ value.equals(value2));
                }
            }
        }
        return b2;
    }
    
    private void Z(final a<View, s> a, final a<View, s> a2, final SparseArray<View> sparseArray, final SparseArray<View> sparseArray2) {
        for (int size = sparseArray.size(), i = 0; i < size; ++i) {
            final View view = (View)sparseArray.valueAt(i);
            if (view != null && this.X(view)) {
                final View view2 = (View)sparseArray2.get(sparseArray.keyAt(i));
                if (view2 != null && this.X(view2)) {
                    final s s = ((a.d.g<View, s>)a).get(view);
                    final s s2 = ((a.d.g<View, s>)a2).get(view2);
                    if (s != null && s2 != null) {
                        this.u.add((Object)s);
                        this.v.add((Object)s2);
                        ((a.d.g<View, s>)a).remove(view);
                        ((a.d.g<View, s>)a2).remove(view2);
                    }
                }
            }
        }
    }
    
    private void a0(final a<View, s> a, final a<View, s> a2) {
        for (int i = ((a.d.g)a).size() - 1; i >= 0; --i) {
            final View view = (View)((a.d.g)a).i(i);
            if (view != null && this.X(view)) {
                final s s = ((a.d.g<View, s>)a2).remove(view);
                if (s != null && this.X(s.b)) {
                    this.u.add((Object)((a.d.g)a).k(i));
                    this.v.add((Object)s);
                }
            }
        }
    }
    
    private void b0(final a<View, s> a, final a<View, s> a2, final a.d.d<View> d, final a.d.d<View> d2) {
        for (int t = d.t(), i = 0; i < t; ++i) {
            final View view = d.v(i);
            if (view != null && this.X(view)) {
                final View view2 = d2.f(d.k(i));
                if (view2 != null && this.X(view2)) {
                    final s s = ((a.d.g<View, s>)a).get(view);
                    final s s2 = ((a.d.g<View, s>)a2).get(view2);
                    if (s != null && s2 != null) {
                        this.u.add((Object)s);
                        this.v.add((Object)s2);
                        ((a.d.g<View, s>)a).remove(view);
                        ((a.d.g<View, s>)a2).remove(view2);
                    }
                }
            }
        }
    }
    
    private void c(final a<View, s> a, final a<View, s> a2) {
        final int n = 0;
        int n2 = 0;
        int i;
        while (true) {
            i = n;
            if (n2 >= ((a.d.g)a).size()) {
                break;
            }
            final s s = (s)((a.d.g)a).m(n2);
            if (this.X(s.b)) {
                this.u.add((Object)s);
                this.v.add((Object)null);
            }
            ++n2;
        }
        while (i < ((a.d.g)a2).size()) {
            final s s2 = (s)((a.d.g)a2).m(i);
            if (this.X(s2.b)) {
                this.v.add((Object)s2);
                this.u.add((Object)null);
            }
            ++i;
        }
    }
    
    private void c0(final a<View, s> a, final a<View, s> a2, final a<String, View> a3, final a<String, View> a4) {
        for (int size = ((a.d.g)a3).size(), i = 0; i < size; ++i) {
            final View view = (View)((a.d.g)a3).m(i);
            if (view != null && this.X(view)) {
                final View view2 = ((a.d.g<String, View>)a4).get(((a.d.g)a3).i(i));
                if (view2 != null && this.X(view2)) {
                    final s s = ((a.d.g<View, s>)a).get(view);
                    final s s2 = ((a.d.g<View, s>)a2).get(view2);
                    if (s != null && s2 != null) {
                        this.u.add((Object)s);
                        this.v.add((Object)s2);
                        ((a.d.g<View, s>)a).remove(view);
                        ((a.d.g<View, s>)a2).remove(view2);
                    }
                }
            }
        }
    }
    
    private void d0(final t t, final t t2) {
        final a a = new a((a.d.g)t.a);
        final a a2 = new a((a.d.g)t2.a);
        int n = 0;
        while (true) {
            final int[] t3 = this.t;
            if (n >= t3.length) {
                break;
            }
            final int n2 = t3[n];
            if (n2 != 1) {
                if (n2 != 2) {
                    if (n2 != 3) {
                        if (n2 == 4) {
                            this.b0((a<View, s>)a, (a<View, s>)a2, t.c, t2.c);
                        }
                    }
                    else {
                        this.Z((a<View, s>)a, (a<View, s>)a2, t.b, t2.b);
                    }
                }
                else {
                    this.c0((a<View, s>)a, (a<View, s>)a2, t.d, t2.d);
                }
            }
            else {
                this.a0((a<View, s>)a, (a<View, s>)a2);
            }
            ++n;
        }
        this.c((a<View, s>)a, (a<View, s>)a2);
    }
    
    private static void e(final t t, View view, final s s) {
        ((a.d.g<View, s>)t.a).put(view, s);
        final int id = view.getId();
        if (id >= 0) {
            if (t.b.indexOfKey(id) >= 0) {
                t.b.put(id, (Object)null);
            }
            else {
                t.b.put(id, (Object)view);
            }
        }
        final String i = a.g.l.t.I(view);
        if (i != null) {
            if (((a.d.g)t.d).containsKey(i)) {
                ((a.d.g<String, View>)t.d).put(i, null);
            }
            else {
                ((a.d.g<String, View>)t.d).put(i, view);
            }
        }
        if (view.getParent() instanceof ListView) {
            final ListView listView = (ListView)view.getParent();
            if (listView.getAdapter().hasStableIds()) {
                final long itemIdAtPosition = listView.getItemIdAtPosition(listView.getPositionForView(view));
                if (t.c.h(itemIdAtPosition) >= 0) {
                    view = t.c.f(itemIdAtPosition);
                    if (view != null) {
                        a.g.l.t.s0(view, false);
                        t.c.l(itemIdAtPosition, null);
                    }
                }
                else {
                    a.g.l.t.s0(view, true);
                    t.c.l(itemIdAtPosition, view);
                }
            }
        }
    }
    
    private void j0(final Animator animator, final a<Animator, d> a) {
        if (animator != null) {
            animator.addListener((Animator$AnimatorListener)new AnimatorListenerAdapter(this, a) {
                final a a;
                final m b;
                
                public void onAnimationEnd(final Animator animator) {
                    ((a.d.g<Object, Object>)this.a).remove(animator);
                    this.b.x.remove((Object)animator);
                }
                
                public void onAnimationStart(final Animator animator) {
                    this.b.x.add((Object)animator);
                }
            });
            this.f(animator);
        }
    }
    
    private void k(final View view, final boolean b) {
        if (view == null) {
            return;
        }
        final int id = view.getId();
        final ArrayList<Integer> j = this.j;
        if (j != null && j.contains((Object)id)) {
            return;
        }
        final ArrayList<View> k = this.k;
        if (k != null && k.contains((Object)view)) {
            return;
        }
        final ArrayList<Class<?>> l = this.l;
        final int n = 0;
        if (l != null) {
            for (int size = l.size(), i = 0; i < size; ++i) {
                if (((Class)this.l.get(i)).isInstance(view)) {
                    return;
                }
            }
        }
        if (view.getParent() instanceof ViewGroup) {
            final s s = new s(view);
            if (b) {
                this.p(s);
            }
            else {
                this.h(s);
            }
            s.c.add((Object)this);
            this.l(s);
            t t;
            if (b) {
                t = this.q;
            }
            else {
                t = this.r;
            }
            e(t, view, s);
        }
        if (view instanceof ViewGroup) {
            final ArrayList<Integer> n2 = this.n;
            if (n2 != null && n2.contains((Object)id)) {
                return;
            }
            final ArrayList<View> o = this.o;
            if (o != null && o.contains((Object)view)) {
                return;
            }
            final ArrayList<Class<?>> p2 = this.p;
            if (p2 != null) {
                for (int size2 = p2.size(), n3 = 0; n3 < size2; ++n3) {
                    if (((Class)this.p.get(n3)).isInstance(view)) {
                        return;
                    }
                }
            }
            final ViewGroup viewGroup = (ViewGroup)view;
            for (int n4 = n; n4 < viewGroup.getChildCount(); ++n4) {
                this.k(viewGroup.getChildAt(n4), b);
            }
        }
    }
    
    public e A() {
        return this.E;
    }
    
    public TimeInterpolator B() {
        return this.e;
    }
    
    s E(final View view, final boolean b) {
        final q s = this.s;
        if (s != null) {
            return ((m)s).E(view, b);
        }
        ArrayList<s> list;
        if (b) {
            list = this.u;
        }
        else {
            list = this.v;
        }
        final s s2 = null;
        if (list == null) {
            return null;
        }
        final int size = list.size();
        final int n = -1;
        int n2 = 0;
        int n3;
        while (true) {
            n3 = n;
            if (n2 >= size) {
                break;
            }
            final s s3 = (s)list.get(n2);
            if (s3 == null) {
                return null;
            }
            if (s3.b == view) {
                n3 = n2;
                break;
            }
            ++n2;
        }
        s s4 = s2;
        if (n3 >= 0) {
            ArrayList<s> list2;
            if (b) {
                list2 = this.v;
            }
            else {
                list2 = this.u;
            }
            s4 = (s)list2.get(n3);
        }
        return s4;
    }
    
    public String F() {
        return this.b;
    }
    
    public g G() {
        return this.G;
    }
    
    public p H() {
        return this.D;
    }
    
    public long M() {
        return this.c;
    }
    
    public List<Integer> N() {
        return (List<Integer>)this.f;
    }
    
    public List<String> P() {
        return (List<String>)this.h;
    }
    
    public List<Class<?>> Q() {
        return (List<Class<?>>)this.i;
    }
    
    public List<View> T() {
        return (List<View>)this.g;
    }
    
    public String[] U() {
        return null;
    }
    
    public s V(final View view, final boolean b) {
        final q s = this.s;
        if (s != null) {
            return ((m)s).V(view, b);
        }
        t t;
        if (b) {
            t = this.q;
        }
        else {
            t = this.r;
        }
        return t.a.get((Object)view);
    }
    
    public boolean W(final s s, final s s2) {
        boolean b2;
        final boolean b = b2 = false;
        if (s != null) {
            b2 = b;
            if (s2 != null) {
                final String[] u = this.U();
                if (u != null) {
                    final int length = u.length;
                    int n = 0;
                    while (true) {
                        b2 = b;
                        if (n >= length) {
                            return b2;
                        }
                        if (Y(s, s2, u[n])) {
                            break;
                        }
                        ++n;
                    }
                }
                else {
                    final Iterator iterator = s.a.keySet().iterator();
                    do {
                        b2 = b;
                        if (iterator.hasNext()) {
                            continue;
                        }
                        return b2;
                    } while (!Y(s, s2, (String)iterator.next()));
                }
                b2 = true;
            }
        }
        return b2;
    }
    
    boolean X(final View view) {
        final int id = view.getId();
        final ArrayList<Integer> j = this.j;
        if (j != null && j.contains((Object)id)) {
            return false;
        }
        final ArrayList<View> k = this.k;
        if (k != null && k.contains((Object)view)) {
            return false;
        }
        final ArrayList<Class<?>> l = this.l;
        if (l != null) {
            for (int size = l.size(), i = 0; i < size; ++i) {
                if (((Class)this.l.get(i)).isInstance(view)) {
                    return false;
                }
            }
        }
        if (this.m != null && a.g.l.t.I(view) != null && this.m.contains((Object)a.g.l.t.I(view))) {
            return false;
        }
        if (this.f.size() == 0 && this.g.size() == 0) {
            final ArrayList<Class<?>> m = this.i;
            if (m == null || m.isEmpty()) {
                final ArrayList<String> h = this.h;
                if (h == null || h.isEmpty()) {
                    return true;
                }
            }
        }
        if (this.f.contains((Object)id) || this.g.contains((Object)view)) {
            return true;
        }
        final ArrayList<String> h2 = this.h;
        if (h2 != null && h2.contains((Object)a.g.l.t.I(view))) {
            return true;
        }
        if (this.i != null) {
            for (int n = 0; n < this.i.size(); ++n) {
                if (((Class)this.i.get(n)).isInstance(view)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public m a(final f f) {
        if (this.B == null) {
            this.B = (ArrayList<f>)new ArrayList();
        }
        this.B.add((Object)f);
        return this;
    }
    
    public m b(final View view) {
        this.g.add((Object)view);
        return this;
    }
    
    public void e0(final View view) {
        if (!this.A) {
            final a<Animator, d> i = I();
            int j = ((a.d.g)i).size();
            final m0 d = c0.d(view);
            --j;
            while (j >= 0) {
                final d d2 = ((a.d.g<Animator, d>)i).m(j);
                if (d2.a != null && d.equals(d2.d)) {
                    a.n.a.b(((a.d.g<Animator, d>)i).i(j));
                }
                --j;
            }
            final ArrayList<f> b = this.B;
            if (b != null && b.size() > 0) {
                final ArrayList list = (ArrayList)this.B.clone();
                for (int size = list.size(), k = 0; k < size; ++k) {
                    ((f)list.get(k)).a(this);
                }
            }
            this.z = true;
        }
    }
    
    protected void f(final Animator animator) {
        if (animator == null) {
            this.y();
        }
        else {
            if (this.z() >= 0L) {
                animator.setDuration(this.z());
            }
            if (this.M() >= 0L) {
                animator.setStartDelay(this.M() + animator.getStartDelay());
            }
            if (this.B() != null) {
                animator.setInterpolator(this.B());
            }
            animator.addListener((Animator$AnimatorListener)new AnimatorListenerAdapter(this) {
                final m a;
                
                public void onAnimationEnd(final Animator animator) {
                    this.a.y();
                    animator.removeListener((Animator$AnimatorListener)this);
                }
            });
            animator.start();
        }
    }
    
    void f0(final ViewGroup viewGroup) {
        this.u = (ArrayList<s>)new ArrayList();
        this.v = (ArrayList<s>)new ArrayList();
        this.d0(this.q, this.r);
        final a<Animator, d> i = I();
        int j = ((a.d.g)i).size();
        final m0 d = c0.d((View)viewGroup);
        --j;
        while (j >= 0) {
            final Animator animator = ((a.d.g<Animator, d>)i).i(j);
            if (animator != null) {
                final d d2 = ((a.d.g<Animator, d>)i).get(animator);
                if (d2 != null && d2.a != null && d.equals(d2.d)) {
                    final s c = d2.c;
                    final View a = d2.a;
                    final s v = this.V(a, true);
                    s e;
                    final s s = e = this.E(a, (boolean)(1 != 0));
                    if (v == null && (e = s) == null) {
                        e = ((a.d.g<K, s>)this.r.a).get(a);
                    }
                    if ((v != null || e != null) && d2.e.W(c, e)) {
                        if (!animator.isRunning() && !animator.isStarted()) {
                            i.remove((Object)animator);
                        }
                        else {
                            animator.cancel();
                        }
                    }
                }
            }
            --j;
        }
        this.x(viewGroup, this.q, this.r, this.u, this.v);
        this.k0();
    }
    
    protected void g() {
        for (int i = this.x.size() - 1; i >= 0; --i) {
            ((Animator)this.x.get(i)).cancel();
        }
        final ArrayList<f> b = this.B;
        if (b != null && b.size() > 0) {
            final ArrayList list = (ArrayList)this.B.clone();
            for (int size = list.size(), j = 0; j < size; ++j) {
                ((f)list.get(j)).d(this);
            }
        }
    }
    
    public m g0(final f f) {
        final ArrayList<f> b = this.B;
        if (b == null) {
            return this;
        }
        b.remove((Object)f);
        if (this.B.size() == 0) {
            this.B = null;
        }
        return this;
    }
    
    public abstract void h(final s p0);
    
    public m h0(final View view) {
        this.g.remove((Object)view);
        return this;
    }
    
    public void i0(final View view) {
        if (this.z) {
            if (!this.A) {
                final a<Animator, d> i = I();
                int j = ((a.d.g)i).size();
                final m0 d = c0.d(view);
                --j;
                while (j >= 0) {
                    final d d2 = ((a.d.g<Animator, d>)i).m(j);
                    if (d2.a != null && d.equals(d2.d)) {
                        a.n.a.c(((a.d.g<Animator, d>)i).i(j));
                    }
                    --j;
                }
                final ArrayList<f> b = this.B;
                if (b != null && b.size() > 0) {
                    final ArrayList list = (ArrayList)this.B.clone();
                    for (int size = list.size(), k = 0; k < size; ++k) {
                        ((f)list.get(k)).b(this);
                    }
                }
            }
            this.z = false;
        }
    }
    
    protected void k0() {
        this.r0();
        final a<Animator, d> i = I();
        for (final Animator animator : this.C) {
            if (((a.d.g)i).containsKey(animator)) {
                this.r0();
                this.j0(animator, i);
            }
        }
        this.C.clear();
        this.y();
    }
    
    void l(final s s) {
        if (this.D != null && !s.a.isEmpty()) {
            final String[] b = this.D.b();
            if (b == null) {
                return;
            }
            final int n = 0;
            int i = 0;
            while (true) {
                while (i < b.length) {
                    if (!s.a.containsKey((Object)b[i])) {
                        final int n2 = n;
                        if (n2 == 0) {
                            this.D.a(s);
                        }
                        return;
                    }
                    else {
                        ++i;
                    }
                }
                final int n2 = 1;
                continue;
            }
        }
    }
    
    public m l0(final long d) {
        this.d = d;
        return this;
    }
    
    public void m0(final e e) {
        this.E = e;
    }
    
    public m n0(final TimeInterpolator e) {
        this.e = e;
        return this;
    }
    
    public void o0(final g g) {
        g i = g;
        if (g == null) {
            i = a.n.m.I;
        }
        this.G = i;
    }
    
    public abstract void p(final s p0);
    
    public void p0(final p d) {
        this.D = d;
    }
    
    public m q0(final long c) {
        this.c = c;
        return this;
    }
    
    void r(final ViewGroup viewGroup, final boolean b) {
        this.t(b);
        final int size = this.f.size();
        final int n = 0;
        Label_0301: {
            if (size > 0 || this.g.size() > 0) {
                final ArrayList<String> h = this.h;
                if (h == null || h.isEmpty()) {
                    final ArrayList<Class<?>> i = this.i;
                    if (i == null || i.isEmpty()) {
                        for (int j = 0; j < this.f.size(); ++j) {
                            final View viewById = viewGroup.findViewById((int)this.f.get(j));
                            if (viewById != null) {
                                final s s = new s(viewById);
                                if (b) {
                                    this.p(s);
                                }
                                else {
                                    this.h(s);
                                }
                                s.c.add((Object)this);
                                this.l(s);
                                t t;
                                if (b) {
                                    t = this.q;
                                }
                                else {
                                    t = this.r;
                                }
                                e(t, viewById, s);
                            }
                        }
                        for (int k = 0; k < this.g.size(); ++k) {
                            final View view = (View)this.g.get(k);
                            final s s2 = new s(view);
                            if (b) {
                                this.p(s2);
                            }
                            else {
                                this.h(s2);
                            }
                            s2.c.add((Object)this);
                            this.l(s2);
                            t t2;
                            if (b) {
                                t2 = this.q;
                            }
                            else {
                                t2 = this.r;
                            }
                            e(t2, view, s2);
                        }
                        break Label_0301;
                    }
                }
            }
            this.k((View)viewGroup, b);
        }
        if (!b) {
            final a<String, String> f = this.F;
            if (f != null) {
                final int size2 = ((a.d.g)f).size();
                final ArrayList list = new ArrayList(size2);
                int n2 = 0;
                int l;
                while (true) {
                    l = n;
                    if (n2 >= size2) {
                        break;
                    }
                    list.add((Object)this.q.d.remove((Object)this.F.i(n2)));
                    ++n2;
                }
                while (l < size2) {
                    final View view2 = (View)list.get(l);
                    if (view2 != null) {
                        ((a.d.g<String, View>)this.q.d).put(((a.d.g<K, String>)this.F).m(l), view2);
                    }
                    ++l;
                }
            }
        }
    }
    
    protected void r0() {
        if (this.y == 0) {
            final ArrayList<f> b = this.B;
            if (b != null && b.size() > 0) {
                final ArrayList list = (ArrayList)this.B.clone();
                for (int size = list.size(), i = 0; i < size; ++i) {
                    ((f)list.get(i)).c(this);
                }
            }
            this.A = false;
        }
        ++this.y;
    }
    
    String s0(String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        sb.append(this.getClass().getSimpleName());
        sb.append("@");
        sb.append(Integer.toHexString(this.hashCode()));
        sb.append(": ");
        final String s2 = s = sb.toString();
        if (this.d != -1L) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(s2);
            sb2.append("dur(");
            sb2.append(this.d);
            sb2.append(") ");
            s = sb2.toString();
        }
        String string = s;
        if (this.c != -1L) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(s);
            sb3.append("dly(");
            sb3.append(this.c);
            sb3.append(") ");
            string = sb3.toString();
        }
        s = string;
        if (this.e != null) {
            final StringBuilder sb4 = new StringBuilder();
            sb4.append(string);
            sb4.append("interp(");
            sb4.append((Object)this.e);
            sb4.append(") ");
            s = sb4.toString();
        }
        if (this.f.size() <= 0) {
            final String string2 = s;
            if (this.g.size() <= 0) {
                return string2;
            }
        }
        final StringBuilder sb5 = new StringBuilder();
        sb5.append(s);
        sb5.append("tgts(");
        s = sb5.toString();
        final int size = this.f.size();
        final int n = 0;
        String s3 = s;
        if (size > 0) {
            int n2 = 0;
            while (true) {
                s3 = s;
                if (n2 >= this.f.size()) {
                    break;
                }
                String string3 = s;
                if (n2 > 0) {
                    final StringBuilder sb6 = new StringBuilder();
                    sb6.append(s);
                    sb6.append(", ");
                    string3 = sb6.toString();
                }
                final StringBuilder sb7 = new StringBuilder();
                sb7.append(string3);
                sb7.append(this.f.get(n2));
                s = sb7.toString();
                ++n2;
            }
        }
        String s4 = s3;
        if (this.g.size() > 0) {
            s = s3;
            int n3 = n;
            while (true) {
                s4 = s;
                if (n3 >= this.g.size()) {
                    break;
                }
                String string4 = s;
                if (n3 > 0) {
                    final StringBuilder sb8 = new StringBuilder();
                    sb8.append(s);
                    sb8.append(", ");
                    string4 = sb8.toString();
                }
                final StringBuilder sb9 = new StringBuilder();
                sb9.append(string4);
                sb9.append(this.g.get(n3));
                s = sb9.toString();
                ++n3;
            }
        }
        final StringBuilder sb10 = new StringBuilder();
        sb10.append(s4);
        sb10.append(")");
        return sb10.toString();
    }
    
    void t(final boolean b) {
        t t;
        if (b) {
            ((a.d.g)this.q.a).clear();
            this.q.b.clear();
            t = this.q;
        }
        else {
            ((a.d.g)this.r.a).clear();
            this.r.b.clear();
            t = this.r;
        }
        t.c.b();
    }
    
    @Override
    public String toString() {
        return this.s0("");
    }
    
    public m v() {
        try {
            final m m = (m)super.clone();
            m.C = (ArrayList<Animator>)new ArrayList();
            m.q = new t();
            m.r = new t();
            m.u = null;
            m.v = null;
            return m;
        }
        catch (final CloneNotSupportedException ex) {
            return null;
        }
    }
    
    public Animator w(final ViewGroup viewGroup, final s s, final s s2) {
        return null;
    }
    
    protected void x(final ViewGroup viewGroup, final t t, final t t2, final ArrayList<s> list, final ArrayList<s> list2) {
        final a<Animator, d> i = I();
        final SparseIntArray sparseIntArray = new SparseIntArray();
        final int size = list.size();
        long n = Long.MAX_VALUE;
        long min;
        int n4;
        for (int j = 0; j < size; j = n4 + 1, n = min) {
            final s s = (s)list.get(j);
            final s s2 = (s)list2.get(j);
            s s3;
            if ((s3 = s) != null) {
                s3 = s;
                if (!s.c.contains((Object)this)) {
                    s3 = null;
                }
            }
            s s4;
            if ((s4 = s2) != null) {
                s4 = s2;
                if (!s2.c.contains((Object)this)) {
                    s4 = null;
                }
            }
            if ((s3 != null || s4 != null) && (s3 == null || s4 == null || this.W(s3, s4))) {
                Animator w = this.w(viewGroup, s3, s4);
                if (w != null) {
                    s s7 = null;
                    Animator animator;
                    View view;
                    if (s4 != null) {
                        final View b = s4.b;
                        final String[] u = this.U();
                        Label_0411: {
                            if (u != null && u.length > 0) {
                                final s s5 = new s(b);
                                final s s6 = ((a.d.g<K, s>)t2.a).get(b);
                                int n2 = j;
                                if (s6 != null) {
                                    int n3 = 0;
                                    while (true) {
                                        n2 = j;
                                        if (n3 >= u.length) {
                                            break;
                                        }
                                        s5.a.put((Object)u[n3], s6.a.get((Object)u[n3]));
                                        ++n3;
                                    }
                                }
                                j = n2;
                                for (int size2 = ((a.d.g)i).size(), k = 0; k < size2; ++k) {
                                    final d d = ((a.d.g<Object, d>)i).get(((a.d.g<Object, d>)i).i(k));
                                    if (d.c != null && d.a == b && d.b.equals((Object)this.F()) && d.c.equals(s5)) {
                                        w = null;
                                        s7 = s5;
                                        break Label_0411;
                                    }
                                }
                                s7 = s5;
                            }
                            else {
                                s7 = null;
                            }
                        }
                        animator = w;
                        view = b;
                    }
                    else {
                        final View b2 = s3.b;
                        animator = w;
                        s7 = null;
                        view = b2;
                    }
                    min = n;
                    n4 = j;
                    if (animator != null) {
                        final p d2 = this.D;
                        min = n;
                        if (d2 != null) {
                            final long c = d2.c(viewGroup, this, s3, s4);
                            sparseIntArray.put(this.C.size(), (int)c);
                            min = Math.min(c, n);
                        }
                        ((a.d.g<Animator, d>)i).put(animator, new d(view, this.F(), this, c0.d((View)viewGroup), s7));
                        this.C.add((Object)animator);
                        n4 = j;
                    }
                    continue;
                }
            }
            min = n;
            n4 = j;
        }
        if (sparseIntArray.size() != 0) {
            for (int l = 0; l < sparseIntArray.size(); ++l) {
                final Animator animator2 = (Animator)this.C.get(sparseIntArray.keyAt(l));
                animator2.setStartDelay(sparseIntArray.valueAt(l) - n + animator2.getStartDelay());
            }
        }
    }
    
    protected void y() {
        final int y = this.y - 1;
        this.y = y;
        if (y == 0) {
            final ArrayList<f> b = this.B;
            if (b != null && b.size() > 0) {
                final ArrayList list = (ArrayList)this.B.clone();
                for (int size = list.size(), i = 0; i < size; ++i) {
                    ((f)list.get(i)).e(this);
                }
            }
            for (int j = 0; j < this.q.c.t(); ++j) {
                final View view = this.q.c.v(j);
                if (view != null) {
                    a.g.l.t.s0(view, false);
                }
            }
            for (int k = 0; k < this.r.c.t(); ++k) {
                final View view2 = this.r.c.v(k);
                if (view2 != null) {
                    a.g.l.t.s0(view2, false);
                }
            }
            this.A = true;
        }
    }
    
    public long z() {
        return this.d;
    }
    
    private static class d
    {
        View a;
        String b;
        s c;
        m0 d;
        m e;
        
        d(final View a, final String b, final m e, final m0 d, final s c) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
        }
    }
    
    public abstract static class e
    {
    }
    
    public interface f
    {
        void a(final m p0);
        
        void b(final m p0);
        
        void c(final m p0);
        
        void d(final m p0);
        
        void e(final m p0);
    }
}
