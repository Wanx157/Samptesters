package a.n;

import android.view.ViewGroup;
import android.animation.Animator$AnimatorListener;
import android.animation.ObjectAnimator;
import android.animation.Animator;
import android.view.View;

public class d extends j0
{
    public d() {
    }
    
    public d(final int n) {
        this.z0(n);
    }
    
    private Animator A0(final View view, final float n, final float n2) {
        if (n == n2) {
            return null;
        }
        c0.g(view, n);
        final ObjectAnimator ofFloat = ObjectAnimator.ofFloat((Object)view, c0.b, new float[] { n2 });
        ofFloat.addListener((Animator$AnimatorListener)new d.d$b(view));
        this.a((m$f)new n(this, view) {
            final View a;
            
            public void e(final m m) {
                c0.g(this.a, 1.0f);
                c0.a(this.a);
                m.g0((m$f)this);
            }
        });
        return (Animator)ofFloat;
    }
    
    private static float B0(final s s, final float n) {
        float floatValue = n;
        if (s != null) {
            final Float n2 = (Float)s.a.get((Object)"android:fade:transitionAlpha");
            floatValue = n;
            if (n2 != null) {
                floatValue = n2;
            }
        }
        return floatValue;
    }
    
    @Override
    public void p(final s s) {
        super.p(s);
        s.a.put((Object)"android:fade:transitionAlpha", (Object)c0.c(s.b));
    }
    
    @Override
    public Animator v0(final ViewGroup viewGroup, final View view, final s s, final s s2) {
        final float n = 0.0f;
        float b0 = B0(s, 0.0f);
        if (b0 == 1.0f) {
            b0 = n;
        }
        return this.A0(view, b0, 1.0f);
    }
    
    @Override
    public Animator x0(final ViewGroup viewGroup, final View view, final s s, final s s2) {
        c0.e(view);
        return this.A0(view, B0(s, 1.0f), 0.0f);
    }
}
