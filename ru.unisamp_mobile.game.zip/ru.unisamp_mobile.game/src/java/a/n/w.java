package a.n;

import android.view.View;

interface w extends b0
{
    void a(final View p0);
    
    void c(final View p0);
}
