package a.n;

import android.graphics.Path;

public abstract class g
{
    public abstract Path a(final float p0, final float p1, final float p2, final float p3);
}
