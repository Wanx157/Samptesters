package a.n;

import android.graphics.Matrix;
import android.view.View;

class h0 extends g0
{
    public float c(final View view) {
        return view.getTransitionAlpha();
    }
    
    @Override
    public void e(final View view, final int n, final int n2, final int n3, final int n4) {
        view.setLeftTopRightBottom(n, n2, n3, n4);
    }
    
    public void f(final View view, final float transitionAlpha) {
        view.setTransitionAlpha(transitionAlpha);
    }
    
    @Override
    public void g(final View view, final int transitionVisibility) {
        view.setTransitionVisibility(transitionVisibility);
    }
    
    public void h(final View view, final Matrix matrix) {
        view.transformMatrixToGlobal(matrix);
    }
    
    public void i(final View view, final Matrix matrix) {
        view.transformMatrixToLocal(matrix);
    }
}
