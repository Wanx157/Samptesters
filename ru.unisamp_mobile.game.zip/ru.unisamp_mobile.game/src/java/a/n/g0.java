package a.n;

import android.annotation.SuppressLint;
import android.os.Build$VERSION;
import android.view.View;

class g0 extends f0
{
    private static boolean i = true;
    
    @SuppressLint({ "NewApi" })
    public void g(final View view, final int transitionVisibility) {
        if (Build$VERSION.SDK_INT == 28) {
            super.g(view, transitionVisibility);
        }
        else if (g0.i) {
            try {
                view.setTransitionVisibility(transitionVisibility);
            }
            catch (final NoSuchMethodError noSuchMethodError) {
                g0.i = false;
            }
        }
    }
}
