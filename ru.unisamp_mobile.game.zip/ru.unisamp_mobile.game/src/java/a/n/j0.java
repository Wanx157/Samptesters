package a.n;

import android.animation.AnimatorListenerAdapter;
import android.animation.Animator$AnimatorListener;
import android.animation.Animator;
import android.view.View;
import android.view.ViewGroup;

public abstract class j0 extends m
{
    private static final String[] L;
    private int K;
    
    static {
        L = new String[] { "android:visibility:visibility", "android:visibility:parent" };
    }
    
    public j0() {
        this.K = 3;
    }
    
    private void t0(final s s) {
        s.a.put((Object)"android:visibility:visibility", (Object)s.b.getVisibility());
        s.a.put((Object)"android:visibility:parent", (Object)s.b.getParent());
        final int[] array = new int[2];
        s.b.getLocationOnScreen(array);
        s.a.put((Object)"android:visibility:screenLocation", (Object)array);
    }
    
    private j0.j0$c u0(final s s, final s s2) {
        final j0.j0$c j0$c = new j0.j0$c();
        j0$c.a = false;
        j0$c.b = false;
        if (s != null && s.a.containsKey((Object)"android:visibility:visibility")) {
            j0$c.c = (int)s.a.get((Object)"android:visibility:visibility");
            j0$c.e = (ViewGroup)s.a.get((Object)"android:visibility:parent");
        }
        else {
            j0$c.c = -1;
            j0$c.e = null;
        }
        if (s2 != null && s2.a.containsKey((Object)"android:visibility:visibility")) {
            j0$c.d = (int)s2.a.get((Object)"android:visibility:visibility");
            j0$c.f = (ViewGroup)s2.a.get((Object)"android:visibility:parent");
        }
        else {
            j0$c.d = -1;
            j0$c.f = null;
        }
        while (true) {
            Label_0301: {
                if (s != null && s2 != null) {
                    if (j0$c.c == j0$c.d && j0$c.e == j0$c.f) {
                        return j0$c;
                    }
                    final int c = j0$c.c;
                    final int d = j0$c.d;
                    if (c != d) {
                        if (c == 0) {
                            break Label_0301;
                        }
                        if (d != 0) {
                            return j0$c;
                        }
                    }
                    else {
                        if (j0$c.f == null) {
                            break Label_0301;
                        }
                        if (j0$c.e != null) {
                            return j0$c;
                        }
                    }
                }
                else if (s != null || j0$c.d != 0) {
                    if (s2 == null && j0$c.c == 0) {
                        break Label_0301;
                    }
                    return j0$c;
                }
                j0$c.b = true;
                j0$c.a = true;
                return j0$c;
            }
            j0$c.b = false;
            continue;
        }
    }
    
    public String[] U() {
        return j0.L;
    }
    
    public boolean W(final s s, final s s2) {
        final boolean b = false;
        if (s == null && s2 == null) {
            return false;
        }
        if (s != null && s2 != null && s2.a.containsKey((Object)"android:visibility:visibility") != s.a.containsKey((Object)"android:visibility:visibility")) {
            return false;
        }
        final j0.j0$c u0 = this.u0(s, s2);
        boolean b2 = b;
        if (u0.a) {
            if (u0.c != 0) {
                b2 = b;
                if (u0.d != 0) {
                    return b2;
                }
            }
            b2 = true;
        }
        return b2;
    }
    
    public void h(final s s) {
        this.t0(s);
    }
    
    public void p(final s s) {
        this.t0(s);
    }
    
    public abstract Animator v0(final ViewGroup p0, final View p1, final s p2, final s p3);
    
    public Animator w(final ViewGroup viewGroup, final s s, final s s2) {
        final j0.j0$c u0 = this.u0(s, s2);
        if (!u0.a || (u0.e == null && u0.f == null)) {
            return null;
        }
        if (u0.b) {
            return this.w0(viewGroup, s, u0.c, s2, u0.d);
        }
        return this.y0(viewGroup, s, u0.c, s2, u0.d);
    }
    
    public Animator w0(final ViewGroup viewGroup, final s s, final int n, final s s2, final int n2) {
        if ((this.K & 0x1) == 0x1 && s2 != null) {
            if (s == null) {
                final View view = (View)s2.b.getParent();
                if (this.u0(this.E(view, false), this.V(view, false)).a) {
                    return null;
                }
            }
            return this.v0(viewGroup, s2.b, s, s2);
        }
        return null;
    }
    
    public abstract Animator x0(final ViewGroup p0, final View p1, final s p2, final s p3);
    
    public Animator y0(final ViewGroup viewGroup, final s s, int n, final s s2, int n2) {
        if ((this.K & 0x2) != 0x2) {
            return null;
        }
        if (s == null) {
            return null;
        }
        final View b = s.b;
        View b2;
        if (s2 != null) {
            b2 = s2.b;
        }
        else {
            b2 = null;
        }
        View view = (View)b.getTag(j.save_overlay_view);
        View view2 = null;
        Label_0287: {
            if (view != null) {
                view2 = null;
                n = 1;
            }
            else {
                View view3 = null;
                Label_0133: {
                    Label_0125: {
                        if (b2 != null && b2.getParent() != null) {
                            if (n2 != 4) {
                                if (b != b2) {
                                    break Label_0125;
                                }
                            }
                            view3 = b2;
                            n = 0;
                            b2 = null;
                            break Label_0133;
                        }
                        if (b2 != null) {
                            view3 = null;
                            n = 0;
                            break Label_0133;
                        }
                    }
                    b2 = null;
                    view3 = null;
                    n = 1;
                }
                View a = b2;
                Label_0277: {
                    if (n != 0) {
                        if (b.getParent() != null) {
                            a = b2;
                            if (!(b.getParent() instanceof View)) {
                                break Label_0277;
                            }
                            final View view4 = (View)b.getParent();
                            if (!this.u0(this.V(view4, true), this.E(view4, true)).a) {
                                a = r.a(viewGroup, b, view4);
                                break Label_0277;
                            }
                            n = view4.getId();
                            a = b2;
                            if (view4.getParent() != null) {
                                break Label_0277;
                            }
                            a = b2;
                            if (n == -1) {
                                break Label_0277;
                            }
                            a = b2;
                            if (viewGroup.findViewById(n) == null) {
                                break Label_0277;
                            }
                            a = b2;
                            if (!super.w) {
                                break Label_0277;
                            }
                        }
                        view2 = view3;
                        n = 0;
                        view = b;
                        break Label_0287;
                    }
                }
                n = 0;
                view2 = view3;
                view = a;
            }
        }
        if (view != null) {
            if (n == 0) {
                final int[] array = (int[])s.a.get((Object)"android:visibility:screenLocation");
                n2 = array[0];
                final int n3 = array[1];
                final int[] array2 = new int[2];
                viewGroup.getLocationOnScreen(array2);
                view.offsetLeftAndRight(n2 - array2[0] - view.getLeft());
                view.offsetTopAndBottom(n3 - array2[1] - view.getTop());
                x.a(viewGroup).a(view);
            }
            final Animator x0 = this.x0(viewGroup, view, s, s2);
            if (n == 0) {
                if (x0 == null) {
                    x.a(viewGroup).c(view);
                }
                else {
                    b.setTag(j.save_overlay_view, (Object)view);
                    this.a((m$f)new n(this, viewGroup, view, b) {
                        final ViewGroup a;
                        final View b;
                        final View c;
                        final j0 d;
                        
                        @Override
                        public void a(final m m) {
                            x.a(this.a).c(this.b);
                        }
                        
                        @Override
                        public void b(final m m) {
                            if (this.b.getParent() == null) {
                                x.a(this.a).a(this.b);
                            }
                            else {
                                this.d.g();
                            }
                        }
                        
                        public void e(final m m) {
                            this.c.setTag(j.save_overlay_view, (Object)null);
                            x.a(this.a).c(this.b);
                            m.g0((m$f)this);
                        }
                    });
                }
            }
            return x0;
        }
        if (view2 != null) {
            n = view2.getVisibility();
            c0.h(view2, 0);
            final Animator x2 = this.x0(viewGroup, view2, s, s2);
            if (x2 != null) {
                final b b3 = new b(view2, n2, true);
                x2.addListener((Animator$AnimatorListener)b3);
                a.a(x2, (AnimatorListenerAdapter)b3);
                this.a((m$f)b3);
            }
            else {
                c0.h(view2, n);
            }
            return x2;
        }
        return null;
    }
    
    public void z0(final int k) {
        if ((k & 0xFFFFFFFC) == 0x0) {
            this.K = k;
            return;
        }
        throw new IllegalArgumentException("Only MODE_IN and MODE_OUT flags are allowed");
    }
    
    private static class b extends AnimatorListenerAdapter implements m$f, a$a
    {
        private final View a;
        private final int b;
        private final ViewGroup c;
        private final boolean d;
        private boolean e;
        boolean f;
        
        b(final View a, final int b, final boolean d) {
            this.f = false;
            this.a = a;
            this.b = b;
            this.c = (ViewGroup)a.getParent();
            this.d = d;
            this.g(true);
        }
        
        private void f() {
            if (!this.f) {
                c0.h(this.a, this.b);
                final ViewGroup c = this.c;
                if (c != null) {
                    c.invalidate();
                }
            }
            this.g(false);
        }
        
        private void g(final boolean e) {
            if (this.d && this.e != e) {
                final ViewGroup c = this.c;
                if (c != null) {
                    x.c(c, this.e = e);
                }
            }
        }
        
        public void a(final m m) {
            this.g(false);
        }
        
        public void b(final m m) {
            this.g(true);
        }
        
        public void c(final m m) {
        }
        
        public void d(final m m) {
        }
        
        public void e(final m m) {
            this.f();
            m.g0((m$f)this);
        }
        
        public void onAnimationCancel(final Animator animator) {
            this.f = true;
        }
        
        public void onAnimationEnd(final Animator animator) {
            this.f();
        }
        
        public void onAnimationPause(final Animator animator) {
            if (!this.f) {
                c0.h(this.a, this.b);
            }
        }
        
        public void onAnimationRepeat(final Animator animator) {
        }
        
        public void onAnimationResume(final Animator animator) {
            if (!this.f) {
                c0.h(this.a, 0);
            }
        }
        
        public void onAnimationStart(final Animator animator) {
        }
    }
}
