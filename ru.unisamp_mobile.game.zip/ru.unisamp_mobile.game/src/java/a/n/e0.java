package a.n;

import android.annotation.SuppressLint;
import android.graphics.Matrix;
import android.view.View;

class e0 extends d0
{
    private static boolean f = true;
    private static boolean g = true;
    
    @SuppressLint({ "NewApi" })
    public void h(final View view, final Matrix matrix) {
        if (e0.f) {
            try {
                view.transformMatrixToGlobal(matrix);
            }
            catch (final NoSuchMethodError noSuchMethodError) {
                e0.f = false;
            }
        }
    }
    
    @SuppressLint({ "NewApi" })
    public void i(final View view, final Matrix matrix) {
        if (e0.g) {
            try {
                view.transformMatrixToLocal(matrix);
            }
            catch (final NoSuchMethodError noSuchMethodError) {
                e0.g = false;
            }
        }
    }
}
