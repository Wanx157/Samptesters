package a.n;

public class b extends q
{
    public b() {
        this.G0();
    }
    
    private void G0() {
        this.D0(1);
        this.v0(new d(2));
        this.v0(new c());
        this.v0(new d(1));
    }
}
