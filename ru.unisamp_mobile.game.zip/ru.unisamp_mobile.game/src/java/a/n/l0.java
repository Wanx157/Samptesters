package a.n;

import android.view.View;
import android.view.WindowId;

class l0 implements m0
{
    private final WindowId a;
    
    l0(final View view) {
        this.a = view.getWindowId();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof l0 && ((l0)o).a.equals((Object)this.a);
    }
    
    @Override
    public int hashCode() {
        return this.a.hashCode();
    }
}
