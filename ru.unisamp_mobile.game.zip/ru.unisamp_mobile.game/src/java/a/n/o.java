package a.n;

import a.d.g;
import java.util.Collection;
import java.util.Iterator;
import android.view.ViewTreeObserver$OnPreDrawListener;
import android.view.View$OnAttachStateChangeListener;
import android.view.View;
import a.g.l.t;
import java.util.ArrayList;
import android.view.ViewGroup;
import a.d.a;
import java.lang.ref.WeakReference;

public class o
{
    private static m a;
    private static ThreadLocal<WeakReference<a.d.a<ViewGroup, ArrayList<m>>>> b;
    static ArrayList<ViewGroup> c;
    
    static {
        o.a = (m)new b();
        o.b = (ThreadLocal<WeakReference<a.d.a<ViewGroup, ArrayList<m>>>>)new ThreadLocal();
        o.c = (ArrayList<ViewGroup>)new ArrayList();
    }
    
    public static void a(final ViewGroup viewGroup, m v) {
        if (!o.c.contains((Object)viewGroup) && t.Q((View)viewGroup)) {
            o.c.add((Object)viewGroup);
            m a;
            if ((a = v) == null) {
                a = o.a;
            }
            v = a.v();
            d(viewGroup, v);
            l.c(viewGroup, null);
            c(viewGroup, v);
        }
    }
    
    static a.d.a<ViewGroup, ArrayList<m>> b() {
        final WeakReference weakReference = (WeakReference)o.b.get();
        if (weakReference != null) {
            final a.d.a a = (a.d.a)weakReference.get();
            if (a != null) {
                return (a.d.a<ViewGroup, ArrayList<m>>)a;
            }
        }
        final a.d.a a2 = new a.d.a();
        o.b.set((Object)new WeakReference((Object)a2));
        return (a.d.a<ViewGroup, ArrayList<m>>)a2;
    }
    
    private static void c(final ViewGroup viewGroup, final m m) {
        if (m != null && viewGroup != null) {
            final a a = new a(m, viewGroup);
            viewGroup.addOnAttachStateChangeListener((View$OnAttachStateChangeListener)a);
            viewGroup.getViewTreeObserver().addOnPreDrawListener((ViewTreeObserver$OnPreDrawListener)a);
        }
    }
    
    private static void d(final ViewGroup viewGroup, final m m) {
        final ArrayList list = ((g<K, ArrayList>)b()).get(viewGroup);
        if (list != null && list.size() > 0) {
            final Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((m)iterator.next()).e0((View)viewGroup);
            }
        }
        if (m != null) {
            m.r(viewGroup, true);
        }
        final l b = l.b(viewGroup);
        if (b != null) {
            b.a();
        }
    }
    
    private static class a implements ViewTreeObserver$OnPreDrawListener, View$OnAttachStateChangeListener
    {
        m b;
        ViewGroup c;
        
        a(final m b, final ViewGroup c) {
            this.b = b;
            this.c = c;
        }
        
        private void a() {
            this.c.getViewTreeObserver().removeOnPreDrawListener((ViewTreeObserver$OnPreDrawListener)this);
            this.c.removeOnAttachStateChangeListener((View$OnAttachStateChangeListener)this);
        }
        
        public boolean onPreDraw() {
            this.a();
            if (!o.c.remove((Object)this.c)) {
                return true;
            }
            final a.d.a<ViewGroup, ArrayList<m>> b = o.b();
            final ArrayList list = ((g<K, ArrayList>)b).get(this.c);
            ArrayList list2 = null;
            ArrayList list3;
            if (list == null) {
                list3 = new ArrayList();
                ((g<ViewGroup, ArrayList<m>>)b).put(this.c, (ArrayList<m>)list3);
            }
            else {
                list3 = list;
                if (list.size() > 0) {
                    list2 = new ArrayList((Collection)list);
                    list3 = list;
                }
            }
            list3.add((Object)this.b);
            this.b.a((m.f)new o$a$a(this, (a.d.a)b));
            this.b.r(this.c, false);
            if (list2 != null) {
                final Iterator iterator = list2.iterator();
                while (iterator.hasNext()) {
                    ((m)iterator.next()).i0((View)this.c);
                }
            }
            this.b.f0(this.c);
            return true;
        }
        
        public void onViewAttachedToWindow(final View view) {
        }
        
        public void onViewDetachedFromWindow(final View view) {
            this.a();
            o.c.remove((Object)this.c);
            final ArrayList list = ((g<K, ArrayList>)o.b()).get(this.c);
            if (list != null && list.size() > 0) {
                final Iterator iterator = list.iterator();
                while (iterator.hasNext()) {
                    ((m)iterator.next()).i0((View)this.c);
                }
            }
            this.b.t(true);
        }
    }
}
