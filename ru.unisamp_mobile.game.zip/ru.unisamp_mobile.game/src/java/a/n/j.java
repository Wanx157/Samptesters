package a.n;

public final class j
{
    public static final int action_container = 2131296311;
    public static final int action_divider = 2131296313;
    public static final int action_image = 2131296314;
    public static final int action_text = 2131296320;
    public static final int actions = 2131296321;
    public static final int async = 2131296333;
    public static final int blocking = 2131296343;
    public static final int chronometer = 2131296369;
    public static final int forever = 2131296464;
    public static final int ghost_view = 2131296469;
    public static final int ghost_view_holder = 2131296470;
    public static final int icon = 2131296488;
    public static final int icon_group = 2131296489;
    public static final int info = 2131296496;
    public static final int italic = 2131296502;
    public static final int line1 = 2131296524;
    public static final int line3 = 2131296525;
    public static final int normal = 2131296605;
    public static final int notification_background = 2131296606;
    public static final int notification_main_column = 2131296607;
    public static final int notification_main_column_container = 2131296608;
    public static final int parent_matrix = 2131296620;
    public static final int right_icon = 2131296650;
    public static final int right_side = 2131296651;
    public static final int save_non_transition_alpha = 2131296661;
    public static final int save_overlay_view = 2131296662;
    public static final int tag_transition_group = 2131296748;
    public static final int tag_unhandled_key_event_manager = 2131296749;
    public static final int tag_unhandled_key_listeners = 2131296750;
    public static final int text = 2131296755;
    public static final int text2 = 2131296756;
    public static final int time = 2131296773;
    public static final int title = 2131296776;
    public static final int transition_current_scene = 2131296785;
    public static final int transition_layout_save = 2131296786;
    public static final int transition_position = 2131296787;
    public static final int transition_scene_layoutid_cache = 2131296788;
    public static final int transition_transform = 2131296789;
}
