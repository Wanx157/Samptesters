package a.n;

import android.view.ViewParent;
import android.graphics.Matrix;
import java.lang.reflect.InvocationTargetException;
import android.annotation.SuppressLint;
import android.util.Log;
import android.view.View;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

class i0
{
    private static Method a;
    private static boolean b;
    private static Field c;
    private static boolean d;
    
    @SuppressLint({ "PrivateApi" })
    private void b() {
        if (!i0.b) {
            try {
                (i0.a = View.class.getDeclaredMethod("setFrame", Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE)).setAccessible(true);
            }
            catch (final NoSuchMethodException ex) {
                Log.i("ViewUtilsBase", "Failed to retrieve setFrame method", (Throwable)ex);
            }
            i0.b = true;
        }
    }
    
    public void a(final View view) {
        if (view.getVisibility() == 0) {
            view.setTag(j.save_non_transition_alpha, (Object)null);
        }
    }
    
    public float c(final View view) {
        final Float n = (Float)view.getTag(j.save_non_transition_alpha);
        float alpha = view.getAlpha();
        if (n != null) {
            alpha /= n;
        }
        return alpha;
    }
    
    public void d(final View view) {
        if (view.getTag(j.save_non_transition_alpha) == null) {
            view.setTag(j.save_non_transition_alpha, (Object)view.getAlpha());
        }
    }
    
    public void e(final View view, final int n, final int n2, final int n3, final int n4) {
        this.b();
        final Method a = i0.a;
        if (a == null) {
            goto Label_0071;
        }
        try {
            a.invoke((Object)view, new Object[] { n, n2, n3, n4 });
            goto Label_0071;
        }
        catch (final InvocationTargetException ex) {
            throw new RuntimeException(ex.getCause());
        }
        catch (final IllegalAccessException ex2) {
            goto Label_0071;
        }
    }
    
    public void f(final View view, final float alpha) {
        final Float n = (Float)view.getTag(j.save_non_transition_alpha);
        if (n != null) {
            view.setAlpha(n * alpha);
        }
        else {
            view.setAlpha(alpha);
        }
    }
    
    public void g(final View view, final int n) {
        if (!i0.d) {
            try {
                (i0.c = View.class.getDeclaredField("mViewFlags")).setAccessible(true);
            }
            catch (final NoSuchFieldException ex) {
                Log.i("ViewUtilsBase", "fetchViewFlagsField: ");
            }
            i0.d = true;
        }
        final Field c = i0.c;
        if (c == null) {
            return;
        }
        try {
            i0.c.setInt((Object)view, n | (c.getInt((Object)view) & 0xFFFFFFF3));
        }
        catch (final IllegalAccessException ex2) {}
    }
    
    public void h(final View view, final Matrix matrix) {
        final ViewParent parent = view.getParent();
        if (parent instanceof View) {
            final View view2 = (View)parent;
            this.h(view2, matrix);
            matrix.preTranslate((float)(-view2.getScrollX()), (float)(-view2.getScrollY()));
        }
        matrix.preTranslate((float)view.getLeft(), (float)view.getTop());
        final Matrix matrix2 = view.getMatrix();
        if (!matrix2.isIdentity()) {
            matrix.preConcat(matrix2);
        }
    }
    
    public void i(final View view, final Matrix matrix) {
        final ViewParent parent = view.getParent();
        if (parent instanceof View) {
            final View view2 = (View)parent;
            this.i(view2, matrix);
            matrix.postTranslate((float)view2.getScrollX(), (float)view2.getScrollY());
        }
        matrix.postTranslate((float)(-view.getLeft()), (float)(-view.getTop()));
        final Matrix matrix2 = view.getMatrix();
        if (!matrix2.isIdentity()) {
            final Matrix matrix3 = new Matrix();
            if (matrix2.invert(matrix3)) {
                matrix.postConcat(matrix3);
            }
        }
    }
}
