package a.n;

import android.annotation.SuppressLint;
import android.view.View;

class f0 extends e0
{
    private static boolean h = true;
    
    @SuppressLint({ "NewApi" })
    public void e(final View view, final int n, final int n2, final int n3, final int n4) {
        if (f0.h) {
            try {
                view.setLeftTopRightBottom(n, n2, n3, n4);
            }
            catch (final NoSuchMethodError noSuchMethodError) {
                f0.h = false;
            }
        }
    }
}
