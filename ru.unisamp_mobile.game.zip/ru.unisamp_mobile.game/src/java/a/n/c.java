package a.n;

import android.graphics.Path;
import java.util.Map;
import android.animation.PropertyValuesHolder;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.Bitmap$Config;
import android.animation.TypeEvaluator;
import android.animation.ObjectAnimator;
import android.animation.Animator$AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.Animator;
import android.view.ViewGroup;
import android.graphics.Rect;
import a.g.l.t;
import android.view.View;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.util.Property;

public class c extends m
{
    private static final String[] N;
    private static final Property<Drawable, PointF> O;
    private static final Property<c.c$k, PointF> P;
    private static final Property<c.c$k, PointF> Q;
    private static final Property<View, PointF> R;
    private static final Property<View, PointF> S;
    private static final Property<View, PointF> T;
    private static k U;
    private int[] K;
    private boolean L;
    private boolean M;
    
    static {
        N = new String[] { "android:changeBounds:bounds", "android:changeBounds:clip", "android:changeBounds:parent", "android:changeBounds:windowX", "android:changeBounds:windowY" };
        O = (Property)new c$b((Class)PointF.class, "boundsOrigin");
        P = (Property)new c$c((Class)PointF.class, "topLeft");
        Q = (Property)new c$d((Class)PointF.class, "bottomRight");
        R = (Property)new c$e((Class)PointF.class, "bottomRight");
        S = (Property)new c$f((Class)PointF.class, "topLeft");
        T = (Property)new c$g((Class)PointF.class, "position");
        c.U = new k();
    }
    
    public c() {
        this.K = new int[2];
        this.L = false;
        this.M = false;
    }
    
    private void t0(final s s) {
        final View b = s.b;
        if (t.Q(b) || b.getWidth() != 0 || b.getHeight() != 0) {
            s.a.put((Object)"android:changeBounds:bounds", (Object)new Rect(b.getLeft(), b.getTop(), b.getRight(), b.getBottom()));
            s.a.put((Object)"android:changeBounds:parent", (Object)s.b.getParent());
            if (this.M) {
                s.b.getLocationInWindow(this.K);
                s.a.put((Object)"android:changeBounds:windowX", (Object)this.K[0]);
                s.a.put((Object)"android:changeBounds:windowY", (Object)this.K[1]);
            }
            if (this.L) {
                s.a.put((Object)"android:changeBounds:clip", (Object)t.u(b));
            }
        }
    }
    
    private boolean u0(final View view, final View view2) {
        final boolean m = this.M;
        boolean b = true;
        if (m) {
            final s e = this.E(view, true);
            b = (((e != null) ? (view2 == e.b) : (view == view2)) && b);
        }
        return b;
    }
    
    public String[] U() {
        return c.N;
    }
    
    public void h(final s s) {
        this.t0(s);
    }
    
    public void p(final s s) {
        this.t0(s);
    }
    
    public Animator w(final ViewGroup viewGroup, final s s, final s s2) {
        if (s == null || s2 == null) {
            return null;
        }
        final Map a = s.a;
        final Map a2 = s2.a;
        final ViewGroup viewGroup2 = (ViewGroup)a.get((Object)"android:changeBounds:parent");
        final ViewGroup viewGroup3 = (ViewGroup)a2.get((Object)"android:changeBounds:parent");
        if (viewGroup2 != null && viewGroup3 != null) {
            final View b = s2.b;
            if (this.u0((View)viewGroup2, (View)viewGroup3)) {
                final Rect rect = (Rect)s.a.get((Object)"android:changeBounds:bounds");
                final Rect rect2 = (Rect)s2.a.get((Object)"android:changeBounds:bounds");
                final int left = rect.left;
                final int left2 = rect2.left;
                final int top = rect.top;
                final int top2 = rect2.top;
                final int right = rect.right;
                final int right2 = rect2.right;
                final int bottom = rect.bottom;
                final int bottom2 = rect2.bottom;
                final int n = right - left;
                final int n2 = bottom - top;
                final int n3 = right2 - left2;
                final int n4 = bottom2 - top2;
                Object o = s.a.get((Object)"android:changeBounds:clip");
                final Rect rect3 = (Rect)s2.a.get((Object)"android:changeBounds:clip");
                int n6 = 0;
                Label_0299: {
                    if ((n != 0 && n2 != 0) || (n3 != 0 && n4 != 0)) {
                        int n5;
                        if (left == left2 && top == top2) {
                            n5 = 0;
                        }
                        else {
                            n5 = 1;
                        }
                        if (right == right2) {
                            n6 = n5;
                            if (bottom == bottom2) {
                                break Label_0299;
                            }
                        }
                        n6 = n5 + 1;
                    }
                    else {
                        n6 = 0;
                    }
                }
                int n7 = 0;
                Label_0335: {
                    if (o == null || ((Rect)o).equals(rect3)) {
                        n7 = n6;
                        if (o != null) {
                            break Label_0335;
                        }
                        n7 = n6;
                        if (rect3 == null) {
                            break Label_0335;
                        }
                    }
                    n7 = n6 + 1;
                }
                if (n7 > 0) {
                    Object o2 = null;
                    Label_0796: {
                        if (!this.L) {
                            c0.f(b, left, top, right, bottom);
                            Path path;
                            Property<View, PointF> property;
                            if (n7 == 2) {
                                if (n != n3 || n2 != n4) {
                                    final c.c$k c$k = new c.c$k(b);
                                    final ObjectAnimator a3 = f.a((Object)c$k, (Property)c.P, this.G().a((float)left, (float)top, (float)left2, (float)top2));
                                    final ObjectAnimator a4 = f.a((Object)c$k, (Property)c.Q, this.G().a((float)right, (float)bottom, (float)right2, (float)bottom2));
                                    o2 = new AnimatorSet();
                                    ((AnimatorSet)o2).playTogether(new Animator[] { (Animator)a3, (Animator)a4 });
                                    ((AnimatorSet)o2).addListener((Animator$AnimatorListener)new c$h(this, c$k));
                                    break Label_0796;
                                }
                                path = this.G().a((float)left, (float)top, (float)left2, (float)top2);
                                property = c.T;
                            }
                            else if (left == left2 && top == top2) {
                                path = this.G().a((float)right, (float)bottom, (float)right2, (float)bottom2);
                                property = c.R;
                            }
                            else {
                                path = this.G().a((float)left, (float)top, (float)left2, (float)top2);
                                property = c.S;
                            }
                            o2 = f.a((Object)b, (Property)property, path);
                        }
                        else {
                            c0.f(b, left, top, Math.max(n, n3) + left, Math.max(n2, n4) + top);
                            Object a5;
                            if (left == left2 && top == top2) {
                                a5 = null;
                            }
                            else {
                                a5 = f.a((Object)b, (Property)c.T, this.G().a((float)left, (float)top, (float)left2, (float)top2));
                            }
                            if (o == null) {
                                o = new Rect(0, 0, n, n2);
                            }
                            Rect rect4;
                            if (rect3 == null) {
                                rect4 = new Rect(0, 0, n3, n4);
                            }
                            else {
                                rect4 = rect3;
                            }
                            ObjectAnimator ofObject;
                            if (!((Rect)o).equals(rect4)) {
                                t.q0(b, (Rect)o);
                                ofObject = ObjectAnimator.ofObject((Object)b, "clipBounds", (TypeEvaluator)c.U, new Object[] { o, rect4 });
                                ofObject.addListener((Animator$AnimatorListener)new c$i(this, b, rect3, left2, top2, right2, bottom2));
                            }
                            else {
                                ofObject = null;
                            }
                            o2 = r.c((Animator)a5, (Animator)ofObject);
                        }
                    }
                    if (b.getParent() instanceof ViewGroup) {
                        final ViewGroup viewGroup4 = (ViewGroup)b.getParent();
                        x.c(viewGroup4, true);
                        this.a((m$f)new n(this, viewGroup4) {
                            boolean a = false;
                            final ViewGroup b;
                            
                            @Override
                            public void a(final m m) {
                                x.c(this.b, false);
                            }
                            
                            @Override
                            public void b(final m m) {
                                x.c(this.b, true);
                            }
                            
                            @Override
                            public void d(final m m) {
                                x.c(this.b, false);
                                this.a = true;
                            }
                            
                            public void e(final m m) {
                                if (!this.a) {
                                    x.c(this.b, false);
                                }
                                m.g0((m$f)this);
                            }
                        });
                    }
                    return (Animator)o2;
                }
            }
            else {
                final int intValue = (int)s.a.get((Object)"android:changeBounds:windowX");
                final int intValue2 = (int)s.a.get((Object)"android:changeBounds:windowY");
                final int intValue3 = (int)s2.a.get((Object)"android:changeBounds:windowX");
                final int intValue4 = (int)s2.a.get((Object)"android:changeBounds:windowY");
                if (intValue != intValue3 || intValue2 != intValue4) {
                    viewGroup.getLocationInWindow(this.K);
                    final Bitmap bitmap = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap$Config.ARGB_8888);
                    b.draw(new Canvas(bitmap));
                    final BitmapDrawable bitmapDrawable = new BitmapDrawable(bitmap);
                    final float c = c0.c(b);
                    c0.g(b, 0.0f);
                    c0.b((View)viewGroup).b((Drawable)bitmapDrawable);
                    final g g = this.G();
                    final int[] k = this.K;
                    final ObjectAnimator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder((Object)bitmapDrawable, new PropertyValuesHolder[] { i.a((Property)a.n.c.O, g.a((float)(intValue - k[0]), (float)(intValue2 - k[1]), (float)(intValue3 - k[0]), (float)(intValue4 - k[1]))) });
                    ofPropertyValuesHolder.addListener((Animator$AnimatorListener)new c$a(this, viewGroup, bitmapDrawable, b, c));
                    return (Animator)ofPropertyValuesHolder;
                }
            }
            return null;
        }
        return null;
    }
}
