package a.n;

import android.graphics.Rect;
import java.util.List;
import java.util.Collection;
import android.view.ViewGroup;
import java.util.ArrayList;
import android.view.View;
import android.annotation.SuppressLint;
import androidx.fragment.app.r;

@SuppressLint({ "RestrictedApi" })
public class e extends r
{
    private static boolean B(final m m) {
        return !r.l(m.N()) || !r.l(m.P()) || !r.l(m.Q());
    }
    
    public Object A(final Object o) {
        if (o == null) {
            return null;
        }
        final q q = new q();
        q.v0((m)o);
        return q;
    }
    
    public void a(final Object o, final View view) {
        if (o != null) {
            ((m)o).b(view);
        }
    }
    
    public void b(final Object o, final ArrayList<View> list) {
        final m m = (m)o;
        if (m == null) {
            return;
        }
        final boolean b = m instanceof q;
        final int n = 0;
        int i = 0;
        if (b) {
            for (q q = (q)m; i < q.y0(); ++i) {
                this.b(q.x0(i), list);
            }
        }
        else if (!B(m) && r.l(m.T())) {
            for (int size = list.size(), j = n; j < size; ++j) {
                m.b((View)list.get(j));
            }
        }
    }
    
    public void c(final ViewGroup viewGroup, final Object o) {
        o.a(viewGroup, (m)o);
    }
    
    public boolean e(final Object o) {
        return o instanceof m;
    }
    
    public Object g(final Object o) {
        m v;
        if (o != null) {
            v = ((m)o).v();
        }
        else {
            v = null;
        }
        return v;
    }
    
    public Object m(final Object o, Object o2, final Object o3) {
        m m = (m)o;
        final m i = (m)o2;
        final m j = (m)o3;
        if (m != null && i != null) {
            final q q = new q();
            q.v0(m);
            q.v0(i);
            q.D0(1);
            m = q;
        }
        else if (m == null) {
            if (i != null) {
                m = i;
            }
            else {
                m = null;
            }
        }
        if (j != null) {
            o2 = new q();
            if (m != null) {
                ((q)o2).v0(m);
            }
            ((q)o2).v0(j);
            return o2;
        }
        return m;
    }
    
    public Object n(final Object o, final Object o2, final Object o3) {
        final q q = new q();
        if (o != null) {
            q.v0((m)o);
        }
        if (o2 != null) {
            q.v0((m)o2);
        }
        if (o3 != null) {
            q.v0((m)o3);
        }
        return q;
    }
    
    public void p(final Object o, final View view) {
        if (o != null) {
            ((m)o).h0(view);
        }
    }
    
    public void q(final Object o, final ArrayList<View> list, final ArrayList<View> list2) {
        final m m = (m)o;
        final boolean b = m instanceof q;
        int i = 0;
        int j = 0;
        if (b) {
            for (q q = (q)m; j < q.y0(); ++j) {
                this.q(q.x0(j), list, list2);
            }
        }
        else if (!B(m)) {
            final List t = m.T();
            if (t.size() == list.size() && t.containsAll((Collection)list)) {
                int size;
                if (list2 == null) {
                    size = 0;
                }
                else {
                    size = list2.size();
                }
                while (i < size) {
                    m.b((View)list2.get(i));
                    ++i;
                }
                for (int k = list.size() - 1; k >= 0; --k) {
                    m.h0((View)list.get(k));
                }
            }
        }
    }
    
    public void r(final Object o, final View view, final ArrayList<View> list) {
        ((m)o).a((m$f)new m$f(this, view, list) {
            final View a;
            final ArrayList b;
            
            public void a(final m m) {
            }
            
            public void b(final m m) {
            }
            
            public void c(final m m) {
            }
            
            public void d(final m m) {
            }
            
            public void e(final m m) {
                m.g0((m$f)this);
                this.a.setVisibility(8);
                for (int size = this.b.size(), i = 0; i < size; ++i) {
                    ((View)this.b.get(i)).setVisibility(0);
                }
            }
        });
    }
    
    public void t(final Object o, final Object o2, final ArrayList<View> list, final Object o3, final ArrayList<View> list2, final Object o4, final ArrayList<View> list3) {
        ((m)o).a((m$f)new n(this, o2, list, o3, list2, o4, list3) {
            final Object a;
            final ArrayList b;
            final Object c;
            final ArrayList d;
            final Object e;
            final ArrayList f;
            final e g;
            
            @Override
            public void c(final m m) {
                final Object a = this.a;
                if (a != null) {
                    this.g.q(a, (ArrayList<View>)this.b, null);
                }
                final Object c = this.c;
                if (c != null) {
                    this.g.q(c, (ArrayList<View>)this.d, null);
                }
                final Object e = this.e;
                if (e != null) {
                    this.g.q(e, (ArrayList<View>)this.f, null);
                }
            }
            
            public void e(final m m) {
                m.g0((m$f)this);
            }
        });
    }
    
    public void u(final Object o, final Rect rect) {
        if (o != null) {
            ((m)o).m0((m$e)new m$e(this, rect) {
                final Rect a;
            });
        }
    }
    
    public void v(final Object o, final View view) {
        if (view != null) {
            final m m = (m)o;
            final Rect rect = new Rect();
            this.k(view, rect);
            m.m0((m$e)new m$e(this, rect) {
                final Rect a;
            });
        }
    }
    
    public void y(final Object o, final View view, final ArrayList<View> list) {
        final q q = (q)o;
        final List t = q.T();
        t.clear();
        for (int size = list.size(), i = 0; i < size; ++i) {
            r.d(t, (View)list.get(i));
        }
        t.add((Object)view);
        list.add((Object)view);
        this.b(q, list);
    }
    
    public void z(final Object o, final ArrayList<View> list, final ArrayList<View> list2) {
        final q q = (q)o;
        if (q != null) {
            q.T().clear();
            q.T().addAll((Collection)list2);
            this.q(q, list, list2);
        }
    }
}
