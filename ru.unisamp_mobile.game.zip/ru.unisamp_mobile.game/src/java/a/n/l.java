package a.n;

import android.view.ViewGroup;

public class l
{
    private ViewGroup a;
    private Runnable b;
    
    public static l b(final ViewGroup viewGroup) {
        return (l)viewGroup.getTag(j.transition_current_scene);
    }
    
    static void c(final ViewGroup viewGroup, final l l) {
        viewGroup.setTag(j.transition_current_scene, (Object)l);
    }
    
    public void a() {
        if (b(this.a) == this) {
            final Runnable b = this.b;
            if (b != null) {
                b.run();
            }
        }
    }
}
