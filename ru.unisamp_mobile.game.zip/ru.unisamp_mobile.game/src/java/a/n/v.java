package a.n;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroupOverlay;

class v implements w
{
    private final ViewGroupOverlay a;
    
    v(final ViewGroup viewGroup) {
        this.a = viewGroup.getOverlay();
    }
    
    @Override
    public void a(final View view) {
        this.a.add(view);
    }
    
    public void b(final Drawable drawable) {
        this.a.add(drawable);
    }
    
    @Override
    public void c(final View view) {
        this.a.remove(view);
    }
    
    public void d(final Drawable drawable) {
        this.a.remove(drawable);
    }
}
