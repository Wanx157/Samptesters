package a.n;

import android.graphics.Matrix;
import a.g.l.t;
import android.graphics.Rect;
import android.os.Build$VERSION;
import android.view.View;
import android.util.Property;

class c0
{
    private static final i0 a;
    static final Property<View, Float> b;
    
    static {
        final int sdk_INT = Build$VERSION.SDK_INT;
        Object a2;
        if (sdk_INT >= 29) {
            a2 = new h0();
        }
        else if (sdk_INT >= 23) {
            a2 = new g0();
        }
        else if (sdk_INT >= 22) {
            a2 = new f0();
        }
        else if (sdk_INT >= 21) {
            a2 = new e0();
        }
        else if (sdk_INT >= 19) {
            a2 = new d0();
        }
        else {
            a2 = new i0();
        }
        a = (i0)a2;
        b = new Property<View, Float>(Float.class, "translationAlpha") {
            public Float a(final View view) {
                return c0.c(view);
            }
            
            public void b(final View view, final Float n) {
                c0.g(view, n);
            }
        };
        new Property<View, Rect>(Rect.class, "clipBounds") {
            public Rect a(final View view) {
                return t.u(view);
            }
            
            public void b(final View view, final Rect rect) {
                t.q0(view, rect);
            }
        };
    }
    
    static void a(final View view) {
        c0.a.a(view);
    }
    
    static b0 b(final View view) {
        if (Build$VERSION.SDK_INT >= 18) {
            return (b0)new a0(view);
        }
        return (b0)z.e(view);
    }
    
    static float c(final View view) {
        return c0.a.c(view);
    }
    
    static m0 d(final View view) {
        if (Build$VERSION.SDK_INT >= 18) {
            return (m0)new l0(view);
        }
        return (m0)new k0(view.getWindowToken());
    }
    
    static void e(final View view) {
        c0.a.d(view);
    }
    
    static void f(final View view, final int n, final int n2, final int n3, final int n4) {
        c0.a.e(view, n, n2, n3, n4);
    }
    
    static void g(final View view, final float n) {
        c0.a.f(view, n);
    }
    
    static void h(final View view, final int n) {
        c0.a.g(view, n);
    }
    
    static void i(final View view, final Matrix matrix) {
        c0.a.h(view, matrix);
    }
    
    static void j(final View view, final Matrix matrix) {
        c0.a.i(view, matrix);
    }
}
