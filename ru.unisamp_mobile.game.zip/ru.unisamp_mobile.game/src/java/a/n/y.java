package a.n;

import android.animation.Animator;
import android.view.ViewGroup;
import java.lang.reflect.InvocationTargetException;
import android.util.Log;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import android.animation.LayoutTransition;

class y
{
    private static LayoutTransition a;
    private static Field b;
    private static boolean c;
    private static Method d;
    private static boolean e;
    
    private static void a(final LayoutTransition layoutTransition) {
        if (!y.e) {
            try {
                (y.d = LayoutTransition.class.getDeclaredMethod("cancel", (Class<?>[])new Class[0])).setAccessible(true);
            }
            catch (final NoSuchMethodException ex) {
                Log.i("ViewGroupUtilsApi14", "Failed to access cancel method by reflection");
            }
            y.e = true;
        }
        final Method d = y.d;
        if (d != null) {
            try {
                d.invoke((Object)layoutTransition, new Object[0]);
            }
            catch (final InvocationTargetException ex2) {
                Log.i("ViewGroupUtilsApi14", "Failed to invoke cancel method by reflection");
            }
            catch (final IllegalAccessException ex3) {
                Log.i("ViewGroupUtilsApi14", "Failed to access cancel method by reflection");
            }
        }
    }
    
    static void b(final ViewGroup viewGroup, boolean boolean1) {
        final LayoutTransition a = y.a;
        final boolean b = false;
        final boolean b2 = false;
        if (a == null) {
            (y.a = new LayoutTransition() {
                public boolean isChangingLayout() {
                    return true;
                }
            }).setAnimator(2, (Animator)null);
            y.a.setAnimator(0, (Animator)null);
            y.a.setAnimator(1, (Animator)null);
            y.a.setAnimator(3, (Animator)null);
            y.a.setAnimator(4, (Animator)null);
        }
    Label_0216_Outer:
        while (true) {
            Field b3 = null;
            Block_7: {
                LayoutTransition a2;
                if (boolean1) {
                    final LayoutTransition layoutTransition = viewGroup.getLayoutTransition();
                    if (layoutTransition != null) {
                        if (layoutTransition.isRunning()) {
                            a(layoutTransition);
                        }
                        if (layoutTransition != y.a) {
                            viewGroup.setTag(j.transition_layout_save, (Object)layoutTransition);
                        }
                    }
                    a2 = y.a;
                }
                else {
                    viewGroup.setLayoutTransition((LayoutTransition)null);
                    if (!y.c) {
                        try {
                            (y.b = ViewGroup.class.getDeclaredField("mLayoutSuppressed")).setAccessible(true);
                        }
                        catch (final NoSuchFieldException ex) {
                            Log.i("ViewGroupUtilsApi14", "Failed to access mLayoutSuppressed field by reflection");
                        }
                        y.c = true;
                    }
                    b3 = y.b;
                    boolean1 = b;
                    if (b3 != null) {
                        break Block_7;
                    }
                    break Label_0216_Outer;
                }
                viewGroup.setLayoutTransition(a2);
                return;
            }
            while (true) {
                try {
                    boolean1 = b3.getBoolean((Object)viewGroup);
                    if (boolean1) {
                        try {
                            y.b.setBoolean((Object)viewGroup, false);
                        }
                        catch (final IllegalAccessException ex2) {
                            break Label_0216;
                        }
                        break Label_0216_Outer;
                        Log.i("ViewGroupUtilsApi14", "Failed to get mLayoutSuppressed field by reflection");
                    }
                    if (boolean1) {
                        viewGroup.requestLayout();
                    }
                    final LayoutTransition a2 = (LayoutTransition)viewGroup.getTag(j.transition_layout_save);
                    if (a2 != null) {
                        viewGroup.setTag(j.transition_layout_save, (Object)null);
                        continue Label_0216_Outer;
                    }
                }
                catch (final IllegalAccessException ex3) {
                    boolean1 = b2;
                    continue;
                }
                break;
            }
            break;
        }
    }
}
