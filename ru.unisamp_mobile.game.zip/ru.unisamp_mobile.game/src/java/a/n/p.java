package a.n;

import android.view.ViewGroup;

public abstract class p
{
    public abstract void a(final s p0);
    
    public abstract String[] b();
    
    public abstract long c(final ViewGroup p0, final m p1, final s p2, final s p3);
}
