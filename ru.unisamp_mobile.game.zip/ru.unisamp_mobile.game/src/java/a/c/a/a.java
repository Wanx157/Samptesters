package a.c.a;

import android.view.View$MeasureSpec;
import android.content.res.ColorStateList;
import android.os.Build$VERSION;
import android.graphics.Rect;
import android.widget.FrameLayout;

public class a extends FrameLayout
{
    private static final f f;
    private boolean b;
    private boolean c;
    final Rect d;
    private final e e;
    
    static {
        final int sdk_INT = Build$VERSION.SDK_INT;
        Object f2;
        if (sdk_INT >= 21) {
            f2 = new c();
        }
        else if (sdk_INT >= 17) {
            f2 = new b();
        }
        else {
            f2 = new d();
        }
        (f = (f)f2).m();
    }
    
    public ColorStateList getCardBackgroundColor() {
        return a.f.f(this.e);
    }
    
    public float getCardElevation() {
        return a.f.k(this.e);
    }
    
    public int getContentPaddingBottom() {
        return this.d.bottom;
    }
    
    public int getContentPaddingLeft() {
        return this.d.left;
    }
    
    public int getContentPaddingRight() {
        return this.d.right;
    }
    
    public int getContentPaddingTop() {
        return this.d.top;
    }
    
    public float getMaxCardElevation() {
        return a.f.a(this.e);
    }
    
    public boolean getPreventCornerOverlap() {
        return this.c;
    }
    
    public float getRadius() {
        return a.f.b(this.e);
    }
    
    public boolean getUseCompatPadding() {
        return this.b;
    }
    
    protected void onMeasure(int measureSpec, final int n) {
        int n2 = measureSpec;
        int measureSpec2 = n;
        if (!(a.f instanceof c)) {
            final int mode = View$MeasureSpec.getMode(measureSpec);
            if (mode == Integer.MIN_VALUE || mode == 1073741824) {
                measureSpec = View$MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil((double)a.f.d(this.e)), View$MeasureSpec.getSize(measureSpec)), mode);
            }
            final int mode2 = View$MeasureSpec.getMode(n);
            if (mode2 != Integer.MIN_VALUE && mode2 != 1073741824) {
                n2 = measureSpec;
                measureSpec2 = n;
            }
            else {
                measureSpec2 = View$MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil((double)a.f.c(this.e)), View$MeasureSpec.getSize(n)), mode2);
                n2 = measureSpec;
            }
        }
        super.onMeasure(n2, measureSpec2);
    }
    
    public void setCardBackgroundColor(final int n) {
        a.f.j(this.e, ColorStateList.valueOf(n));
    }
    
    public void setCardBackgroundColor(final ColorStateList list) {
        a.f.j(this.e, list);
    }
    
    public void setCardElevation(final float n) {
        a.f.g(this.e, n);
    }
    
    public void setMaxCardElevation(final float n) {
        a.f.l(this.e, n);
    }
    
    public void setMinimumHeight(final int minimumHeight) {
        super.setMinimumHeight(minimumHeight);
    }
    
    public void setMinimumWidth(final int minimumWidth) {
        super.setMinimumWidth(minimumWidth);
    }
    
    public void setPadding(final int n, final int n2, final int n3, final int n4) {
    }
    
    public void setPaddingRelative(final int n, final int n2, final int n3, final int n4) {
    }
    
    public void setPreventCornerOverlap(final boolean c) {
        if (c != this.c) {
            this.c = c;
            a.f.i(this.e);
        }
    }
    
    public void setRadius(final float n) {
        a.f.h(this.e, n);
    }
    
    public void setUseCompatPadding(final boolean b) {
        if (this.b != b) {
            this.b = b;
            a.f.e(this.e);
        }
    }
}
