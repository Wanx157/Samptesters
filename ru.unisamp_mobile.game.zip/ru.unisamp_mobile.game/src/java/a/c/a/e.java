package a.c.a;

import android.graphics.drawable.Drawable;
import android.view.View;

interface e
{
    void a(final int p0, final int p1, final int p2, final int p3);
    
    View b();
    
    boolean c();
    
    Drawable d();
    
    void e(final int p0, final int p1);
    
    boolean f();
}
