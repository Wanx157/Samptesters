package a.c.a;

import android.content.res.ColorStateList;

class c implements f
{
    private g n(final e e) {
        return (g)e.d();
    }
    
    public float a(final e e) {
        return this.n(e).c();
    }
    
    public float b(final e e) {
        return this.n(e).d();
    }
    
    public float c(final e e) {
        return this.b(e) * 2.0f;
    }
    
    public float d(final e e) {
        return this.b(e) * 2.0f;
    }
    
    public void e(final e e) {
        this.l(e, this.a(e));
    }
    
    public ColorStateList f(final e e) {
        return this.n(e).b();
    }
    
    public void g(final e e, final float elevation) {
        e.b().setElevation(elevation);
    }
    
    public void h(final e e, final float n) {
        this.n(e).h(n);
    }
    
    public void i(final e e) {
        this.l(e, this.a(e));
    }
    
    public void j(final e e, final ColorStateList list) {
        this.n(e).f(list);
    }
    
    public float k(final e e) {
        return e.b().getElevation();
    }
    
    public void l(final e e, final float n) {
        this.n(e).g(n, e.c(), e.f());
        this.o(e);
    }
    
    public void m() {
    }
    
    public void o(final e e) {
        if (!e.c()) {
            e.a(0, 0, 0, 0);
            return;
        }
        final float a = this.a(e);
        final float b = this.b(e);
        final int n = (int)Math.ceil((double)h.c(a, b, e.f()));
        final int n2 = (int)Math.ceil((double)h.d(a, b, e.f()));
        e.a(n, n2, n, n2);
    }
}
