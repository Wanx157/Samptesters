package a.c.a;

import android.content.res.ColorStateList;

interface f
{
    float a(final e p0);
    
    float b(final e p0);
    
    float c(final e p0);
    
    float d(final e p0);
    
    void e(final e p0);
    
    ColorStateList f(final e p0);
    
    void g(final e p0, final float p1);
    
    void h(final e p0, final float p1);
    
    void i(final e p0);
    
    void j(final e p0, final ColorStateList p1);
    
    float k(final e p0);
    
    void l(final e p0, final float p1);
    
    void m();
}
