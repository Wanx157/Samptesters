package a.c.a;

class b extends d
{
    public void m() {
        h.r = (h$a)new b$a(this);
    }
}
