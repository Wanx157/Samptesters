package a.c.a;

import android.graphics.Rect;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.content.res.ColorStateList;
import android.graphics.RectF;

class d implements f
{
    final RectF a;
    
    d() {
        this.a = new RectF();
    }
    
    private h n(final e e) {
        return (h)e.d();
    }
    
    public float a(final e e) {
        return this.n(e).i();
    }
    
    public float b(final e e) {
        return this.n(e).g();
    }
    
    public float c(final e e) {
        return this.n(e).j();
    }
    
    public float d(final e e) {
        return this.n(e).k();
    }
    
    public void e(final e e) {
    }
    
    public ColorStateList f(final e e) {
        return this.n(e).f();
    }
    
    public void g(final e e, final float n) {
        this.n(e).r(n);
    }
    
    public void h(final e e, final float n) {
        this.n(e).p(n);
        this.o(e);
    }
    
    public void i(final e e) {
        this.n(e).m(e.f());
        this.o(e);
    }
    
    public void j(final e e, final ColorStateList list) {
        this.n(e).o(list);
    }
    
    public float k(final e e) {
        return this.n(e).l();
    }
    
    public void l(final e e, final float n) {
        this.n(e).q(n);
        this.o(e);
    }
    
    public void m() {
        h.r = (h$a)new h$a(this) {
            final d a;
            
            public void a(final Canvas canvas, final RectF rectF, final float n, final Paint paint) {
                final float n2 = 2.0f * n;
                final float n3 = rectF.width() - n2 - 1.0f;
                final float height = rectF.height();
                if (n >= 1.0f) {
                    final float n4 = n + 0.5f;
                    final RectF a = this.a.a;
                    final float n5 = -n4;
                    a.set(n5, n5, n4, n4);
                    final int save = canvas.save();
                    canvas.translate(rectF.left + n4, rectF.top + n4);
                    canvas.drawArc(this.a.a, 180.0f, 90.0f, true, paint);
                    canvas.translate(n3, 0.0f);
                    canvas.rotate(90.0f);
                    canvas.drawArc(this.a.a, 180.0f, 90.0f, true, paint);
                    canvas.translate(height - n2 - 1.0f, 0.0f);
                    canvas.rotate(90.0f);
                    canvas.drawArc(this.a.a, 180.0f, 90.0f, true, paint);
                    canvas.translate(n3, 0.0f);
                    canvas.rotate(90.0f);
                    canvas.drawArc(this.a.a, 180.0f, 90.0f, true, paint);
                    canvas.restoreToCount(save);
                    final float left = rectF.left;
                    final float top = rectF.top;
                    canvas.drawRect(left + n4 - 1.0f, top, rectF.right - n4 + 1.0f, top + n4, paint);
                    final float left2 = rectF.left;
                    final float bottom = rectF.bottom;
                    canvas.drawRect(left2 + n4 - 1.0f, bottom - n4, rectF.right - n4 + 1.0f, bottom, paint);
                }
                canvas.drawRect(rectF.left, rectF.top + n, rectF.right, rectF.bottom - n, paint);
            }
        };
    }
    
    public void o(final e e) {
        final Rect rect = new Rect();
        this.n(e).h(rect);
        e.e((int)Math.ceil((double)this.d(e)), (int)Math.ceil((double)this.c(e)));
        e.a(rect.left, rect.top, rect.right, rect.bottom);
    }
}
