package a.d;

import java.util.Iterator;
import java.util.Collection;
import java.util.Map$Entry;
import java.util.Set;
import java.util.Map;

public class a<K, V> extends g<K, V> implements Map<K, V>
{
    f<K, V> i;
    
    public a() {
    }
    
    public a(final int n) {
        super(n);
    }
    
    public a(final g g) {
        super(g);
    }
    
    private f<K, V> n() {
        if (this.i == null) {
            this.i = new f<K, V>(this) {
                final a d;
                
                protected void a() {
                    this.d.clear();
                }
                
                protected Object b(final int n, final int n2) {
                    return this.d.c[(n << 1) + n2];
                }
                
                protected Map<K, V> c() {
                    return (Map<K, V>)this.d;
                }
                
                protected int d() {
                    return this.d.d;
                }
                
                protected int e(final Object o) {
                    return this.d.f(o);
                }
                
                protected int f(final Object o) {
                    return this.d.h(o);
                }
                
                protected void g(final K k, final V v) {
                    this.d.put((Object)k, (Object)v);
                }
                
                protected void h(final int n) {
                    this.d.k(n);
                }
                
                protected V i(final int n, final V v) {
                    return (V)this.d.l(n, (Object)v);
                }
            };
        }
        return this.i;
    }
    
    public Set<Map$Entry<K, V>> entrySet() {
        return (Set<Map$Entry<K, V>>)this.n().l();
    }
    
    public Set<K> keySet() {
        return (Set<K>)this.n().m();
    }
    
    public boolean o(final Collection<?> collection) {
        return f.p((Map)this, (Collection)collection);
    }
    
    public void putAll(final Map<? extends K, ? extends V> map) {
        this.c(super.d + map.size());
        for (final Map$Entry map$Entry : map.entrySet()) {
            this.put(map$Entry.getKey(), map$Entry.getValue());
        }
    }
    
    public Collection<V> values() {
        return (Collection<V>)this.n().n();
    }
}
