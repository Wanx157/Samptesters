package a.d;

import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.Set;
import java.util.Collection;

public final class b<E> implements Collection<E>, Set<E>
{
    private static final int[] f;
    private static final Object[] g;
    private static Object[] h;
    private static int i;
    private static Object[] j;
    private static int k;
    private int[] b;
    Object[] c;
    int d;
    private f<E, E> e;
    
    static {
        f = new int[0];
        g = new Object[0];
    }
    
    public b() {
        this(0);
    }
    
    public b(final int n) {
        if (n == 0) {
            this.b = a.d.b.f;
            this.c = a.d.b.g;
        }
        else {
            this.c(n);
        }
        this.d = 0;
    }
    
    private void c(final int n) {
        Label_0147: {
            if (n == 8) {
                synchronized (b.class) {
                    if (a.d.b.j != null) {
                        final Object[] j = a.d.b.j;
                        this.c = j;
                        a.d.b.j = (Object[])j[0];
                        this.b = (int[])j[1];
                        j[0] = (j[1] = null);
                        --a.d.b.k;
                        return;
                    }
                    break Label_0147;
                }
            }
            if (n == 4) {
                synchronized (b.class) {
                    if (a.d.b.h != null) {
                        final Object[] h = a.d.b.h;
                        this.c = h;
                        a.d.b.h = (Object[])h[0];
                        this.b = (int[])h[1];
                        h[0] = (h[1] = null);
                        --a.d.b.i;
                        return;
                    }
                }
            }
        }
        this.b = new int[n];
        this.c = new Object[n];
    }
    
    private static void h(final int[] array, final Object[] array2, int i) {
        if (array.length == 8) {
            synchronized (b.class) {
                if (b.k < 10) {
                    array2[0] = b.j;
                    array2[1] = array;
                    --i;
                    while (i >= 2) {
                        array2[i] = null;
                        --i;
                    }
                    b.j = array2;
                    ++b.k;
                }
                return;
            }
        }
        if (array.length == 4) {
            synchronized (b.class) {
                if (b.i < 10) {
                    array2[0] = b.h;
                    array2[1] = array;
                    --i;
                    while (i >= 2) {
                        array2[i] = null;
                        --i;
                    }
                    b.h = array2;
                    ++b.i;
                }
            }
        }
    }
    
    private f<E, E> i() {
        if (this.e == null) {
            this.e = (f<E, E>)new b$a(this);
        }
        return this.e;
    }
    
    private int j(final Object o, final int n) {
        final int d = this.d;
        if (d == 0) {
            return -1;
        }
        int a = a.d.c.a(this.b, d, n);
        if (a < 0) {
            return a;
        }
        if (o.equals(this.c[a])) {
            return a;
        }
        int n2;
        for (n2 = a + 1; n2 < d && this.b[n2] == n; ++n2) {
            if (o.equals(this.c[n2])) {
                return n2;
            }
        }
        --a;
        while (a >= 0 && this.b[a] == n) {
            if (o.equals(this.c[a])) {
                return a;
            }
            --a;
        }
        return ~n2;
    }
    
    private int m() {
        final int d = this.d;
        if (d == 0) {
            return -1;
        }
        final int a = a.d.c.a(this.b, d, 0);
        if (a < 0) {
            return a;
        }
        if (this.c[a] == null) {
            return a;
        }
        int n;
        for (n = a + 1; n < d && this.b[n] == 0; ++n) {
            if (this.c[n] == null) {
                return n;
            }
        }
        for (int n2 = a - 1; n2 >= 0 && this.b[n2] == 0; --n2) {
            if (this.c[n2] == null) {
                return n2;
            }
        }
        return ~n;
    }
    
    public boolean add(final E e) {
        int n;
        int hashCode;
        if (e == null) {
            n = this.m();
            hashCode = 0;
        }
        else {
            hashCode = e.hashCode();
            n = this.j(e, hashCode);
        }
        if (n >= 0) {
            return false;
        }
        final int n2 = ~n;
        final int d = this.d;
        if (d >= this.b.length) {
            int n3 = 4;
            if (d >= 8) {
                n3 = (d >> 1) + d;
            }
            else if (d >= 4) {
                n3 = 8;
            }
            final int[] b = this.b;
            final Object[] c = this.c;
            this.c(n3);
            final int[] b2 = this.b;
            if (b2.length > 0) {
                System.arraycopy((Object)b, 0, (Object)b2, 0, b.length);
                System.arraycopy((Object)c, 0, (Object)this.c, 0, c.length);
            }
            h(b, c, this.d);
        }
        final int d2 = this.d;
        if (n2 < d2) {
            final int[] b3 = this.b;
            final int n4 = n2 + 1;
            System.arraycopy((Object)b3, n2, (Object)b3, n4, d2 - n2);
            final Object[] c2 = this.c;
            System.arraycopy((Object)c2, n2, (Object)c2, n4, this.d - n2);
        }
        this.b[n2] = hashCode;
        this.c[n2] = e;
        ++this.d;
        return true;
    }
    
    public boolean addAll(final Collection<? extends E> collection) {
        this.d(this.d + collection.size());
        final Iterator iterator = collection.iterator();
        boolean b = false;
        while (iterator.hasNext()) {
            b |= this.add(iterator.next());
        }
        return b;
    }
    
    public void clear() {
        final int d = this.d;
        if (d != 0) {
            h(this.b, this.c, d);
            this.b = a.d.b.f;
            this.c = a.d.b.g;
            this.d = 0;
        }
    }
    
    public boolean contains(final Object o) {
        return this.indexOf(o) >= 0;
    }
    
    public boolean containsAll(final Collection<?> collection) {
        final Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            if (!this.contains(iterator.next())) {
                return false;
            }
        }
        return true;
    }
    
    public void d(int d) {
        final int[] b = this.b;
        if (b.length < d) {
            final Object[] c = this.c;
            this.c(d);
            d = this.d;
            if (d > 0) {
                System.arraycopy((Object)b, 0, (Object)this.b, 0, d);
                System.arraycopy((Object)c, 0, (Object)this.c, 0, this.d);
            }
            h(b, c, this.d);
        }
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Set)) {
            return false;
        }
        final Set set = (Set)o;
        if (this.size() != set.size()) {
            return false;
        }
        int i = 0;
        try {
            while (i < this.d) {
                if (!set.contains((Object)this.o(i))) {
                    return false;
                }
                ++i;
            }
            return true;
        }
        catch (final NullPointerException | ClassCastException ex) {
            return false;
        }
    }
    
    @Override
    public int hashCode() {
        final int[] b = this.b;
        final int d = this.d;
        int i = 0;
        int n = 0;
        while (i < d) {
            n += b[i];
            ++i;
        }
        return n;
    }
    
    public int indexOf(final Object o) {
        int n;
        if (o == null) {
            n = this.m();
        }
        else {
            n = this.j(o, o.hashCode());
        }
        return n;
    }
    
    public boolean isEmpty() {
        return this.d <= 0;
    }
    
    public Iterator<E> iterator() {
        return (Iterator<E>)this.i().m().iterator();
    }
    
    public E n(final int n) {
        final Object[] c = this.c;
        final Object o = c[n];
        final int d = this.d;
        if (d <= 1) {
            h(this.b, c, d);
            this.b = a.d.b.f;
            this.c = a.d.b.g;
            this.d = 0;
        }
        else {
            final int[] b = this.b;
            final int length = b.length;
            int n2 = 8;
            if (length > 8 && d < b.length / 3) {
                if (d > 8) {
                    n2 = d + (d >> 1);
                }
                final int[] b2 = this.b;
                final Object[] c2 = this.c;
                this.c(n2);
                --this.d;
                if (n > 0) {
                    System.arraycopy((Object)b2, 0, (Object)this.b, 0, n);
                    System.arraycopy((Object)c2, 0, (Object)this.c, 0, n);
                }
                final int d2 = this.d;
                if (n < d2) {
                    final int n3 = n + 1;
                    System.arraycopy((Object)b2, n3, (Object)this.b, n, d2 - n);
                    System.arraycopy((Object)c2, n3, (Object)this.c, n, this.d - n);
                }
            }
            else {
                final int d3 = this.d - 1;
                if (n < (this.d = d3)) {
                    final int[] b3 = this.b;
                    final int n4 = n + 1;
                    System.arraycopy((Object)b3, n4, (Object)b3, n, d3 - n);
                    final Object[] c3 = this.c;
                    System.arraycopy((Object)c3, n4, (Object)c3, n, this.d - n);
                }
                this.c[this.d] = null;
            }
        }
        return (E)o;
    }
    
    public E o(final int n) {
        return (E)this.c[n];
    }
    
    public boolean remove(final Object o) {
        final int index = this.indexOf(o);
        if (index >= 0) {
            this.n(index);
            return true;
        }
        return false;
    }
    
    public boolean removeAll(final Collection<?> collection) {
        final Iterator iterator = collection.iterator();
        boolean b = false;
        while (iterator.hasNext()) {
            b |= this.remove(iterator.next());
        }
        return b;
    }
    
    public boolean retainAll(final Collection<?> collection) {
        int i = this.d - 1;
        boolean b = false;
        while (i >= 0) {
            if (!collection.contains(this.c[i])) {
                this.n(i);
                b = true;
            }
            --i;
        }
        return b;
    }
    
    public int size() {
        return this.d;
    }
    
    public Object[] toArray() {
        final int d = this.d;
        final Object[] array = new Object[d];
        System.arraycopy((Object)this.c, 0, (Object)array, 0, d);
        return array;
    }
    
    public <T> T[] toArray(final T[] array) {
        Object[] array2 = array;
        if (array.length < this.d) {
            array2 = (Object[])Array.newInstance((Class)array.getClass().getComponentType(), this.d);
        }
        System.arraycopy((Object)this.c, 0, (Object)array2, 0, this.d);
        final int length = ((T[])array2).length;
        final int d = this.d;
        if (length > d) {
            array2[d] = null;
        }
        return (T[])array2;
    }
    
    @Override
    public String toString() {
        if (this.isEmpty()) {
            return "{}";
        }
        final StringBuilder sb = new StringBuilder(this.d * 14);
        sb.append('{');
        for (int i = 0; i < this.d; ++i) {
            if (i > 0) {
                sb.append(", ");
            }
            final E o = this.o(i);
            if (o != this) {
                sb.append((Object)o);
            }
            else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
