package a.d;

public class d<E> implements Cloneable
{
    private static final Object f;
    private boolean b;
    private long[] c;
    private Object[] d;
    private int e;
    
    static {
        f = new Object();
    }
    
    public d() {
        this(10);
    }
    
    public d(int f) {
        this.b = false;
        if (f == 0) {
            this.c = a.d.c.b;
            this.d = a.d.c.c;
        }
        else {
            f = a.d.c.f(f);
            this.c = new long[f];
            this.d = new Object[f];
        }
    }
    
    private void e() {
        final int e = this.e;
        final long[] c = this.c;
        final Object[] d = this.d;
        int i = 0;
        int e2 = 0;
        while (i < e) {
            final Object o = d[i];
            int n = e2;
            if (o != a.d.d.f) {
                if (i != e2) {
                    c[e2] = c[i];
                    d[e2] = o;
                    d[i] = null;
                }
                n = e2 + 1;
            }
            ++i;
            e2 = n;
        }
        this.b = false;
        this.e = e2;
    }
    
    public void a(final long n, final E e) {
        final int e2 = this.e;
        if (e2 != 0 && n <= this.c[e2 - 1]) {
            this.l(n, e);
            return;
        }
        if (this.b && this.e >= this.c.length) {
            this.e();
        }
        final int e3 = this.e;
        if (e3 >= this.c.length) {
            final int f = a.d.c.f(e3 + 1);
            final long[] c = new long[f];
            final Object[] d = new Object[f];
            final long[] c2 = this.c;
            System.arraycopy((Object)c2, 0, (Object)c, 0, c2.length);
            final Object[] d2 = this.d;
            System.arraycopy((Object)d2, 0, (Object)d, 0, d2.length);
            this.c = c;
            this.d = d;
        }
        this.c[e3] = n;
        this.d[e3] = e;
        this.e = e3 + 1;
    }
    
    public void b() {
        final int e = this.e;
        final Object[] d = this.d;
        for (int i = 0; i < e; ++i) {
            d[i] = null;
        }
        this.e = 0;
        this.b = false;
    }
    
    public d<E> c() {
        try {
            final d d = (d)super.clone();
            d.c = this.c.clone();
            d.d = this.d.clone();
            return d;
        }
        catch (final CloneNotSupportedException ex) {
            throw new AssertionError((Object)ex);
        }
    }
    
    public E f(final long n) {
        return this.g(n, null);
    }
    
    public E g(final long n, final E e) {
        final int b = a.d.c.b(this.c, this.e, n);
        if (b >= 0) {
            final Object[] d = this.d;
            if (d[b] != a.d.d.f) {
                return (E)d[b];
            }
        }
        return e;
    }
    
    public int h(final long n) {
        if (this.b) {
            this.e();
        }
        return a.d.c.b(this.c, this.e, n);
    }
    
    public long k(final int n) {
        if (this.b) {
            this.e();
        }
        return this.c[n];
    }
    
    public void l(final long n, final E e) {
        final int b = a.d.c.b(this.c, this.e, n);
        if (b >= 0) {
            this.d[b] = e;
        }
        else {
            final int n2 = ~b;
            if (n2 < this.e) {
                final Object[] d = this.d;
                if (d[n2] == a.d.d.f) {
                    this.c[n2] = n;
                    d[n2] = e;
                    return;
                }
            }
            int n3 = n2;
            if (this.b) {
                n3 = n2;
                if (this.e >= this.c.length) {
                    this.e();
                    n3 = ~a.d.c.b(this.c, this.e, n);
                }
            }
            final int e2 = this.e;
            if (e2 >= this.c.length) {
                final int f = a.d.c.f(e2 + 1);
                final long[] c = new long[f];
                final Object[] d2 = new Object[f];
                final long[] c2 = this.c;
                System.arraycopy((Object)c2, 0, (Object)c, 0, c2.length);
                final Object[] d3 = this.d;
                System.arraycopy((Object)d3, 0, (Object)d2, 0, d3.length);
                this.c = c;
                this.d = d2;
            }
            final int e3 = this.e;
            if (e3 - n3 != 0) {
                final long[] c3 = this.c;
                final int n4 = n3 + 1;
                System.arraycopy((Object)c3, n3, (Object)c3, n4, e3 - n3);
                final Object[] d4 = this.d;
                System.arraycopy((Object)d4, n3, (Object)d4, n4, this.e - n3);
            }
            this.c[n3] = n;
            this.d[n3] = e;
            ++this.e;
        }
    }
    
    public void p(final long n) {
        final int b = a.d.c.b(this.c, this.e, n);
        if (b >= 0) {
            final Object[] d = this.d;
            final Object o = d[b];
            final Object f = a.d.d.f;
            if (o != f) {
                d[b] = f;
                this.b = true;
            }
        }
    }
    
    public void r(final int n) {
        final Object[] d = this.d;
        final Object o = d[n];
        final Object f = a.d.d.f;
        if (o != f) {
            d[n] = f;
            this.b = true;
        }
    }
    
    public int t() {
        if (this.b) {
            this.e();
        }
        return this.e;
    }
    
    @Override
    public String toString() {
        if (this.t() <= 0) {
            return "{}";
        }
        final StringBuilder sb = new StringBuilder(this.e * 28);
        sb.append('{');
        for (int i = 0; i < this.e; ++i) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(this.k(i));
            sb.append('=');
            final E v = this.v(i);
            if (v != this) {
                sb.append((Object)v);
            }
            else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
    
    public E v(final int n) {
        if (this.b) {
            this.e();
        }
        return (E)this.d[n];
    }
}
