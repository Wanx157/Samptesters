package a.d;

import java.util.Map;
import java.util.ConcurrentModificationException;

public class g<K, V>
{
    static Object[] e;
    static int f;
    static Object[] g;
    static int h;
    int[] b;
    Object[] c;
    int d;
    
    public g() {
        this.b = a.d.c.a;
        this.c = a.d.c.c;
        this.d = 0;
    }
    
    public g(final int n) {
        if (n == 0) {
            this.b = a.d.c.a;
            this.c = a.d.c.c;
        }
        else {
            this.a(n);
        }
        this.d = 0;
    }
    
    public g(final g<K, V> g) {
        this();
        if (g != null) {
            this.j((g<? extends K, ? extends V>)g);
        }
    }
    
    private void a(final int n) {
        Label_0147: {
            if (n == 8) {
                synchronized (g.class) {
                    if (a.d.g.g != null) {
                        final Object[] g = a.d.g.g;
                        this.c = g;
                        a.d.g.g = (Object[])g[0];
                        this.b = (int[])g[1];
                        g[0] = (g[1] = null);
                        --a.d.g.h;
                        return;
                    }
                    break Label_0147;
                }
            }
            if (n == 4) {
                synchronized (g.class) {
                    if (a.d.g.e != null) {
                        final Object[] e = a.d.g.e;
                        this.c = e;
                        a.d.g.e = (Object[])e[0];
                        this.b = (int[])e[1];
                        e[0] = (e[1] = null);
                        --a.d.g.f;
                        return;
                    }
                }
            }
        }
        this.b = new int[n];
        this.c = new Object[n << 1];
    }
    
    private static int b(final int[] array, int a, final int n) {
        try {
            a = c.a(array, a, n);
            return a;
        }
        catch (final ArrayIndexOutOfBoundsException ex) {
            throw new ConcurrentModificationException();
        }
    }
    
    private static void d(final int[] array, final Object[] array2, int i) {
        if (array.length == 8) {
            synchronized (g.class) {
                if (a.d.g.h < 10) {
                    array2[0] = a.d.g.g;
                    array2[1] = array;
                    for (i = (i << 1) - 1; i >= 2; --i) {
                        array2[i] = null;
                    }
                    a.d.g.g = array2;
                    ++a.d.g.h;
                }
                return;
            }
        }
        if (array.length == 4) {
            synchronized (g.class) {
                if (a.d.g.f < 10) {
                    array2[0] = a.d.g.e;
                    array2[1] = array;
                    for (i = (i << 1) - 1; i >= 2; --i) {
                        array2[i] = null;
                    }
                    a.d.g.e = array2;
                    ++a.d.g.f;
                }
            }
        }
    }
    
    public void c(final int n) {
        final int d = this.d;
        final int[] b = this.b;
        if (b.length < n) {
            final Object[] c = this.c;
            this.a(n);
            if (this.d > 0) {
                System.arraycopy((Object)b, 0, (Object)this.b, 0, d);
                System.arraycopy((Object)c, 0, (Object)this.c, 0, d << 1);
            }
            d(b, c, d);
        }
        if (this.d == d) {
            return;
        }
        throw new ConcurrentModificationException();
    }
    
    public void clear() {
        final int d = this.d;
        if (d > 0) {
            final int[] b = this.b;
            final Object[] c = this.c;
            this.b = a.d.c.a;
            this.c = a.d.c.c;
            this.d = 0;
            d(b, c, d);
        }
        if (this.d <= 0) {
            return;
        }
        throw new ConcurrentModificationException();
    }
    
    public boolean containsKey(final Object o) {
        return this.f(o) >= 0;
    }
    
    public boolean containsValue(final Object o) {
        return this.h(o) >= 0;
    }
    
    int e(final Object o, final int n) {
        final int d = this.d;
        if (d == 0) {
            return -1;
        }
        int b = b(this.b, d, n);
        if (b < 0) {
            return b;
        }
        if (o.equals(this.c[b << 1])) {
            return b;
        }
        int n2;
        for (n2 = b + 1; n2 < d && this.b[n2] == n; ++n2) {
            if (o.equals(this.c[n2 << 1])) {
                return n2;
            }
        }
        --b;
        while (b >= 0 && this.b[b] == n) {
            if (o.equals(this.c[b << 1])) {
                return b;
            }
            --b;
        }
        return ~n2;
    }
    
    @Override
    public boolean equals(Object m) {
        if (this == m) {
            return true;
        }
        if (m instanceof g) {
            final g g = (g)m;
            if (this.size() != g.size()) {
                return false;
            }
            int i = 0;
            try {
                while (i < this.d) {
                    final K j = this.i(i);
                    final V k = this.m(i);
                    final Object value = g.get(j);
                    if (k == null) {
                        if (value != null || !g.containsKey(j)) {
                            return false;
                        }
                    }
                    else if (!k.equals(value)) {
                        return false;
                    }
                    ++i;
                }
                return true;
            }
            catch (final NullPointerException | ClassCastException ex) {
                return false;
            }
        }
        if (!(m instanceof Map)) {
            return false;
        }
        final Map map = (Map)m;
        if (this.size() != map.size()) {
            return false;
        }
        int l = 0;
        try {
            while (l < this.d) {
                final K i2 = this.i(l);
                m = this.m(l);
                final Object value2 = map.get((Object)i2);
                if (m == null) {
                    if (value2 != null || !map.containsKey((Object)i2)) {
                        return false;
                    }
                }
                else if (!m.equals(value2)) {
                    return false;
                }
                ++l;
            }
            return true;
        }
        catch (final NullPointerException | ClassCastException ex2) {
            return false;
        }
    }
    
    public int f(final Object o) {
        int n;
        if (o == null) {
            n = this.g();
        }
        else {
            n = this.e(o, o.hashCode());
        }
        return n;
    }
    
    int g() {
        final int d = this.d;
        if (d == 0) {
            return -1;
        }
        int b = b(this.b, d, 0);
        if (b < 0) {
            return b;
        }
        if (this.c[b << 1] == null) {
            return b;
        }
        int n;
        for (n = b + 1; n < d && this.b[n] == 0; ++n) {
            if (this.c[n << 1] == null) {
                return n;
            }
        }
        --b;
        while (b >= 0 && this.b[b] == 0) {
            if (this.c[b << 1] == null) {
                return b;
            }
            --b;
        }
        return ~n;
    }
    
    public V get(final Object o) {
        return this.getOrDefault(o, null);
    }
    
    public V getOrDefault(final Object o, V v) {
        final int f = this.f(o);
        if (f >= 0) {
            v = (V)this.c[(f << 1) + 1];
        }
        return v;
    }
    
    int h(final Object o) {
        final int n = this.d * 2;
        final Object[] c = this.c;
        if (o == null) {
            for (int i = 1; i < n; i += 2) {
                if (c[i] == null) {
                    return i >> 1;
                }
            }
        }
        else {
            for (int j = 1; j < n; j += 2) {
                if (o.equals(c[j])) {
                    return j >> 1;
                }
            }
        }
        return -1;
    }
    
    @Override
    public int hashCode() {
        final int[] b = this.b;
        final Object[] c = this.c;
        final int d = this.d;
        int n = 1;
        int i = 0;
        int n2 = 0;
        while (i < d) {
            final Object o = c[n];
            final int n3 = b[i];
            int hashCode;
            if (o == null) {
                hashCode = 0;
            }
            else {
                hashCode = o.hashCode();
            }
            n2 += (hashCode ^ n3);
            ++i;
            n += 2;
        }
        return n2;
    }
    
    public K i(final int n) {
        return (K)this.c[n << 1];
    }
    
    public boolean isEmpty() {
        return this.d <= 0;
    }
    
    public void j(final g<? extends K, ? extends V> g) {
        final int d = g.d;
        this.c(this.d + d);
        final int d2 = this.d;
        int i = 0;
        if (d2 == 0) {
            if (d > 0) {
                System.arraycopy((Object)g.b, 0, (Object)this.b, 0, d);
                System.arraycopy((Object)g.c, 0, (Object)this.c, 0, d << 1);
                this.d = d;
            }
        }
        else {
            while (i < d) {
                this.put(g.i(i), g.m(i));
                ++i;
            }
        }
    }
    
    public V k(int d) {
        final Object[] c = this.c;
        final int n = d << 1;
        final Object o = c[n + 1];
        final int d2 = this.d;
        final int n2 = 0;
        if (d2 <= 1) {
            d(this.b, c, d2);
            this.b = a.d.c.a;
            this.c = a.d.c.c;
            d = n2;
        }
        else {
            final int n3 = d2 - 1;
            final int[] b = this.b;
            final int length = b.length;
            int n4 = 8;
            if (length > 8 && d2 < b.length / 3) {
                if (d2 > 8) {
                    n4 = d2 + (d2 >> 1);
                }
                final int[] b2 = this.b;
                final Object[] c2 = this.c;
                this.a(n4);
                if (d2 != this.d) {
                    throw new ConcurrentModificationException();
                }
                if (d > 0) {
                    System.arraycopy((Object)b2, 0, (Object)this.b, 0, d);
                    System.arraycopy((Object)c2, 0, (Object)this.c, 0, n);
                }
                if (d < n3) {
                    final int n5 = d + 1;
                    final int[] b3 = this.b;
                    final int n6 = n3 - d;
                    System.arraycopy((Object)b2, n5, (Object)b3, d, n6);
                    System.arraycopy((Object)c2, n5 << 1, (Object)this.c, n, n6 << 1);
                }
            }
            else {
                if (d < n3) {
                    final int[] b4 = this.b;
                    final int n7 = d + 1;
                    final int n8 = n3 - d;
                    System.arraycopy((Object)b4, n7, (Object)b4, d, n8);
                    final Object[] c3 = this.c;
                    System.arraycopy((Object)c3, n7 << 1, (Object)c3, n, n8 << 1);
                }
                final Object[] c4 = this.c;
                d = n3 << 1;
                c4[d + 1] = (c4[d] = null);
            }
            d = n3;
        }
        if (d2 == this.d) {
            this.d = d;
            return (V)o;
        }
        throw new ConcurrentModificationException();
    }
    
    public V l(int n, final V v) {
        n = (n << 1) + 1;
        final Object[] c = this.c;
        final Object o = c[n];
        c[n] = v;
        return (V)o;
    }
    
    public V m(final int n) {
        return (V)this.c[(n << 1) + 1];
    }
    
    public V put(final K k, final V v) {
        final int d = this.d;
        int n;
        int hashCode;
        if (k == null) {
            n = this.g();
            hashCode = 0;
        }
        else {
            hashCode = k.hashCode();
            n = this.e(k, hashCode);
        }
        if (n >= 0) {
            final int n2 = (n << 1) + 1;
            final Object[] c = this.c;
            final Object o = c[n2];
            c[n2] = v;
            return (V)o;
        }
        final int n3 = ~n;
        if (d >= this.b.length) {
            int n4 = 4;
            if (d >= 8) {
                n4 = (d >> 1) + d;
            }
            else if (d >= 4) {
                n4 = 8;
            }
            final int[] b = this.b;
            final Object[] c2 = this.c;
            this.a(n4);
            if (d != this.d) {
                throw new ConcurrentModificationException();
            }
            final int[] b2 = this.b;
            if (b2.length > 0) {
                System.arraycopy((Object)b, 0, (Object)b2, 0, b.length);
                System.arraycopy((Object)c2, 0, (Object)this.c, 0, c2.length);
            }
            d(b, c2, d);
        }
        if (n3 < d) {
            final int[] b3 = this.b;
            final int n5 = n3 + 1;
            System.arraycopy((Object)b3, n3, (Object)b3, n5, d - n3);
            final Object[] c3 = this.c;
            System.arraycopy((Object)c3, n3 << 1, (Object)c3, n5 << 1, this.d - n3 << 1);
        }
        final int d2 = this.d;
        if (d == d2) {
            final int[] b4 = this.b;
            if (n3 < b4.length) {
                b4[n3] = hashCode;
                final Object[] c4 = this.c;
                final int n6 = n3 << 1;
                c4[n6] = k;
                c4[n6 + 1] = v;
                this.d = d2 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }
    
    public V putIfAbsent(final K k, final V v) {
        Object o;
        if ((o = this.get(k)) == null) {
            o = this.put(k, v);
        }
        return (V)o;
    }
    
    public V remove(final Object o) {
        final int f = this.f(o);
        if (f >= 0) {
            return this.k(f);
        }
        return null;
    }
    
    public boolean remove(Object m, final Object o) {
        final int f = this.f(m);
        if (f >= 0) {
            m = this.m(f);
            if (o == m || (o != null && o.equals(m))) {
                this.k(f);
                return true;
            }
        }
        return false;
    }
    
    public V replace(final K k, final V v) {
        final int f = this.f(k);
        if (f >= 0) {
            return this.l(f, v);
        }
        return null;
    }
    
    public boolean replace(final K k, final V v, final V v2) {
        final int f = this.f(k);
        if (f >= 0) {
            final V m = this.m(f);
            if (m == v || (v != null && v.equals(m))) {
                this.l(f, v2);
                return true;
            }
        }
        return false;
    }
    
    public int size() {
        return this.d;
    }
    
    @Override
    public String toString() {
        if (this.isEmpty()) {
            return "{}";
        }
        final StringBuilder sb = new StringBuilder(this.d * 28);
        sb.append('{');
        for (int i = 0; i < this.d; ++i) {
            if (i > 0) {
                sb.append(", ");
            }
            final K j = this.i(i);
            if (j != this) {
                sb.append((Object)j);
            }
            else {
                sb.append("(this Map)");
            }
            sb.append('=');
            final V m = this.m(i);
            if (m != this) {
                sb.append((Object)m);
            }
            else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
