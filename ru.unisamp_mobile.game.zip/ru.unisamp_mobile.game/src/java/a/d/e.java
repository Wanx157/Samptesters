package a.d;

import java.util.Locale;
import java.util.Map$Entry;
import java.util.LinkedHashMap;

public class e<K, V>
{
    private final LinkedHashMap<K, V> a;
    private int b;
    private int c;
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;
    
    public e(final int c) {
        if (c > 0) {
            this.c = c;
            this.a = (LinkedHashMap<K, V>)new LinkedHashMap(0, 0.75f, true);
            return;
        }
        throw new IllegalArgumentException("maxSize <= 0");
    }
    
    private int e(final K k, final V v) {
        final int f = this.f(k, v);
        if (f >= 0) {
            return f;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Negative size: ");
        sb.append((Object)k);
        sb.append("=");
        sb.append((Object)v);
        throw new IllegalStateException(sb.toString());
    }
    
    protected V a(final K k) {
        return null;
    }
    
    protected void b(final boolean b, final K k, final V v, final V v2) {
    }
    
    public final V c(final K k) {
        if (k != null) {
            synchronized (this) {
                final Object value = this.a.get((Object)k);
                if (value != null) {
                    ++this.g;
                    return (V)value;
                }
                ++this.h;
                monitorexit(this);
                final V a = this.a(k);
                if (a == null) {
                    return null;
                }
                synchronized (this) {
                    ++this.e;
                    final Object put = this.a.put((Object)k, (Object)a);
                    if (put != null) {
                        this.a.put((Object)k, put);
                    }
                    else {
                        this.b += this.e(k, a);
                    }
                    monitorexit(this);
                    if (put != null) {
                        this.b(false, k, a, (V)put);
                        return (V)put;
                    }
                    this.g(this.c);
                    return a;
                }
            }
        }
        throw new NullPointerException("key == null");
    }
    
    public final V d(final K k, final V v) {
        if (k != null && v != null) {
            synchronized (this) {
                ++this.d;
                this.b += this.e(k, v);
                final Object put = this.a.put((Object)k, (Object)v);
                if (put != null) {
                    this.b -= this.e(k, (V)put);
                }
                monitorexit(this);
                if (put != null) {
                    this.b(false, k, (V)put, v);
                }
                this.g(this.c);
                return (V)put;
            }
        }
        throw new NullPointerException("key == null || value == null");
    }
    
    protected int f(final K k, final V v) {
        return 1;
    }
    
    public void g(final int n) {
        while (true) {
            monitorenter(this);
            try {
                if (this.b < 0 || (this.a.isEmpty() && this.b != 0)) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append(this.getClass().getName());
                    sb.append(".sizeOf() is reporting inconsistent results!");
                    throw new IllegalStateException(sb.toString());
                }
                if (this.b <= n || this.a.isEmpty()) {
                    monitorexit(this);
                    return;
                }
                final Map$Entry map$Entry = (Map$Entry)this.a.entrySet().iterator().next();
                final Object key = map$Entry.getKey();
                final Object value = map$Entry.getValue();
                this.a.remove(key);
                this.b -= this.e((K)key, (V)value);
                ++this.f;
                monitorexit(this);
                this.b(true, (K)key, (V)value, null);
            }
            finally {
                monitorexit(this);
                while (true) {}
            }
        }
    }
    
    @Override
    public final String toString() {
        synchronized (this) {
            final int n = this.g + this.h;
            int n2;
            if (n != 0) {
                n2 = this.g * 100 / n;
            }
            else {
                n2 = 0;
            }
            return String.format(Locale.US, "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", new Object[] { this.c, this.g, this.h, n2 });
        }
    }
}
