package a.d;

import java.util.NoSuchElementException;
import java.lang.reflect.Array;
import java.util.Map$Entry;
import java.util.Set;
import java.util.Iterator;
import java.util.Collection;
import java.util.Map;

abstract class f<K, V>
{
    b a;
    c b;
    e c;
    
    public static <K, V> boolean j(final Map<K, V> map, final Collection<?> collection) {
        final Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            if (!map.containsKey(iterator.next())) {
                return false;
            }
        }
        return true;
    }
    
    public static <T> boolean k(final Set<T> set, final Object o) {
        boolean b = true;
        if (set == o) {
            return true;
        }
        if (!(o instanceof Set)) {
            return false;
        }
        final Set set2 = (Set)o;
        try {
            if (set.size() != set2.size() || !set.containsAll((Collection)set2)) {
                b = false;
            }
            return b;
        }
        catch (final NullPointerException | ClassCastException ex) {
            return false;
        }
    }
    
    public static <K, V> boolean o(final Map<K, V> map, final Collection<?> collection) {
        final int size = map.size();
        final Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            map.remove(iterator.next());
        }
        return size != map.size();
    }
    
    public static <K, V> boolean p(final Map<K, V> map, final Collection<?> collection) {
        final int size = map.size();
        final Iterator iterator = map.keySet().iterator();
        while (iterator.hasNext()) {
            if (!collection.contains(iterator.next())) {
                iterator.remove();
            }
        }
        return size != map.size();
    }
    
    protected abstract void a();
    
    protected abstract Object b(final int p0, final int p1);
    
    protected abstract Map<K, V> c();
    
    protected abstract int d();
    
    protected abstract int e(final Object p0);
    
    protected abstract int f(final Object p0);
    
    protected abstract void g(final K p0, final V p1);
    
    protected abstract void h(final int p0);
    
    protected abstract V i(final int p0, final V p1);
    
    public Set<Map$Entry<K, V>> l() {
        if (this.a == null) {
            this.a = new b();
        }
        return (Set<Map$Entry<K, V>>)this.a;
    }
    
    public Set<K> m() {
        if (this.b == null) {
            this.b = new c();
        }
        return (Set<K>)this.b;
    }
    
    public Collection<V> n() {
        if (this.c == null) {
            this.c = new e();
        }
        return (Collection<V>)this.c;
    }
    
    public Object[] q(final int n) {
        final int d = this.d();
        final Object[] array = new Object[d];
        for (int i = 0; i < d; ++i) {
            array[i] = this.b(i, n);
        }
        return array;
    }
    
    public <T> T[] r(final T[] array, final int n) {
        final int d = this.d();
        Object[] array2 = array;
        if (array.length < d) {
            array2 = (Object[])Array.newInstance((Class)array.getClass().getComponentType(), d);
        }
        for (int i = 0; i < d; ++i) {
            array2[i] = this.b(i, n);
        }
        if (array2.length > d) {
            array2[d] = null;
        }
        return (T[])array2;
    }
    
    final class a<T> implements Iterator<T>
    {
        final int b;
        int c;
        int d;
        boolean e;
        final f f;
        
        a(final f f, final int b) {
            this.f = f;
            this.e = false;
            this.b = b;
            this.c = f.d();
        }
        
        public boolean hasNext() {
            return this.d < this.c;
        }
        
        public T next() {
            if (this.hasNext()) {
                final Object b = this.f.b(this.d, this.b);
                ++this.d;
                this.e = true;
                return (T)b;
            }
            throw new NoSuchElementException();
        }
        
        public void remove() {
            if (this.e) {
                final int d = this.d - 1;
                this.d = d;
                --this.c;
                this.e = false;
                this.f.h(d);
                return;
            }
            throw new IllegalStateException();
        }
    }
    
    final class b implements Set<Map$Entry<K, V>>
    {
        final f b;
        
        b(final f b) {
            this.b = b;
        }
        
        public boolean addAll(final Collection<? extends Map$Entry<K, V>> collection) {
            final int d = this.b.d();
            for (final Map$Entry map$Entry : collection) {
                this.b.g(map$Entry.getKey(), map$Entry.getValue());
            }
            return d != this.b.d();
        }
        
        public boolean c(final Map$Entry<K, V> map$Entry) {
            throw new UnsupportedOperationException();
        }
        
        public void clear() {
            this.b.a();
        }
        
        public boolean contains(final Object o) {
            if (!(o instanceof Map$Entry)) {
                return false;
            }
            final Map$Entry map$Entry = (Map$Entry)o;
            final int e = this.b.e(map$Entry.getKey());
            return e >= 0 && a.d.c.c(this.b.b(e, 1), map$Entry.getValue());
        }
        
        public boolean containsAll(final Collection<?> collection) {
            final Iterator iterator = collection.iterator();
            while (iterator.hasNext()) {
                if (!this.contains(iterator.next())) {
                    return false;
                }
            }
            return true;
        }
        
        @Override
        public boolean equals(final Object o) {
            return f.k((java.util.Set<Object>)this, o);
        }
        
        @Override
        public int hashCode() {
            int i = this.b.d() - 1;
            int n = 0;
            while (i >= 0) {
                final Object b = this.b.b(i, 0);
                final Object b2 = this.b.b(i, 1);
                int hashCode;
                if (b == null) {
                    hashCode = 0;
                }
                else {
                    hashCode = b.hashCode();
                }
                int hashCode2;
                if (b2 == null) {
                    hashCode2 = 0;
                }
                else {
                    hashCode2 = b2.hashCode();
                }
                n += (hashCode ^ hashCode2);
                --i;
            }
            return n;
        }
        
        public boolean isEmpty() {
            return this.b.d() == 0;
        }
        
        public Iterator<Map$Entry<K, V>> iterator() {
            return (Iterator<Map$Entry<K, V>>)this.b.new d();
        }
        
        public boolean remove(final Object o) {
            throw new UnsupportedOperationException();
        }
        
        public boolean removeAll(final Collection<?> collection) {
            throw new UnsupportedOperationException();
        }
        
        public boolean retainAll(final Collection<?> collection) {
            throw new UnsupportedOperationException();
        }
        
        public int size() {
            return this.b.d();
        }
        
        public Object[] toArray() {
            throw new UnsupportedOperationException();
        }
        
        public <T> T[] toArray(final T[] array) {
            throw new UnsupportedOperationException();
        }
    }
    
    final class c implements Set<K>
    {
        final f b;
        
        c(final f b) {
            this.b = b;
        }
        
        public boolean add(final K k) {
            throw new UnsupportedOperationException();
        }
        
        public boolean addAll(final Collection<? extends K> collection) {
            throw new UnsupportedOperationException();
        }
        
        public void clear() {
            this.b.a();
        }
        
        public boolean contains(final Object o) {
            return this.b.e(o) >= 0;
        }
        
        public boolean containsAll(final Collection<?> collection) {
            return f.j(this.b.c(), collection);
        }
        
        @Override
        public boolean equals(final Object o) {
            return f.k((java.util.Set<Object>)this, o);
        }
        
        @Override
        public int hashCode() {
            int i = this.b.d() - 1;
            int n = 0;
            while (i >= 0) {
                final Object b = this.b.b(i, 0);
                int hashCode;
                if (b == null) {
                    hashCode = 0;
                }
                else {
                    hashCode = b.hashCode();
                }
                n += hashCode;
                --i;
            }
            return n;
        }
        
        public boolean isEmpty() {
            return this.b.d() == 0;
        }
        
        public Iterator<K> iterator() {
            return (Iterator<K>)this.b.new a(0);
        }
        
        public boolean remove(final Object o) {
            final int e = this.b.e(o);
            if (e >= 0) {
                this.b.h(e);
                return true;
            }
            return false;
        }
        
        public boolean removeAll(final Collection<?> collection) {
            return f.o(this.b.c(), collection);
        }
        
        public boolean retainAll(final Collection<?> collection) {
            return f.p(this.b.c(), collection);
        }
        
        public int size() {
            return this.b.d();
        }
        
        public Object[] toArray() {
            return this.b.q(0);
        }
        
        public <T> T[] toArray(final T[] array) {
            return this.b.r(array, 0);
        }
    }
    
    final class d implements Iterator<Map$Entry<K, V>>, Map$Entry<K, V>
    {
        int b;
        int c;
        boolean d;
        final f e;
        
        d(final f e) {
            this.e = e;
            this.d = false;
            this.b = e.d() - 1;
            this.c = -1;
        }
        
        public Map$Entry<K, V> b() {
            if (this.hasNext()) {
                ++this.c;
                this.d = true;
                return (Map$Entry<K, V>)this;
            }
            throw new NoSuchElementException();
        }
        
        @Override
        public boolean equals(final Object o) {
            if (!this.d) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            final boolean b = o instanceof Map$Entry;
            final boolean b2 = false;
            if (!b) {
                return false;
            }
            final Map$Entry map$Entry = (Map$Entry)o;
            boolean b3 = b2;
            if (a.d.c.c(map$Entry.getKey(), this.e.b(this.c, 0))) {
                b3 = b2;
                if (a.d.c.c(map$Entry.getValue(), this.e.b(this.c, 1))) {
                    b3 = true;
                }
            }
            return b3;
        }
        
        public K getKey() {
            if (this.d) {
                return (K)this.e.b(this.c, 0);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        
        public V getValue() {
            if (this.d) {
                return (V)this.e.b(this.c, 1);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        
        public boolean hasNext() {
            return this.c < this.b;
        }
        
        @Override
        public int hashCode() {
            if (this.d) {
                final f e = this.e;
                final int c = this.c;
                int hashCode = 0;
                final Object b = e.b(c, 0);
                final Object b2 = this.e.b(this.c, 1);
                int hashCode2;
                if (b == null) {
                    hashCode2 = 0;
                }
                else {
                    hashCode2 = b.hashCode();
                }
                if (b2 != null) {
                    hashCode = b2.hashCode();
                }
                return hashCode2 ^ hashCode;
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        
        public void remove() {
            if (this.d) {
                this.e.h(this.c);
                --this.c;
                --this.b;
                this.d = false;
                return;
            }
            throw new IllegalStateException();
        }
        
        public V setValue(final V v) {
            if (this.d) {
                return this.e.i(this.c, v);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.getKey());
            sb.append("=");
            sb.append(this.getValue());
            return sb.toString();
        }
    }
    
    final class e implements Collection<V>
    {
        final f b;
        
        e(final f b) {
            this.b = b;
        }
        
        public boolean add(final V v) {
            throw new UnsupportedOperationException();
        }
        
        public boolean addAll(final Collection<? extends V> collection) {
            throw new UnsupportedOperationException();
        }
        
        public void clear() {
            this.b.a();
        }
        
        public boolean contains(final Object o) {
            return this.b.f(o) >= 0;
        }
        
        public boolean containsAll(final Collection<?> collection) {
            final Iterator iterator = collection.iterator();
            while (iterator.hasNext()) {
                if (!this.contains(iterator.next())) {
                    return false;
                }
            }
            return true;
        }
        
        public boolean isEmpty() {
            return this.b.d() == 0;
        }
        
        public Iterator<V> iterator() {
            return (Iterator<V>)this.b.new a(1);
        }
        
        public boolean remove(final Object o) {
            final int f = this.b.f(o);
            if (f >= 0) {
                this.b.h(f);
                return true;
            }
            return false;
        }
        
        public boolean removeAll(final Collection<?> collection) {
            int d = this.b.d();
            int i = 0;
            boolean b = false;
            while (i < d) {
                int n = d;
                int n2 = i;
                if (collection.contains(this.b.b(i, 1))) {
                    this.b.h(i);
                    n2 = i - 1;
                    n = d - 1;
                    b = true;
                }
                i = n2 + 1;
                d = n;
            }
            return b;
        }
        
        public boolean retainAll(final Collection<?> collection) {
            int d = this.b.d();
            int i = 0;
            boolean b = false;
            while (i < d) {
                int n = d;
                int n2 = i;
                if (!collection.contains(this.b.b(i, 1))) {
                    this.b.h(i);
                    n2 = i - 1;
                    n = d - 1;
                    b = true;
                }
                i = n2 + 1;
                d = n;
            }
            return b;
        }
        
        public int size() {
            return this.b.d();
        }
        
        public Object[] toArray() {
            return this.b.q(1);
        }
        
        public <T> T[] toArray(final T[] array) {
            return this.b.r(array, 1);
        }
    }
}
