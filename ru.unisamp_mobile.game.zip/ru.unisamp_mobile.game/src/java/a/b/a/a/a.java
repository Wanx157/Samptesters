package a.b.a.a;

public class a extends c
{
    private static volatile a c;
    private c a;
    private c b;
    
    private a() {
        final b b = new b();
        this.b = b;
        this.a = b;
    }
    
    public static a b() {
        if (a.c != null) {
            return a.c;
        }
        synchronized (a.class) {
            if (a.c == null) {
                a.c = new a();
            }
            return a.c;
        }
    }
    
    public boolean a() {
        return this.a.a();
    }
}
