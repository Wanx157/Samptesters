package a.b.a.a;

import android.os.Looper;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public class b extends c
{
    private final Object a;
    private final ExecutorService b;
    
    public b() {
        this.a = new Object();
        this.b = Executors.newFixedThreadPool(2, (ThreadFactory)new b$a(this));
    }
    
    public boolean a() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }
}
