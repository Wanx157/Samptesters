package a.b.a.a;

public abstract class c
{
    public abstract boolean a();
}
