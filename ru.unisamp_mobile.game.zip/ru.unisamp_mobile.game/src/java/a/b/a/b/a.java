package a.b.a.b;

import java.util.Map$Entry;
import java.util.HashMap;

public class a<K, V> extends b<K, V>
{
    private HashMap<K, b$c<K, V>> f;
    
    public a() {
        this.f = (HashMap<K, b$c<K, V>>)new HashMap();
    }
    
    public boolean contains(final K k) {
        return this.f.containsKey((Object)k);
    }
    
    protected b$c<K, V> h(final K k) {
        return (b$c<K, V>)this.f.get((Object)k);
    }
    
    public V n(final K k, final V v) {
        final b$c<K, V> h = this.h(k);
        if (h != null) {
            return (V)h.c;
        }
        this.f.put((Object)k, (Object)this.m((Object)k, (Object)v));
        return null;
    }
    
    public V o(final K k) {
        final Object o = super.o((Object)k);
        this.f.remove((Object)k);
        return (V)o;
    }
    
    public Map$Entry<K, V> p(final K k) {
        if (this.contains(k)) {
            return (Map$Entry<K, V>)((b$c)this.f.get((Object)k)).e;
        }
        return null;
    }
}
