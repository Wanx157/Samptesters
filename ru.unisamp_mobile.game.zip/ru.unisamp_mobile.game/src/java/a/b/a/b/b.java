package a.b.a.b;

import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.Map$Entry;

public class b<K, V> implements Iterable<Map$Entry<K, V>>
{
    c<K, V> b;
    private c<K, V> c;
    private WeakHashMap<f<K, V>, Boolean> d;
    private int e;
    
    public b() {
        this.d = (WeakHashMap<f<K, V>, Boolean>)new WeakHashMap();
        this.e = 0;
    }
    
    public Iterator<Map$Entry<K, V>> c() {
        final b.b$b b$b = new b.b$b((c)this.c, (c)this.b);
        this.d.put((Object)b$b, (Object)Boolean.FALSE);
        return (Iterator<Map$Entry<K, V>>)b$b;
    }
    
    public Map$Entry<K, V> d() {
        return (Map$Entry<K, V>)this.b;
    }
    
    @Override
    public boolean equals(final Object o) {
        boolean b = true;
        if (o == this) {
            return true;
        }
        if (!(o instanceof b)) {
            return false;
        }
        final b b2 = (b)o;
        if (this.size() != b2.size()) {
            return false;
        }
        final Iterator<Map$Entry<K, V>> iterator = this.iterator();
        final Iterator iterator2 = b2.iterator();
        while (iterator.hasNext() && iterator2.hasNext()) {
            final Map$Entry map$Entry = (Map$Entry)iterator.next();
            final Object next = iterator2.next();
            if ((map$Entry == null && next != null) || (map$Entry != null && !map$Entry.equals(next))) {
                return false;
            }
        }
        if (iterator.hasNext() || iterator2.hasNext()) {
            b = false;
        }
        return b;
    }
    
    protected c<K, V> h(final K obj) {
        c<K, V> c;
        for (c = this.b; c != null && !c.b.equals(obj); c = c.d) {}
        return c;
    }
    
    @Override
    public int hashCode() {
        final Iterator<Map$Entry<K, V>> iterator = this.iterator();
        int n = 0;
        while (iterator.hasNext()) {
            n += ((Map$Entry)iterator.next()).hashCode();
        }
        return n;
    }
    
    public b.b$d i() {
        final b.b$d b$d = new b.b$d(this);
        this.d.put((Object)b$d, (Object)Boolean.FALSE);
        return b$d;
    }
    
    public Iterator<Map$Entry<K, V>> iterator() {
        final b.b$a b$a = new b.b$a((c)this.b, (c)this.c);
        this.d.put((Object)b$a, (Object)Boolean.FALSE);
        return (Iterator<Map$Entry<K, V>>)b$a;
    }
    
    public Map$Entry<K, V> j() {
        return (Map$Entry<K, V>)this.c;
    }
    
    protected c<K, V> m(final K k, final V v) {
        final c c = new c((K)k, (V)v);
        ++this.e;
        final c<K, V> c2 = this.c;
        if (c2 == null) {
            this.b = c;
        }
        else {
            c2.d = c;
            c.e = (c<K, V>)c2;
        }
        return this.c = c;
    }
    
    public V n(final K k, final V v) {
        final c<K, V> h = this.h(k);
        if (h != null) {
            return h.c;
        }
        this.m(k, v);
        return null;
    }
    
    public V o(final K k) {
        final c<K, V> h = this.h(k);
        if (h == null) {
            return null;
        }
        --this.e;
        if (!this.d.isEmpty()) {
            final Iterator iterator = this.d.keySet().iterator();
            while (iterator.hasNext()) {
                ((f)iterator.next()).b((c)h);
            }
        }
        final c<K, V> e = (c<K, V>)h.e;
        if (e != null) {
            e.d = (c<K, V>)h.d;
        }
        else {
            this.b = h.d;
        }
        final c<K, V> d = (c<K, V>)h.d;
        if (d != null) {
            d.e = (c<K, V>)h.e;
        }
        else {
            this.c = h.e;
        }
        h.d = null;
        h.e = null;
        return h.c;
    }
    
    public int size() {
        return this.e;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("[");
        final Iterator<Map$Entry<K, V>> iterator = this.iterator();
        while (iterator.hasNext()) {
            sb.append(iterator.next().toString());
            if (iterator.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
    
    static class c<K, V> implements Map$Entry<K, V>
    {
        final K b;
        final V c;
        c<K, V> d;
        c<K, V> e;
        
        c(final K b, final V c) {
            this.b = b;
            this.c = c;
        }
        
        @Override
        public boolean equals(final Object o) {
            boolean b = true;
            if (o == this) {
                return true;
            }
            if (!(o instanceof c)) {
                return false;
            }
            final c c = (c)o;
            if (!this.b.equals(c.b) || !this.c.equals(c.c)) {
                b = false;
            }
            return b;
        }
        
        public K getKey() {
            return this.b;
        }
        
        public V getValue() {
            return this.c;
        }
        
        @Override
        public int hashCode() {
            return this.b.hashCode() ^ this.c.hashCode();
        }
        
        public V setValue(final V v) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append((Object)this.b);
            sb.append("=");
            sb.append((Object)this.c);
            return sb.toString();
        }
    }
    
    interface f<K, V>
    {
        void b(final c<K, V> p0);
    }
}
