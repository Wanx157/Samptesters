package a.g.j;

import android.text.TextUtils;
import android.os.Build$VERSION;
import java.util.Locale;

public final class f
{
    private static final Locale a;
    
    static {
        a = new Locale("", "");
    }
    
    private static int a(final Locale locale) {
        final byte directionality = Character.getDirectionality(locale.getDisplayName(locale).charAt(0));
        if (directionality != 1 && directionality != 2) {
            return 0;
        }
        return 1;
    }
    
    public static int b(final Locale locale) {
        if (Build$VERSION.SDK_INT >= 17) {
            return TextUtils.getLayoutDirectionFromLocale(locale);
        }
        if (locale != null && !locale.equals((Object)f.a)) {
            final String c = b.c(locale);
            if (c == null) {
                return a(locale);
            }
            if (c.equalsIgnoreCase("Arab") || c.equalsIgnoreCase("Hebr")) {
                return 1;
            }
        }
        return 0;
    }
}
