package a.g.j;

import android.icu.util.ULocale;
import java.lang.reflect.InvocationTargetException;
import java.util.Locale;
import android.util.Log;
import android.os.Build$VERSION;
import java.lang.reflect.Method;

public final class b
{
    private static Method a;
    private static Method b;
    
    static {
        final int sdk_INT = Build$VERSION.SDK_INT;
        if (sdk_INT < 21) {
            try {
                final Class<?> forName = Class.forName("libcore.icu.ICU");
                if (forName != null) {
                    a.g.j.b.a = forName.getMethod("getScript", String.class);
                    a.g.j.b.b = forName.getMethod("addLikelySubtags", String.class);
                }
            }
            catch (final Exception ex) {
                a.g.j.b.a = null;
                a.g.j.b.b = null;
                Log.w("ICUCompat", (Throwable)ex);
            }
        }
        else if (sdk_INT < 24) {
            try {
                a.g.j.b.b = Class.forName("libcore.icu.ICU").getMethod("addLikelySubtags", Locale.class);
            }
            catch (final Exception ex2) {
                throw new IllegalStateException((Throwable)ex2);
            }
        }
    }
    
    private static String a(Locale ex) {
        final String string = ((Locale)ex).toString();
        try {
            if (a.g.j.b.b != null) {
                ex = (InvocationTargetException)a.g.j.b.b.invoke((Object)null, new Object[] { string });
                return (String)ex;
            }
            return string;
        }
        catch (final InvocationTargetException ex) {}
        catch (final IllegalAccessException ex2) {}
        Log.w("ICUCompat", (Throwable)ex);
        return string;
    }
    
    private static String b(String o) {
        try {
            if (a.g.j.b.a != null) {
                o = a.g.j.b.a.invoke((Object)null, new Object[] { o });
                return (String)o;
            }
            return null;
        }
        catch (final InvocationTargetException o) {}
        catch (final IllegalAccessException ex) {}
        Log.w("ICUCompat", (Throwable)o);
        return null;
    }
    
    public static String c(final Locale locale) {
        final int sdk_INT = Build$VERSION.SDK_INT;
        if (sdk_INT >= 24) {
            return ULocale.addLikelySubtags(ULocale.forLocale(locale)).getScript();
        }
        if (sdk_INT >= 21) {
            String script = null;
            try {
                script = ((Locale)a.g.j.b.b.invoke((Object)null, new Object[] { locale })).getScript();
                return script;
            }
            catch (final IllegalAccessException script) {}
            catch (final InvocationTargetException ex) {}
            Log.w("ICUCompat", (Throwable)script);
            return locale.getScript();
        }
        final String a = a(locale);
        if (a != null) {
            return b(a);
        }
        return null;
    }
}
