package a.g.j;

public interface d
{
    boolean a(final CharSequence p0, final int p1, final int p2);
}
