package a.g.j;

public final class e
{
    public static final d a;
    public static final d b;
    public static final d c;
    public static final d d;
    
    static {
        a = (d)new e.e$e((c)null, false);
        b = (d)new e.e$e((c)null, true);
        c = (d)new e.e$e((c)e.e$b.a, false);
        d = (d)new e.e$e((c)e.e$b.a, true);
        final e.e$a b2 = e.e$a.b;
        final e.e$f b3 = e.e$f.b;
    }
    
    static int a(final int n) {
        if (n == 0) {
            return 1;
        }
        if (n != 1 && n != 2) {
            return 2;
        }
        return 0;
    }
    
    static int b(final int n) {
        if (n != 0) {
            if (n != 1 && n != 2) {
                switch (n) {
                    default: {
                        return 2;
                    }
                    case 16:
                    case 17: {
                        break;
                    }
                    case 14:
                    case 15: {
                        return 1;
                    }
                }
            }
            return 0;
        }
        return 1;
    }
    
    private interface c
    {
        int a(final CharSequence p0, final int p1, final int p2);
    }
}
