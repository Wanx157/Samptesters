package a.g.k;

public interface e<T>
{
    boolean a(final T p0);
    
    T b();
}
