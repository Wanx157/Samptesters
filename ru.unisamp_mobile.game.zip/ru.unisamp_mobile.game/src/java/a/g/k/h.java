package a.g.k;

public final class h
{
    public static void a(final boolean b, final Object o) {
        if (b) {
            return;
        }
        throw new IllegalArgumentException(String.valueOf(o));
    }
    
    public static int b(final int n) {
        if (n >= 0) {
            return n;
        }
        throw new IllegalArgumentException();
    }
    
    public static <T> T c(final T t) {
        if (t != null) {
            return t;
        }
        throw null;
    }
    
    public static <T> T d(final T t, final Object o) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(String.valueOf(o));
    }
}
