package a.g.k;

import android.util.Log;
import java.io.Writer;

@Deprecated
public class b extends Writer
{
    private final String b;
    private StringBuilder c;
    
    public b(final String b) {
        this.c = new StringBuilder(128);
        this.b = b;
    }
    
    private void a() {
        if (this.c.length() > 0) {
            Log.d(this.b, this.c.toString());
            final StringBuilder c = this.c;
            c.delete(0, c.length());
        }
    }
    
    public void close() {
        this.a();
    }
    
    public void flush() {
        this.a();
    }
    
    public void write(final char[] array, final int n, final int n2) {
        for (int i = 0; i < n2; ++i) {
            final char c = array[n + i];
            if (c == '\n') {
                this.a();
            }
            else {
                this.c.append(c);
            }
        }
    }
}
