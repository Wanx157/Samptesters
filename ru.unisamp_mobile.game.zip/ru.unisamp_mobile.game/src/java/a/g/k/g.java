package a.g.k;

public class g<T> extends f<T>
{
    private final Object c;
    
    public g(final int n) {
        super(n);
        this.c = new Object();
    }
    
    @Override
    public boolean a(final T t) {
        final Object c = this.c;
        synchronized (c) {
            return super.a(t);
        }
    }
    
    @Override
    public T b() {
        final Object c = this.c;
        synchronized (c) {
            return super.b();
        }
    }
}
