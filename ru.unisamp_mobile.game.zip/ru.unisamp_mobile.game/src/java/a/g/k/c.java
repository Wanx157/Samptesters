package a.g.k;

import java.util.Arrays;
import java.util.Objects;
import android.os.Build$VERSION;

public class c
{
    public static boolean a(final Object o, final Object obj) {
        if (Build$VERSION.SDK_INT >= 19) {
            return Objects.equals(o, obj);
        }
        return o == obj || (o != null && o.equals(obj));
    }
    
    public static int b(final Object... array) {
        if (Build$VERSION.SDK_INT >= 19) {
            return Objects.hash(array);
        }
        return Arrays.hashCode(array);
    }
}
