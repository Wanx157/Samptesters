package a.g.h;

import android.os.UserManager;
import android.os.Build$VERSION;
import android.content.Context;

public class b
{
    public static boolean a(final Context context) {
        return Build$VERSION.SDK_INT < 24 || ((UserManager)context.getSystemService((Class)UserManager.class)).isUserUnlocked();
    }
}
