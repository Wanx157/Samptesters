package a.g.h;

import android.util.Log;
import android.os.Trace;
import android.os.Build$VERSION;

public final class a
{
    static {
        final int sdk_INT = Build$VERSION.SDK_INT;
        if (sdk_INT >= 18 && sdk_INT < 29) {
            try {
                Trace.class.getField("TRACE_TAG_APP").getLong((Object)null);
                Trace.class.getMethod("isTagEnabled", Long.TYPE);
                Trace.class.getMethod("asyncTraceBegin", Long.TYPE, String.class, Integer.TYPE);
                Trace.class.getMethod("asyncTraceEnd", Long.TYPE, String.class, Integer.TYPE);
                Trace.class.getMethod("traceCounter", Long.TYPE, String.class, Integer.TYPE);
            }
            catch (final Exception ex) {
                Log.i("TraceCompat", "Unable to initialize via reflection.", (Throwable)ex);
            }
        }
    }
    
    public static void a(final String s) {
        if (Build$VERSION.SDK_INT >= 18) {
            Trace.beginSection(s);
        }
    }
    
    public static void b() {
        if (Build$VERSION.SDK_INT >= 18) {
            Trace.endSection();
        }
    }
}
