package a.g.l;

import a.g.k.c;
import a.g.k.h;
import a.g.e.b;
import android.view.WindowInsets;
import android.os.Build$VERSION;

public class b0
{
    public static final b0 b;
    private final i a;
    
    static {
        b = new a().a().a().b().c();
    }
    
    public b0(final b0 b0) {
        i a3 = null;
        Label_0163: {
            if (b0 != null) {
                final i a = b0.a;
                Object a2;
                if (Build$VERSION.SDK_INT >= 29 && a instanceof b0.b0$h) {
                    a2 = new b0.b0$h(this, (b0.b0$h)a);
                }
                else if (Build$VERSION.SDK_INT >= 28 && a instanceof b0.b0$g) {
                    a2 = new b0.b0$g(this, (b0.b0$g)a);
                }
                else if (Build$VERSION.SDK_INT >= 21 && a instanceof b0.b0$f) {
                    a2 = new b0.b0$f(this, (b0.b0$f)a);
                }
                else {
                    if (Build$VERSION.SDK_INT < 20 || !(a instanceof b0.b0$e)) {
                        a3 = new i(this);
                        break Label_0163;
                    }
                    a2 = new b0.b0$e(this, (b0.b0$e)a);
                }
                this.a = (i)a2;
                return;
            }
            a3 = new i(this);
        }
        this.a = a3;
    }
    
    private b0(final WindowInsets windowInsets) {
        final int sdk_INT = Build$VERSION.SDK_INT;
        Object a;
        if (sdk_INT >= 29) {
            a = new b0.b0$h(this, windowInsets);
        }
        else if (sdk_INT >= 28) {
            a = new b0.b0$g(this, windowInsets);
        }
        else if (sdk_INT >= 21) {
            a = new b0.b0$f(this, windowInsets);
        }
        else {
            if (sdk_INT < 20) {
                this.a = new i(this);
                return;
            }
            a = new b0.b0$e(this, windowInsets);
        }
        this.a = (i)a;
    }
    
    static b k(final b b, final int n, final int n2, final int n3, final int n4) {
        final int max = Math.max(0, b.a - n);
        final int max2 = Math.max(0, b.b - n2);
        final int max3 = Math.max(0, b.c - n3);
        final int max4 = Math.max(0, b.d - n4);
        if (max == n && max2 == n2 && max3 == n3 && max4 == n4) {
            return b;
        }
        return b.a(max, max2, max3, max4);
    }
    
    public static b0 o(final WindowInsets windowInsets) {
        h.c(windowInsets);
        return new b0(windowInsets);
    }
    
    public b0 a() {
        return this.a.a();
    }
    
    public b0 b() {
        return this.a.b();
    }
    
    public b0 c() {
        return this.a.c();
    }
    
    public b d() {
        return this.a.e();
    }
    
    public int e() {
        return this.i().d;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof b0 && c.a(this.a, ((b0)o).a));
    }
    
    public int f() {
        return this.i().a;
    }
    
    public int g() {
        return this.i().c;
    }
    
    public int h() {
        return this.i().b;
    }
    
    @Override
    public int hashCode() {
        final i a = this.a;
        int hashCode;
        if (a == null) {
            hashCode = 0;
        }
        else {
            hashCode = a.hashCode();
        }
        return hashCode;
    }
    
    public b i() {
        return this.a.g();
    }
    
    public b0 j(final int n, final int n2, final int n3, final int n4) {
        return this.a.h(n, n2, n3, n4);
    }
    
    public boolean l() {
        return this.a.i();
    }
    
    @Deprecated
    public b0 m(final int n, final int n2, final int n3, final int n4) {
        final a a = new a(this);
        a.c(a.g.e.b.a(n, n2, n3, n4));
        return a.a();
    }
    
    public WindowInsets n() {
        final i a = this.a;
        WindowInsets b;
        if (a instanceof b0.b0$e) {
            b = ((b0.b0$e)a).b;
        }
        else {
            b = null;
        }
        return b;
    }
    
    public static final class a
    {
        private final d a;
        
        public a() {
            final int sdk_INT = Build$VERSION.SDK_INT;
            Object a;
            if (sdk_INT >= 29) {
                a = new b0$c();
            }
            else if (sdk_INT >= 20) {
                a = new b0$b();
            }
            else {
                a = new d();
            }
            this.a = (d)a;
        }
        
        public a(final b0 b0) {
            final int sdk_INT = Build$VERSION.SDK_INT;
            Object a;
            if (sdk_INT >= 29) {
                a = new b0$c(b0);
            }
            else if (sdk_INT >= 20) {
                a = new b0$b(b0);
            }
            else {
                a = new d(b0);
            }
            this.a = (d)a;
        }
        
        public b0 a() {
            return this.a.a();
        }
        
        public a b(final b b) {
            this.a.b(b);
            return this;
        }
        
        public a c(final b b) {
            this.a.c(b);
            return this;
        }
    }
    
    private static class d
    {
        private final b0 a;
        
        d() {
            this(new b0((b0)null));
        }
        
        d(final b0 a) {
            this.a = a;
        }
        
        b0 a() {
            return this.a;
        }
        
        void b(final b b) {
        }
        
        void c(final b b) {
        }
    }
    
    private static class i
    {
        final b0 a;
        
        i(final b0 a) {
            this.a = a;
        }
        
        b0 a() {
            return this.a;
        }
        
        b0 b() {
            return this.a;
        }
        
        b0 c() {
            return this.a;
        }
        
        a.g.l.c d() {
            return null;
        }
        
        b e() {
            return this.g();
        }
        
        @Override
        public boolean equals(final Object o) {
            boolean b = true;
            if (this == o) {
                return true;
            }
            if (!(o instanceof i)) {
                return false;
            }
            final i i = (i)o;
            if (this.j() != i.j() || this.i() != i.i() || !c.a(this.g(), i.g()) || !c.a(this.f(), i.f()) || !c.a(this.d(), i.d())) {
                b = false;
            }
            return b;
        }
        
        b f() {
            return a.g.e.b.e;
        }
        
        b g() {
            return a.g.e.b.e;
        }
        
        b0 h(final int n, final int n2, final int n3, final int n4) {
            return b0.b;
        }
        
        @Override
        public int hashCode() {
            return c.b(this.j(), this.i(), this.g(), this.f(), this.d());
        }
        
        boolean i() {
            return false;
        }
        
        boolean j() {
            return false;
        }
    }
}
