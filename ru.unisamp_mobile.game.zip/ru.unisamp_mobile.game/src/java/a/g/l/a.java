package a.g.l;

import android.view.accessibility.AccessibilityNodeInfo;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeProvider;
import android.os.Build$VERSION;
import a.g.l.c0.d;
import android.view.accessibility.AccessibilityEvent;
import java.lang.ref.WeakReference;
import android.util.SparseArray;
import android.text.style.ClickableSpan;
import java.util.Collections;
import a.g.l.c0.c;
import java.util.List;
import android.view.View;
import android.view.View$AccessibilityDelegate;

public class a
{
    private static final View$AccessibilityDelegate c;
    private final View$AccessibilityDelegate a;
    private final View$AccessibilityDelegate b;
    
    static {
        c = new View$AccessibilityDelegate();
    }
    
    public a() {
        this(a.g.l.a.c);
    }
    
    public a(final View$AccessibilityDelegate a) {
        this.a = a;
        this.b = new a(this);
    }
    
    static List<c.a> c(final View view) {
        List emptyList;
        if ((emptyList = (List)view.getTag(a.g.c.tag_accessibility_actions)) == null) {
            emptyList = Collections.emptyList();
        }
        return (List<c.a>)emptyList;
    }
    
    private boolean e(final ClickableSpan clickableSpan, final View view) {
        if (clickableSpan != null) {
            final ClickableSpan[] p2 = a.g.l.c0.c.p(view.createAccessibilityNodeInfo().getText());
            for (int n = 0; p2 != null && n < p2.length; ++n) {
                if (clickableSpan.equals(p2[n])) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean k(final int n, final View view) {
        final SparseArray sparseArray = (SparseArray)view.getTag(a.g.c.tag_accessibility_clickable_spans);
        if (sparseArray != null) {
            final WeakReference weakReference = (WeakReference)sparseArray.get(n);
            if (weakReference != null) {
                final ClickableSpan clickableSpan = (ClickableSpan)weakReference.get();
                if (this.e(clickableSpan, view)) {
                    clickableSpan.onClick(view);
                    return true;
                }
            }
        }
        return false;
    }
    
    public boolean a(final View view, final AccessibilityEvent accessibilityEvent) {
        return this.a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }
    
    public d b(final View view) {
        if (Build$VERSION.SDK_INT >= 16) {
            final AccessibilityNodeProvider accessibilityNodeProvider = this.a.getAccessibilityNodeProvider(view);
            if (accessibilityNodeProvider != null) {
                return new d(accessibilityNodeProvider);
            }
        }
        return null;
    }
    
    View$AccessibilityDelegate d() {
        return this.b;
    }
    
    public void f(final View view, final AccessibilityEvent accessibilityEvent) {
        this.a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }
    
    public void g(final View view, final c c) {
        this.a.onInitializeAccessibilityNodeInfo(view, c.v0());
    }
    
    public void h(final View view, final AccessibilityEvent accessibilityEvent) {
        this.a.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }
    
    public boolean i(final ViewGroup viewGroup, final View view, final AccessibilityEvent accessibilityEvent) {
        return this.a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }
    
    public boolean j(final View view, final int n, final Bundle bundle) {
        final List<c.a> c = c(view);
        final int n2 = 0;
        int n3 = 0;
        int d;
        while (true) {
            d = n2;
            if (n3 >= c.size()) {
                break;
            }
            final c.a a = (c.a)c.get(n3);
            if (a.b() == n) {
                d = (a.d(view, bundle) ? 1 : 0);
                break;
            }
            ++n3;
        }
        int performAccessibilityAction = d;
        if (d == 0) {
            performAccessibilityAction = d;
            if (Build$VERSION.SDK_INT >= 16) {
                performAccessibilityAction = (this.a.performAccessibilityAction(view, n, bundle) ? 1 : 0);
            }
        }
        int k;
        if ((k = performAccessibilityAction) == 0) {
            k = performAccessibilityAction;
            if (n == a.g.c.accessibility_action_clickable_span) {
                k = (this.k(bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1), view) ? 1 : 0);
            }
        }
        return k != 0;
    }
    
    public void l(final View view, final int n) {
        this.a.sendAccessibilityEvent(view, n);
    }
    
    public void m(final View view, final AccessibilityEvent accessibilityEvent) {
        this.a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }
    
    static final class a extends View$AccessibilityDelegate
    {
        final a.g.l.a a;
        
        a(final a.g.l.a a) {
            this.a = a;
        }
        
        public boolean dispatchPopulateAccessibilityEvent(final View view, final AccessibilityEvent accessibilityEvent) {
            return this.a.a(view, accessibilityEvent);
        }
        
        public AccessibilityNodeProvider getAccessibilityNodeProvider(final View view) {
            final d b = this.a.b(view);
            AccessibilityNodeProvider accessibilityNodeProvider;
            if (b != null) {
                accessibilityNodeProvider = (AccessibilityNodeProvider)b.d();
            }
            else {
                accessibilityNodeProvider = null;
            }
            return accessibilityNodeProvider;
        }
        
        public void onInitializeAccessibilityEvent(final View view, final AccessibilityEvent accessibilityEvent) {
            this.a.f(view, accessibilityEvent);
        }
        
        public void onInitializeAccessibilityNodeInfo(final View view, final AccessibilityNodeInfo accessibilityNodeInfo) {
            final c w0 = a.g.l.c0.c.w0(accessibilityNodeInfo);
            w0.o0(t.T(view));
            w0.g0(t.O(view));
            w0.k0(t.p(view));
            this.a.g(view, w0);
            w0.e(accessibilityNodeInfo.getText(), view);
            final List<c.a> c = a.g.l.a.c(view);
            for (int i = 0; i < c.size(); ++i) {
                w0.b((c.a)c.get(i));
            }
        }
        
        public void onPopulateAccessibilityEvent(final View view, final AccessibilityEvent accessibilityEvent) {
            this.a.h(view, accessibilityEvent);
        }
        
        public boolean onRequestSendAccessibilityEvent(final ViewGroup viewGroup, final View view, final AccessibilityEvent accessibilityEvent) {
            return this.a.i(viewGroup, view, accessibilityEvent);
        }
        
        public boolean performAccessibilityAction(final View view, final int n, final Bundle bundle) {
            return this.a.j(view, n, bundle);
        }
        
        public void sendAccessibilityEvent(final View view, final int n) {
            this.a.l(view, n);
        }
        
        public void sendAccessibilityEventUnchecked(final View view, final AccessibilityEvent accessibilityEvent) {
            this.a.m(view, accessibilityEvent);
        }
    }
}
