package a.g.l;

import android.view.View;

public class z implements y
{
    public void b(final View view) {
    }
    
    public void c(final View view) {
    }
}
