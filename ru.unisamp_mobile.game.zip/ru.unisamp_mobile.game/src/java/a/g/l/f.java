package a.g.l;

import android.view.LayoutInflater$Factory;
import android.os.Build$VERSION;
import android.util.Log;
import android.view.LayoutInflater$Factory2;
import android.view.LayoutInflater;
import java.lang.reflect.Field;

public final class f
{
    private static Field a;
    private static boolean b;
    
    private static void a(final LayoutInflater layoutInflater, final LayoutInflater$Factory2 layoutInflater$Factory2) {
        if (!f.b) {
            try {
                (f.a = LayoutInflater.class.getDeclaredField("mFactory2")).setAccessible(true);
            }
            catch (final NoSuchFieldException ex) {
                final StringBuilder sb = new StringBuilder();
                sb.append("forceSetFactory2 Could not find field 'mFactory2' on class ");
                sb.append(LayoutInflater.class.getName());
                sb.append("; inflation may have unexpected results.");
                Log.e("LayoutInflaterCompatHC", sb.toString(), (Throwable)ex);
            }
            f.b = true;
        }
        final Field a = f.a;
        if (a != null) {
            try {
                a.set((Object)layoutInflater, (Object)layoutInflater$Factory2);
            }
            catch (final IllegalAccessException ex2) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("forceSetFactory2 could not set the Factory2 on LayoutInflater ");
                sb2.append((Object)layoutInflater);
                sb2.append("; inflation may have unexpected results.");
                Log.e("LayoutInflaterCompatHC", sb2.toString(), (Throwable)ex2);
            }
        }
    }
    
    public static void b(final LayoutInflater layoutInflater, final LayoutInflater$Factory2 factory2) {
        layoutInflater.setFactory2(factory2);
        if (Build$VERSION.SDK_INT < 21) {
            final LayoutInflater$Factory factory3 = layoutInflater.getFactory();
            if (factory3 instanceof LayoutInflater$Factory2) {
                a(layoutInflater, (LayoutInflater$Factory2)factory3);
            }
            else {
                a(layoutInflater, factory2);
            }
        }
    }
}
