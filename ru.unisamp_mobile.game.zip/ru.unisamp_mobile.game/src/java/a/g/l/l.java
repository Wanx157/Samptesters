package a.g.l;

import android.view.View;

public interface l extends n
{
    void h(final View p0, final View p1, final int p2, final int p3);
    
    void i(final View p0, final int p1);
    
    void j(final View p0, final int p1, final int p2, final int[] p3, final int p4);
    
    void n(final View p0, final int p1, final int p2, final int p3, final int p4, final int p5);
    
    boolean o(final View p0, final View p1, final int p2, final int p3);
}
