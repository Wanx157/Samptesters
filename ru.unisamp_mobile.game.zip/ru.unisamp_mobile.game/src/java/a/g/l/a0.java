package a.g.l;

import android.view.View;

public interface a0
{
    void a(final View p0);
}
