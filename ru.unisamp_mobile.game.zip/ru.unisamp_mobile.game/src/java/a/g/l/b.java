package a.g.l;

import android.util.Log;
import android.view.SubMenu;
import android.view.MenuItem;
import android.view.View;
import android.content.Context;

public abstract class b
{
    private b a;
    
    public b(final Context context) {
    }
    
    public boolean a() {
        return false;
    }
    
    public boolean b() {
        return true;
    }
    
    public abstract View c();
    
    public View d(final MenuItem menuItem) {
        return this.c();
    }
    
    public boolean e() {
        return false;
    }
    
    public void f(final SubMenu subMenu) {
    }
    
    public boolean g() {
        return false;
    }
    
    public void h() {
        this.a = null;
    }
    
    public void i(final a a) {
    }
    
    public void j(final b a) {
        if (this.a != null && a != null) {
            final StringBuilder sb = new StringBuilder();
            sb.append("setVisibilityListener: Setting a new ActionProvider.VisibilityListener when one is already set. Are you reusing this ");
            sb.append(this.getClass().getSimpleName());
            sb.append(" instance while it is still in use somewhere else?");
            Log.w("ActionProvider(support)", sb.toString());
        }
        this.a = a;
    }
    
    public interface a
    {
    }
    
    public interface b
    {
        void onActionProviderVisibilityChanged(final boolean p0);
    }
}
