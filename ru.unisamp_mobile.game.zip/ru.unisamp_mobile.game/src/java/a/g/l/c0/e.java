package a.g.l.c0;

import android.view.View;
import android.os.Build$VERSION;
import android.view.accessibility.AccessibilityRecord;

public class e
{
    public static void a(final AccessibilityRecord accessibilityRecord, final int maxScrollX) {
        if (Build$VERSION.SDK_INT >= 15) {
            accessibilityRecord.setMaxScrollX(maxScrollX);
        }
    }
    
    public static void b(final AccessibilityRecord accessibilityRecord, final int maxScrollY) {
        if (Build$VERSION.SDK_INT >= 15) {
            accessibilityRecord.setMaxScrollY(maxScrollY);
        }
    }
    
    public static void c(final AccessibilityRecord accessibilityRecord, final View view, final int n) {
        if (Build$VERSION.SDK_INT >= 16) {
            accessibilityRecord.setSource(view, n);
        }
    }
}
