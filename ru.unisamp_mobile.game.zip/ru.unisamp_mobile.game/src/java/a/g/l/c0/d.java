package a.g.l.c0;

import java.util.ArrayList;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import android.os.Bundle;
import java.util.List;
import android.os.Build$VERSION;

public class d
{
    private final Object a;
    
    public d() {
        final int sdk_INT = Build$VERSION.SDK_INT;
        Object a;
        if (sdk_INT >= 19) {
            a = new d.d$b(this);
        }
        else if (sdk_INT >= 16) {
            a = new a(this);
        }
        else {
            a = null;
        }
        this.a = a;
    }
    
    public d(final Object a) {
        this.a = a;
    }
    
    public c a(final int n) {
        return null;
    }
    
    public List<c> b(final String s, final int n) {
        return null;
    }
    
    public c c(final int n) {
        return null;
    }
    
    public Object d() {
        return this.a;
    }
    
    public boolean e(final int n, final int n2, final Bundle bundle) {
        return false;
    }
    
    static class a extends AccessibilityNodeProvider
    {
        final d a;
        
        a(final d a) {
            this.a = a;
        }
        
        public AccessibilityNodeInfo createAccessibilityNodeInfo(final int n) {
            final c a = this.a.a(n);
            if (a == null) {
                return null;
            }
            return a.v0();
        }
        
        public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(final String s, int i) {
            final List<c> b = this.a.b(s, i);
            if (b == null) {
                return null;
            }
            final ArrayList list = new ArrayList();
            int size;
            for (size = b.size(), i = 0; i < size; ++i) {
                ((List)list).add((Object)((c)b.get(i)).v0());
            }
            return (List<AccessibilityNodeInfo>)list;
        }
        
        public boolean performAction(final int n, final int n2, final Bundle bundle) {
            return this.a.e(n, n2, bundle);
        }
    }
}
