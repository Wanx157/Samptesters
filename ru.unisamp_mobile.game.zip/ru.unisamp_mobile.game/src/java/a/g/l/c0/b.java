package a.g.l.c0;

import android.os.Build$VERSION;
import android.view.accessibility.AccessibilityEvent;

public final class b
{
    public static int a(final AccessibilityEvent accessibilityEvent) {
        if (Build$VERSION.SDK_INT >= 19) {
            return accessibilityEvent.getContentChangeTypes();
        }
        return 0;
    }
    
    public static void b(final AccessibilityEvent accessibilityEvent, final int contentChangeTypes) {
        if (Build$VERSION.SDK_INT >= 19) {
            accessibilityEvent.setContentChangeTypes(contentChangeTypes);
        }
    }
}
