package a.g.l.c0;

import android.os.Bundle;
import android.view.View;

public interface f
{
    boolean a(final View p0, final a p1);
    
    public abstract static class a
    {
        Bundle a;
        
        public void a(final Bundle a) {
            this.a = a;
        }
    }
}
