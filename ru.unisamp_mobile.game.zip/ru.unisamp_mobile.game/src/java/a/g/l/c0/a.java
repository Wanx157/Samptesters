package a.g.l.c0;

import android.os.Bundle;
import android.view.View;
import android.text.style.ClickableSpan;

public final class a extends ClickableSpan
{
    private final int b;
    private final c c;
    private final int d;
    
    public a(final int b, final c c, final int d) {
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public void onClick(final View view) {
        final Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.b);
        this.c.N(this.d, bundle);
    }
}
