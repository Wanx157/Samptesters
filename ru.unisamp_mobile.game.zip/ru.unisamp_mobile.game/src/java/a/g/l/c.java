package a.g.l;

public final class c
{
    private final Object a;
    
    private c(final Object a) {
        this.a = a;
    }
    
    static c a(final Object o) {
        c c;
        if (o == null) {
            c = null;
        }
        else {
            c = new c(o);
        }
        return c;
    }
    
    @Override
    public boolean equals(Object a) {
        boolean equals = true;
        if (this == a) {
            return true;
        }
        if (a != null && c.class == a.getClass()) {
            final c c = (c)a;
            a = this.a;
            final Object a2 = c.a;
            if (a == null) {
                if (a2 != null) {
                    equals = false;
                }
            }
            else {
                equals = a.equals(a2);
            }
            return equals;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        final Object a = this.a;
        int hashCode;
        if (a == null) {
            hashCode = 0;
        }
        else {
            hashCode = a.hashCode();
        }
        return hashCode;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("DisplayCutoutCompat{");
        sb.append(this.a);
        sb.append("}");
        return sb.toString();
    }
}
