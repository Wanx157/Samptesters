package a.g.l;

import android.view.accessibility.AccessibilityEvent;
import android.util.Log;
import android.os.Build$VERSION;
import android.view.View;
import android.view.ViewParent;

public final class w
{
    public static boolean a(final ViewParent viewParent, final View view, final float n, final float n2, final boolean b) {
        if (Build$VERSION.SDK_INT >= 21) {
            try {
                return viewParent.onNestedFling(view, n, n2, b);
            }
            catch (final AbstractMethodError abstractMethodError) {
                final StringBuilder sb = new StringBuilder();
                sb.append("ViewParent ");
                sb.append((Object)viewParent);
                sb.append(" does not implement interface method onNestedFling");
                Log.e("ViewParentCompat", sb.toString(), (Throwable)abstractMethodError);
                return false;
            }
        }
        if (viewParent instanceof n) {
            return ((n)viewParent).onNestedFling(view, n, n2, b);
        }
        return false;
    }
    
    public static boolean b(final ViewParent viewParent, final View view, final float n, final float n2) {
        if (Build$VERSION.SDK_INT >= 21) {
            try {
                return viewParent.onNestedPreFling(view, n, n2);
            }
            catch (final AbstractMethodError abstractMethodError) {
                final StringBuilder sb = new StringBuilder();
                sb.append("ViewParent ");
                sb.append((Object)viewParent);
                sb.append(" does not implement interface method onNestedPreFling");
                Log.e("ViewParentCompat", sb.toString(), (Throwable)abstractMethodError);
                return false;
            }
        }
        if (viewParent instanceof n) {
            return ((n)viewParent).onNestedPreFling(view, n, n2);
        }
        return false;
    }
    
    public static void c(final ViewParent viewParent, final View view, final int n, final int n2, final int[] array, final int n3) {
        if (viewParent instanceof l) {
            ((l)viewParent).j(view, n, n2, array, n3);
        }
        else if (n3 == 0) {
            if (Build$VERSION.SDK_INT >= 21) {
                try {
                    viewParent.onNestedPreScroll(view, n, n2, array);
                }
                catch (final AbstractMethodError abstractMethodError) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("ViewParent ");
                    sb.append((Object)viewParent);
                    sb.append(" does not implement interface method onNestedPreScroll");
                    Log.e("ViewParentCompat", sb.toString(), (Throwable)abstractMethodError);
                }
            }
            else if (viewParent instanceof n) {
                ((n)viewParent).onNestedPreScroll(view, n, n2, array);
            }
        }
    }
    
    public static void d(final ViewParent viewParent, final View view, final int n, final int n2, final int n3, final int n4, final int n5, final int[] array) {
        if (viewParent instanceof m) {
            ((m)viewParent).m(view, n, n2, n3, n4, n5, array);
        }
        else {
            array[0] += n3;
            array[1] += n4;
            if (viewParent instanceof l) {
                ((l)viewParent).n(view, n, n2, n3, n4, n5);
            }
            else if (n5 == 0) {
                if (Build$VERSION.SDK_INT >= 21) {
                    try {
                        viewParent.onNestedScroll(view, n, n2, n3, n4);
                    }
                    catch (final AbstractMethodError abstractMethodError) {
                        final StringBuilder sb = new StringBuilder();
                        sb.append("ViewParent ");
                        sb.append((Object)viewParent);
                        sb.append(" does not implement interface method onNestedScroll");
                        Log.e("ViewParentCompat", sb.toString(), (Throwable)abstractMethodError);
                    }
                }
                else if (viewParent instanceof n) {
                    ((n)viewParent).onNestedScroll(view, n, n2, n3, n4);
                }
            }
        }
    }
    
    public static void e(final ViewParent viewParent, final View view, final View view2, final int n, final int n2) {
        if (viewParent instanceof l) {
            ((l)viewParent).h(view, view2, n, n2);
        }
        else if (n2 == 0) {
            if (Build$VERSION.SDK_INT >= 21) {
                try {
                    viewParent.onNestedScrollAccepted(view, view2, n);
                }
                catch (final AbstractMethodError abstractMethodError) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("ViewParent ");
                    sb.append((Object)viewParent);
                    sb.append(" does not implement interface method onNestedScrollAccepted");
                    Log.e("ViewParentCompat", sb.toString(), (Throwable)abstractMethodError);
                }
            }
            else if (viewParent instanceof n) {
                ((n)viewParent).onNestedScrollAccepted(view, view2, n);
            }
        }
    }
    
    public static boolean f(final ViewParent viewParent, final View view, final View view2, final int n, final int n2) {
        if (viewParent instanceof l) {
            return ((l)viewParent).o(view, view2, n, n2);
        }
        if (n2 == 0) {
            if (Build$VERSION.SDK_INT >= 21) {
                try {
                    return viewParent.onStartNestedScroll(view, view2, n);
                }
                catch (final AbstractMethodError abstractMethodError) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("ViewParent ");
                    sb.append((Object)viewParent);
                    sb.append(" does not implement interface method onStartNestedScroll");
                    Log.e("ViewParentCompat", sb.toString(), (Throwable)abstractMethodError);
                    return false;
                }
            }
            if (viewParent instanceof n) {
                return ((n)viewParent).onStartNestedScroll(view, view2, n);
            }
        }
        return false;
    }
    
    public static void g(final ViewParent viewParent, final View view, final int n) {
        if (viewParent instanceof l) {
            ((l)viewParent).i(view, n);
        }
        else if (n == 0) {
            if (Build$VERSION.SDK_INT >= 21) {
                try {
                    viewParent.onStopNestedScroll(view);
                }
                catch (final AbstractMethodError abstractMethodError) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("ViewParent ");
                    sb.append((Object)viewParent);
                    sb.append(" does not implement interface method onStopNestedScroll");
                    Log.e("ViewParentCompat", sb.toString(), (Throwable)abstractMethodError);
                }
            }
            else if (viewParent instanceof n) {
                ((n)viewParent).onStopNestedScroll(view);
            }
        }
    }
    
    @Deprecated
    public static boolean h(final ViewParent viewParent, final View view, final AccessibilityEvent accessibilityEvent) {
        return viewParent.requestSendAccessibilityEvent(view, accessibilityEvent);
    }
}
