package a.g.l;

import android.view.View;

public interface p
{
    b0 a(final View p0, final b0 p1);
}
