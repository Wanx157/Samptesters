package a.g.l;

import android.view.View;
import a.g.c;
import android.os.Build$VERSION;
import android.view.ViewGroup;

public final class v
{
    public static boolean a(final ViewGroup viewGroup) {
        if (Build$VERSION.SDK_INT >= 21) {
            return viewGroup.isTransitionGroup();
        }
        final Boolean b = (Boolean)viewGroup.getTag(c.tag_transition_group);
        return (b != null && b) || viewGroup.getBackground() != null || t.I((View)viewGroup) != null;
    }
}
