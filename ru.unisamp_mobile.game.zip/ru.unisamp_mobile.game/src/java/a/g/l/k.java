package a.g.l;

import android.view.View;
import android.view.ViewParent;

public class k
{
    private ViewParent a;
    private ViewParent b;
    private final View c;
    private boolean d;
    private int[] e;
    
    public k(final View c) {
        this.c = c;
    }
    
    private boolean g(final int n, final int n2, final int n3, final int n4, final int[] array, final int n5, int[] i) {
        if (this.l()) {
            final ViewParent h = this.h(n5);
            if (h == null) {
                return false;
            }
            if (n != 0 || n2 != 0 || n3 != 0 || n4 != 0) {
                int n6;
                int n7;
                if (array != null) {
                    this.c.getLocationInWindow(array);
                    n6 = array[0];
                    n7 = array[1];
                }
                else {
                    n6 = 0;
                    n7 = 0;
                }
                if (i == null) {
                    i = this.i();
                    i[1] = (i[0] = 0);
                }
                w.d(h, this.c, n, n2, n3, n4, n5, i);
                if (array != null) {
                    this.c.getLocationInWindow(array);
                    array[0] -= n6;
                    array[1] -= n7;
                }
                return true;
            }
            if (array != null) {
                array[1] = (array[0] = 0);
            }
        }
        return false;
    }
    
    private ViewParent h(final int n) {
        if (n == 0) {
            return this.a;
        }
        if (n != 1) {
            return null;
        }
        return this.b;
    }
    
    private int[] i() {
        if (this.e == null) {
            this.e = new int[2];
        }
        return this.e;
    }
    
    private void n(final int n, final ViewParent viewParent) {
        if (n != 0) {
            if (n == 1) {
                this.b = viewParent;
            }
        }
        else {
            this.a = viewParent;
        }
    }
    
    public boolean a(final float n, final float n2, final boolean b) {
        if (this.l()) {
            final ViewParent h = this.h(0);
            if (h != null) {
                return w.a(h, this.c, n, n2, b);
            }
        }
        return false;
    }
    
    public boolean b(final float n, final float n2) {
        if (this.l()) {
            final ViewParent h = this.h(0);
            if (h != null) {
                return w.b(h, this.c, n, n2);
            }
        }
        return false;
    }
    
    public boolean c(final int n, final int n2, final int[] array, final int[] array2) {
        return this.d(n, n2, array, array2, 0);
    }
    
    public boolean d(final int n, final int n2, final int[] array, final int[] array2, final int n3) {
        final boolean l = this.l();
        boolean b2;
        final boolean b = b2 = false;
        if (l) {
            final ViewParent h = this.h(n3);
            if (h == null) {
                return false;
            }
            if (n == 0 && n2 == 0) {
                b2 = b;
                if (array2 != null) {
                    array2[1] = (array2[0] = 0);
                    b2 = b;
                }
            }
            else {
                int n4;
                int n5;
                if (array2 != null) {
                    this.c.getLocationInWindow(array2);
                    n4 = array2[0];
                    n5 = array2[1];
                }
                else {
                    n4 = 0;
                    n5 = 0;
                }
                int[] i = array;
                if (array == null) {
                    i = this.i();
                }
                i[1] = (i[0] = 0);
                w.c(h, this.c, n, n2, i, n3);
                if (array2 != null) {
                    this.c.getLocationInWindow(array2);
                    array2[0] -= n4;
                    array2[1] -= n5;
                }
                if (i[0] == 0) {
                    b2 = b;
                    if (i[1] == 0) {
                        return b2;
                    }
                }
                b2 = true;
            }
        }
        return b2;
    }
    
    public void e(final int n, final int n2, final int n3, final int n4, final int[] array, final int n5, final int[] array2) {
        this.g(n, n2, n3, n4, array, n5, array2);
    }
    
    public boolean f(final int n, final int n2, final int n3, final int n4, final int[] array) {
        return this.g(n, n2, n3, n4, array, 0, null);
    }
    
    public boolean j() {
        return this.k(0);
    }
    
    public boolean k(final int n) {
        return this.h(n) != null;
    }
    
    public boolean l() {
        return this.d;
    }
    
    public void m(final boolean d) {
        if (this.d) {
            t.A0(this.c);
        }
        this.d = d;
    }
    
    public boolean o(final int n) {
        return this.p(n, 0);
    }
    
    public boolean p(final int n, final int n2) {
        if (this.k(n2)) {
            return true;
        }
        if (this.l()) {
            ViewParent viewParent = this.c.getParent();
            View c = this.c;
            while (viewParent != null) {
                if (w.f(viewParent, c, this.c, n, n2)) {
                    this.n(n2, viewParent);
                    w.e(viewParent, c, this.c, n, n2);
                    return true;
                }
                if (viewParent instanceof View) {
                    c = (View)viewParent;
                }
                viewParent = viewParent.getParent();
            }
        }
        return false;
    }
    
    public void q() {
        this.r(0);
    }
    
    public void r(final int n) {
        final ViewParent h = this.h(n);
        if (h != null) {
            w.g(h, this.c, n);
            this.n(n, null);
        }
    }
}
