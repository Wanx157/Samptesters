package a.g.l;

import android.view.View;

public interface y
{
    void a(final View p0);
    
    void b(final View p0);
    
    void c(final View p0);
}
