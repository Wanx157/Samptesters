package a.g.l;

import android.graphics.PorterDuff$Mode;
import android.content.res.ColorStateList;
import android.os.Build$VERSION;
import android.util.Log;
import android.view.MenuItem;

public final class h
{
    public static MenuItem a(final MenuItem menuItem, final b b) {
        if (menuItem instanceof a.g.f.a.b) {
            return (MenuItem)((a.g.f.a.b)menuItem).a(b);
        }
        Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
        return menuItem;
    }
    
    public static void b(final MenuItem menuItem, final char c, final int n) {
        if (menuItem instanceof a.g.f.a.b) {
            ((a.g.f.a.b)menuItem).setAlphabeticShortcut(c, n);
        }
        else if (Build$VERSION.SDK_INT >= 26) {
            menuItem.setAlphabeticShortcut(c, n);
        }
    }
    
    public static void c(final MenuItem menuItem, final CharSequence charSequence) {
        if (menuItem instanceof a.g.f.a.b) {
            ((a.g.f.a.b)menuItem).setContentDescription(charSequence);
        }
        else if (Build$VERSION.SDK_INT >= 26) {
            menuItem.setContentDescription(charSequence);
        }
    }
    
    public static void d(final MenuItem menuItem, final ColorStateList list) {
        if (menuItem instanceof a.g.f.a.b) {
            ((a.g.f.a.b)menuItem).setIconTintList(list);
        }
        else if (Build$VERSION.SDK_INT >= 26) {
            menuItem.setIconTintList(list);
        }
    }
    
    public static void e(final MenuItem menuItem, final PorterDuff$Mode porterDuff$Mode) {
        if (menuItem instanceof a.g.f.a.b) {
            ((a.g.f.a.b)menuItem).setIconTintMode(porterDuff$Mode);
        }
        else if (Build$VERSION.SDK_INT >= 26) {
            menuItem.setIconTintMode(porterDuff$Mode);
        }
    }
    
    public static void f(final MenuItem menuItem, final char c, final int n) {
        if (menuItem instanceof a.g.f.a.b) {
            ((a.g.f.a.b)menuItem).setNumericShortcut(c, n);
        }
        else if (Build$VERSION.SDK_INT >= 26) {
            menuItem.setNumericShortcut(c, n);
        }
    }
    
    public static void g(final MenuItem menuItem, final CharSequence charSequence) {
        if (menuItem instanceof a.g.f.a.b) {
            ((a.g.f.a.b)menuItem).setTooltipText(charSequence);
        }
        else if (Build$VERSION.SDK_INT >= 26) {
            menuItem.setTooltipText(charSequence);
        }
    }
}
