package a.g.l;

import android.view.PointerIcon;
import android.os.Build$VERSION;
import android.content.Context;

public final class r
{
    private Object a;
    
    private r(final Object a) {
        this.a = a;
    }
    
    public static r b(final Context context, final int n) {
        if (Build$VERSION.SDK_INT >= 24) {
            return new r(PointerIcon.getSystemIcon(context, n));
        }
        return new r(null);
    }
    
    public Object a() {
        return this.a;
    }
}
