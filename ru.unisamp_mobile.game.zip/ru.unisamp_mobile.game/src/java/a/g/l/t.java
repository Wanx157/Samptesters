package a.g.l;

import android.view.ViewGroup;
import android.util.SparseArray;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Map$Entry;
import android.view.View$OnAttachStateChangeListener;
import android.view.ViewTreeObserver$OnGlobalLayoutListener;
import android.view.PointerIcon;
import android.view.View$OnApplyWindowInsetsListener;
import android.view.WindowManager;
import android.view.Display;
import java.util.ArrayList;
import android.graphics.PorterDuff$Mode;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.view.View$AccessibilityDelegate;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.content.Context;
import android.view.KeyEvent;
import java.util.List;
import android.animation.ValueAnimator;
import a.g.l.c0.f;
import android.os.Bundle;
import android.view.WindowInsets;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.util.Log;
import android.view.accessibility.AccessibilityManager;
import android.annotation.SuppressLint;
import android.os.Build$VERSION;
import a.g.c;
import android.graphics.Rect;
import android.view.View;
import java.util.WeakHashMap;
import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicInteger;

public class t
{
    private static final AtomicInteger a;
    private static Field b;
    private static boolean c;
    private static Field d;
    private static boolean e;
    private static WeakHashMap<View, String> f;
    private static WeakHashMap<View, x> g;
    private static Field h;
    private static boolean i;
    private static ThreadLocal<Rect> j;
    private static final int[] k;
    
    static {
        a = new AtomicInteger(1);
        t.g = null;
        t.i = false;
        k = new int[] { a.g.c.accessibility_custom_action_0, a.g.c.accessibility_custom_action_1, a.g.c.accessibility_custom_action_2, a.g.c.accessibility_custom_action_3, a.g.c.accessibility_custom_action_4, a.g.c.accessibility_custom_action_5, a.g.c.accessibility_custom_action_6, a.g.c.accessibility_custom_action_7, a.g.c.accessibility_custom_action_8, a.g.c.accessibility_custom_action_9, a.g.c.accessibility_custom_action_10, a.g.c.accessibility_custom_action_11, a.g.c.accessibility_custom_action_12, a.g.c.accessibility_custom_action_13, a.g.c.accessibility_custom_action_14, a.g.c.accessibility_custom_action_15, a.g.c.accessibility_custom_action_16, a.g.c.accessibility_custom_action_17, a.g.c.accessibility_custom_action_18, a.g.c.accessibility_custom_action_19, a.g.c.accessibility_custom_action_20, a.g.c.accessibility_custom_action_21, a.g.c.accessibility_custom_action_22, a.g.c.accessibility_custom_action_23, a.g.c.accessibility_custom_action_24, a.g.c.accessibility_custom_action_25, a.g.c.accessibility_custom_action_26, a.g.c.accessibility_custom_action_27, a.g.c.accessibility_custom_action_28, a.g.c.accessibility_custom_action_29, a.g.c.accessibility_custom_action_30, a.g.c.accessibility_custom_action_31 };
        new e();
    }
    
    @SuppressLint({ "InlinedApi" })
    public static int A(final View view) {
        if (Build$VERSION.SDK_INT >= 26) {
            return view.getImportantForAutofill();
        }
        return 0;
    }
    
    public static void A0(final View view) {
        if (Build$VERSION.SDK_INT >= 21) {
            view.stopNestedScroll();
        }
        else if (view instanceof a.g.l.j) {
            ((a.g.l.j)view).stopNestedScroll();
        }
    }
    
    public static int B(final View view) {
        if (Build$VERSION.SDK_INT >= 17) {
            return view.getLayoutDirection();
        }
        return 0;
    }
    
    private static void B0(final View view) {
        final float translationY = view.getTranslationY();
        view.setTranslationY(1.0f + translationY);
        view.setTranslationY(translationY);
    }
    
    public static int C(final View p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          16
        //     5: if_icmplt       13
        //     8: aload_0        
        //     9: invokevirtual   android/view/View.getMinimumHeight:()I
        //    12: ireturn        
        //    13: getstatic       a/g/l/t.e:Z
        //    16: ifne            40
        //    19: ldc             Landroid/view/View;.class
        //    21: ldc             "mMinHeight"
        //    23: invokevirtual   java/lang/Class.getDeclaredField:(Ljava/lang/String;)Ljava/lang/reflect/Field;
        //    26: astore_2       
        //    27: aload_2        
        //    28: putstatic       a/g/l/t.d:Ljava/lang/reflect/Field;
        //    31: aload_2        
        //    32: iconst_1       
        //    33: invokevirtual   java/lang/reflect/Field.setAccessible:(Z)V
        //    36: iconst_1       
        //    37: putstatic       a/g/l/t.e:Z
        //    40: getstatic       a/g/l/t.d:Ljava/lang/reflect/Field;
        //    43: astore_2       
        //    44: aload_2        
        //    45: ifnull          62
        //    48: aload_2        
        //    49: aload_0        
        //    50: invokevirtual   java/lang/reflect/Field.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    53: checkcast       Ljava/lang/Integer;
        //    56: invokevirtual   java/lang/Integer.intValue:()I
        //    59: istore_1       
        //    60: iload_1        
        //    61: ireturn        
        //    62: iconst_0       
        //    63: ireturn        
        //    64: astore_2       
        //    65: goto            36
        //    68: astore_0       
        //    69: goto            62
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  19     36     64     68     Ljava/lang/NoSuchFieldException;
        //  48     60     68     72     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0062:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static int D(final View p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          16
        //     5: if_icmplt       13
        //     8: aload_0        
        //     9: invokevirtual   android/view/View.getMinimumWidth:()I
        //    12: ireturn        
        //    13: getstatic       a/g/l/t.c:Z
        //    16: ifne            40
        //    19: ldc             Landroid/view/View;.class
        //    21: ldc             "mMinWidth"
        //    23: invokevirtual   java/lang/Class.getDeclaredField:(Ljava/lang/String;)Ljava/lang/reflect/Field;
        //    26: astore_2       
        //    27: aload_2        
        //    28: putstatic       a/g/l/t.b:Ljava/lang/reflect/Field;
        //    31: aload_2        
        //    32: iconst_1       
        //    33: invokevirtual   java/lang/reflect/Field.setAccessible:(Z)V
        //    36: iconst_1       
        //    37: putstatic       a/g/l/t.c:Z
        //    40: getstatic       a/g/l/t.b:Ljava/lang/reflect/Field;
        //    43: astore_2       
        //    44: aload_2        
        //    45: ifnull          62
        //    48: aload_2        
        //    49: aload_0        
        //    50: invokevirtual   java/lang/reflect/Field.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    53: checkcast       Ljava/lang/Integer;
        //    56: invokevirtual   java/lang/Integer.intValue:()I
        //    59: istore_1       
        //    60: iload_1        
        //    61: ireturn        
        //    62: iconst_0       
        //    63: ireturn        
        //    64: astore_2       
        //    65: goto            36
        //    68: astore_0       
        //    69: goto            62
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  19     36     64     68     Ljava/lang/NoSuchFieldException;
        //  48     60     68     72     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0062:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static a E(final View view) {
        a l;
        if ((l = l(view)) == null) {
            l = new a();
        }
        k0(view, l);
        return l;
    }
    
    public static int F(final View view) {
        if (Build$VERSION.SDK_INT >= 17) {
            return view.getPaddingEnd();
        }
        return view.getPaddingRight();
    }
    
    public static int G(final View view) {
        if (Build$VERSION.SDK_INT >= 17) {
            return view.getPaddingStart();
        }
        return view.getPaddingLeft();
    }
    
    public static b0 H(final View view) {
        if (Build$VERSION.SDK_INT >= 23) {
            return b0.o(t.h.a(view));
        }
        return null;
    }
    
    public static String I(final View view) {
        if (Build$VERSION.SDK_INT >= 21) {
            return view.getTransitionName();
        }
        final WeakHashMap<View, String> f = t.f;
        if (f == null) {
            return null;
        }
        return (String)f.get((Object)view);
    }
    
    public static int J(final View view) {
        if (Build$VERSION.SDK_INT >= 16) {
            return view.getWindowSystemUiVisibility();
        }
        return 0;
    }
    
    public static float K(final View view) {
        if (Build$VERSION.SDK_INT >= 21) {
            return view.getZ();
        }
        return 0.0f;
    }
    
    public static boolean L(final View view) {
        return Build$VERSION.SDK_INT >= 15 && view.hasOnClickListeners();
    }
    
    public static boolean M(final View view) {
        return Build$VERSION.SDK_INT < 16 || view.hasOverlappingRendering();
    }
    
    public static boolean N(final View view) {
        return Build$VERSION.SDK_INT >= 16 && view.hasTransientState();
    }
    
    public static boolean O(final View view) {
        final Boolean b = a().f(view);
        return b != null && b;
    }
    
    public static boolean P(final View view) {
        if (Build$VERSION.SDK_INT >= 19) {
            return view.isAttachedToWindow();
        }
        return view.getWindowToken() != null;
    }
    
    public static boolean Q(final View view) {
        if (Build$VERSION.SDK_INT >= 19) {
            return view.isLaidOut();
        }
        return view.getWidth() > 0 && view.getHeight() > 0;
    }
    
    public static boolean R(final View view) {
        if (Build$VERSION.SDK_INT >= 21) {
            return view.isNestedScrollingEnabled();
        }
        return view instanceof a.g.l.j && ((a.g.l.j)view).isNestedScrollingEnabled();
    }
    
    public static boolean S(final View view) {
        return Build$VERSION.SDK_INT >= 17 && view.isPaddingRelative();
    }
    
    public static boolean T(final View view) {
        final Boolean b = j0().f(view);
        return b != null && b;
    }
    
    static void U(final View view, final int contentChangeTypes) {
        if (!((AccessibilityManager)view.getContext().getSystemService("accessibility")).isEnabled()) {
            return;
        }
        final boolean b = p(view) != null;
        if (o(view) == 0 && (!b || view.getVisibility() != 0)) {
            if (view.getParent() != null) {
                try {
                    view.getParent().notifySubtreeAccessibilityStateChanged(view, view, contentChangeTypes);
                }
                catch (final AbstractMethodError abstractMethodError) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append(view.getParent().getClass().getSimpleName());
                    sb.append(" does not fully implement ViewParent");
                    Log.e("ViewCompat", sb.toString(), (Throwable)abstractMethodError);
                }
            }
        }
        else {
            final AccessibilityEvent obtain = AccessibilityEvent.obtain();
            int eventType;
            if (b) {
                eventType = 32;
            }
            else {
                eventType = 2048;
            }
            obtain.setEventType(eventType);
            obtain.setContentChangeTypes(contentChangeTypes);
            view.sendAccessibilityEventUnchecked(obtain);
        }
    }
    
    public static void V(final View view, final int n) {
        final int sdk_INT = Build$VERSION.SDK_INT;
        if (sdk_INT >= 23) {
            view.offsetLeftAndRight(n);
        }
        else if (sdk_INT >= 21) {
            final Rect x = x();
            boolean b = false;
            final ViewParent parent = view.getParent();
            if (parent instanceof View) {
                final View view2 = (View)parent;
                x.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
                b = (x.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom()) ^ true);
            }
            e(view, n);
            if (b && x.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
                ((View)parent).invalidate(x);
            }
        }
        else {
            e(view, n);
        }
    }
    
    public static void W(final View view, final int n) {
        final int sdk_INT = Build$VERSION.SDK_INT;
        if (sdk_INT >= 23) {
            view.offsetTopAndBottom(n);
        }
        else if (sdk_INT >= 21) {
            final Rect x = x();
            boolean b = false;
            final ViewParent parent = view.getParent();
            if (parent instanceof View) {
                final View view2 = (View)parent;
                x.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
                b = (x.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom()) ^ true);
            }
            f(view, n);
            if (b && x.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
                ((View)parent).invalidate(x);
            }
        }
        else {
            f(view, n);
        }
    }
    
    public static b0 X(final View view, final b0 b0) {
        if (Build$VERSION.SDK_INT >= 21) {
            final WindowInsets n = b0.n();
            if (n != null) {
                final WindowInsets onApplyWindowInsets = view.onApplyWindowInsets(n);
                if (!onApplyWindowInsets.equals((Object)n)) {
                    return b0.o(onApplyWindowInsets);
                }
            }
        }
        return b0;
    }
    
    public static void Y(final View view, final a.g.l.c0.c c) {
        view.onInitializeAccessibilityNodeInfo(c.v0());
    }
    
    private static f<CharSequence> Z() {
        return (f<CharSequence>)new t$c(a.g.c.tag_accessibility_pane_title, (Class)CharSequence.class, 8, 28);
    }
    
    private static f<Boolean> a() {
        return (f<Boolean>)new t$d(a.g.c.tag_accessibility_heading, (Class)Boolean.class, 28);
    }
    
    public static boolean a0(final View view, final int n, final Bundle bundle) {
        return Build$VERSION.SDK_INT >= 16 && view.performAccessibilityAction(n, bundle);
    }
    
    public static int b(final View view, final CharSequence charSequence, final a.g.l.c0.f f) {
        final int r = r(view);
        if (r != -1) {
            c(view, new a.g.l.c0.c.a(r, charSequence, f));
        }
        return r;
    }
    
    public static void b0(final View view) {
        if (Build$VERSION.SDK_INT >= 16) {
            view.postInvalidateOnAnimation();
        }
        else {
            view.postInvalidate();
        }
    }
    
    private static void c(final View view, final a.g.l.c0.c.a a) {
        if (Build$VERSION.SDK_INT >= 21) {
            E(view);
            f0(a.b(), view);
            q(view).add((Object)a);
            U(view, 0);
        }
    }
    
    public static void c0(final View view, final Runnable runnable) {
        if (Build$VERSION.SDK_INT >= 16) {
            view.postOnAnimation(runnable);
        }
        else {
            view.postDelayed(runnable, ValueAnimator.getFrameDelay());
        }
    }
    
    public static x d(final View view) {
        if (t.g == null) {
            t.g = (WeakHashMap<View, x>)new WeakHashMap();
        }
        x x;
        if ((x = (x)t.g.get((Object)view)) == null) {
            x = new x(view);
            t.g.put((Object)view, (Object)x);
        }
        return x;
    }
    
    public static void d0(final View view, final Runnable runnable, final long n) {
        if (Build$VERSION.SDK_INT >= 16) {
            view.postOnAnimationDelayed(runnable, n);
        }
        else {
            view.postDelayed(runnable, ValueAnimator.getFrameDelay() + n);
        }
    }
    
    private static void e(final View view, final int n) {
        view.offsetLeftAndRight(n);
        if (view.getVisibility() == 0) {
            B0(view);
            final ViewParent parent = view.getParent();
            if (parent instanceof View) {
                B0((View)parent);
            }
        }
    }
    
    public static void e0(final View view, final int n) {
        if (Build$VERSION.SDK_INT >= 21) {
            f0(n, view);
            U(view, 0);
        }
    }
    
    private static void f(final View view, final int n) {
        view.offsetTopAndBottom(n);
        if (view.getVisibility() == 0) {
            B0(view);
            final ViewParent parent = view.getParent();
            if (parent instanceof View) {
                B0((View)parent);
            }
        }
    }
    
    private static void f0(final int n, final View view) {
        final List<a.g.l.c0.c.a> q = q(view);
        for (int i = 0; i < q.size(); ++i) {
            if (((a.g.l.c0.c.a)q.get(i)).b() == n) {
                q.remove(i);
                break;
            }
        }
    }
    
    public static b0 g(final View view, final b0 b0, final Rect rect) {
        if (Build$VERSION.SDK_INT >= 21) {
            return t.g.a(view, b0, rect);
        }
        return b0;
    }
    
    public static void g0(final View view, final a.g.l.c0.c.a a, final CharSequence charSequence, final a.g.l.c0.f f) {
        if (f == null && charSequence == null) {
            e0(view, a.b());
        }
        else {
            c(view, a.a(charSequence, f));
        }
    }
    
    public static b0 h(final View view, final b0 b0) {
        if (Build$VERSION.SDK_INT >= 21) {
            final WindowInsets n = b0.n();
            if (n != null && !view.dispatchApplyWindowInsets(n).equals((Object)n)) {
                return b0.o(n);
            }
        }
        return b0;
    }
    
    public static void h0(final View view) {
        final int sdk_INT = Build$VERSION.SDK_INT;
        if (sdk_INT >= 20) {
            view.requestApplyInsets();
        }
        else if (sdk_INT >= 16) {
            view.requestFitSystemWindows();
        }
    }
    
    static boolean i(final View view, final KeyEvent keyEvent) {
        return Build$VERSION.SDK_INT < 28 && t.k.a(view).b(view, keyEvent);
    }
    
    public static void i0(final View view, @SuppressLint({ "ContextFirst" }) final Context context, final int[] array, final AttributeSet set, final TypedArray typedArray, final int n, final int n2) {
        if (Build$VERSION.SDK_INT >= 29) {
            t.i.a(view, context, array, set, typedArray, n, n2);
        }
    }
    
    static boolean j(final View view, final KeyEvent keyEvent) {
        return Build$VERSION.SDK_INT < 28 && t.k.a(view).f(keyEvent);
    }
    
    private static f<Boolean> j0() {
        return (f<Boolean>)new t$b(a.g.c.tag_screen_reader_focusable, (Class)Boolean.class, 28);
    }
    
    public static int k() {
        if (Build$VERSION.SDK_INT >= 17) {
            return View.generateViewId();
        }
        int value;
        int n;
        do {
            value = t.a.get();
            if ((n = value + 1) > 16777215) {
                n = 1;
            }
        } while (!t.a.compareAndSet(value, n));
        return value;
    }
    
    public static void k0(final View view, final a a) {
        a a2 = a;
        if (a == null) {
            a2 = a;
            if (m(view) instanceof a.a) {
                a2 = new a();
            }
        }
        View$AccessibilityDelegate d;
        if (a2 == null) {
            d = null;
        }
        else {
            d = a2.d();
        }
        view.setAccessibilityDelegate(d);
    }
    
    public static a l(final View view) {
        final View$AccessibilityDelegate m = m(view);
        if (m == null) {
            return null;
        }
        if (m instanceof a.a) {
            return ((a.a)m).a;
        }
        return new a(m);
    }
    
    public static void l0(final View view, final boolean b) {
        a().g(view, b);
    }
    
    private static View$AccessibilityDelegate m(final View view) {
        if (Build$VERSION.SDK_INT >= 29) {
            return view.getAccessibilityDelegate();
        }
        return n(view);
    }
    
    public static void m0(final View view, final int accessibilityLiveRegion) {
        if (Build$VERSION.SDK_INT >= 19) {
            view.setAccessibilityLiveRegion(accessibilityLiveRegion);
        }
    }
    
    private static View$AccessibilityDelegate n(final View view) {
        if (t.i) {
            return null;
        }
        if (t.h == null) {
            try {
                (t.h = View.class.getDeclaredField("mAccessibilityDelegate")).setAccessible(true);
            }
            finally {
                t.i = true;
                return null;
            }
        }
        try {
            final Object value = t.h.get((Object)view);
            if (value instanceof View$AccessibilityDelegate) {
                return (View$AccessibilityDelegate)value;
            }
            return null;
        }
        finally {
            t.i = true;
            return null;
        }
    }
    
    public static void n0(final View view, final Drawable drawable) {
        if (Build$VERSION.SDK_INT >= 16) {
            view.setBackground(drawable);
        }
        else {
            view.setBackgroundDrawable(drawable);
        }
    }
    
    public static int o(final View view) {
        if (Build$VERSION.SDK_INT >= 19) {
            return view.getAccessibilityLiveRegion();
        }
        return 0;
    }
    
    public static void o0(final View view, final ColorStateList list) {
        if (Build$VERSION.SDK_INT >= 21) {
            view.setBackgroundTintList(list);
            if (Build$VERSION.SDK_INT == 21) {
                final Drawable background = view.getBackground();
                final boolean b = view.getBackgroundTintList() != null || view.getBackgroundTintMode() != null;
                if (background != null && b) {
                    if (background.isStateful()) {
                        background.setState(view.getDrawableState());
                    }
                    view.setBackground(background);
                }
            }
        }
        else if (view instanceof s) {
            ((s)view).setSupportBackgroundTintList(list);
        }
    }
    
    public static CharSequence p(final View view) {
        return Z().f(view);
    }
    
    public static void p0(final View view, final PorterDuff$Mode porterDuff$Mode) {
        if (Build$VERSION.SDK_INT >= 21) {
            view.setBackgroundTintMode(porterDuff$Mode);
            if (Build$VERSION.SDK_INT == 21) {
                final Drawable background = view.getBackground();
                final boolean b = view.getBackgroundTintList() != null || view.getBackgroundTintMode() != null;
                if (background != null && b) {
                    if (background.isStateful()) {
                        background.setState(view.getDrawableState());
                    }
                    view.setBackground(background);
                }
            }
        }
        else if (view instanceof s) {
            ((s)view).setSupportBackgroundTintMode(porterDuff$Mode);
        }
    }
    
    private static List<a.g.l.c0.c.a> q(final View view) {
        ArrayList list;
        if ((list = (ArrayList)view.getTag(a.g.c.tag_accessibility_actions)) == null) {
            list = new ArrayList();
            view.setTag(a.g.c.tag_accessibility_actions, (Object)list);
        }
        return (List<a.g.l.c0.c.a>)list;
    }
    
    public static void q0(final View view, final Rect clipBounds) {
        if (Build$VERSION.SDK_INT >= 18) {
            view.setClipBounds(clipBounds);
        }
    }
    
    private static int r(final View view) {
        final List<a.g.l.c0.c.a> q = q(view);
        int n = 0;
        int n2 = -1;
        while (true) {
            final int[] k = t.k;
            if (n >= k.length || n2 != -1) {
                break;
            }
            final int n3 = k[n];
            int i = 0;
            boolean b = true;
            while (i < q.size()) {
                b &= (((a.g.l.c0.c.a)q.get(i)).b() != n3);
                ++i;
            }
            if (b) {
                n2 = n3;
            }
            ++n;
        }
        return n2;
    }
    
    public static void r0(final View view, final float elevation) {
        if (Build$VERSION.SDK_INT >= 21) {
            view.setElevation(elevation);
        }
    }
    
    public static ColorStateList s(final View view) {
        if (Build$VERSION.SDK_INT >= 21) {
            return view.getBackgroundTintList();
        }
        ColorStateList supportBackgroundTintList;
        if (view instanceof s) {
            supportBackgroundTintList = ((s)view).getSupportBackgroundTintList();
        }
        else {
            supportBackgroundTintList = null;
        }
        return supportBackgroundTintList;
    }
    
    public static void s0(final View view, final boolean hasTransientState) {
        if (Build$VERSION.SDK_INT >= 16) {
            view.setHasTransientState(hasTransientState);
        }
    }
    
    public static PorterDuff$Mode t(final View view) {
        if (Build$VERSION.SDK_INT >= 21) {
            return view.getBackgroundTintMode();
        }
        PorterDuff$Mode supportBackgroundTintMode;
        if (view instanceof s) {
            supportBackgroundTintMode = ((s)view).getSupportBackgroundTintMode();
        }
        else {
            supportBackgroundTintMode = null;
        }
        return supportBackgroundTintMode;
    }
    
    public static void t0(final View view, final int n) {
        final int sdk_INT = Build$VERSION.SDK_INT;
        int importantForAccessibility;
        if (sdk_INT >= 19) {
            importantForAccessibility = n;
        }
        else {
            if (sdk_INT < 16) {
                return;
            }
            if ((importantForAccessibility = n) == 4) {
                importantForAccessibility = 2;
            }
        }
        view.setImportantForAccessibility(importantForAccessibility);
    }
    
    public static Rect u(final View view) {
        if (Build$VERSION.SDK_INT >= 18) {
            return view.getClipBounds();
        }
        return null;
    }
    
    public static void u0(final View view, final int importantForAutofill) {
        if (Build$VERSION.SDK_INT >= 26) {
            view.setImportantForAutofill(importantForAutofill);
        }
    }
    
    public static Display v(final View view) {
        if (Build$VERSION.SDK_INT >= 17) {
            return view.getDisplay();
        }
        if (P(view)) {
            return ((WindowManager)view.getContext().getSystemService("window")).getDefaultDisplay();
        }
        return null;
    }
    
    public static void v0(final View view, final p p2) {
        if (Build$VERSION.SDK_INT >= 21) {
            if (p2 == null) {
                view.setOnApplyWindowInsetsListener((View$OnApplyWindowInsetsListener)null);
                return;
            }
            view.setOnApplyWindowInsetsListener((View$OnApplyWindowInsetsListener)new View$OnApplyWindowInsetsListener(p2) {
                final p a;
                
                public WindowInsets onApplyWindowInsets(final View view, final WindowInsets windowInsets) {
                    return this.a.a(view, b0.o(windowInsets)).n();
                }
            });
        }
    }
    
    public static float w(final View view) {
        if (Build$VERSION.SDK_INT >= 21) {
            return view.getElevation();
        }
        return 0.0f;
    }
    
    public static void w0(final View view, final int n, final int n2, final int n3, final int n4) {
        if (Build$VERSION.SDK_INT >= 17) {
            view.setPaddingRelative(n, n2, n3, n4);
        }
        else {
            view.setPadding(n, n2, n3, n4);
        }
    }
    
    private static Rect x() {
        if (t.j == null) {
            t.j = (ThreadLocal<Rect>)new ThreadLocal();
        }
        Rect rect;
        if ((rect = (Rect)t.j.get()) == null) {
            rect = new Rect();
            t.j.set((Object)rect);
        }
        rect.setEmpty();
        return rect;
    }
    
    public static void x0(final View view, final r r) {
        if (Build$VERSION.SDK_INT >= 24) {
            Object a;
            if (r != null) {
                a = r.a();
            }
            else {
                a = null;
            }
            view.setPointerIcon((PointerIcon)a);
        }
    }
    
    public static boolean y(final View view) {
        return Build$VERSION.SDK_INT >= 16 && view.getFitsSystemWindows();
    }
    
    public static void y0(final View view, final int n, final int n2) {
        if (Build$VERSION.SDK_INT >= 23) {
            view.setScrollIndicators(n, n2);
        }
    }
    
    public static int z(final View view) {
        if (Build$VERSION.SDK_INT >= 16) {
            return view.getImportantForAccessibility();
        }
        return 0;
    }
    
    public static void z0(final View view, final String transitionName) {
        if (Build$VERSION.SDK_INT >= 21) {
            view.setTransitionName(transitionName);
        }
        else {
            if (t.f == null) {
                t.f = (WeakHashMap<View, String>)new WeakHashMap();
            }
            t.f.put((Object)view, (Object)transitionName);
        }
    }
    
    static class e implements ViewTreeObserver$OnGlobalLayoutListener, View$OnAttachStateChangeListener
    {
        private WeakHashMap<View, Boolean> b;
        
        e() {
            this.b = (WeakHashMap<View, Boolean>)new WeakHashMap();
        }
        
        private void a(final View view, final boolean b) {
            final boolean b2 = view.getVisibility() == 0;
            if (b != b2) {
                if (b2) {
                    t.U(view, 16);
                }
                this.b.put((Object)view, (Object)b2);
            }
        }
        
        private void b(final View view) {
            view.getViewTreeObserver().addOnGlobalLayoutListener((ViewTreeObserver$OnGlobalLayoutListener)this);
        }
        
        public void onGlobalLayout() {
            for (final Map$Entry map$Entry : this.b.entrySet()) {
                this.a((View)map$Entry.getKey(), (boolean)map$Entry.getValue());
            }
        }
        
        public void onViewAttachedToWindow(final View view) {
            this.b(view);
        }
        
        public void onViewDetachedFromWindow(final View view) {
        }
    }
    
    abstract static class f<T>
    {
        private final int a;
        private final Class<T> b;
        private final int c;
        
        f(final int n, final Class<T> clazz, final int n2) {
            this(n, clazz, 0, n2);
        }
        
        f(final int a, final Class<T> b, final int n, final int c) {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        
        private boolean b() {
            return Build$VERSION.SDK_INT >= 19;
        }
        
        private boolean c() {
            return Build$VERSION.SDK_INT >= this.c;
        }
        
        boolean a(final Boolean b, final Boolean b2) {
            boolean b3 = false;
            if ((b != null && b) == (b2 != null && b2)) {
                b3 = true;
            }
            return b3;
        }
        
        abstract T d(final View p0);
        
        abstract void e(final View p0, final T p1);
        
        T f(final View view) {
            if (this.c()) {
                return this.d(view);
            }
            if (this.b()) {
                final Object tag = view.getTag(this.a);
                if (this.b.isInstance(tag)) {
                    return (T)tag;
                }
            }
            return null;
        }
        
        void g(final View view, final T t) {
            if (this.c()) {
                this.e(view, t);
            }
            else if (this.b() && this.h(this.f(view), t)) {
                t.E(view);
                view.setTag(this.a, (Object)t);
                t.U(view, 0);
            }
        }
        
        abstract boolean h(final T p0, final T p1);
    }
    
    private static class g
    {
        static b0 a(final View view, final b0 b0, final Rect rect) {
            final WindowInsets n = b0.n();
            if (n != null) {
                return b0.o(view.computeSystemWindowInsets(n, rect));
            }
            rect.setEmpty();
            return b0;
        }
    }
    
    private static class h
    {
        public static WindowInsets a(final View view) {
            return view.getRootWindowInsets();
        }
    }
    
    private static class i
    {
        static void a(final View view, final Context context, final int[] array, final AttributeSet set, final TypedArray typedArray, final int n, final int n2) {
            view.saveAttributeDataForStyleable(context, array, set, typedArray, n, n2);
        }
    }
    
    public interface j
    {
        boolean a(final View p0, final KeyEvent p1);
    }
    
    static class k
    {
        private static final ArrayList<WeakReference<View>> d;
        private WeakHashMap<View, Boolean> a;
        private SparseArray<WeakReference<View>> b;
        private WeakReference<KeyEvent> c;
        
        static {
            d = new ArrayList();
        }
        
        k() {
            this.a = null;
            this.b = null;
            this.c = null;
        }
        
        static k a(final View view) {
            k k;
            if ((k = (k)view.getTag(a.g.c.tag_unhandled_key_event_manager)) == null) {
                k = new k();
                view.setTag(a.g.c.tag_unhandled_key_event_manager, (Object)k);
            }
            return k;
        }
        
        private View c(final View view, final KeyEvent keyEvent) {
            final WeakHashMap<View, Boolean> a = this.a;
            if (a != null) {
                if (a.containsKey((Object)view)) {
                    if (view instanceof ViewGroup) {
                        final ViewGroup viewGroup = (ViewGroup)view;
                        for (int i = viewGroup.getChildCount() - 1; i >= 0; --i) {
                            final View c = this.c(viewGroup.getChildAt(i), keyEvent);
                            if (c != null) {
                                return c;
                            }
                        }
                    }
                    if (this.e(view, keyEvent)) {
                        return view;
                    }
                }
            }
            return null;
        }
        
        private SparseArray<WeakReference<View>> d() {
            if (this.b == null) {
                this.b = (SparseArray<WeakReference<View>>)new SparseArray();
            }
            return this.b;
        }
        
        private boolean e(final View view, final KeyEvent keyEvent) {
            final ArrayList list = (ArrayList)view.getTag(a.g.c.tag_unhandled_key_listeners);
            if (list != null) {
                for (int i = list.size() - 1; i >= 0; --i) {
                    if (((j)list.get(i)).a(view, keyEvent)) {
                        return true;
                    }
                }
            }
            return false;
        }
        
        private void g() {
            final WeakHashMap<View, Boolean> a = this.a;
            if (a != null) {
                a.clear();
            }
            if (k.d.isEmpty()) {
                return;
            }
            final ArrayList<WeakReference<View>> d;
            monitorenter(d = k.d);
            try {
                if (this.a == null) {
                    this.a = (WeakHashMap<View, Boolean>)new WeakHashMap();
                }
                for (int i = k.d.size() - 1; i >= 0; --i) {
                    final View view = (View)((WeakReference)k.d.get(i)).get();
                    if (view == null) {
                        k.d.remove(i);
                    }
                    else {
                        this.a.put((Object)view, (Object)Boolean.TRUE);
                        for (ViewParent viewParent = view.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
                            this.a.put((Object)viewParent, (Object)Boolean.TRUE);
                        }
                    }
                }
                monitorexit(d);
            }
            finally {
                monitorexit(d);
                while (true) {}
            }
        }
        
        boolean b(View c, final KeyEvent keyEvent) {
            if (keyEvent.getAction() == 0) {
                this.g();
            }
            c = this.c(c, keyEvent);
            if (keyEvent.getAction() == 0) {
                final int keyCode = keyEvent.getKeyCode();
                if (c != null && !KeyEvent.isModifierKey(keyCode)) {
                    this.d().put(keyCode, (Object)new WeakReference((Object)c));
                }
            }
            return c != null;
        }
        
        boolean f(final KeyEvent keyEvent) {
            final WeakReference<KeyEvent> c = this.c;
            if (c != null && c.get() == keyEvent) {
                return false;
            }
            this.c = (WeakReference<KeyEvent>)new WeakReference((Object)keyEvent);
            final WeakReference weakReference = null;
            final SparseArray<WeakReference<View>> d = this.d();
            WeakReference weakReference2 = weakReference;
            if (keyEvent.getAction() == 1) {
                final int indexOfKey = d.indexOfKey(keyEvent.getKeyCode());
                weakReference2 = weakReference;
                if (indexOfKey >= 0) {
                    weakReference2 = (WeakReference)d.valueAt(indexOfKey);
                    d.removeAt(indexOfKey);
                }
            }
            WeakReference weakReference3;
            if ((weakReference3 = weakReference2) == null) {
                weakReference3 = (WeakReference)d.get(keyEvent.getKeyCode());
            }
            if (weakReference3 != null) {
                final View view = (View)weakReference3.get();
                if (view != null && t.P(view)) {
                    this.e(view, keyEvent);
                }
                return true;
            }
            return false;
        }
    }
}
