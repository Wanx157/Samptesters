package a.g.l;

public interface j
{
    boolean isNestedScrollingEnabled();
    
    void stopNestedScroll();
}
