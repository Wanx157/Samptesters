package a.g.l;

import android.view.MotionEvent;

public final class i
{
    public static boolean a(final MotionEvent motionEvent, final int n) {
        return (motionEvent.getSource() & n) == n;
    }
}
