package a.g.l;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator$AnimatorUpdateListener;
import android.os.Build$VERSION;
import android.animation.TimeInterpolator;
import android.view.animation.Interpolator;
import android.animation.Animator$AnimatorListener;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import java.lang.ref.WeakReference;

public final class x
{
    private WeakReference<View> a;
    Runnable b;
    Runnable c;
    int d;
    
    x(final View view) {
        this.b = null;
        this.c = null;
        this.d = -1;
        this.a = (WeakReference<View>)new WeakReference((Object)view);
    }
    
    private void g(final View view, final y y) {
        if (y != null) {
            view.animate().setListener((Animator$AnimatorListener)new AnimatorListenerAdapter(this, y, view) {
                final y a;
                final View b;
                
                public void onAnimationCancel(final Animator animator) {
                    this.a.c(this.b);
                }
                
                public void onAnimationEnd(final Animator animator) {
                    this.a.a(this.b);
                }
                
                public void onAnimationStart(final Animator animator) {
                    this.a.b(this.b);
                }
            });
        }
        else {
            view.animate().setListener((Animator$AnimatorListener)null);
        }
    }
    
    public x a(final float n) {
        final View view = (View)this.a.get();
        if (view != null) {
            view.animate().alpha(n);
        }
        return this;
    }
    
    public void b() {
        final View view = (View)this.a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }
    
    public long c() {
        final View view = (View)this.a.get();
        if (view != null) {
            return view.animate().getDuration();
        }
        return 0L;
    }
    
    public x d(final long duration) {
        final View view = (View)this.a.get();
        if (view != null) {
            view.animate().setDuration(duration);
        }
        return this;
    }
    
    public x e(final Interpolator interpolator) {
        final View view = (View)this.a.get();
        if (view != null) {
            view.animate().setInterpolator((TimeInterpolator)interpolator);
        }
        return this;
    }
    
    public x f(y y) {
        final View view = (View)this.a.get();
        if (view != null) {
            if (Build$VERSION.SDK_INT < 16) {
                view.setTag(2113929216, (Object)y);
                y = (y)new x.x$c(this);
            }
            this.g(view, y);
        }
        return this;
    }
    
    public x h(final long startDelay) {
        final View view = (View)this.a.get();
        if (view != null) {
            view.animate().setStartDelay(startDelay);
        }
        return this;
    }
    
    public x i(final a0 a0) {
        final View view = (View)this.a.get();
        if (view != null && Build$VERSION.SDK_INT >= 19) {
            Object updateListener = null;
            if (a0 != null) {
                updateListener = new ValueAnimator$AnimatorUpdateListener(this, a0, view) {
                    final a0 a;
                    final View b;
                    
                    public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                        this.a.a(this.b);
                    }
                };
            }
            view.animate().setUpdateListener((ValueAnimator$AnimatorUpdateListener)updateListener);
        }
        return this;
    }
    
    public void j() {
        final View view = (View)this.a.get();
        if (view != null) {
            view.animate().start();
        }
    }
    
    public x k(final float n) {
        final View view = (View)this.a.get();
        if (view != null) {
            view.animate().translationY(n);
        }
        return this;
    }
}
