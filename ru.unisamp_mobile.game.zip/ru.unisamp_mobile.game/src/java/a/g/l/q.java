package a.g.l;

import android.view.ViewTreeObserver;
import android.view.View;
import android.view.View$OnAttachStateChangeListener;
import android.view.ViewTreeObserver$OnPreDrawListener;

public final class q implements ViewTreeObserver$OnPreDrawListener, View$OnAttachStateChangeListener
{
    private final View b;
    private ViewTreeObserver c;
    private final Runnable d;
    
    private q(final View b, final Runnable d) {
        this.b = b;
        this.c = b.getViewTreeObserver();
        this.d = d;
    }
    
    public static q a(final View view, final Runnable runnable) {
        if (view == null) {
            throw new NullPointerException("view == null");
        }
        if (runnable != null) {
            final q q = new q(view, runnable);
            view.getViewTreeObserver().addOnPreDrawListener((ViewTreeObserver$OnPreDrawListener)q);
            view.addOnAttachStateChangeListener((View$OnAttachStateChangeListener)q);
            return q;
        }
        throw new NullPointerException("runnable == null");
    }
    
    public void b() {
        ViewTreeObserver viewTreeObserver;
        if (this.c.isAlive()) {
            viewTreeObserver = this.c;
        }
        else {
            viewTreeObserver = this.b.getViewTreeObserver();
        }
        viewTreeObserver.removeOnPreDrawListener((ViewTreeObserver$OnPreDrawListener)this);
        this.b.removeOnAttachStateChangeListener((View$OnAttachStateChangeListener)this);
    }
    
    public boolean onPreDraw() {
        this.b();
        this.d.run();
        return true;
    }
    
    public void onViewAttachedToWindow(final View view) {
        this.c = view.getViewTreeObserver();
    }
    
    public void onViewDetachedFromWindow(final View view) {
        this.b();
    }
}
