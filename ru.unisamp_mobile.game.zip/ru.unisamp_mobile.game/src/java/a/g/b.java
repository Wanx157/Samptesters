package a.g;

public final class b
{
    public static final int compat_button_inset_horizontal_material = 2131100492;
    public static final int compat_button_inset_vertical_material = 2131100493;
    public static final int compat_button_padding_horizontal_material = 2131100494;
    public static final int compat_button_padding_vertical_material = 2131100495;
    public static final int compat_control_corner_material = 2131100496;
    public static final int compat_notification_large_icon_max_height = 2131100497;
    public static final int compat_notification_large_icon_max_width = 2131100498;
    public static final int notification_action_icon_size = 2131100774;
    public static final int notification_action_text_size = 2131100775;
    public static final int notification_big_circle_margin = 2131100776;
    public static final int notification_content_margin_start = 2131100777;
    public static final int notification_large_icon_height = 2131100778;
    public static final int notification_large_icon_width = 2131100779;
    public static final int notification_main_column_padding_top = 2131100780;
    public static final int notification_media_narrow_margin = 2131100781;
    public static final int notification_right_icon_size = 2131100782;
    public static final int notification_right_side_padding_top = 2131100783;
    public static final int notification_small_icon_background_padding = 2131100784;
    public static final int notification_small_icon_size_as_large = 2131100785;
    public static final int notification_subtext_size = 2131100786;
    public static final int notification_top_pad = 2131100787;
    public static final int notification_top_pad_large_text = 2131100788;
}
