package a.g.e;

import java.io.InputStream;
import android.os.ParcelFileDescriptor;
import android.content.ContentResolver;
import a.g.i.b$f;
import android.os.CancellationSignal;
import android.graphics.fonts.Font;
import androidx.core.content.d.c$c;
import java.io.IOException;
import android.graphics.fonts.FontStyle;
import android.graphics.Typeface$CustomFallbackBuilder;
import android.graphics.fonts.FontFamily$Builder;
import android.graphics.fonts.Font$Builder;
import android.graphics.Typeface;
import android.content.res.Resources;
import androidx.core.content.d.c$b;
import android.content.Context;

public class i extends j
{
    public Typeface b(Context context, final c$b c$b, final Resources resources, final int n) {
        final c$c[] a = c$b.a();
        final int length = a.length;
        final int n2 = 0;
        context = null;
        int n3 = 0;
    Label_0126_Outer:
        while (true) {
            int slant = 1;
            Label_0132: {
                if (n3 >= length) {
                    break Label_0132;
                }
                final c$c c$c = a[n3];
            Label_0158_Outer:
                while (true) {
                    try {
                        final Font$Builder setWeight = new Font$Builder(resources, c$c.b()).setWeight(c$c.e());
                        if (!c$c.f()) {
                            slant = 0;
                        }
                        final Font build = setWeight.setSlant(slant).setTtcIndex(c$c.c()).setFontVariationSettings(c$c.d()).build();
                        if (context == null) {
                            context = (Context)new FontFamily$Builder(build);
                        }
                        else {
                            ((FontFamily$Builder)context).addFont(build);
                        }
                        ++n3;
                        continue Label_0126_Outer;
                    Label_0158:
                        while (true) {
                            while (true) {
                                n3 = 700;
                                break Label_0158;
                                Label_0138: {
                                    iftrue(Label_0153:)((n & 0x1) == 0x0);
                                }
                                continue Label_0158_Outer;
                            }
                            int n4 = n2;
                            iftrue(Label_0172:)((n & 0x2) == 0x0);
                            n4 = 1;
                            Label_0172: {
                                return new Typeface$CustomFallbackBuilder(((FontFamily$Builder)context).build()).setStyle(new FontStyle(n3, n4)).build();
                            }
                            iftrue(Label_0138:)(context != null);
                            return null;
                            Label_0153:
                            n3 = 400;
                            continue Label_0158;
                        }
                    }
                    catch (final IOException ex) {
                        continue;
                    }
                    break;
                }
            }
        }
    }
    
    public Typeface c(Context context, CancellationSignal style, final b$f[] array, final int n) {
        final ContentResolver contentResolver = context.getContentResolver();
        final int length = array.length;
        final int n2 = 0;
        context = null;
        int n3 = 0;
    Label_0209_Outer:
        while (true) {
            int slant = 1;
            Label_0218: {
                if (n3 >= length) {
                    break Label_0218;
                }
                final b$f b$f = array[n3];
                Object o = context;
                ParcelFileDescriptor openFileDescriptor;
                final Throwable t;
                int n4;
                Label_0244_Outer:Block_7_Outer:
                while (true) {
                    try {
                        openFileDescriptor = contentResolver.openFileDescriptor(b$f.c(), "r", style);
                        Label_0065: {
                            if (openFileDescriptor != null) {
                                try {
                                    o = new Font$Builder(openFileDescriptor);
                                    o = ((Font$Builder)o).setWeight(b$f.d());
                                    if (!b$f.e()) {
                                        slant = 0;
                                    }
                                    o = ((Font$Builder)o).setSlant(slant).setTtcIndex(b$f.b()).build();
                                    if (context == null) {
                                        o = (context = (Context)new FontFamily$Builder((Font)o));
                                    }
                                    else {
                                        ((FontFamily$Builder)context).addFont((Font)o);
                                    }
                                    o = context;
                                    if (openFileDescriptor != null) {
                                        break Label_0065;
                                    }
                                }
                                finally {
                                    if (openFileDescriptor != null) {
                                        try {
                                            openFileDescriptor.close();
                                        }
                                        finally {
                                            o = context;
                                            t.addSuppressed((Throwable)openFileDescriptor);
                                        }
                                    }
                                    o = context;
                                }
                                break Label_0209;
                            }
                            o = context;
                            if (openFileDescriptor == null) {
                                break Label_0209;
                            }
                        }
                        o = context;
                        openFileDescriptor.close();
                        o = context;
                        ++n3;
                        context = (Context)o;
                        continue Label_0209_Outer;
                        Label_0258: {
                            while (true) {
                                while (true) {
                                    while (true) {
                                        n4 = 1;
                                        break Label_0258;
                                        iftrue(Label_0224:)(context != null);
                                        return null;
                                        Label_0239: {
                                            n3 = 400;
                                        }
                                        n4 = n2;
                                        iftrue(Label_0258:)((n & 0x2) == 0x0);
                                        continue Label_0244_Outer;
                                    }
                                    n3 = 700;
                                    continue Block_7_Outer;
                                }
                                Label_0224: {
                                    iftrue(Label_0239:)((n & 0x1) == 0x0);
                                }
                                continue;
                            }
                        }
                        style = (CancellationSignal)new FontStyle(n3, n4);
                        return new Typeface$CustomFallbackBuilder(((FontFamily$Builder)context).build()).setStyle((FontStyle)style).build();
                    }
                    catch (final IOException ex) {
                        continue;
                    }
                    break;
                }
            }
        }
    }
    
    protected Typeface d(final Context context, final InputStream inputStream) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }
    
    public Typeface e(final Context context, final Resources resources, final int n, final String s, final int n2) {
        try {
            final Font build = new Font$Builder(resources, n).build();
            return new Typeface$CustomFallbackBuilder(new FontFamily$Builder(build).build()).setStyle(build.getStyle()).build();
        }
        catch (final IOException ex) {
            return null;
        }
    }
    
    protected b$f h(final b$f[] array, final int n) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }
}
