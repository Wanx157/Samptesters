package a.g.e;

import android.os.ParcelFileDescriptor;
import android.content.res.AssetManager;
import java.lang.reflect.Array;
import java.util.Map;
import android.content.ContentResolver;
import a.g.i.b;
import java.io.IOException;
import android.graphics.Typeface$Builder;
import a.g.i.b$f;
import android.os.CancellationSignal;
import androidx.core.content.d.c$c;
import android.graphics.Typeface;
import android.content.res.Resources;
import androidx.core.content.d.c$b;
import java.nio.ByteBuffer;
import android.graphics.fonts.FontVariationAxis;
import android.content.Context;
import java.lang.reflect.InvocationTargetException;
import android.util.Log;
import java.lang.reflect.Method;
import java.lang.reflect.Constructor;

public class g extends e
{
    protected final Class<?> g;
    protected final Constructor<?> h;
    protected final Method i;
    protected final Method j;
    protected final Method k;
    protected final Method l;
    protected final Method m;
    
    public g() {
        final Throwable t = null;
        Class<?> y = null;
        Constructor<?> z = null;
        Method v = null;
        Object w = null;
        Method a = null;
        Method u = null;
        Method x = null;
        Label_0120: {
            try {
                y = this.y();
                z = this.z(y);
                v = this.v(y);
                w = this.w(y);
                a = this.A(y);
                u = this.u(y);
                x = this.x(y);
                break Label_0120;
            }
            catch (final NoSuchMethodException y) {}
            catch (final ClassNotFoundException ex) {}
            final StringBuilder sb = new StringBuilder();
            sb.append("Unable to collect necessary methods for class ");
            sb.append(y.getClass().getName());
            Log.e("TypefaceCompatApi26Impl", sb.toString(), (Throwable)y);
            x = null;
            z = null;
            final Constructor<?> constructor = (Constructor<?>)(w = z);
            a = (u = (Method)w);
            v = (Method)constructor;
            y = (Class<?>)t;
        }
        this.g = y;
        this.h = z;
        this.i = v;
        this.j = (Method)w;
        this.k = a;
        this.l = u;
        this.m = x;
    }
    
    private Object o() {
        try {
            return this.h.newInstance(new Object[0]);
        }
        catch (final IllegalAccessException | InstantiationException | InvocationTargetException ex) {
            return null;
        }
    }
    
    private void p(final Object o) {
        try {
            this.l.invoke(o, new Object[0]);
        }
        catch (final IllegalAccessException | InvocationTargetException ex) {}
    }
    
    private boolean q(final Context context, final Object o, final String s, final int n, final int n2, final int n3, final FontVariationAxis[] array) {
        try {
            return (boolean)this.i.invoke(o, new Object[] { context.getAssets(), s, 0, Boolean.FALSE, n, n2, n3, array });
        }
        catch (final IllegalAccessException | InvocationTargetException ex) {
            return false;
        }
    }
    
    private boolean r(final Object o, final ByteBuffer byteBuffer, final int n, final int n2, final int n3) {
        try {
            return (boolean)this.j.invoke(o, new Object[] { byteBuffer, n, null, n2, n3 });
        }
        catch (final IllegalAccessException | InvocationTargetException ex) {
            return false;
        }
    }
    
    private boolean s(final Object o) {
        try {
            return (boolean)this.k.invoke(o, new Object[0]);
        }
        catch (final IllegalAccessException | InvocationTargetException ex) {
            return false;
        }
    }
    
    private boolean t() {
        if (this.i == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        return this.i != null;
    }
    
    protected Method A(final Class<?> clazz) {
        return clazz.getMethod("freeze", (Class[])new Class[0]);
    }
    
    @Override
    public Typeface b(final Context context, final c$b c$b, final Resources resources, int i) {
        if (!this.t()) {
            return super.b(context, c$b, resources, i);
        }
        final Object o = this.o();
        if (o == null) {
            return null;
        }
        final c$c[] a = c$b.a();
        int length;
        c$c c$c;
        for (length = a.length, i = 0; i < length; ++i) {
            c$c = a[i];
            if (!this.q(context, o, c$c.a(), c$c.c(), c$c.e(), c$c.f() ? 1 : 0, FontVariationAxis.fromFontVariationSettings(c$c.d()))) {
                this.p(o);
                return null;
            }
        }
        if (!this.s(o)) {
            return null;
        }
        return this.l(o);
    }
    
    @Override
    public Typeface c(Context openFileDescriptor, final CancellationSignal cancellationSignal, final b$f[] array, final int n) {
        if (array.length < 1) {
            return null;
        }
        if (!this.t()) {
            final b$f h = this.h(array, n);
            final ContentResolver contentResolver = openFileDescriptor.getContentResolver();
            try {
                openFileDescriptor = (Context)contentResolver.openFileDescriptor(h.c(), "r", cancellationSignal);
                if (openFileDescriptor == null) {
                    if (openFileDescriptor != null) {
                        ((ParcelFileDescriptor)openFileDescriptor).close();
                    }
                    return null;
                }
                try {
                    final Typeface build = new Typeface$Builder(((ParcelFileDescriptor)openFileDescriptor).getFileDescriptor()).setWeight(h.d()).setItalic(h.e()).build();
                    if (openFileDescriptor != null) {
                        ((ParcelFileDescriptor)openFileDescriptor).close();
                    }
                    return build;
                }
                finally {
                    if (openFileDescriptor != null) {
                        try {
                            ((ParcelFileDescriptor)openFileDescriptor).close();
                        }
                        finally {
                            final Throwable t;
                            ((Throwable)cancellationSignal).addSuppressed(t);
                        }
                    }
                }
            }
            catch (final IOException ex) {
                return null;
            }
        }
        final Map i = a.g.i.b.i(openFileDescriptor, array, cancellationSignal);
        final Object o = this.o();
        if (o == null) {
            return null;
        }
        final int length = array.length;
        boolean b = false;
        for (final b$f b$f : array) {
            final ByteBuffer byteBuffer = (ByteBuffer)i.get((Object)b$f.c());
            if (byteBuffer != null) {
                if (!this.r(o, byteBuffer, b$f.b(), b$f.d(), b$f.e() ? 1 : 0)) {
                    this.p(o);
                    return null;
                }
                b = true;
            }
        }
        if (!b) {
            this.p(o);
            return null;
        }
        if (!this.s(o)) {
            return null;
        }
        final Typeface l = this.l(o);
        if (l == null) {
            return null;
        }
        return Typeface.create(l, n);
    }
    
    public Typeface e(final Context context, final Resources resources, final int n, final String s, final int n2) {
        if (!this.t()) {
            return super.e(context, resources, n, s, n2);
        }
        final Object o = this.o();
        if (o == null) {
            return null;
        }
        if (!this.q(context, o, s, 0, -1, -1, null)) {
            this.p(o);
            return null;
        }
        if (!this.s(o)) {
            return null;
        }
        return this.l(o);
    }
    
    protected Typeface l(final Object o) {
        try {
            final Object instance = Array.newInstance((Class)this.g, 1);
            Array.set(instance, 0, o);
            return (Typeface)this.m.invoke((Object)null, new Object[] { instance, -1, -1 });
        }
        catch (final IllegalAccessException | InvocationTargetException ex) {
            return null;
        }
    }
    
    protected Method u(final Class<?> clazz) {
        return clazz.getMethod("abortCreation", (Class[])new Class[0]);
    }
    
    protected Method v(final Class<?> clazz) {
        final Class type = Integer.TYPE;
        final Class type2 = Boolean.TYPE;
        final Class type3 = Integer.TYPE;
        return clazz.getMethod("addFontFromAssetManager", AssetManager.class, String.class, type, type2, type3, type3, type3, FontVariationAxis[].class);
    }
    
    protected Method w(final Class<?> clazz) {
        final Class type = Integer.TYPE;
        return clazz.getMethod("addFontFromBuffer", ByteBuffer.class, type, FontVariationAxis[].class, type, type);
    }
    
    protected Method x(final Class<?> clazz) {
        final Class<?> class1 = Array.newInstance((Class)clazz, 1).getClass();
        final Class type = Integer.TYPE;
        final Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", class1, type, type);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
    
    protected Class<?> y() {
        return Class.forName("android.graphics.FontFamily");
    }
    
    protected Constructor<?> z(final Class<?> clazz) {
        return clazz.getConstructor((Class<?>[])new Class[0]);
    }
}
