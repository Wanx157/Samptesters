package a.g.e;

import android.net.Uri;
import a.d.g;
import a.g.i.b$f;
import android.os.CancellationSignal;
import androidx.core.content.d.c$c;
import android.content.res.Resources;
import androidx.core.content.d.c$b;
import android.content.Context;
import java.lang.reflect.InvocationTargetException;
import android.util.Log;
import java.lang.reflect.Array;
import android.graphics.Typeface;
import java.util.List;
import java.nio.ByteBuffer;
import java.lang.reflect.Method;
import java.lang.reflect.Constructor;

class f extends j
{
    private static final Class<?> b;
    private static final Constructor<?> c;
    private static final Method d;
    private static final Method e;
    
    static {
        Constructor<?> c2 = null;
        Class<?> forName = null;
        Method method = null;
        Method method2 = null;
        Label_0111: {
            try {
                forName = Class.forName("android.graphics.FontFamily");
                final java.lang.reflect.Constructor<?> constructor = forName.getConstructor((Class<?>[])new Class[0]);
                method = forName.getMethod("addFontWeightStyle", ByteBuffer.class, Integer.TYPE, List.class, Integer.TYPE, Boolean.TYPE);
                method2 = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance((Class)forName, 1).getClass());
                c2 = constructor;
                break Label_0111;
            }
            catch (final NoSuchMethodException method2) {}
            catch (final ClassNotFoundException ex) {}
            Log.e("TypefaceCompatApi24Impl", ((Throwable)method2).getClass().getName(), (Throwable)method2);
            forName = null;
            method2 = (method = null);
        }
        c = c2;
        b = forName;
        d = method;
        e = method2;
    }
    
    private static boolean k(final Object o, final ByteBuffer byteBuffer, final int n, final int n2, final boolean b) {
        try {
            return (boolean)f.d.invoke(o, new Object[] { byteBuffer, n, null, n2, b });
        }
        catch (final IllegalAccessException | InvocationTargetException ex) {
            return false;
        }
    }
    
    private static Typeface l(final Object o) {
        try {
            final Object instance = Array.newInstance((Class)f.b, 1);
            Array.set(instance, 0, o);
            return (Typeface)f.e.invoke((Object)null, new Object[] { instance });
        }
        catch (final IllegalAccessException | InvocationTargetException ex) {
            return null;
        }
    }
    
    public static boolean m() {
        if (f.d == null) {
            Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
        }
        return f.d != null;
    }
    
    private static Object n() {
        try {
            return f.c.newInstance(new Object[0]);
        }
        catch (final IllegalAccessException | InstantiationException | InvocationTargetException ex) {
            return null;
        }
    }
    
    public Typeface b(final Context context, final c$b c$b, final Resources resources, int i) {
        final Object n = n();
        if (n == null) {
            return null;
        }
        final c$c[] a = c$b.a();
        int length;
        c$c c$c;
        ByteBuffer b;
        for (length = a.length, i = 0; i < length; ++i) {
            c$c = a[i];
            b = k.b(context, resources, c$c.b());
            if (b == null) {
                return null;
            }
            if (!k(n, b, c$c.c(), c$c.e(), c$c.f())) {
                return null;
            }
        }
        return l(n);
    }
    
    public Typeface c(final Context context, final CancellationSignal cancellationSignal, final b$f[] array, final int n) {
        final Object n2 = n();
        if (n2 == null) {
            return null;
        }
        final g g = new g();
        for (final b$f b$f : array) {
            final Uri c = b$f.c();
            ByteBuffer f;
            if ((f = (ByteBuffer)g.get((Object)c)) == null) {
                f = k.f(context, cancellationSignal, c);
                g.put((Object)c, (Object)f);
            }
            if (f == null) {
                return null;
            }
            if (!k(n2, f, b$f.b(), b$f.d(), b$f.e())) {
                return null;
            }
        }
        final Typeface l = l(n2);
        if (l == null) {
            return null;
        }
        return Typeface.create(l, n);
    }
}
