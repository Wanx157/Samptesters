package a.g.e;

import androidx.core.content.d.c$b;
import androidx.core.content.d.c$d;
import android.os.Handler;
import androidx.core.content.d.f$a;
import android.content.res.Resources;
import androidx.core.content.d.c$a;
import a.g.i.b;
import android.os.CancellationSignal;
import android.content.Context;
import android.os.Build$VERSION;
import android.graphics.Typeface;
import a.d.e;
import android.annotation.SuppressLint;

@SuppressLint({ "NewApi" })
public class d
{
    private static final j a;
    private static final e<String, Typeface> b;
    
    static {
        final int sdk_INT = Build$VERSION.SDK_INT;
        Object a2;
        if (sdk_INT >= 29) {
            a2 = new i();
        }
        else if (sdk_INT >= 28) {
            a2 = new h();
        }
        else if (sdk_INT >= 26) {
            a2 = new g();
        }
        else if (sdk_INT >= 24 && f.m()) {
            a2 = new f();
        }
        else if (Build$VERSION.SDK_INT >= 21) {
            a2 = new a.g.e.e();
        }
        else {
            a2 = new j();
        }
        a = (j)a2;
        b = new e<String, Typeface>(16);
    }
    
    public static Typeface a(final Context context, final Typeface typeface, final int n) {
        if (context != null) {
            if (Build$VERSION.SDK_INT < 21) {
                final Typeface g = g(context, typeface, n);
                if (g != null) {
                    return g;
                }
            }
            return Typeface.create(typeface, n);
        }
        throw new IllegalArgumentException("Context cannot be null");
    }
    
    public static Typeface b(final Context context, final CancellationSignal cancellationSignal, final b.f[] array, final int n) {
        return d.a.c(context, cancellationSignal, array, n);
    }
    
    public static Typeface c(final Context context, final c$a c$a, final Resources resources, final int n, final int n2, final f$a f$a, final Handler handler, final boolean b) {
        Typeface typeface;
        if (c$a instanceof c$d) {
            final c$d c$d = (c$d)c$a;
            boolean b2 = false;
            Label_0038: {
                if (b) {
                    if (c$d.a() != 0) {
                        break Label_0038;
                    }
                }
                else if (f$a != null) {
                    break Label_0038;
                }
                b2 = true;
            }
            int c;
            if (b) {
                c = c$d.c();
            }
            else {
                c = -1;
            }
            typeface = b.g(context, c$d.b(), f$a, handler, b2, c, n2);
        }
        else {
            final Typeface typeface2 = typeface = d.a.b(context, (c$b)c$a, resources, n2);
            if (f$a != null) {
                if (typeface2 != null) {
                    f$a.b(typeface2, handler);
                    typeface = typeface2;
                }
                else {
                    f$a.a(-3, handler);
                    typeface = typeface2;
                }
            }
        }
        if (typeface != null) {
            d.b.d(e(resources, n, n2), typeface);
        }
        return typeface;
    }
    
    public static Typeface d(final Context context, final Resources resources, final int n, final String s, final int n2) {
        final Typeface e = d.a.e(context, resources, n, s, n2);
        if (e != null) {
            d.b.d(e(resources, n, n2), e);
        }
        return e;
    }
    
    private static String e(final Resources resources, final int n, final int n2) {
        final StringBuilder sb = new StringBuilder();
        sb.append(resources.getResourcePackageName(n));
        sb.append("-");
        sb.append(n);
        sb.append("-");
        sb.append(n2);
        return sb.toString();
    }
    
    public static Typeface f(final Resources resources, final int n, final int n2) {
        return d.b.c(e(resources, n, n2));
    }
    
    private static Typeface g(final Context context, final Typeface typeface, final int n) {
        final c$b i = d.a.i(typeface);
        if (i == null) {
            return null;
        }
        return d.a.b(context, i, context.getResources(), n);
    }
}
