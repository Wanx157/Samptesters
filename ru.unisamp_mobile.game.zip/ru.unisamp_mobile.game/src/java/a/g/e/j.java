package a.g.e;

import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.io.Closeable;
import a.g.i.b;
import android.os.CancellationSignal;
import android.content.res.Resources;
import android.content.Context;
import java.lang.reflect.Field;
import android.util.Log;
import androidx.core.content.d.c$c;
import android.graphics.Typeface;
import androidx.core.content.d.c$b;
import java.util.concurrent.ConcurrentHashMap;

class j
{
    private ConcurrentHashMap<Long, c$b> a;
    
    j() {
        this.a = (ConcurrentHashMap<Long, c$b>)new ConcurrentHashMap();
    }
    
    private void a(final Typeface typeface, final c$b c$b) {
        final long j = j(typeface);
        if (j != 0L) {
            this.a.put((Object)j, (Object)c$b);
        }
    }
    
    private c$c f(final c$b c$b, final int n) {
        return g(c$b.a(), n, (c<c$c>)new j$b(this));
    }
    
    private static <T> T g(final T[] array, int i, final c<T> c) {
        int n;
        if ((i & 0x1) == 0x0) {
            n = 400;
        }
        else {
            n = 700;
        }
        final boolean b = (i & 0x2) != 0x0;
        T t = null;
        int n2 = Integer.MAX_VALUE;
        int length;
        T t2;
        int abs;
        int n3;
        int n4;
        int n5;
        for (length = array.length, i = 0; i < length; ++i, n2 = n5) {
            t2 = array[i];
            abs = Math.abs(c.a(t2) - n);
            if (c.b(t2) == b) {
                n3 = 0;
            }
            else {
                n3 = 1;
            }
            n4 = abs * 2 + n3;
            if (t == null || (n5 = n2) > n4) {
                t = t2;
                n5 = n4;
            }
        }
        return t;
    }
    
    private static long j(final Typeface typeface) {
        if (typeface == null) {
            return 0L;
        }
        try {
            final Field declaredField = Typeface.class.getDeclaredField("native_instance");
            declaredField.setAccessible(true);
            return ((Number)declaredField.get((Object)typeface)).longValue();
        }
        catch (final IllegalAccessException ex) {
            Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", (Throwable)ex);
            return 0L;
        }
        catch (final NoSuchFieldException ex2) {
            Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", (Throwable)ex2);
            return 0L;
        }
    }
    
    public Typeface b(final Context context, final c$b c$b, final Resources resources, final int n) {
        final c$c f = this.f(c$b, n);
        if (f == null) {
            return null;
        }
        final Typeface d = a.g.e.d.d(context, resources, f.b(), f.a(), n);
        this.a(d, c$b);
        return d;
    }
    
    public Typeface c(final Context context, final CancellationSignal cancellationSignal, final b.f[] array, final int n) {
        if (array.length < 1) {
            return null;
        }
        final b.f h = this.h(array, n);
        try {
            final InputStream openInputStream = context.getContentResolver().openInputStream(h.c());
            try {
                final Typeface d = this.d(context, openInputStream);
                k.a((Closeable)openInputStream);
                return d;
            }
            catch (final IOException ex) {}
        }
        catch (final IOException ex2) {}
    }
    
    protected Typeface d(Context e, final InputStream inputStream) {
        e = (Context)k.e(e);
        if (e == null) {
            return null;
        }
        try {
            if (!k.d((File)e, inputStream)) {
                return null;
            }
            return Typeface.createFromFile(((File)e).getPath());
        }
        catch (final RuntimeException ex) {
            return null;
        }
        finally {
            ((File)e).delete();
        }
    }
    
    public Typeface e(Context e, final Resources resources, final int n, final String s, final int n2) {
        e = (Context)k.e(e);
        if (e == null) {
            return null;
        }
        try {
            if (!k.c((File)e, resources, n)) {
                return null;
            }
            return Typeface.createFromFile(((File)e).getPath());
        }
        catch (final RuntimeException ex) {
            return null;
        }
        finally {
            ((File)e).delete();
        }
    }
    
    protected b.f h(final b.f[] array, final int n) {
        return g(array, n, (c<b.f>)new j$a(this));
    }
    
    c$b i(final Typeface typeface) {
        final long j = j(typeface);
        if (j == 0L) {
            return null;
        }
        return (c$b)this.a.get((Object)j);
    }
    
    private interface c<T>
    {
        int a(final T p0);
        
        boolean b(final T p0);
    }
}
