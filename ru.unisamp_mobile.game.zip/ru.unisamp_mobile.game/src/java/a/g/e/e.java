package a.g.e;

import android.content.ContentResolver;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import a.g.i.b$f;
import android.os.CancellationSignal;
import androidx.core.content.d.c$c;
import android.content.res.Resources;
import androidx.core.content.d.c$b;
import android.content.Context;
import android.util.Log;
import android.system.ErrnoException;
import android.system.OsConstants;
import android.system.Os;
import java.io.File;
import android.os.ParcelFileDescriptor;
import java.lang.reflect.Array;
import android.graphics.Typeface;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Constructor;

class e extends j
{
    private static Class<?> b;
    private static Constructor<?> c;
    private static Method d;
    private static Method e;
    private static boolean f;
    
    private static boolean k(final Object ex, final String s, final int n, final boolean b) {
        n();
        try {
            return (boolean)a.g.e.e.d.invoke((Object)ex, new Object[] { s, n, b });
        }
        catch (final InvocationTargetException ex) {}
        catch (final IllegalAccessException ex2) {}
        throw new RuntimeException((Throwable)ex);
    }
    
    private static Typeface l(Object ex) {
        n();
        try {
            final Object instance = Array.newInstance((Class)a.g.e.e.b, 1);
            Array.set(instance, 0, (Object)ex);
            ex = (InvocationTargetException)a.g.e.e.e.invoke((Object)null, new Object[] { instance });
            return (Typeface)ex;
        }
        catch (final InvocationTargetException ex) {}
        catch (final IllegalAccessException ex2) {}
        throw new RuntimeException((Throwable)ex);
    }
    
    private File m(final ParcelFileDescriptor parcelFileDescriptor) {
        try {
            final StringBuilder sb = new StringBuilder();
            sb.append("/proc/self/fd/");
            sb.append(parcelFileDescriptor.getFd());
            final String readlink = Os.readlink(sb.toString());
            if (OsConstants.S_ISREG(Os.stat(readlink).st_mode)) {
                return new File(readlink);
            }
            return null;
        }
        catch (final ErrnoException ex) {
            return null;
        }
    }
    
    private static void n() {
        if (a.g.e.e.f) {
            return;
        }
        a.g.e.e.f = true;
        Constructor<?> c = null;
        Object forName = null;
        Method method = null;
        Method method2 = null;
        Label_0111: {
            try {
                forName = Class.forName("android.graphics.FontFamily");
                final Constructor constructor = ((Class)forName).getConstructor((Class[])new Class[0]);
                method = ((Class)forName).getMethod("addFontWeightStyle", String.class, Integer.TYPE, Boolean.TYPE);
                method2 = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance((Class)forName, 1).getClass());
                c = constructor;
                break Label_0111;
            }
            catch (final NoSuchMethodException forName) {}
            catch (final ClassNotFoundException ex) {}
            Log.e("TypefaceCompatApi21Impl", ((Class)forName).getClass().getName(), (Throwable)forName);
            method2 = null;
            forName = (method = null);
        }
        a.g.e.e.c = c;
        a.g.e.e.b = (Class<?>)forName;
        a.g.e.e.d = method;
        a.g.e.e.e = method2;
    }
    
    private static Object o() {
        n();
        Object instance = null;
        try {
            instance = a.g.e.e.c.newInstance(new Object[0]);
            return instance;
        }
        catch (final InvocationTargetException instance) {}
        catch (final InstantiationException instance) {}
        catch (final IllegalAccessException ex) {}
        throw new RuntimeException((Throwable)instance);
    }
    
    public Typeface b(final Context context, c$b e, final Resources resources, int i) {
        final Object o = o();
        final c$c[] a = e.a();
        final int length = a.length;
        i = 0;
        while (i < length) {
            final c$c c$c = a[i];
            e = (c$b)k.e(context);
            if (e == null) {
                return null;
            }
            try {
                if (!k.c((File)e, resources, c$c.b())) {
                    return null;
                }
                final boolean k = k(o, ((File)e).getPath(), c$c.e(), c$c.f());
                ((File)e).delete();
                if (!k) {
                    return null;
                }
                ++i;
                continue;
            }
            catch (final RuntimeException ex) {
                return null;
            }
            finally {
                ((File)e).delete();
            }
            break;
        }
        return l(o);
    }
    
    public Typeface c(final Context context, CancellationSignal openFileDescriptor, b$f[] array, final int n) {
        if (array.length < 1) {
            return null;
        }
        final b$f h = this.h(array, n);
        final ContentResolver contentResolver = context.getContentResolver();
        try {
            openFileDescriptor = (CancellationSignal)contentResolver.openFileDescriptor(h.c(), "r", openFileDescriptor);
            if (openFileDescriptor == null) {
                if (openFileDescriptor != null) {
                    ((ParcelFileDescriptor)openFileDescriptor).close();
                }
                return null;
            }
            try {
                final File m = this.m((ParcelFileDescriptor)openFileDescriptor);
                if (m != null && m.canRead()) {
                    final Typeface fromFile = Typeface.createFromFile(m);
                    if (openFileDescriptor != null) {
                        ((ParcelFileDescriptor)openFileDescriptor).close();
                    }
                    return fromFile;
                }
                array = (b$f[])(Object)new FileInputStream(((ParcelFileDescriptor)openFileDescriptor).getFileDescriptor());
                try {
                    final Typeface d = super.d(context, (InputStream)(Object)array);
                    ((FileInputStream)(Object)array).close();
                    if (openFileDescriptor != null) {
                        ((ParcelFileDescriptor)openFileDescriptor).close();
                    }
                    return d;
                }
                finally {
                    try {
                        ((FileInputStream)(Object)array).close();
                    }
                    finally {
                        final Throwable t;
                        ((Throwable)context).addSuppressed(t);
                    }
                }
            }
            finally {
                if (openFileDescriptor != null) {
                    try {
                        ((ParcelFileDescriptor)openFileDescriptor).close();
                    }
                    finally {
                        final Throwable t2;
                        ((Throwable)context).addSuppressed(t2);
                    }
                }
            }
        }
        catch (final IOException ex) {
            return null;
        }
    }
}
