package a.g.e;

import android.graphics.Insets;

public final class b
{
    public static final b e;
    public final int a;
    public final int b;
    public final int c;
    public final int d;
    
    static {
        e = new b(0, 0, 0, 0);
    }
    
    private b(final int a, final int b, final int c, final int d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public static b a(final int n, final int n2, final int n3, final int n4) {
        if (n == 0 && n2 == 0 && n3 == 0 && n4 == 0) {
            return b.e;
        }
        return new b(n, n2, n3, n4);
    }
    
    public static b b(final Insets insets) {
        return a(insets.left, insets.top, insets.right, insets.bottom);
    }
    
    public Insets c() {
        return Insets.of(this.a, this.b, this.c, this.d);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o != null && b.class == o.getClass()) {
            final b b = (b)o;
            return this.d == b.d && this.a == b.a && this.c == b.c && this.b == b.b;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return ((this.a * 31 + this.b) * 31 + this.c) * 31 + this.d;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("Insets{left=");
        sb.append(this.a);
        sb.append(", top=");
        sb.append(this.b);
        sb.append(", right=");
        sb.append(this.c);
        sb.append(", bottom=");
        sb.append(this.d);
        sb.append('}');
        return sb.toString();
    }
}
