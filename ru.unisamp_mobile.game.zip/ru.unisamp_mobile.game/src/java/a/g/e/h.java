package a.g.e;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Array;
import android.graphics.Typeface;

public class h extends g
{
    protected Typeface l(Object ex) {
        try {
            final Object instance = Array.newInstance(super.g, 1);
            Array.set(instance, 0, (Object)ex);
            ex = (InvocationTargetException)super.m.invoke((Object)null, new Object[] { instance, "sans-serif", -1, -1 });
            return (Typeface)ex;
        }
        catch (final InvocationTargetException ex) {}
        catch (final IllegalAccessException ex2) {}
        throw new RuntimeException((Throwable)ex);
    }
    
    protected Method x(final Class<?> clazz) {
        final Class<?> class1 = Array.newInstance((Class)clazz, 1).getClass();
        final Class type = Integer.TYPE;
        final Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", class1, String.class, type, type);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
}
