package a.g.e;

import android.os.ParcelFileDescriptor;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import android.content.ContentResolver;
import java.nio.channels.FileChannel$MapMode;
import java.io.FileInputStream;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Process;
import android.os.StrictMode$ThreadPolicy;
import android.util.Log;
import java.io.FileOutputStream;
import android.os.StrictMode;
import java.io.InputStream;
import java.io.File;
import java.nio.ByteBuffer;
import android.content.res.Resources;
import android.content.Context;
import java.io.IOException;
import java.io.Closeable;

public class k
{
    public static void a(final Closeable closeable) {
        if (closeable == null) {
            return;
        }
        try {
            closeable.close();
        }
        catch (final IOException ex) {}
    }
    
    public static ByteBuffer b(Context e, final Resources resources, final int n) {
        e = (Context)e(e);
        if (e == null) {
            return null;
        }
        try {
            if (!c((File)e, resources, n)) {
                return null;
            }
            return g((File)e);
        }
        finally {
            ((File)e).delete();
        }
    }
    
    public static boolean c(final File file, final Resources resources, final int n) {
        Closeable closeable;
        try {
            final InputStream openRawResource = resources.openRawResource(n);
            try {
                final boolean d = d(file, openRawResource);
                a((Closeable)openRawResource);
                return d;
            }
            finally {}
        }
        finally {
            closeable = null;
        }
        a(closeable);
    }
    
    public static boolean d(final File file, final InputStream ex) {
        final StrictMode$ThreadPolicy allowThreadDiskWrites = StrictMode.allowThreadDiskWrites();
        final Closeable closeable = null;
        Object o = null;
        Closeable closeable2;
        try {
            try {
                o = o;
                final FileOutputStream fileOutputStream = new FileOutputStream(file, false);
                try {
                    final byte[] array = new byte[1024];
                    while (true) {
                        final int read = ((InputStream)ex).read(array);
                        if (read == -1) {
                            break;
                        }
                        fileOutputStream.write(array, 0, read);
                    }
                    a((Closeable)fileOutputStream);
                    StrictMode.setThreadPolicy(allowThreadDiskWrites);
                    return true;
                }
                catch (final IOException ex) {}
                finally {
                    o = fileOutputStream;
                }
            }
            finally {}
        }
        catch (final IOException ex) {
            closeable2 = closeable;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Error copying resource contents to temp file: ");
        sb.append(ex.getMessage());
        Log.e("TypefaceCompatUtil", sb.toString());
        a(closeable2);
        StrictMode.setThreadPolicy(allowThreadDiskWrites);
        return false;
        a((Closeable)o);
        StrictMode.setThreadPolicy(allowThreadDiskWrites);
        throw closeable2;
    }
    
    public static File e(Context cacheDir) {
        cacheDir = (Context)cacheDir.getCacheDir();
        if (cacheDir == null) {
            return null;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(".font");
        sb.append(Process.myPid());
        sb.append("-");
        sb.append(Process.myTid());
        sb.append("-");
        final String string = sb.toString();
        int n = 0;
    Label_0120_Outer:
        while (true) {
            Label_0126: {
                if (n >= 100) {
                    break Label_0126;
                }
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(string);
                sb2.append(n);
                final File file = new File((File)cacheDir, sb2.toString());
                while (true) {
                    try {
                        if (file.createNewFile()) {
                            return file;
                        }
                        ++n;
                        continue Label_0120_Outer;
                        return null;
                    }
                    catch (final IOException ex) {
                        continue;
                    }
                    break;
                }
            }
        }
    }
    
    public static ByteBuffer f(Context openFileDescriptor, CancellationSignal cancellationSignal, final Uri uri) {
        final ContentResolver contentResolver = openFileDescriptor.getContentResolver();
        try {
            openFileDescriptor = (Context)contentResolver.openFileDescriptor(uri, "r", cancellationSignal);
            if (openFileDescriptor == null) {
                if (openFileDescriptor != null) {
                    ((ParcelFileDescriptor)openFileDescriptor).close();
                }
                return null;
            }
            try {
                cancellationSignal = (CancellationSignal)new FileInputStream(((ParcelFileDescriptor)openFileDescriptor).getFileDescriptor());
                try {
                    final FileChannel channel = ((FileInputStream)cancellationSignal).getChannel();
                    final MappedByteBuffer map = channel.map(FileChannel$MapMode.READ_ONLY, 0L, channel.size());
                    ((FileInputStream)cancellationSignal).close();
                    if (openFileDescriptor != null) {
                        ((ParcelFileDescriptor)openFileDescriptor).close();
                    }
                    return (ByteBuffer)map;
                }
                finally {
                    try {
                        ((FileInputStream)cancellationSignal).close();
                    }
                    finally {
                        final Throwable t;
                        ((Throwable)uri).addSuppressed(t);
                    }
                }
            }
            finally {
                if (openFileDescriptor != null) {
                    try {
                        ((ParcelFileDescriptor)openFileDescriptor).close();
                    }
                    finally {
                        final Throwable t2;
                        ((Throwable)cancellationSignal).addSuppressed(t2);
                    }
                }
            }
        }
        catch (final IOException ex) {
            return null;
        }
    }
    
    private static ByteBuffer g(final File file) {
        try {
            final FileInputStream fileInputStream = new FileInputStream(file);
            try {
                final FileChannel channel = fileInputStream.getChannel();
                final MappedByteBuffer map = channel.map(FileChannel$MapMode.READ_ONLY, 0L, channel.size());
                fileInputStream.close();
                return (ByteBuffer)map;
            }
            finally {
                try {
                    fileInputStream.close();
                }
                finally {
                    final Throwable t;
                    ((Throwable)file).addSuppressed(t);
                }
            }
        }
        catch (final IOException ex) {
            return null;
        }
    }
}
