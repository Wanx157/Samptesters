package a.g.f.a;

import android.view.Menu;

public interface a extends Menu
{
}
