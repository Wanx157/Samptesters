package a.g.f.a;

import android.view.SubMenu;

public interface c extends a, SubMenu
{
}
