package a.g;

public final class a
{
    public static final int alpha = 2130903080;
    public static final int font = 2130903397;
    public static final int fontProviderAuthority = 2130903399;
    public static final int fontProviderCerts = 2130903400;
    public static final int fontProviderFetchStrategy = 2130903401;
    public static final int fontProviderFetchTimeout = 2130903402;
    public static final int fontProviderPackage = 2130903403;
    public static final int fontProviderQuery = 2130903404;
    public static final int fontStyle = 2130903405;
    public static final int fontVariationSettings = 2130903406;
    public static final int fontWeight = 2130903407;
    public static final int ttcIndex = 2130903895;
}
