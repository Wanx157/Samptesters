package a.g.i;

import android.database.Cursor;
import a.g.k.h;
import a.g.e.k;
import java.util.HashMap;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Collection;
import java.util.Collections;
import android.content.pm.PackageManager;
import java.util.concurrent.Callable;
import android.os.Handler;
import androidx.core.content.d.f$a;
import android.content.pm.PackageManager$NameNotFoundException;
import a.g.e.d;
import android.content.ContentResolver;
import android.net.Uri;
import android.content.ContentUris;
import android.os.Build$VERSION;
import android.net.Uri$Builder;
import android.content.res.Resources;
import android.content.pm.ProviderInfo;
import android.os.CancellationSignal;
import android.content.Context;
import java.util.Arrays;
import java.util.List;
import android.content.pm.Signature;
import java.util.Comparator;
import java.util.ArrayList;
import a.d.g;
import android.graphics.Typeface;
import a.d.e;

public class b
{
    static final a.d.e<String, Typeface> a;
    private static final c b;
    static final Object c;
    static final a.d.g<String, ArrayList<c.d<g>>> d;
    private static final Comparator<byte[]> e;
    
    static {
        a = new a.d.e<String, Typeface>(16);
        b = new c("fonts", 10, 10000);
        c = new Object();
        d = new a.d.g<String, ArrayList<c.d<g>>>();
        e = (Comparator)new Comparator<byte[]>() {
            public int a(final byte[] array, final byte[] array2) {
                if (array.length == array2.length) {
                    for (int i = 0; i < array.length; ++i) {
                        if (array[i] != array2[i]) {
                            final byte b = array[i];
                            final byte b2 = array2[i];
                            final int length = b;
                            final int length2 = b2;
                            return length - length2;
                        }
                    }
                    return 0;
                }
                final int length = array.length;
                final int length2 = array2.length;
                return length - length2;
            }
        };
    }
    
    private static List<byte[]> a(final Signature[] array) {
        final ArrayList list = new ArrayList();
        for (int i = 0; i < array.length; ++i) {
            ((List)list).add((Object)array[i].toByteArray());
        }
        return (List<byte[]>)list;
    }
    
    private static boolean b(final List<byte[]> list, final List<byte[]> list2) {
        if (list.size() != list2.size()) {
            return false;
        }
        for (int i = 0; i < list.size(); ++i) {
            if (!Arrays.equals((byte[])list.get(i), (byte[])list2.get(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static e c(final Context context, final CancellationSignal cancellationSignal, final a a) {
        final ProviderInfo h = h(context.getPackageManager(), a, context.getResources());
        if (h == null) {
            return new e(1, null);
        }
        return new e(0, e(context, a, h.authority, cancellationSignal));
    }
    
    private static List<List<byte[]>> d(final a a, final Resources resources) {
        if (a.a() != null) {
            return a.a();
        }
        return (List<List<byte[]>>)androidx.core.content.d.c.c(resources, a.b());
    }
    
    static f[] e(final Context context, final a a, String s, final CancellationSignal cancellationSignal) {
        final ArrayList list = new ArrayList();
        final Uri build = new Uri$Builder().scheme("content").authority(s).build();
        final Uri build2 = new Uri$Builder().scheme("content").authority(s).appendPath("file").build();
        final String s2 = s = null;
        try {
            Object o;
            if (Build$VERSION.SDK_INT > 16) {
                s = s2;
                final ContentResolver contentResolver = context.getContentResolver();
                s = s2;
                final String f = a.f();
                s = s2;
                o = contentResolver.query(build, new String[] { "_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code" }, "query = ?", new String[] { f }, (String)null, cancellationSignal);
            }
            else {
                s = s2;
                final ContentResolver contentResolver2 = context.getContentResolver();
                s = s2;
                final String f2 = a.f();
                s = s2;
                o = contentResolver2.query(build, new String[] { "_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code" }, "query = ?", new String[] { f2 }, (String)null);
            }
            ArrayList list2 = list;
            if (o != null) {
                list2 = list;
                s = (String)o;
                if (((Cursor)o).getCount() > 0) {
                    s = (String)o;
                    final int columnIndex = ((Cursor)o).getColumnIndex("result_code");
                    s = (String)o;
                    s = (String)o;
                    final ArrayList list3 = new ArrayList();
                    s = (String)o;
                    final int columnIndex2 = ((Cursor)o).getColumnIndex("_id");
                    s = (String)o;
                    final int columnIndex3 = ((Cursor)o).getColumnIndex("file_id");
                    s = (String)o;
                    final int columnIndex4 = ((Cursor)o).getColumnIndex("font_ttc_index");
                    s = (String)o;
                    final int columnIndex5 = ((Cursor)o).getColumnIndex("font_weight");
                    s = (String)o;
                    final int columnIndex6 = ((Cursor)o).getColumnIndex("font_italic");
                    while (true) {
                        s = (String)o;
                        if (!((Cursor)o).moveToNext()) {
                            break;
                        }
                        int int1;
                        if (columnIndex != -1) {
                            s = (String)o;
                            int1 = ((Cursor)o).getInt(columnIndex);
                        }
                        else {
                            int1 = 0;
                        }
                        int int2;
                        if (columnIndex4 != -1) {
                            s = (String)o;
                            int2 = ((Cursor)o).getInt(columnIndex4);
                        }
                        else {
                            int2 = 0;
                        }
                        Uri uri;
                        if (columnIndex3 == -1) {
                            s = (String)o;
                            uri = ContentUris.withAppendedId(build, ((Cursor)o).getLong(columnIndex2));
                        }
                        else {
                            s = (String)o;
                            uri = ContentUris.withAppendedId(build2, ((Cursor)o).getLong(columnIndex3));
                        }
                        int int3;
                        if (columnIndex5 != -1) {
                            s = (String)o;
                            int3 = ((Cursor)o).getInt(columnIndex5);
                        }
                        else {
                            int3 = 400;
                        }
                        boolean b = false;
                        Label_0490: {
                            if (columnIndex6 != -1) {
                                s = (String)o;
                                if (((Cursor)o).getInt(columnIndex6) == 1) {
                                    b = true;
                                    break Label_0490;
                                }
                            }
                            b = false;
                        }
                        s = (String)o;
                        s = (String)o;
                        final f f3 = new f(uri, int2, int3, b, int1);
                        s = (String)o;
                        list3.add((Object)f3);
                    }
                    list2 = list3;
                }
            }
            if (o != null) {
                ((Cursor)o).close();
            }
            return (f[])list2.toArray((Object[])new f[0]);
        }
        finally {
            Label_0560: {
                if (s != null) {
                    ((Cursor)s).close();
                    break Label_0560;
                }
                break Label_0560;
            }
            while (true) {}
        }
    }
    
    static g f(final Context context, final a a, final int n) {
        try {
            final e c = c(context, null, a);
            final int b = c.b();
            int n2 = -3;
            if (b == 0) {
                final Typeface b2 = a.g.e.d.b(context, null, c.a(), n);
                if (b2 != null) {
                    n2 = 0;
                }
                return new g(b2, n2);
            }
            if (c.b() == 1) {
                n2 = -2;
            }
            return new g(null, n2);
        }
        catch (final PackageManager$NameNotFoundException ex) {
            return new g(null, -1);
        }
    }
    
    public static Typeface g(Context a, final a a2, final f$a f$a, final Handler handler, final boolean b, int b2, final int n) {
        final StringBuilder sb = new StringBuilder();
        sb.append(a2.c());
        sb.append("-");
        sb.append(n);
        final String string = sb.toString();
        final Typeface typeface = b.a.c(string);
        if (typeface != null) {
            if (f$a != null) {
                f$a.d(typeface);
            }
            return typeface;
        }
        if (b && b2 == -1) {
            final g f = f(a, a2, n);
            if (f$a != null) {
                b2 = f.b;
                if (b2 == 0) {
                    f$a.b(f.a, handler);
                }
                else {
                    f$a.a(b2, handler);
                }
            }
            return f.a;
        }
        final Callable<g> callable = (Callable<g>)new Callable<g>(a, a2, n, string) {
            final Context a;
            final a b;
            final int c;
            final String d;
            
            public g a() {
                final g f = a.g.i.b.f(this.a, this.b, this.c);
                final Typeface a = f.a;
                if (a != null) {
                    a.g.i.b.a.d(this.d, a);
                }
                return f;
            }
        };
        a = null;
        Label_0173: {
            if (!b) {
                break Label_0173;
            }
            try {
                a = (Context)b.b.e((java.util.concurrent.Callable<g>)callable, b2).a;
                return (Typeface)a;
                Label_0182: {
                    a = (Context)new b$b(f$a, handler);
                }
                Label_0192: {
                    break Label_0192;
                    iftrue(Label_0182:)(f$a != null);
                    a = null;
                }
                final Object c = b.c;
                synchronized (c) {
                    final ArrayList list = b.d.get(string);
                    if (list != null) {
                        if (a != null) {
                            list.add((Object)a);
                        }
                        return null;
                    }
                    if (a != null) {
                        final ArrayList list2 = new ArrayList();
                        list2.add((Object)a);
                        b.d.put(string, (ArrayList<c.d<g>>)list2);
                    }
                    monitorexit(c);
                    b.b.d((java.util.concurrent.Callable<Object>)callable, (c.d<Object>)new b$c(string));
                    return null;
                }
            }
            catch (final InterruptedException ex) {
                return (Typeface)a;
            }
        }
    }
    
    public static ProviderInfo h(final PackageManager packageManager, final a a, final Resources resources) {
        final String d = a.d();
        int i = 0;
        final ProviderInfo resolveContentProvider = packageManager.resolveContentProvider(d, 0);
        if (resolveContentProvider == null) {
            final StringBuilder sb = new StringBuilder();
            sb.append("No package found for authority: ");
            sb.append(d);
            throw new PackageManager$NameNotFoundException(sb.toString());
        }
        if (resolveContentProvider.packageName.equals((Object)a.e())) {
            final List<byte[]> a2 = a(packageManager.getPackageInfo(resolveContentProvider.packageName, 64).signatures);
            Collections.sort((List)a2, (Comparator)a.g.i.b.e);
            for (List<List<byte[]>> d2 = d(a, resources); i < d2.size(); ++i) {
                final ArrayList list = new ArrayList((Collection)d2.get(i));
                Collections.sort((List)list, (Comparator)a.g.i.b.e);
                if (b(a2, (List<byte[]>)list)) {
                    return resolveContentProvider;
                }
            }
            return null;
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("Found content provider ");
        sb2.append(d);
        sb2.append(", but package was not ");
        sb2.append(a.e());
        throw new PackageManager$NameNotFoundException(sb2.toString());
    }
    
    public static Map<Uri, ByteBuffer> i(final Context context, final f[] array, final CancellationSignal cancellationSignal) {
        final HashMap hashMap = new HashMap();
        for (final f f : array) {
            if (f.a() == 0) {
                final Uri c = f.c();
                if (!hashMap.containsKey((Object)c)) {
                    hashMap.put((Object)c, (Object)k.f(context, cancellationSignal, c));
                }
            }
        }
        return (Map<Uri, ByteBuffer>)Collections.unmodifiableMap((Map)hashMap);
    }
    
    public static class e
    {
        private final int a;
        private final f[] b;
        
        public e(final int a, final f[] b) {
            this.a = a;
            this.b = b;
        }
        
        public f[] a() {
            return this.b;
        }
        
        public int b() {
            return this.a;
        }
    }
    
    public static class f
    {
        private final Uri a;
        private final int b;
        private final int c;
        private final boolean d;
        private final int e;
        
        public f(final Uri uri, final int b, final int c, final boolean d, final int e) {
            h.c(uri);
            this.a = uri;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
        }
        
        public int a() {
            return this.e;
        }
        
        public int b() {
            return this.b;
        }
        
        public Uri c() {
            return this.a;
        }
        
        public int d() {
            return this.c;
        }
        
        public boolean e() {
            return this.d;
        }
    }
    
    private static final class g
    {
        final Typeface a;
        final int b;
        
        g(final Typeface a, final int b) {
            this.a = a;
            this.b = b;
        }
    }
}
