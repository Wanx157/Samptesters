package a.g.i;

import java.util.concurrent.Callable;
import android.os.Message;
import android.os.Handler$Callback;
import android.os.Handler;
import android.os.HandlerThread;

public class c
{
    private final Object a;
    private HandlerThread b;
    private Handler c;
    private int d;
    private Handler$Callback e;
    private final int f;
    private final int g;
    private final String h;
    
    public c(final String h, final int g, final int f) {
        this.a = new Object();
        this.e = (Handler$Callback)new Handler$Callback() {
            final c a;
            
            public boolean handleMessage(final Message message) {
                final int what = message.what;
                if (what == 0) {
                    this.a.a();
                    return true;
                }
                if (what != 1) {
                    return true;
                }
                this.a.b((Runnable)message.obj);
                return true;
            }
        };
        this.h = h;
        this.g = g;
        this.f = f;
        this.d = 0;
    }
    
    private void c(final Runnable runnable) {
        final Object a = this.a;
        synchronized (a) {
            if (this.b == null) {
                (this.b = new HandlerThread(this.h, this.g)).start();
                this.c = new Handler(this.b.getLooper(), this.e);
                ++this.d;
            }
            this.c.removeMessages(0);
            this.c.sendMessage(this.c.obtainMessage(1, (Object)runnable));
        }
    }
    
    void a() {
        final Object a = this.a;
        synchronized (a) {
            if (this.c.hasMessages(1)) {
                return;
            }
            this.b.quit();
            this.b = null;
            this.c = null;
        }
    }
    
    void b(final Runnable runnable) {
        runnable.run();
        final Object a = this.a;
        synchronized (a) {
            this.c.removeMessages(0);
            this.c.sendMessageDelayed(this.c.obtainMessage(0), (long)this.f);
        }
    }
    
    public <T> void d(final Callable<T> callable, final d<T> d) {
        this.c((Runnable)new Runnable(this, callable, new Handler(), d) {
            final Callable b;
            final Handler c;
            final d d;
            
            public void run() {
                Object call;
                try {
                    call = this.b.call();
                }
                catch (final Exception ex) {
                    call = null;
                }
                this.c.post((Runnable)new Runnable(this, call) {
                    final Object b;
                    final c$b c;
                    
                    public void run() {
                        this.c.d.a(this.b);
                    }
                });
            }
        });
    }
    
    public <T> T e(final Callable<T> p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: invokespecial   java/util/concurrent/locks/ReentrantLock.<init>:()V
        //     7: astore          7
        //     9: aload           7
        //    11: invokevirtual   java/util/concurrent/locks/ReentrantLock.newCondition:()Ljava/util/concurrent/locks/Condition;
        //    14: astore          10
        //    16: new             Ljava/util/concurrent/atomic/AtomicReference;
        //    19: dup            
        //    20: invokespecial   java/util/concurrent/atomic/AtomicReference.<init>:()V
        //    23: astore          8
        //    25: new             Ljava/util/concurrent/atomic/AtomicBoolean;
        //    28: dup            
        //    29: iconst_1       
        //    30: invokespecial   java/util/concurrent/atomic/AtomicBoolean.<init>:(Z)V
        //    33: astore          9
        //    35: aload_0        
        //    36: new             La/g/i/c$c;
        //    39: dup            
        //    40: aload_0        
        //    41: aload           8
        //    43: aload_1        
        //    44: aload           7
        //    46: aload           9
        //    48: aload           10
        //    50: invokespecial   a/g/i/c$c.<init>:(La/g/i/c;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/Callable;Ljava/util/concurrent/locks/ReentrantLock;Ljava/util/concurrent/atomic/AtomicBoolean;Ljava/util/concurrent/locks/Condition;)V
        //    53: invokespecial   a/g/i/c.c:(Ljava/lang/Runnable;)V
        //    56: aload           7
        //    58: invokevirtual   java/util/concurrent/locks/ReentrantLock.lock:()V
        //    61: aload           9
        //    63: invokevirtual   java/util/concurrent/atomic/AtomicBoolean.get:()Z
        //    66: ifne            82
        //    69: aload           8
        //    71: invokevirtual   java/util/concurrent/atomic/AtomicReference.get:()Ljava/lang/Object;
        //    74: astore_1       
        //    75: aload           7
        //    77: invokevirtual   java/util/concurrent/locks/ReentrantLock.unlock:()V
        //    80: aload_1        
        //    81: areturn        
        //    82: getstatic       java/util/concurrent/TimeUnit.MILLISECONDS:Ljava/util/concurrent/TimeUnit;
        //    85: iload_2        
        //    86: i2l            
        //    87: invokevirtual   java/util/concurrent/TimeUnit.toNanos:(J)J
        //    90: lstore_3       
        //    91: aload           10
        //    93: lload_3        
        //    94: invokeinterface java/util/concurrent/locks/Condition.awaitNanos:(J)J
        //    99: lstore          5
        //   101: lload           5
        //   103: lstore_3       
        //   104: aload           9
        //   106: invokevirtual   java/util/concurrent/atomic/AtomicBoolean.get:()Z
        //   109: ifne            125
        //   112: aload           8
        //   114: invokevirtual   java/util/concurrent/atomic/AtomicReference.get:()Ljava/lang/Object;
        //   117: astore_1       
        //   118: aload           7
        //   120: invokevirtual   java/util/concurrent/locks/ReentrantLock.unlock:()V
        //   123: aload_1        
        //   124: areturn        
        //   125: lload_3        
        //   126: lconst_0       
        //   127: lcmp           
        //   128: ifle            134
        //   131: goto            91
        //   134: new             Ljava/lang/InterruptedException;
        //   137: astore_1       
        //   138: aload_1        
        //   139: ldc             "timeout"
        //   141: invokespecial   java/lang/InterruptedException.<init>:(Ljava/lang/String;)V
        //   144: aload_1        
        //   145: athrow         
        //   146: astore_1       
        //   147: aload           7
        //   149: invokevirtual   java/util/concurrent/locks/ReentrantLock.unlock:()V
        //   152: goto            157
        //   155: aload_1        
        //   156: athrow         
        //   157: goto            155
        //   160: astore_1       
        //   161: goto            104
        //    Signature:
        //  <T:Ljava/lang/Object;>(Ljava/util/concurrent/Callable<TT;>;I)TT;
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  61     75     146    160    Any
        //  82     91     146    160    Any
        //  91     101    160    164    Ljava/lang/InterruptedException;
        //  91     101    146    160    Any
        //  104    118    146    160    Any
        //  134    146    146    160    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0091:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public interface d<T>
    {
        void a(final T p0);
    }
}
