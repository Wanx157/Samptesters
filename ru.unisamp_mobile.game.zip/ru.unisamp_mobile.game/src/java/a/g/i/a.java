package a.g.i;

import android.util.Base64;
import a.g.k.h;
import java.util.List;

public final class a
{
    private final String a;
    private final String b;
    private final String c;
    private final List<List<byte[]>> d;
    private final int e;
    private final String f;
    
    public a(final String s, final String s2, final String s3, final List<List<byte[]>> list) {
        h.c(s);
        this.a = s;
        h.c(s2);
        this.b = s2;
        h.c(s3);
        this.c = s3;
        h.c(list);
        this.d = list;
        this.e = 0;
        final StringBuilder sb = new StringBuilder(this.a);
        sb.append("-");
        sb.append(this.b);
        sb.append("-");
        sb.append(this.c);
        this.f = sb.toString();
    }
    
    public List<List<byte[]>> a() {
        return this.d;
    }
    
    public int b() {
        return this.e;
    }
    
    public String c() {
        return this.f;
    }
    
    public String d() {
        return this.a;
    }
    
    public String e() {
        return this.b;
    }
    
    public String f() {
        return this.c;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("FontRequest {mProviderAuthority: ");
        sb2.append(this.a);
        sb2.append(", mProviderPackage: ");
        sb2.append(this.b);
        sb2.append(", mQuery: ");
        sb2.append(this.c);
        sb2.append(", mCertificates:");
        sb.append(sb2.toString());
        for (int i = 0; i < this.d.size(); ++i) {
            sb.append(" [");
            final List list = (List)this.d.get(i);
            for (int j = 0; j < list.size(); ++j) {
                sb.append(" \"");
                sb.append(Base64.encodeToString((byte[])list.get(j), 0));
                sb.append("\"");
            }
            sb.append(" ]");
        }
        sb.append("}");
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("mCertificatesArray: ");
        sb3.append(this.e);
        sb.append(sb3.toString());
        return sb.toString();
    }
}
