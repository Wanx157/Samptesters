package a.h.a;

import android.widget.Filter;
import android.view.ViewGroup;
import android.database.ContentObserver;
import android.view.View;
import android.database.DataSetObserver;
import android.content.Context;
import android.database.Cursor;
import android.widget.Filterable;
import android.widget.BaseAdapter;

public abstract class a extends BaseAdapter implements Filterable, b$a
{
    protected boolean b;
    protected boolean c;
    protected Cursor d;
    protected Context e;
    protected int f;
    protected a.a$a g;
    protected DataSetObserver h;
    protected b i;
    
    public a(final Context context, final Cursor cursor, final boolean b) {
        int n;
        if (b) {
            n = 1;
        }
        else {
            n = 2;
        }
        this.f(context, cursor, n);
    }
    
    public abstract CharSequence a(final Cursor p0);
    
    public void b(Cursor j) {
        j = this.j(j);
        if (j != null) {
            j.close();
        }
    }
    
    public Cursor c() {
        return this.d;
    }
    
    public abstract void e(final View p0, final Context p1, final Cursor p2);
    
    void f(final Context e, final Cursor d, int n) {
        boolean b = false;
        if ((n & 0x1) == 0x1) {
            n |= 0x2;
            this.c = true;
        }
        else {
            this.c = false;
        }
        if (d != null) {
            b = true;
        }
        this.d = d;
        this.b = b;
        this.e = e;
        int columnIndexOrThrow;
        if (b) {
            columnIndexOrThrow = d.getColumnIndexOrThrow("_id");
        }
        else {
            columnIndexOrThrow = -1;
        }
        this.f = columnIndexOrThrow;
        Object h;
        if ((n & 0x2) == 0x2) {
            this.g = new a.a$a(this);
            h = new a.a$b(this);
        }
        else {
            h = null;
            this.g = null;
        }
        this.h = (DataSetObserver)h;
        if (b) {
            final a.a$a g = this.g;
            if (g != null) {
                d.registerContentObserver((ContentObserver)g);
            }
            final DataSetObserver h2 = this.h;
            if (h2 != null) {
                d.registerDataSetObserver(h2);
            }
        }
    }
    
    public abstract View g(final Context p0, final Cursor p1, final ViewGroup p2);
    
    public int getCount() {
        if (this.b) {
            final Cursor d = this.d;
            if (d != null) {
                return d.getCount();
            }
        }
        return 0;
    }
    
    public View getDropDownView(final int n, final View view, final ViewGroup viewGroup) {
        if (this.b) {
            this.d.moveToPosition(n);
            View g;
            if ((g = view) == null) {
                g = this.g(this.e, this.d, viewGroup);
            }
            this.e(g, this.e, this.d);
            return g;
        }
        return null;
    }
    
    public Filter getFilter() {
        if (this.i == null) {
            this.i = new b((b$a)this);
        }
        return (Filter)this.i;
    }
    
    public Object getItem(final int n) {
        if (this.b) {
            final Cursor d = this.d;
            if (d != null) {
                d.moveToPosition(n);
                return this.d;
            }
        }
        return null;
    }
    
    public long getItemId(final int n) {
        if (this.b) {
            final Cursor d = this.d;
            if (d != null && d.moveToPosition(n)) {
                return this.d.getLong(this.f);
            }
        }
        return 0L;
    }
    
    public View getView(final int n, final View view, final ViewGroup viewGroup) {
        if (!this.b) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        }
        if (this.d.moveToPosition(n)) {
            View h;
            if ((h = view) == null) {
                h = this.h(this.e, this.d, viewGroup);
            }
            this.e(h, this.e, this.d);
            return h;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("couldn't move cursor to position ");
        sb.append(n);
        throw new IllegalStateException(sb.toString());
    }
    
    public abstract View h(final Context p0, final Cursor p1, final ViewGroup p2);
    
    protected void i() {
        if (this.c) {
            final Cursor d = this.d;
            if (d != null && !d.isClosed()) {
                this.b = this.d.requery();
            }
        }
    }
    
    public Cursor j(final Cursor d) {
        final Cursor d2 = this.d;
        if (d == d2) {
            return null;
        }
        if (d2 != null) {
            final a.a$a g = this.g;
            if (g != null) {
                d2.unregisterContentObserver((ContentObserver)g);
            }
            final DataSetObserver h = this.h;
            if (h != null) {
                d2.unregisterDataSetObserver(h);
            }
        }
        if ((this.d = d) != null) {
            final a.a$a g2 = this.g;
            if (g2 != null) {
                d.registerContentObserver((ContentObserver)g2);
            }
            final DataSetObserver h2 = this.h;
            if (h2 != null) {
                d.registerDataSetObserver(h2);
            }
            this.f = d.getColumnIndexOrThrow("_id");
            this.b = true;
            this.notifyDataSetChanged();
        }
        else {
            this.f = -1;
            this.b = false;
            this.notifyDataSetInvalidated();
        }
        return d2;
    }
}
