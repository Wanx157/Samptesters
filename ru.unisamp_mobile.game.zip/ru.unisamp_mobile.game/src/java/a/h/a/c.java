package a.h.a;

import android.view.View;
import android.view.ViewGroup;
import android.database.Cursor;
import android.content.Context;
import android.view.LayoutInflater;

public abstract class c extends a
{
    private int j;
    private int k;
    private LayoutInflater l;
    
    @Deprecated
    public c(final Context context, final int n, final Cursor cursor, final boolean b) {
        super(context, cursor, b);
        this.k = n;
        this.j = n;
        this.l = (LayoutInflater)context.getSystemService("layout_inflater");
    }
    
    @Override
    public View g(final Context context, final Cursor cursor, final ViewGroup viewGroup) {
        return this.l.inflate(this.k, viewGroup, false);
    }
    
    @Override
    public View h(final Context context, final Cursor cursor, final ViewGroup viewGroup) {
        return this.l.inflate(this.j, viewGroup, false);
    }
}
