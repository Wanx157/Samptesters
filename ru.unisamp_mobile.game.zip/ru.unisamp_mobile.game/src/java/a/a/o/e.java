package a.a.o;

import android.view.ViewGroup;
import android.view.MenuInflater;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.view.menu.g;
import android.view.View;
import java.lang.ref.WeakReference;
import androidx.appcompat.widget.ActionBarContextView;
import android.content.Context;
import androidx.appcompat.view.menu.g$a;

public class e extends b implements g$a
{
    private Context d;
    private ActionBarContextView e;
    private b$a f;
    private WeakReference<View> g;
    private boolean h;
    private g i;
    
    public e(final Context d, final ActionBarContextView e, final b$a f, final boolean b) {
        this.d = d;
        this.e = e;
        this.f = f;
        final g i = new g(((ViewGroup)e).getContext());
        i.S(1);
        (this.i = i).R((g$a)this);
    }
    
    public boolean a(final g g, final MenuItem menuItem) {
        return this.f.b((b)this, menuItem);
    }
    
    public void b(final g g) {
        this.k();
        this.e.l();
    }
    
    public void c() {
        if (this.h) {
            return;
        }
        this.h = true;
        ((ViewGroup)this.e).sendAccessibilityEvent(32);
        this.f.d((b)this);
    }
    
    public View d() {
        final WeakReference<View> g = this.g;
        View view;
        if (g != null) {
            view = (View)g.get();
        }
        else {
            view = null;
        }
        return view;
    }
    
    public Menu e() {
        return (Menu)this.i;
    }
    
    public MenuInflater f() {
        return (MenuInflater)new a.a.o.g(((ViewGroup)this.e).getContext());
    }
    
    public CharSequence g() {
        return this.e.getSubtitle();
    }
    
    public CharSequence i() {
        return this.e.getTitle();
    }
    
    public void k() {
        this.f.a((b)this, (Menu)this.i);
    }
    
    public boolean l() {
        return this.e.j();
    }
    
    public void m(final View customView) {
        this.e.setCustomView(customView);
        WeakReference g;
        if (customView != null) {
            g = new WeakReference((Object)customView);
        }
        else {
            g = null;
        }
        this.g = (WeakReference<View>)g;
    }
    
    public void n(final int n) {
        this.o((CharSequence)this.d.getString(n));
    }
    
    public void o(final CharSequence subtitle) {
        this.e.setSubtitle(subtitle);
    }
    
    public void q(final int n) {
        this.r((CharSequence)this.d.getString(n));
    }
    
    public void r(final CharSequence title) {
        this.e.setTitle(title);
    }
    
    public void s(final boolean titleOptional) {
        super.s(titleOptional);
        this.e.setTitleOptional(titleOptional);
    }
}
