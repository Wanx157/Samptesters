package a.a.o;

import java.util.Iterator;
import a.g.l.z;
import a.g.l.y;
import android.view.animation.Interpolator;
import a.g.l.x;
import java.util.ArrayList;

public class h
{
    final ArrayList<x> a;
    private long b;
    private Interpolator c;
    y d;
    private boolean e;
    private final z f;
    
    public h() {
        this.b = -1L;
        this.f = (z)new h$a(this);
        this.a = (ArrayList<x>)new ArrayList();
    }
    
    public void a() {
        if (!this.e) {
            return;
        }
        final Iterator iterator = this.a.iterator();
        while (iterator.hasNext()) {
            ((x)iterator.next()).b();
        }
        this.e = false;
    }
    
    void b() {
        this.e = false;
    }
    
    public h c(final x x) {
        if (!this.e) {
            this.a.add((Object)x);
        }
        return this;
    }
    
    public h d(final x x, final x x2) {
        this.a.add((Object)x);
        x2.h(x.c());
        this.a.add((Object)x2);
        return this;
    }
    
    public h e(final long b) {
        if (!this.e) {
            this.b = b;
        }
        return this;
    }
    
    public h f(final Interpolator c) {
        if (!this.e) {
            this.c = c;
        }
        return this;
    }
    
    public h g(final y d) {
        if (!this.e) {
            this.d = d;
        }
        return this;
    }
    
    public void h() {
        if (this.e) {
            return;
        }
        for (final x x : this.a) {
            final long b = this.b;
            if (b >= 0L) {
                x.d(b);
            }
            final Interpolator c = this.c;
            if (c != null) {
                x.e(c);
            }
            if (this.d != null) {
                x.f((y)this.f);
            }
            x.j();
        }
        this.e = true;
    }
}
