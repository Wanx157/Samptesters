package a.a.o;

@Deprecated
public interface c
{
    void c();
    
    void f();
}
