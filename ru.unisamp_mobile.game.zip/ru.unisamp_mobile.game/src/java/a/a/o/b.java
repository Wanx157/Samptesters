package a.a.o;

import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.Menu;
import android.view.View;

public abstract class b
{
    private Object b;
    private boolean c;
    
    public abstract void c();
    
    public abstract View d();
    
    public abstract Menu e();
    
    public abstract MenuInflater f();
    
    public abstract CharSequence g();
    
    public Object h() {
        return this.b;
    }
    
    public abstract CharSequence i();
    
    public boolean j() {
        return this.c;
    }
    
    public abstract void k();
    
    public abstract boolean l();
    
    public abstract void m(final View p0);
    
    public abstract void n(final int p0);
    
    public abstract void o(final CharSequence p0);
    
    public void p(final Object b) {
        this.b = b;
    }
    
    public abstract void q(final int p0);
    
    public abstract void r(final CharSequence p0);
    
    public void s(final boolean c) {
        this.c = c;
    }
    
    public interface a
    {
        boolean a(final b p0, final Menu p1);
        
        boolean b(final b p0, final MenuItem p1);
        
        boolean c(final b p0, final Menu p1);
        
        void d(final b p0);
    }
}
