package a.a.o;

import android.view.MenuInflater;
import androidx.appcompat.view.menu.o;
import a.g.f.a.a;
import android.view.Menu;
import android.view.View;
import android.content.Context;
import android.view.ActionMode;

public class f extends ActionMode
{
    final Context a;
    final b b;
    
    public f(final Context a, final b b) {
        this.a = a;
        this.b = b;
    }
    
    public void finish() {
        this.b.c();
    }
    
    public View getCustomView() {
        return this.b.d();
    }
    
    public Menu getMenu() {
        return (Menu)new o(this.a, (a)this.b.e());
    }
    
    public MenuInflater getMenuInflater() {
        return this.b.f();
    }
    
    public CharSequence getSubtitle() {
        return this.b.g();
    }
    
    public Object getTag() {
        return this.b.h();
    }
    
    public CharSequence getTitle() {
        return this.b.i();
    }
    
    public boolean getTitleOptionalHint() {
        return this.b.j();
    }
    
    public void invalidate() {
        this.b.k();
    }
    
    public boolean isTitleOptional() {
        return this.b.l();
    }
    
    public void setCustomView(final View view) {
        this.b.m(view);
    }
    
    public void setSubtitle(final int n) {
        this.b.n(n);
    }
    
    public void setSubtitle(final CharSequence charSequence) {
        this.b.o(charSequence);
    }
    
    public void setTag(final Object o) {
        this.b.p(o);
    }
    
    public void setTitle(final int n) {
        this.b.q(n);
    }
    
    public void setTitle(final CharSequence charSequence) {
        this.b.r(charSequence);
    }
    
    public void setTitleOptionalHint(final boolean b) {
        this.b.s(b);
    }
}
