package a.a.o;

import androidx.appcompat.widget.d0;
import androidx.appcompat.widget.v0;
import android.content.res.TypedArray;
import android.view.SubMenu;
import a.g.l.h;
import android.view.View;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.i;
import java.lang.reflect.Constructor;
import android.util.Log;
import android.graphics.PorterDuff$Mode;
import android.content.res.ColorStateList;
import android.view.InflateException;
import android.view.MenuItem;
import java.lang.reflect.Method;
import android.view.MenuItem$OnMenuItemClickListener;
import android.content.res.XmlResourceParser;
import org.xmlpull.v1.XmlPullParserException;
import java.io.IOException;
import android.util.Xml;
import a.g.f.a.a;
import a.g.l.b;
import android.view.Menu;
import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParser;
import android.content.ContextWrapper;
import android.app.Activity;
import android.content.Context;
import android.view.MenuInflater;

public class g extends MenuInflater
{
    static final Class<?>[] e;
    static final Class<?>[] f;
    final Object[] a;
    final Object[] b;
    Context c;
    private Object d;
    
    static {
        f = (e = new Class[] { Context.class });
    }
    
    public g(final Context c) {
        super(c);
        this.c = c;
        final Object[] array = { c };
        this.a = array;
        this.b = array;
    }
    
    private Object a(final Object o) {
        if (o instanceof Activity) {
            return o;
        }
        Object a = o;
        if (o instanceof ContextWrapper) {
            a = this.a(((ContextWrapper)o).getBaseContext());
        }
        return a;
    }
    
    private void c(final XmlPullParser xmlPullParser, final AttributeSet set, final Menu menu) {
        final b b = new b(menu);
        int i = xmlPullParser.getEventType();
        String name3;
        while (true) {
            while (i != 2) {
                int n = xmlPullParser.next();
                if ((i = n) == 1) {
                    String s = null;
                    int j = 0;
                    int n2 = 0;
                    while (j == 0) {
                        if (n == 1) {
                            throw new RuntimeException("Unexpected end of document");
                        }
                        int n3;
                        int n4;
                        String name;
                        if (n != 2) {
                            if (n != 3) {
                                n3 = j;
                                n4 = n2;
                                name = s;
                            }
                            else {
                                final String name2 = xmlPullParser.getName();
                                if (n2 != 0 && name2.equals((Object)s)) {
                                    name = null;
                                    n4 = 0;
                                    n3 = j;
                                }
                                else if (name2.equals((Object)"group")) {
                                    b.h();
                                    n3 = j;
                                    n4 = n2;
                                    name = s;
                                }
                                else if (name2.equals((Object)"item")) {
                                    n3 = j;
                                    n4 = n2;
                                    name = s;
                                    if (!b.d()) {
                                        final a.g.l.b a = b.A;
                                        if (a != null && a.a()) {
                                            b.b();
                                            n3 = j;
                                            n4 = n2;
                                            name = s;
                                        }
                                        else {
                                            b.a();
                                            n3 = j;
                                            n4 = n2;
                                            name = s;
                                        }
                                    }
                                }
                                else {
                                    n3 = j;
                                    n4 = n2;
                                    name = s;
                                    if (name2.equals((Object)"menu")) {
                                        n3 = 1;
                                        n4 = n2;
                                        name = s;
                                    }
                                }
                            }
                        }
                        else if (n2 != 0) {
                            n3 = j;
                            n4 = n2;
                            name = s;
                        }
                        else {
                            name = xmlPullParser.getName();
                            if (name.equals((Object)"group")) {
                                b.f(set);
                                n3 = j;
                                n4 = n2;
                                name = s;
                            }
                            else if (name.equals((Object)"item")) {
                                b.g(set);
                                n3 = j;
                                n4 = n2;
                                name = s;
                            }
                            else if (name.equals((Object)"menu")) {
                                this.c(xmlPullParser, set, (Menu)b.b());
                                n3 = j;
                                n4 = n2;
                                name = s;
                            }
                            else {
                                n4 = 1;
                                n3 = j;
                            }
                        }
                        final int next = xmlPullParser.next();
                        j = n3;
                        n2 = n4;
                        s = name;
                        n = next;
                    }
                    return;
                }
            }
            name3 = xmlPullParser.getName();
            if (name3.equals((Object)"menu")) {
                final int n = xmlPullParser.next();
                continue;
            }
            break;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Expecting menu, got ");
        sb.append(name3);
        throw new RuntimeException(sb.toString());
    }
    
    Object b() {
        if (this.d == null) {
            this.d = this.a(this.c);
        }
        return this.d;
    }
    
    public void inflate(final int n, final Menu menu) {
        if (!(menu instanceof a.g.f.a.a)) {
            super.inflate(n, menu);
            return;
        }
        XmlResourceParser layout = null;
        try {
            try {
                final XmlResourceParser xmlResourceParser = layout = this.c.getResources().getLayout(n);
                this.c((XmlPullParser)xmlResourceParser, Xml.asAttributeSet((XmlPullParser)xmlResourceParser), menu);
                if (xmlResourceParser != null) {
                    xmlResourceParser.close();
                }
            }
            finally {
                if (layout != null) {
                    layout.close();
                }
            }
        }
        catch (final IOException ex) {}
        catch (final XmlPullParserException ex2) {}
    }
    
    private static class a implements MenuItem$OnMenuItemClickListener
    {
        private static final Class<?>[] c;
        private Object a;
        private Method b;
        
        static {
            c = new Class[] { MenuItem.class };
        }
        
        public a(final Object a, final String name) {
            this.a = a;
            final Class<?> class1 = a.getClass();
            try {
                this.b = class1.getMethod(name, a.c);
            }
            catch (final Exception ex) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Couldn't resolve menu item onClick handler ");
                sb.append(name);
                sb.append(" in class ");
                sb.append(class1.getName());
                final InflateException ex2 = new InflateException(sb.toString());
                ex2.initCause((Throwable)ex);
                throw ex2;
            }
        }
        
        public boolean onMenuItemClick(final MenuItem menuItem) {
            try {
                if (this.b.getReturnType() == Boolean.TYPE) {
                    return (boolean)this.b.invoke(this.a, new Object[] { menuItem });
                }
                this.b.invoke(this.a, new Object[] { menuItem });
                return true;
            }
            catch (final Exception ex) {
                throw new RuntimeException((Throwable)ex);
            }
        }
    }
    
    private class b
    {
        a.g.l.b A;
        private CharSequence B;
        private CharSequence C;
        private ColorStateList D;
        private PorterDuff$Mode E;
        final g F;
        private Menu a;
        private int b;
        private int c;
        private int d;
        private int e;
        private boolean f;
        private boolean g;
        private boolean h;
        private int i;
        private int j;
        private CharSequence k;
        private CharSequence l;
        private int m;
        private char n;
        private int o;
        private char p;
        private int q;
        private int r;
        private boolean s;
        private boolean t;
        private boolean u;
        private int v;
        private int w;
        private String x;
        private String y;
        private String z;
        
        public b(final g f, final Menu a) {
            this.F = f;
            this.D = null;
            this.E = null;
            this.a = a;
            this.h();
        }
        
        private char c(final String s) {
            if (s == null) {
                return '\0';
            }
            return s.charAt(0);
        }
        
        private <T> T e(final String name, final Class<?>[] parameterTypes, final Object[] array) {
            try {
                final java.lang.reflect.Constructor<?> constructor = Class.forName(name, false, this.F.c.getClassLoader()).getConstructor(parameterTypes);
                constructor.setAccessible(true);
                return (T)constructor.newInstance(array);
            }
            catch (final Exception ex) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Cannot instantiate class: ");
                sb.append(name);
                Log.w("SupportMenuInflater", sb.toString(), (Throwable)ex);
                return null;
            }
        }
        
        private void i(final MenuItem menuItem) {
            final MenuItem setEnabled = menuItem.setChecked(this.s).setVisible(this.t).setEnabled(this.u);
            final int r = this.r;
            boolean b = false;
            setEnabled.setCheckable(r >= 1).setTitleCondensed(this.l).setIcon(this.m);
            final int v = this.v;
            if (v >= 0) {
                menuItem.setShowAsAction(v);
            }
            if (this.z != null) {
                if (this.F.c.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                menuItem.setOnMenuItemClickListener((MenuItem$OnMenuItemClickListener)new a(this.F.b(), this.z));
            }
            if (this.r >= 2) {
                if (menuItem instanceof i) {
                    ((i)menuItem).t(true);
                }
                else if (menuItem instanceof j) {
                    ((j)menuItem).h(true);
                }
            }
            final String x = this.x;
            if (x != null) {
                menuItem.setActionView((View)this.e(x, a.a.o.g.e, this.F.a));
                b = true;
            }
            final int w = this.w;
            if (w > 0) {
                if (!b) {
                    menuItem.setActionView(w);
                }
                else {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                }
            }
            final a.g.l.b a = this.A;
            if (a != null) {
                a.g.l.h.a(menuItem, a);
            }
            a.g.l.h.c(menuItem, this.B);
            a.g.l.h.g(menuItem, this.C);
            a.g.l.h.b(menuItem, this.n, this.o);
            a.g.l.h.f(menuItem, this.p, this.q);
            final PorterDuff$Mode e = this.E;
            if (e != null) {
                a.g.l.h.e(menuItem, e);
            }
            final ColorStateList d = this.D;
            if (d != null) {
                a.g.l.h.d(menuItem, d);
            }
        }
        
        public void a() {
            this.h = true;
            this.i(this.a.add(this.b, this.i, this.j, this.k));
        }
        
        public SubMenu b() {
            this.h = true;
            final SubMenu addSubMenu = this.a.addSubMenu(this.b, this.i, this.j, this.k);
            this.i(addSubMenu.getItem());
            return addSubMenu;
        }
        
        public boolean d() {
            return this.h;
        }
        
        public void f(final AttributeSet set) {
            final TypedArray obtainStyledAttributes = this.F.c.obtainStyledAttributes(set, a.a.j.MenuGroup);
            this.b = obtainStyledAttributes.getResourceId(a.a.j.MenuGroup_android_id, 0);
            this.c = obtainStyledAttributes.getInt(a.a.j.MenuGroup_android_menuCategory, 0);
            this.d = obtainStyledAttributes.getInt(a.a.j.MenuGroup_android_orderInCategory, 0);
            this.e = obtainStyledAttributes.getInt(a.a.j.MenuGroup_android_checkableBehavior, 0);
            this.f = obtainStyledAttributes.getBoolean(a.a.j.MenuGroup_android_visible, true);
            this.g = obtainStyledAttributes.getBoolean(a.a.j.MenuGroup_android_enabled, true);
            obtainStyledAttributes.recycle();
        }
        
        public void g(final AttributeSet set) {
            final v0 u = v0.u(this.F.c, set, a.a.j.MenuItem);
            this.i = u.n(a.a.j.MenuItem_android_id, 0);
            this.j = ((u.k(a.a.j.MenuItem_android_menuCategory, this.c) & 0xFFFF0000) | (u.k(a.a.j.MenuItem_android_orderInCategory, this.d) & 0xFFFF));
            this.k = u.p(a.a.j.MenuItem_android_title);
            this.l = u.p(a.a.j.MenuItem_android_titleCondensed);
            this.m = u.n(a.a.j.MenuItem_android_icon, 0);
            this.n = this.c(u.o(a.a.j.MenuItem_android_alphabeticShortcut));
            this.o = u.k(a.a.j.MenuItem_alphabeticModifiers, 4096);
            this.p = this.c(u.o(a.a.j.MenuItem_android_numericShortcut));
            this.q = u.k(a.a.j.MenuItem_numericModifiers, 4096);
            int r;
            if (u.s(a.a.j.MenuItem_android_checkable)) {
                r = (u.a(a.a.j.MenuItem_android_checkable, false) ? 1 : 0);
            }
            else {
                r = this.e;
            }
            this.r = r;
            this.s = u.a(a.a.j.MenuItem_android_checked, false);
            this.t = u.a(a.a.j.MenuItem_android_visible, this.f);
            this.u = u.a(a.a.j.MenuItem_android_enabled, this.g);
            this.v = u.k(a.a.j.MenuItem_showAsAction, -1);
            this.z = u.o(a.a.j.MenuItem_android_onClick);
            this.w = u.n(a.a.j.MenuItem_actionLayout, 0);
            this.x = u.o(a.a.j.MenuItem_actionViewClass);
            final String o = u.o(a.a.j.MenuItem_actionProviderClass);
            this.y = o;
            final boolean b = o != null;
            if (b && this.w == 0 && this.x == null) {
                this.A = this.e(this.y, a.a.o.g.f, this.F.b);
            }
            else {
                if (b) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                }
                this.A = null;
            }
            this.B = u.p(a.a.j.MenuItem_contentDescription);
            this.C = u.p(a.a.j.MenuItem_tooltipText);
            if (u.s(a.a.j.MenuItem_iconTintMode)) {
                this.E = d0.e(u.k(a.a.j.MenuItem_iconTintMode, -1), this.E);
            }
            else {
                this.E = null;
            }
            if (u.s(a.a.j.MenuItem_iconTint)) {
                this.D = u.c(a.a.j.MenuItem_iconTint);
            }
            else {
                this.D = null;
            }
            u.w();
            this.h = false;
        }
        
        public void h() {
            this.b = 0;
            this.c = 0;
            this.d = 0;
            this.e = 0;
            this.f = true;
            this.g = true;
        }
    }
}
