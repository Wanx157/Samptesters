package a.a.l.a;

import android.util.StateSet;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build$VERSION;
import a.o.a.a.h;
import androidx.appcompat.widget.l0;
import androidx.core.content.d.g;
import org.xmlpull.v1.XmlPullParserException;
import android.content.res.Resources$Theme;
import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParser;
import android.content.Context;
import android.content.res.Resources;
import android.annotation.SuppressLint;
import androidx.core.graphics.drawable.b;

@SuppressLint({ "RestrictedAPI" })
public class a extends d implements b
{
    private c p;
    private a.a$g q;
    private int r;
    private int s;
    private boolean t;
    
    public a() {
        this(null, null);
    }
    
    a(final c c, final Resources resources) {
        super((d$a)null);
        this.r = -1;
        this.s = -1;
        this.h((b$c)new c(c, this, resources));
        this.onStateChange(((Drawable)this).getState());
        this.jumpToCurrentState();
    }
    
    public static a m(final Context context, final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final String name = xmlPullParser.getName();
        if (name.equals((Object)"animated-selector")) {
            final a a = new a();
            a.n(context, resources, xmlPullParser, set, resources$Theme);
            return a;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(xmlPullParser.getPositionDescription());
        sb.append(": invalid animated-selector tag ");
        sb.append(name);
        throw new XmlPullParserException(sb.toString());
    }
    
    private void o(final Context context, final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final int n = xmlPullParser.getDepth() + 1;
        while (true) {
            final int next = xmlPullParser.next();
            if (next == 1) {
                break;
            }
            final int depth = xmlPullParser.getDepth();
            if (depth < n && next == 3) {
                break;
            }
            if (next != 2) {
                continue;
            }
            if (depth > n) {
                continue;
            }
            if (xmlPullParser.getName().equals((Object)"item")) {
                this.q(context, resources, xmlPullParser, set, resources$Theme);
            }
            else {
                if (!xmlPullParser.getName().equals((Object)"transition")) {
                    continue;
                }
                this.r(context, resources, xmlPullParser, set, resources$Theme);
            }
        }
    }
    
    private void p() {
        this.onStateChange(((Drawable)this).getState());
    }
    
    private int q(final Context context, final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final TypedArray k = g.k(resources, resources$Theme, set, a.a.m.b.AnimatedStateListDrawableItem);
        final int resourceId = k.getResourceId(a.a.m.b.AnimatedStateListDrawableItem_android_id, 0);
        final int resourceId2 = k.getResourceId(a.a.m.b.AnimatedStateListDrawableItem_android_drawable, -1);
        Drawable j;
        if (resourceId2 > 0) {
            j = l0.h().j(context, resourceId2);
        }
        else {
            j = null;
        }
        k.recycle();
        final int[] i = this.k(set);
        Drawable drawable = j;
        if (j == null) {
            int next;
            do {
                next = xmlPullParser.next();
            } while (next == 4);
            if (next != 2) {
                final StringBuilder sb = new StringBuilder();
                sb.append(xmlPullParser.getPositionDescription());
                sb.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
                throw new XmlPullParserException(sb.toString());
            }
            if (xmlPullParser.getName().equals((Object)"vector")) {
                drawable = h.c(resources, xmlPullParser, set, resources$Theme);
            }
            else if (Build$VERSION.SDK_INT >= 21) {
                drawable = Drawable.createFromXmlInner(resources, xmlPullParser, set, resources$Theme);
            }
            else {
                drawable = Drawable.createFromXmlInner(resources, xmlPullParser, set);
            }
        }
        if (drawable != null) {
            return this.p.B(i, drawable, resourceId);
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(xmlPullParser.getPositionDescription());
        sb2.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
        throw new XmlPullParserException(sb2.toString());
    }
    
    private int r(final Context context, final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final TypedArray k = g.k(resources, resources$Theme, set, a.a.m.b.AnimatedStateListDrawableTransition);
        final int resourceId = k.getResourceId(a.a.m.b.AnimatedStateListDrawableTransition_android_fromId, -1);
        final int resourceId2 = k.getResourceId(a.a.m.b.AnimatedStateListDrawableTransition_android_toId, -1);
        final int resourceId3 = k.getResourceId(a.a.m.b.AnimatedStateListDrawableTransition_android_drawable, -1);
        Drawable j;
        if (resourceId3 > 0) {
            j = l0.h().j(context, resourceId3);
        }
        else {
            j = null;
        }
        final boolean boolean1 = k.getBoolean(a.a.m.b.AnimatedStateListDrawableTransition_android_reversible, false);
        k.recycle();
        Drawable drawable = j;
        if (j == null) {
            int next;
            do {
                next = xmlPullParser.next();
            } while (next == 4);
            if (next != 2) {
                final StringBuilder sb = new StringBuilder();
                sb.append(xmlPullParser.getPositionDescription());
                sb.append(": <transition> tag requires a 'drawable' attribute or child tag defining a drawable");
                throw new XmlPullParserException(sb.toString());
            }
            if (xmlPullParser.getName().equals((Object)"animated-vector")) {
                drawable = a.o.a.a.b.a(context, resources, xmlPullParser, set, resources$Theme);
            }
            else if (Build$VERSION.SDK_INT >= 21) {
                drawable = Drawable.createFromXmlInner(resources, xmlPullParser, set, resources$Theme);
            }
            else {
                drawable = Drawable.createFromXmlInner(resources, xmlPullParser, set);
            }
        }
        if (drawable == null) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(xmlPullParser.getPositionDescription());
            sb2.append(": <transition> tag requires a 'drawable' attribute or child tag defining a drawable");
            throw new XmlPullParserException(sb2.toString());
        }
        if (resourceId != -1 && resourceId2 != -1) {
            return this.p.C(resourceId, resourceId2, drawable, boolean1);
        }
        final StringBuilder sb3 = new StringBuilder();
        sb3.append(xmlPullParser.getPositionDescription());
        sb3.append(": <transition> tag requires 'fromId' & 'toId' attributes");
        throw new XmlPullParserException(sb3.toString());
    }
    
    private boolean s(final int n) {
        final a.a$g q = this.q;
        int s;
        if (q != null) {
            if (n == this.r) {
                return true;
            }
            if (n == this.s && q.a()) {
                q.b();
                this.r = this.s;
                this.s = n;
                return true;
            }
            s = this.r;
            q.d();
        }
        else {
            s = ((a.a.l.a.b)this).c();
        }
        this.q = null;
        this.s = -1;
        this.r = -1;
        final c p = this.p;
        final int e = p.E(s);
        final int e2 = p.E(n);
        if (e2 != 0) {
            if (e != 0) {
                final int g = p.G(e, e2);
                if (g < 0) {
                    return false;
                }
                final boolean i = p.I(e, e2);
                ((a.a.l.a.b)this).g(g);
                final Drawable current = this.getCurrent();
                Object q2;
                if (current instanceof AnimationDrawable) {
                    q2 = new a.a$e((AnimationDrawable)current, p.H(e, e2), i);
                }
                else if (current instanceof a.o.a.a.b) {
                    q2 = new a.a$d((a.o.a.a.b)current);
                }
                else {
                    if (!(current instanceof Animatable)) {
                        return false;
                    }
                    q2 = new a.a$b((Animatable)current);
                }
                ((a.a$g)q2).c();
                this.q = (a.a$g)q2;
                this.s = s;
                this.r = n;
                return true;
            }
        }
        return false;
    }
    
    private void t(final TypedArray typedArray) {
        final c p = this.p;
        if (Build$VERSION.SDK_INT >= 21) {
            ((b$c)p).d |= typedArray.getChangingConfigurations();
        }
        ((b$c)p).x(typedArray.getBoolean(a.a.m.b.AnimatedStateListDrawableCompat_android_variablePadding, ((b$c)p).i));
        ((b$c)p).t(typedArray.getBoolean(a.a.m.b.AnimatedStateListDrawableCompat_android_constantSize, ((b$c)p).l));
        ((b$c)p).u(typedArray.getInt(a.a.m.b.AnimatedStateListDrawableCompat_android_enterFadeDuration, ((b$c)p).A));
        ((b$c)p).v(typedArray.getInt(a.a.m.b.AnimatedStateListDrawableCompat_android_exitFadeDuration, ((b$c)p).B));
        this.setDither(typedArray.getBoolean(a.a.m.b.AnimatedStateListDrawableCompat_android_dither, ((b$c)p).x));
    }
    
    void h(final b$c b$c) {
        super.h(b$c);
        if (b$c instanceof c) {
            this.p = (c)b$c;
        }
    }
    
    public boolean isStateful() {
        return true;
    }
    
    public void jumpToCurrentState() {
        super.jumpToCurrentState();
        final a.a$g q = this.q;
        if (q != null) {
            q.d();
            this.q = null;
            ((a.a.l.a.b)this).g(this.r);
            this.r = -1;
            this.s = -1;
        }
    }
    
    c l() {
        return new c(this.p, this, null);
    }
    
    public Drawable mutate() {
        if (!this.t) {
            super.mutate();
            this.p.r();
            this.t = true;
        }
        return (Drawable)this;
    }
    
    public void n(final Context context, final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
        final TypedArray k = g.k(resources, resources$Theme, set, a.a.m.b.AnimatedStateListDrawableCompat);
        this.setVisible(k.getBoolean(a.a.m.b.AnimatedStateListDrawableCompat_android_visible, true), true);
        this.t(k);
        ((a.a.l.a.b)this).i(resources);
        k.recycle();
        this.o(context, resources, xmlPullParser, set, resources$Theme);
        this.p();
    }
    
    protected boolean onStateChange(final int[] state) {
        final int f = this.p.F(state);
        final boolean b = f != ((a.a.l.a.b)this).c() && (this.s(f) || ((a.a.l.a.b)this).g(f));
        final Drawable current = this.getCurrent();
        boolean b2 = b;
        if (current != null) {
            b2 = (b | current.setState(state));
        }
        return b2;
    }
    
    public boolean setVisible(final boolean b, final boolean b2) {
        final boolean setVisible = super.setVisible(b, b2);
        if (this.q != null && (setVisible || b2)) {
            if (b) {
                this.q.c();
            }
            else {
                this.jumpToCurrentState();
            }
        }
        return setVisible;
    }
    
    static class c extends d$a
    {
        a.d.d<Long> K;
        a.d.h<Integer> L;
        
        c(final c c, final a a, final Resources resources) {
            super((d$a)c, (d)a, resources);
            a.d.h l;
            if (c != null) {
                this.K = c.K;
                l = c.L;
            }
            else {
                this.K = (a.d.d<Long>)new a.d.d();
                l = new a.d.h();
            }
            this.L = (a.d.h<Integer>)l;
        }
        
        private static long D(final int n, final int n2) {
            return (long)n2 | (long)n << 32;
        }
        
        int B(final int[] array, final Drawable drawable, final int n) {
            final int z = super.z(array, drawable);
            this.L.p(z, (Object)n);
            return z;
        }
        
        int C(final int n, final int n2, final Drawable drawable, final boolean b) {
            final int a = super.a(drawable);
            final long d = D(n, n2);
            long n3;
            if (b) {
                n3 = 8589934592L;
            }
            else {
                n3 = 0L;
            }
            final a.d.d<Long> k = this.K;
            final long n4 = a;
            k.a(d, (Object)(n4 | n3));
            if (b) {
                this.K.a(D(n2, n), (Object)(0x100000000L | n4 | n3));
            }
            return a;
        }
        
        int E(int intValue) {
            final int n = 0;
            if (intValue < 0) {
                intValue = n;
            }
            else {
                intValue = (int)this.L.g(intValue, (Object)0);
            }
            return intValue;
        }
        
        int F(final int[] array) {
            final int a = super.A(array);
            if (a >= 0) {
                return a;
            }
            return super.A(StateSet.WILD_CARD);
        }
        
        int G(final int n, final int n2) {
            return (int)(long)this.K.g(D(n, n2), (Object)(-1L));
        }
        
        boolean H(final int n, final int n2) {
            return ((long)this.K.g(D(n, n2), (Object)(-1L)) & 0x100000000L) != 0x0L;
        }
        
        boolean I(final int n, final int n2) {
            return ((long)this.K.g(D(n, n2), (Object)(-1L)) & 0x200000000L) != 0x0L;
        }
        
        public Drawable newDrawable() {
            return (Drawable)new a(this, null);
        }
        
        public Drawable newDrawable(final Resources resources) {
            return (Drawable)new a(this, resources);
        }
        
        void r() {
            this.K = (a.d.d<Long>)this.K.c();
            this.L = (a.d.h<Integer>)this.L.c();
        }
    }
}
