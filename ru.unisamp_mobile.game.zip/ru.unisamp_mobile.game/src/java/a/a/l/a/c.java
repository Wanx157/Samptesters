package a.a.l.a;

import android.graphics.PorterDuff$Mode;
import android.content.res.ColorStateList;
import android.graphics.ColorFilter;
import androidx.core.graphics.drawable.a;
import android.graphics.Region;
import android.graphics.Rect;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable$Callback;
import android.graphics.drawable.Drawable;

public class c extends Drawable implements Drawable$Callback
{
    private Drawable b;
    
    public c(final Drawable drawable) {
        this.b(drawable);
    }
    
    public Drawable a() {
        return this.b;
    }
    
    public void b(final Drawable b) {
        final Drawable b2 = this.b;
        if (b2 != null) {
            b2.setCallback((Drawable$Callback)null);
        }
        if ((this.b = b) != null) {
            b.setCallback((Drawable$Callback)this);
        }
    }
    
    public void draw(final Canvas canvas) {
        this.b.draw(canvas);
    }
    
    public int getChangingConfigurations() {
        return this.b.getChangingConfigurations();
    }
    
    public Drawable getCurrent() {
        return this.b.getCurrent();
    }
    
    public int getIntrinsicHeight() {
        return this.b.getIntrinsicHeight();
    }
    
    public int getIntrinsicWidth() {
        return this.b.getIntrinsicWidth();
    }
    
    public int getMinimumHeight() {
        return this.b.getMinimumHeight();
    }
    
    public int getMinimumWidth() {
        return this.b.getMinimumWidth();
    }
    
    public int getOpacity() {
        return this.b.getOpacity();
    }
    
    public boolean getPadding(final Rect rect) {
        return this.b.getPadding(rect);
    }
    
    public int[] getState() {
        return this.b.getState();
    }
    
    public Region getTransparentRegion() {
        return this.b.getTransparentRegion();
    }
    
    public void invalidateDrawable(final Drawable drawable) {
        this.invalidateSelf();
    }
    
    public boolean isAutoMirrored() {
        return a.h(this.b);
    }
    
    public boolean isStateful() {
        return this.b.isStateful();
    }
    
    public void jumpToCurrentState() {
        this.b.jumpToCurrentState();
    }
    
    protected void onBoundsChange(final Rect bounds) {
        this.b.setBounds(bounds);
    }
    
    protected boolean onLevelChange(final int level) {
        return this.b.setLevel(level);
    }
    
    public void scheduleDrawable(final Drawable drawable, final Runnable runnable, final long n) {
        this.scheduleSelf(runnable, n);
    }
    
    public void setAlpha(final int alpha) {
        this.b.setAlpha(alpha);
    }
    
    public void setAutoMirrored(final boolean b) {
        a.j(this.b, b);
    }
    
    public void setChangingConfigurations(final int changingConfigurations) {
        this.b.setChangingConfigurations(changingConfigurations);
    }
    
    public void setColorFilter(final ColorFilter colorFilter) {
        this.b.setColorFilter(colorFilter);
    }
    
    public void setDither(final boolean dither) {
        this.b.setDither(dither);
    }
    
    public void setFilterBitmap(final boolean filterBitmap) {
        this.b.setFilterBitmap(filterBitmap);
    }
    
    public void setHotspot(final float n, final float n2) {
        a.k(this.b, n, n2);
    }
    
    public void setHotspotBounds(final int n, final int n2, final int n3, final int n4) {
        a.l(this.b, n, n2, n3, n4);
    }
    
    public boolean setState(final int[] state) {
        return this.b.setState(state);
    }
    
    public void setTint(final int n) {
        a.n(this.b, n);
    }
    
    public void setTintList(final ColorStateList list) {
        a.o(this.b, list);
    }
    
    public void setTintMode(final PorterDuff$Mode porterDuff$Mode) {
        a.p(this.b, porterDuff$Mode);
    }
    
    public boolean setVisible(final boolean b, final boolean b2) {
        return super.setVisible(b, b2) || this.b.setVisible(b, b2);
    }
    
    public void unscheduleDrawable(final Drawable drawable, final Runnable runnable) {
        this.unscheduleSelf(runnable);
    }
}
