package a.a.l.a;

import android.graphics.drawable.Drawable;
import android.util.StateSet;
import android.util.AttributeSet;
import android.content.res.Resources$Theme;
import android.content.res.Resources;
import android.annotation.SuppressLint;

@SuppressLint({ "RestrictedAPI" })
class d extends b
{
    private a n;
    private boolean o;
    
    d(final a a) {
        if (a != null) {
            this.h(a);
        }
    }
    
    d(final a a, final Resources resources) {
        this.h(new a(a, this, resources));
        this.onStateChange(((Drawable)this).getState());
    }
    
    public void applyTheme(final Resources$Theme resources$Theme) {
        super.applyTheme(resources$Theme);
        this.onStateChange(((Drawable)this).getState());
    }
    
    void h(final b$c b$c) {
        super.h(b$c);
        if (b$c instanceof a) {
            this.n = (a)b$c;
        }
    }
    
    public boolean isStateful() {
        return true;
    }
    
    a j() {
        return new a(this.n, this, null);
    }
    
    int[] k(final AttributeSet set) {
        final int attributeCount = set.getAttributeCount();
        final int[] array = new int[attributeCount];
        int i = 0;
        int n = 0;
        while (i < attributeCount) {
            final int attributeNameResource = set.getAttributeNameResource(i);
            int n2 = n;
            if (attributeNameResource != 0) {
                n2 = n;
                if (attributeNameResource != 16842960) {
                    n2 = n;
                    if (attributeNameResource != 16843161) {
                        int n3;
                        if (set.getAttributeBooleanValue(i, false)) {
                            n3 = attributeNameResource;
                        }
                        else {
                            n3 = -attributeNameResource;
                        }
                        array[n] = n3;
                        n2 = n + 1;
                    }
                }
            }
            ++i;
            n = n2;
        }
        return StateSet.trimStateSet(array, n);
    }
    
    public Drawable mutate() {
        if (!this.o) {
            super.mutate();
            this.n.r();
            this.o = true;
        }
        return (Drawable)this;
    }
    
    protected boolean onStateChange(final int[] array) {
        final boolean onStateChange = super.onStateChange(array);
        int n;
        if ((n = this.n.A(array)) < 0) {
            n = this.n.A(StateSet.WILD_CARD);
        }
        return this.g(n) || onStateChange;
    }
    
    static class a extends b$c
    {
        int[][] J;
        
        a(final a a, final d d, final Resources resources) {
            super((b$c)a, (b)d, resources);
            if (a != null) {
                this.J = a.J;
            }
            else {
                this.J = new int[this.f()][];
            }
        }
        
        int A(final int[] array) {
            final int[][] j = this.J;
            for (int h = this.h(), i = 0; i < h; ++i) {
                if (StateSet.stateSetMatches(j[i], array)) {
                    return i;
                }
            }
            return -1;
        }
        
        public Drawable newDrawable() {
            return (Drawable)new d(this, null);
        }
        
        public Drawable newDrawable(final Resources resources) {
            return (Drawable)new d(this, resources);
        }
        
        public void o(final int n, final int n2) {
            super.o(n, n2);
            final int[][] j = new int[n2][];
            System.arraycopy((Object)this.J, 0, (Object)j, 0, n);
            this.J = j;
        }
        
        void r() {
            final int[][] j = this.J;
            final int[][] i = new int[j.length][];
            for (int k = j.length - 1; k >= 0; --k) {
                final int[][] l = this.J;
                int[] array;
                if (l[k] != null) {
                    array = l[k].clone();
                }
                else {
                    array = null;
                }
                i[k] = array;
            }
            this.J = i;
        }
        
        int z(final int[] array, final Drawable drawable) {
            final int a = this.a(drawable);
            this.J[a] = array;
            return a;
        }
    }
}
