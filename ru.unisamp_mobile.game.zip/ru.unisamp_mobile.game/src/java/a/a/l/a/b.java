package a.a.l.a;

import android.util.SparseArray;
import android.graphics.PorterDuff$Mode;
import android.content.res.ColorStateList;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable$ConstantState;
import android.graphics.Canvas;
import android.content.res.Resources$Theme;
import android.os.SystemClock;
import android.content.res.Resources;
import android.os.Build$VERSION;
import androidx.core.graphics.drawable.a;
import android.graphics.Rect;
import android.graphics.drawable.Drawable$Callback;
import android.graphics.drawable.Drawable;

class b extends Drawable implements Drawable$Callback
{
    private c b;
    private Rect c;
    private Drawable d;
    private Drawable e;
    private int f;
    private boolean g;
    private int h;
    private boolean i;
    private Runnable j;
    private long k;
    private long l;
    private b m;
    
    b() {
        this.f = 255;
        this.h = -1;
    }
    
    private void d(final Drawable drawable) {
        if (this.m == null) {
            this.m = new b();
        }
        final b m = this.m;
        m.b(drawable.getCallback());
        drawable.setCallback((Drawable$Callback)m);
        try {
            if (this.b.A <= 0 && this.g) {
                drawable.setAlpha(this.f);
            }
            if (this.b.E) {
                drawable.setColorFilter(this.b.D);
            }
            else {
                if (this.b.H) {
                    a.o(drawable, this.b.F);
                }
                if (this.b.I) {
                    a.p(drawable, this.b.G);
                }
            }
            drawable.setVisible(this.isVisible(), true);
            drawable.setDither(this.b.x);
            drawable.setState(this.getState());
            drawable.setLevel(this.getLevel());
            drawable.setBounds(this.getBounds());
            if (Build$VERSION.SDK_INT >= 23) {
                drawable.setLayoutDirection(this.getLayoutDirection());
            }
            if (Build$VERSION.SDK_INT >= 19) {
                drawable.setAutoMirrored(this.b.C);
            }
            final Rect c = this.c;
            if (Build$VERSION.SDK_INT >= 21 && c != null) {
                drawable.setHotspotBounds(c.left, c.top, c.right, c.bottom);
            }
        }
        finally {
            drawable.setCallback(this.m.a());
        }
    }
    
    private boolean e() {
        final boolean autoMirrored = this.isAutoMirrored();
        boolean b = true;
        if (!autoMirrored || a.f((Drawable)this) != 1) {
            b = false;
        }
        return b;
    }
    
    static int f(final Resources resources, int densityDpi) {
        if (resources != null) {
            densityDpi = resources.getDisplayMetrics().densityDpi;
        }
        int n = densityDpi;
        if (densityDpi == 0) {
            n = 160;
        }
        return n;
    }
    
    void a(final boolean b) {
        final int n = 1;
        this.g = true;
        final long uptimeMillis = SystemClock.uptimeMillis();
        final Drawable d = this.d;
        int n2 = 0;
        Label_0104: {
            Label_0102: {
                if (d != null) {
                    final long k = this.k;
                    if (k == 0L) {
                        break Label_0102;
                    }
                    if (k > uptimeMillis) {
                        d.setAlpha((255 - (int)((k - uptimeMillis) * 255L) / this.b.A) * this.f / 255);
                        n2 = 1;
                        break Label_0104;
                    }
                    d.setAlpha(this.f);
                }
                this.k = 0L;
            }
            n2 = 0;
        }
        final Drawable e = this.e;
        Label_0194: {
            if (e != null) {
                final long l = this.l;
                if (l == 0L) {
                    break Label_0194;
                }
                if (l > uptimeMillis) {
                    e.setAlpha((int)((l - uptimeMillis) * 255L) / this.b.B * this.f / 255);
                    n2 = n;
                    break Label_0194;
                }
                e.setVisible(false, false);
                this.e = null;
            }
            this.l = 0L;
        }
        if (b && n2 != 0) {
            this.scheduleSelf(this.j, uptimeMillis + 16L);
        }
    }
    
    public void applyTheme(final Resources$Theme resources$Theme) {
        this.b.b(resources$Theme);
    }
    
    c b() {
        throw null;
    }
    
    int c() {
        return this.h;
    }
    
    public boolean canApplyTheme() {
        return this.b.canApplyTheme();
    }
    
    public void draw(final Canvas canvas) {
        final Drawable d = this.d;
        if (d != null) {
            d.draw(canvas);
        }
        final Drawable e = this.e;
        if (e != null) {
            e.draw(canvas);
        }
    }
    
    boolean g(int a) {
        if (a == this.h) {
            return false;
        }
        final long uptimeMillis = SystemClock.uptimeMillis();
        if (this.b.B > 0) {
            final Drawable e = this.e;
            if (e != null) {
                e.setVisible(false, false);
            }
            final Drawable d = this.d;
            if (d != null) {
                this.e = d;
                this.l = this.b.B + uptimeMillis;
            }
            else {
                this.e = null;
                this.l = 0L;
            }
        }
        else {
            final Drawable d2 = this.d;
            if (d2 != null) {
                d2.setVisible(false, false);
            }
        }
        Label_0191: {
            if (a >= 0) {
                final c b = this.b;
                if (a < b.h) {
                    final Drawable g = b.g(a);
                    this.d = g;
                    this.h = a;
                    if (g != null) {
                        a = this.b.A;
                        if (a > 0) {
                            this.k = uptimeMillis + a;
                        }
                        this.d(g);
                    }
                    break Label_0191;
                }
            }
            this.d = null;
            this.h = -1;
        }
        if (this.k != 0L || this.l != 0L) {
            final Runnable j = this.j;
            if (j == null) {
                this.j = (Runnable)new Runnable(this) {
                    final b b;
                    
                    public void run() {
                        this.b.a(true);
                        this.b.invalidateSelf();
                    }
                };
            }
            else {
                this.unscheduleSelf(j);
            }
            this.a(true);
        }
        this.invalidateSelf();
        return true;
    }
    
    public int getAlpha() {
        return this.f;
    }
    
    public int getChangingConfigurations() {
        return super.getChangingConfigurations() | this.b.getChangingConfigurations();
    }
    
    public final Drawable$ConstantState getConstantState() {
        if (this.b.c()) {
            this.b.d = this.getChangingConfigurations();
            return this.b;
        }
        return null;
    }
    
    public Drawable getCurrent() {
        return this.d;
    }
    
    public void getHotspotBounds(final Rect rect) {
        final Rect c = this.c;
        if (c != null) {
            rect.set(c);
        }
        else {
            super.getHotspotBounds(rect);
        }
    }
    
    public int getIntrinsicHeight() {
        if (this.b.q()) {
            return this.b.i();
        }
        final Drawable d = this.d;
        int intrinsicHeight;
        if (d != null) {
            intrinsicHeight = d.getIntrinsicHeight();
        }
        else {
            intrinsicHeight = -1;
        }
        return intrinsicHeight;
    }
    
    public int getIntrinsicWidth() {
        if (this.b.q()) {
            return this.b.m();
        }
        final Drawable d = this.d;
        int intrinsicWidth;
        if (d != null) {
            intrinsicWidth = d.getIntrinsicWidth();
        }
        else {
            intrinsicWidth = -1;
        }
        return intrinsicWidth;
    }
    
    public int getMinimumHeight() {
        if (this.b.q()) {
            return this.b.j();
        }
        final Drawable d = this.d;
        int minimumHeight;
        if (d != null) {
            minimumHeight = d.getMinimumHeight();
        }
        else {
            minimumHeight = 0;
        }
        return minimumHeight;
    }
    
    public int getMinimumWidth() {
        if (this.b.q()) {
            return this.b.k();
        }
        final Drawable d = this.d;
        int minimumWidth;
        if (d != null) {
            minimumWidth = d.getMinimumWidth();
        }
        else {
            minimumWidth = 0;
        }
        return minimumWidth;
    }
    
    public int getOpacity() {
        final Drawable d = this.d;
        int n;
        if (d != null && d.isVisible()) {
            n = this.b.n();
        }
        else {
            n = -2;
        }
        return n;
    }
    
    public void getOutline(final Outline outline) {
        final Drawable d = this.d;
        if (d != null) {
            d.getOutline(outline);
        }
    }
    
    public boolean getPadding(final Rect rect) {
        final Rect l = this.b.l();
        boolean b;
        if (l != null) {
            rect.set(l);
            b = ((l.right | (l.left | l.top | l.bottom)) != 0x0);
        }
        else {
            final Drawable d = this.d;
            if (d != null) {
                b = d.getPadding(rect);
            }
            else {
                b = super.getPadding(rect);
            }
        }
        if (this.e()) {
            final int left = rect.left;
            rect.left = rect.right;
            rect.right = left;
        }
        return b;
    }
    
    void h(final c b) {
        this.b = b;
        final int h = this.h;
        if (h >= 0) {
            final Drawable g = b.g(h);
            if ((this.d = g) != null) {
                this.d(g);
            }
        }
        this.e = null;
    }
    
    final void i(final Resources resources) {
        this.b.y(resources);
    }
    
    public void invalidateDrawable(final Drawable drawable) {
        final c b = this.b;
        if (b != null) {
            b.p();
        }
        if (drawable == this.d && this.getCallback() != null) {
            this.getCallback().invalidateDrawable((Drawable)this);
        }
    }
    
    public boolean isAutoMirrored() {
        return this.b.C;
    }
    
    public void jumpToCurrentState() {
        final Drawable e = this.e;
        final int n = 1;
        int n2;
        if (e != null) {
            e.jumpToCurrentState();
            this.e = null;
            n2 = 1;
        }
        else {
            n2 = 0;
        }
        final Drawable d = this.d;
        if (d != null) {
            d.jumpToCurrentState();
            if (this.g) {
                this.d.setAlpha(this.f);
            }
        }
        if (this.l != 0L) {
            this.l = 0L;
            n2 = 1;
        }
        if (this.k != 0L) {
            this.k = 0L;
            n2 = n;
        }
        if (n2 != 0) {
            this.invalidateSelf();
        }
    }
    
    public Drawable mutate() {
        if (!this.i && super.mutate() == this) {
            final c b = this.b();
            b.r();
            this.h(b);
            this.i = true;
        }
        return this;
    }
    
    protected void onBoundsChange(final Rect rect) {
        final Drawable e = this.e;
        if (e != null) {
            e.setBounds(rect);
        }
        final Drawable d = this.d;
        if (d != null) {
            d.setBounds(rect);
        }
    }
    
    public boolean onLayoutDirectionChanged(final int n) {
        return this.b.w(n, this.c());
    }
    
    protected boolean onLevelChange(final int n) {
        final Drawable e = this.e;
        if (e != null) {
            return e.setLevel(n);
        }
        final Drawable d = this.d;
        return d != null && d.setLevel(n);
    }
    
    protected boolean onStateChange(final int[] array) {
        final Drawable e = this.e;
        if (e != null) {
            return e.setState(array);
        }
        final Drawable d = this.d;
        return d != null && d.setState(array);
    }
    
    public void scheduleDrawable(final Drawable drawable, final Runnable runnable, final long n) {
        if (drawable == this.d && this.getCallback() != null) {
            this.getCallback().scheduleDrawable((Drawable)this, runnable, n);
        }
    }
    
    public void setAlpha(final int n) {
        if (!this.g || this.f != n) {
            this.g = true;
            this.f = n;
            final Drawable d = this.d;
            if (d != null) {
                if (this.k == 0L) {
                    d.setAlpha(n);
                }
                else {
                    this.a(false);
                }
            }
        }
    }
    
    public void setAutoMirrored(final boolean c) {
        final c b = this.b;
        if (b.C != c) {
            b.C = c;
            final Drawable d = this.d;
            if (d != null) {
                a.j(d, c);
            }
        }
    }
    
    public void setColorFilter(final ColorFilter colorFilter) {
        final c b = this.b;
        b.E = true;
        if (b.D != colorFilter) {
            b.D = colorFilter;
            final Drawable d = this.d;
            if (d != null) {
                d.setColorFilter(colorFilter);
            }
        }
    }
    
    public void setDither(final boolean b) {
        final c b2 = this.b;
        if (b2.x != b) {
            b2.x = b;
            final Drawable d = this.d;
            if (d != null) {
                d.setDither(b);
            }
        }
    }
    
    public void setHotspot(final float n, final float n2) {
        final Drawable d = this.d;
        if (d != null) {
            a.k(d, n, n2);
        }
    }
    
    public void setHotspotBounds(final int n, final int n2, final int n3, final int n4) {
        final Rect c = this.c;
        if (c == null) {
            this.c = new Rect(n, n2, n3, n4);
        }
        else {
            c.set(n, n2, n3, n4);
        }
        final Drawable d = this.d;
        if (d != null) {
            a.l(d, n, n2, n3, n4);
        }
    }
    
    public void setTintList(final ColorStateList f) {
        final c b = this.b;
        b.H = true;
        if (b.F != f) {
            b.F = f;
            a.o(this.d, f);
        }
    }
    
    public void setTintMode(final PorterDuff$Mode g) {
        final c b = this.b;
        b.I = true;
        if (b.G != g) {
            b.G = g;
            a.p(this.d, g);
        }
    }
    
    public boolean setVisible(final boolean b, final boolean b2) {
        final boolean setVisible = super.setVisible(b, b2);
        final Drawable e = this.e;
        if (e != null) {
            e.setVisible(b, b2);
        }
        final Drawable d = this.d;
        if (d != null) {
            d.setVisible(b, b2);
        }
        return setVisible;
    }
    
    public void unscheduleDrawable(final Drawable drawable, final Runnable runnable) {
        if (drawable == this.d && this.getCallback() != null) {
            this.getCallback().unscheduleDrawable((Drawable)this, runnable);
        }
    }
    
    static class b implements Drawable$Callback
    {
        private Drawable$Callback b;
        
        public Drawable$Callback a() {
            final Drawable$Callback b = this.b;
            this.b = null;
            return b;
        }
        
        public b b(final Drawable$Callback b) {
            this.b = b;
            return this;
        }
        
        public void invalidateDrawable(final Drawable drawable) {
        }
        
        public void scheduleDrawable(final Drawable drawable, final Runnable runnable, final long n) {
            final Drawable$Callback b = this.b;
            if (b != null) {
                b.scheduleDrawable(drawable, runnable, n);
            }
        }
        
        public void unscheduleDrawable(final Drawable drawable, final Runnable runnable) {
            final Drawable$Callback b = this.b;
            if (b != null) {
                b.unscheduleDrawable(drawable, runnable);
            }
        }
    }
    
    abstract static class c extends Drawable$ConstantState
    {
        int A;
        int B;
        boolean C;
        ColorFilter D;
        boolean E;
        ColorStateList F;
        PorterDuff$Mode G;
        boolean H;
        boolean I;
        final b a;
        Resources b;
        int c;
        int d;
        int e;
        SparseArray<Drawable$ConstantState> f;
        Drawable[] g;
        int h;
        boolean i;
        boolean j;
        Rect k;
        boolean l;
        boolean m;
        int n;
        int o;
        int p;
        int q;
        boolean r;
        int s;
        boolean t;
        boolean u;
        boolean v;
        boolean w;
        boolean x;
        boolean y;
        int z;
        
        c(final c c, final b a, final Resources resources) {
            this.c = 160;
            final int n = 0;
            this.i = false;
            this.l = false;
            this.x = true;
            this.A = 0;
            this.B = 0;
            this.a = a;
            Resources b;
            if (resources != null) {
                b = resources;
            }
            else if (c != null) {
                b = c.b;
            }
            else {
                b = null;
            }
            this.b = b;
            int c2;
            if (c != null) {
                c2 = c.c;
            }
            else {
                c2 = 0;
            }
            final int f = a.a.l.a.b.f(resources, c2);
            this.c = f;
            if (c != null) {
                this.d = c.d;
                this.e = c.e;
                this.v = true;
                this.w = true;
                this.i = c.i;
                this.l = c.l;
                this.x = c.x;
                this.y = c.y;
                this.z = c.z;
                this.A = c.A;
                this.B = c.B;
                this.C = c.C;
                this.D = c.D;
                this.E = c.E;
                this.F = c.F;
                this.G = c.G;
                this.H = c.H;
                this.I = c.I;
                if (c.c == f) {
                    if (c.j) {
                        this.k = new Rect(c.k);
                        this.j = true;
                    }
                    if (c.m) {
                        this.n = c.n;
                        this.o = c.o;
                        this.p = c.p;
                        this.q = c.q;
                        this.m = true;
                    }
                }
                if (c.r) {
                    this.s = c.s;
                    this.r = true;
                }
                if (c.t) {
                    this.u = c.u;
                    this.t = true;
                }
                final Drawable[] g = c.g;
                this.g = new Drawable[g.length];
                this.h = c.h;
                final SparseArray<Drawable$ConstantState> f2 = c.f;
                SparseArray clone;
                if (f2 != null) {
                    clone = f2.clone();
                }
                else {
                    clone = new SparseArray(this.h);
                }
                this.f = (SparseArray<Drawable$ConstantState>)clone;
                for (int h = this.h, i = n; i < h; ++i) {
                    if (g[i] != null) {
                        final Drawable$ConstantState constantState = g[i].getConstantState();
                        if (constantState != null) {
                            this.f.put(i, (Object)constantState);
                        }
                        else {
                            this.g[i] = g[i];
                        }
                    }
                }
            }
            else {
                this.g = new Drawable[10];
                this.h = 0;
            }
        }
        
        private void e() {
            final SparseArray<Drawable$ConstantState> f = this.f;
            if (f != null) {
                for (int size = f.size(), i = 0; i < size; ++i) {
                    this.g[this.f.keyAt(i)] = this.s(((Drawable$ConstantState)this.f.valueAt(i)).newDrawable(this.b));
                }
                this.f = null;
            }
        }
        
        private Drawable s(Drawable mutate) {
            if (Build$VERSION.SDK_INT >= 23) {
                mutate.setLayoutDirection(this.z);
            }
            mutate = mutate.mutate();
            mutate.setCallback((Drawable$Callback)this.a);
            return mutate;
        }
        
        public final int a(final Drawable drawable) {
            final int h = this.h;
            if (h >= this.g.length) {
                this.o(h, h + 10);
            }
            drawable.mutate();
            drawable.setVisible(false, true);
            drawable.setCallback((Drawable$Callback)this.a);
            this.g[h] = drawable;
            ++this.h;
            this.e |= drawable.getChangingConfigurations();
            this.p();
            this.k = null;
            this.j = false;
            this.m = false;
            this.v = false;
            return h;
        }
        
        final void b(final Resources$Theme resources$Theme) {
            if (resources$Theme != null) {
                this.e();
                final int h = this.h;
                final Drawable[] g = this.g;
                for (int i = 0; i < h; ++i) {
                    if (g[i] != null && g[i].canApplyTheme()) {
                        g[i].applyTheme(resources$Theme);
                        this.e |= g[i].getChangingConfigurations();
                    }
                }
                this.y(resources$Theme.getResources());
            }
        }
        
        public boolean c() {
            monitorenter(this);
            try {
                if (this.v) {
                    final boolean w = this.w;
                    monitorexit(this);
                    return w;
                }
                this.e();
                this.v = true;
                final int h = this.h;
                final Drawable[] g = this.g;
                for (int i = 0; i < h; ++i) {
                    if (g[i].getConstantState() == null) {
                        this.w = false;
                        monitorexit(this);
                        return false;
                    }
                }
                this.w = true;
                monitorexit(this);
                return true;
            }
            finally {
                monitorexit(this);
                while (true) {}
            }
        }
        
        public boolean canApplyTheme() {
            final int h = this.h;
            final Drawable[] g = this.g;
            for (int i = 0; i < h; ++i) {
                final Drawable drawable = g[i];
                if (drawable != null) {
                    if (drawable.canApplyTheme()) {
                        return true;
                    }
                }
                else {
                    final Drawable$ConstantState drawable$ConstantState = (Drawable$ConstantState)this.f.get(i);
                    if (drawable$ConstantState != null && drawable$ConstantState.canApplyTheme()) {
                        return true;
                    }
                }
            }
            return false;
        }
        
        protected void d() {
            this.m = true;
            this.e();
            final int h = this.h;
            final Drawable[] g = this.g;
            this.o = -1;
            this.n = -1;
            int i = 0;
            this.q = 0;
            this.p = 0;
            while (i < h) {
                final Drawable drawable = g[i];
                final int intrinsicWidth = drawable.getIntrinsicWidth();
                if (intrinsicWidth > this.n) {
                    this.n = intrinsicWidth;
                }
                final int intrinsicHeight = drawable.getIntrinsicHeight();
                if (intrinsicHeight > this.o) {
                    this.o = intrinsicHeight;
                }
                final int minimumWidth = drawable.getMinimumWidth();
                if (minimumWidth > this.p) {
                    this.p = minimumWidth;
                }
                final int minimumHeight = drawable.getMinimumHeight();
                if (minimumHeight > this.q) {
                    this.q = minimumHeight;
                }
                ++i;
            }
        }
        
        final int f() {
            return this.g.length;
        }
        
        public final Drawable g(final int n) {
            final Drawable drawable = this.g[n];
            if (drawable != null) {
                return drawable;
            }
            final SparseArray<Drawable$ConstantState> f = this.f;
            if (f != null) {
                final int indexOfKey = f.indexOfKey(n);
                if (indexOfKey >= 0) {
                    final Drawable s = this.s(((Drawable$ConstantState)this.f.valueAt(indexOfKey)).newDrawable(this.b));
                    this.g[n] = s;
                    this.f.removeAt(indexOfKey);
                    if (this.f.size() == 0) {
                        this.f = null;
                    }
                    return s;
                }
            }
            return null;
        }
        
        public int getChangingConfigurations() {
            return this.d | this.e;
        }
        
        public final int h() {
            return this.h;
        }
        
        public final int i() {
            if (!this.m) {
                this.d();
            }
            return this.o;
        }
        
        public final int j() {
            if (!this.m) {
                this.d();
            }
            return this.q;
        }
        
        public final int k() {
            if (!this.m) {
                this.d();
            }
            return this.p;
        }
        
        public final Rect l() {
            final boolean i = this.i;
            Rect k = null;
            if (i) {
                return null;
            }
            if (this.k == null && !this.j) {
                this.e();
                final Rect rect = new Rect();
                final int h = this.h;
                final Drawable[] g = this.g;
                Rect rect2;
                for (int j = 0; j < h; ++j, k = rect2) {
                    rect2 = k;
                    if (g[j].getPadding(rect)) {
                        Rect rect3;
                        if ((rect3 = k) == null) {
                            rect3 = new Rect(0, 0, 0, 0);
                        }
                        final int left = rect.left;
                        if (left > rect3.left) {
                            rect3.left = left;
                        }
                        final int top = rect.top;
                        if (top > rect3.top) {
                            rect3.top = top;
                        }
                        final int right = rect.right;
                        if (right > rect3.right) {
                            rect3.right = right;
                        }
                        final int bottom = rect.bottom;
                        rect2 = rect3;
                        if (bottom > rect3.bottom) {
                            rect3.bottom = bottom;
                            rect2 = rect3;
                        }
                    }
                }
                this.j = true;
                return this.k = k;
            }
            return this.k;
        }
        
        public final int m() {
            if (!this.m) {
                this.d();
            }
            return this.n;
        }
        
        public final int n() {
            if (this.r) {
                return this.s;
            }
            this.e();
            final int h = this.h;
            final Drawable[] g = this.g;
            int s;
            if (h > 0) {
                s = g[0].getOpacity();
            }
            else {
                s = -2;
            }
            for (int i = 1; i < h; ++i) {
                s = Drawable.resolveOpacity(s, g[i].getOpacity());
            }
            this.s = s;
            this.r = true;
            return s;
        }
        
        public void o(final int n, final int n2) {
            final Drawable[] g = new Drawable[n2];
            System.arraycopy((Object)this.g, 0, (Object)g, 0, n);
            this.g = g;
        }
        
        void p() {
            this.r = false;
            this.t = false;
        }
        
        public final boolean q() {
            return this.l;
        }
        
        abstract void r();
        
        public final void t(final boolean l) {
            this.l = l;
        }
        
        public final void u(final int a) {
            this.A = a;
        }
        
        public final void v(final int b) {
            this.B = b;
        }
        
        final boolean w(final int n, final int n2) {
            final int h = this.h;
            final Drawable[] g = this.g;
            int i = 0;
            boolean b = false;
            while (i < h) {
                boolean b2 = b;
                if (g[i] != null) {
                    final boolean b3 = Build$VERSION.SDK_INT >= 23 && g[i].setLayoutDirection(n);
                    b2 = b;
                    if (i == n2) {
                        b2 = b3;
                    }
                }
                ++i;
                b = b2;
            }
            this.z = n;
            return b;
        }
        
        public final void x(final boolean i) {
            this.i = i;
        }
        
        final void y(final Resources b) {
            if (b != null) {
                this.b = b;
                if (this.c != (this.c = b.f(b, this.c))) {
                    this.m = false;
                    this.j = false;
                }
            }
        }
    }
}
