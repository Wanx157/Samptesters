package a.a;

public final class h
{
    public static final int abc_action_bar_home_description = 2131689472;
    public static final int abc_action_bar_up_description = 2131689473;
    public static final int abc_action_menu_overflow_description = 2131689474;
    public static final int abc_action_mode_done = 2131689475;
    public static final int abc_activity_chooser_view_see_all = 2131689476;
    public static final int abc_activitychooserview_choose_application = 2131689477;
    public static final int abc_capital_off = 2131689478;
    public static final int abc_capital_on = 2131689479;
    public static final int abc_menu_alt_shortcut_label = 2131689480;
    public static final int abc_menu_ctrl_shortcut_label = 2131689481;
    public static final int abc_menu_delete_shortcut_label = 2131689482;
    public static final int abc_menu_enter_shortcut_label = 2131689483;
    public static final int abc_menu_function_shortcut_label = 2131689484;
    public static final int abc_menu_meta_shortcut_label = 2131689485;
    public static final int abc_menu_shift_shortcut_label = 2131689486;
    public static final int abc_menu_space_shortcut_label = 2131689487;
    public static final int abc_menu_sym_shortcut_label = 2131689488;
    public static final int abc_prepend_shortcut_label = 2131689489;
    public static final int abc_search_hint = 2131689490;
    public static final int abc_searchview_description_clear = 2131689491;
    public static final int abc_searchview_description_query = 2131689492;
    public static final int abc_searchview_description_search = 2131689493;
    public static final int abc_searchview_description_submit = 2131689494;
    public static final int abc_searchview_description_voice = 2131689495;
    public static final int abc_shareactionprovider_share_with = 2131689496;
    public static final int abc_shareactionprovider_share_with_application = 2131689497;
    public static final int abc_toolbar_collapse_description = 2131689498;
    public static final int search_menu_title = 2131689645;
    public static final int status_bar_notification_info_overflow = 2131689656;
}
