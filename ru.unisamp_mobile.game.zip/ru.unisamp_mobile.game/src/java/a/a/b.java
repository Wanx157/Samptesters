package a.a;

public final class b
{
    public static final int abc_action_bar_embed_tabs = 2130968576;
    public static final int abc_allow_stacked_button_bar = 2130968577;
    public static final int abc_config_actionMenuItemAllCaps = 2130968578;
}
